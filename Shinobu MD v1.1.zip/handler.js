// handler.js — Shorax MD V1
const fs = require("fs");
const util = require("util");
const chalk = require("chalk");

module.exports = async (sock, m) => {
  try {
    let plugins = global.plugins;
    await global.loadDatabase(sock, m);

    const prefix = m.prefix;
    const isCmd = m?.body?.startsWith(prefix);
    const args = isCmd ? m.body.trim().split(/ +/).slice(1) : [];
    const text = args.join(" ");
    const q = text;
    const command = isCmd
      ? m.body.slice(prefix.length).trim().split(" ").shift().toLowerCase()
      : "";
    const cmd = prefix + command;
    const quoted = m.quoted ? m.quoted : m;
    const mime = quoted?.msg?.mimetype || quoted?.mimetype || null;
    const qmsg = m.quoted || m;
    const botNumber = m.botNumber;
    const isOwner = m.isOwner;

    m.cmd = cmd;
    m.mime = mime;
    m.qmsg = qmsg;
    m.args = args;
    m.text = text;
    m.isGroup = m.chat.endsWith("g.us");
    m.metadata = {};
    m.isAdmin = false;
    m.isBotAdmin = false;
    m.example = (teks, cmds = cmd) => m.reply(`*Contoh:*\n${cmds} ${teks}`);

    // ── React helper ─────────────────────
    m.react = async (emoji) => {
      await sock.sendMessage(m.chat, {
        react: { text: emoji, key: m.key },
      }).catch(() => {});
    };

    // ── Cek premium / banned ─────────────
    const settings = global.db?.settings || {};
    const senderClean = (m.sender || "").split("@")[0];
    m.isPremium =
      isOwner ||
      (settings.premium || []).some((p) => {
        const c = typeof p === "string" ? p : p.id;
        return (c || "").split("@")[0] === senderClean;
      }) ||
      (settings.partner || []).some((p) => {
        const c = typeof p === "string" ? p : p.id;
        return (c || "").split("@")[0] === senderClean;
      });

    m.isBanned = (settings.banned || []).some(
      (b) => (b || "").split("@")[0] === senderClean
    );

    if (m.isBanned) {
      await m.react("🚫");
      return m.reply("🚫 Kamu dibanned dari bot ini.");
    }

    // ── Mode bot ─────────────────────────
    if (!sock.public && !isOwner) return;

    // ── Registrasi check ─────────────────
    if (global.registrasiEnabled && !isOwner) {
      const user = global.db?.users?.[m.sender];
      if (isCmd && command !== "daftar" && !user?.registered) {
        await m.react("❌");
        return m.reply(
          `📋 Kamu belum terdaftar!\nKetik *${prefix}daftar* untuk mendaftar.`
        );
      }
    }

    // ── Group metadata ───────────────────
    if (m.isGroup) {
      let meta = global.groupMetadataCache.get(m.chat);
      if (!meta) meta = await sock.groupMetadata(m.chat).catch(() => {});
      m.metadata = meta;
      const p = meta?.participants || [];
      m.isAdmin = p.some(
        (i) => (i.id === m.sender || i.jid === m.sender) && i.admin !== null
      );
      m.isBotAdmin = p.some(
        (i) => (i.id === botNumber || i.jid === botNumber) && i.admin !== null
      );
    }

    // ── Before hooks ─────────────────────
    for (let name in plugins) {
      let plugin = plugins[name];
      if (typeof plugin?.before !== "function") continue;
      let stop = await plugin.before(m, {
        sock, isOwner,
        isAdmin: m.isAdmin,
        isBotAdmin: m.isBotAdmin,
        metadata: m.metadata,
      });
      if (stop) return;
    }

    // ── All hooks ────────────────────────
    for (let name in plugins) {
      let plugin = plugins[name];
      if (typeof plugin?.all !== "function") continue;
      await plugin.all(m, {
        sock, isOwner,
        isAdmin: m.isAdmin,
        isBotAdmin: m.isBotAdmin,
        metadata: m.metadata,
      });
    }

    if (!isCmd) return;

    console.log(
      chalk.black.bgMagenta("\n 〄 Shorax MD \n"),
      chalk.magenta(`From : ${m?.pushName || m.sender}\n`),
      chalk.magenta(`CMD  : ${cmd}`)
    );

    // ── Auto typing ──────────────────────
    if (global.autoTyping) {
      await sock.sendPresenceUpdate("composing", m.chat).catch(() => {});
    }

    // ── Plugin executor ──────────────────
    for (let name in plugins) {
      let plugin = plugins[name];
      if (!plugin?.command) continue;
      const cmds = Array.isArray(plugin.command) ? plugin.command : [plugin.command];
      if (!cmds.includes(command)) continue;

      // ── React ⏱️ saat mulai proses ──────
      await m.react("⏱️");

      // ── Permission checks ─────────────
      if (plugin.owner && !isOwner) {
        return;
      }
      if (plugin.premium && !m.isPremium) {
        await m.react("❌");
        return m.reply(
          "💎 *Premium Only!*\nFitur ini khusus member Premium.\n\nKetik *.benefitpremium* untuk info upgrade."
        );
      }
      if (plugin.group && !m.isGroup) {
        await m.react("❌");
        return m.reply("👥 *Grup Only!*\nFitur ini hanya bisa digunakan di grup.");
      }
      if (plugin.private && m.isGroup) {
        await m.react("❌");
        return m.reply("💬 *Private Only!*\nFitur ini hanya bisa di chat pribadi.");
      }
      if (plugin.admin && !m.isAdmin) {
        await m.react("❌");
        return m.reply("🛡️ *Admin Only!*\nKamu harus admin grup untuk menggunakan ini.");
      }
      if (plugin.botAdmin && !m.isBotAdmin) {
        await m.react("❌");
        return m.reply("🤖 *Bot Bukan Admin!*\nJadikan bot sebagai admin grup dulu.");
      }

      // ── Energi/limit check ────────────
      if (!isOwner && !m.isPremium) {
        const userData = global.db?.users?.[m.sender];
        if (userData && global.energiDefault > 0) {
          const cost = plugin.limit || 1;
          if (userData.energi < cost) {
            await m.react("❌");
            return m.reply(
              `⚡ *Energi Habis!*\n\nLimit harianmu sudah habis.\nTunggu reset tengah malam atau upgrade Premium.\n\nKetik *.benefitpremium* untuk info.`
            );
          }
          userData.energi -= cost;
        }
      }

      global.db.settings.totalhit = (global.db.settings.totalhit || 0) + 1;

      try {
        await plugin(m, {
          sock, args, text, q,
          quoted: m.quoted || m,
          mime, command, cmd, prefix,
          isOwner,
          isAdmin: m.isAdmin,
          isBotAdmin: m.isBotAdmin,
          metadata: m.metadata,
        });

        // ── React ✅ setelah selesai ────
        await m.react("✅");

      } catch (err) {
        console.error(chalk.red(`[Error] Plugin ${name}:`), err);
        // ── React ❌ kalau error ─────────
        await m.react("❌");
        m.reply(
          `☢️ *Error!*\n\nCommand \`${cmd}\` mengalami kendala.\n\n\`\`\`${err.message}\`\`\``
        );
      }
    }

    if (global.autoTyping) {
      await sock.sendPresenceUpdate("paused", m.chat).catch(() => {});
    }

  } catch (err) {
    console.log(util.format(err));
  }
};

process.on("uncaughtException", (err) => {
  console.error("Uncaught Exception:", err);
});

let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  delete require.cache[file];
  require(file);
});
