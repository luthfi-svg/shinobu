const fs = require("fs");

// ═══════════════════════════════════════════
//  Shinobu MD V1 — Config
// ═══════════════════════════════════════════

// ── INFO BOT ──────────────────────────────
global.botname      = "Shorax V1"
global.versibot     = "1.0.0"
global.ownername    = "FarelTech"         // Global Owner
global.owner        = "6282194398295"     // Nomor owner (format: 62xxx)
global.pairingNumber = "628131472848"  // Nomor WA yang di-pair

// ── LINK ──────────────────────────────────
global.linkChannel  = "https://whatsapp.com/channel/0029VbCfQZU5EjxvYKYOFW0B"
global.idChannel    = "120363427915199733@newsletter"
global.linkGrup     = "https://chat.whatsapp.com/DRMgzaUcoYuArYF0viRrKK"
global.thumbnail    = "https://files.catbox.moe/a4mdxx.jpg"


// ── PREFIX & MODE ─────────────────────────
global.prefix       = "."                        // prefix
global.mode         = "self"               // public / self

// ── STICKER ───────────────────────────────
global.packname     = "Shorax V1"
global.author       = "Owner"

// ── PAYMENT ───────────────────────────────
global.dana         = "only qris"
global.ovo          = "only qris"
global.gopay        = "only qris"
global.qris         = ""                     // URL gambar QRIS

// ── PTERODACTYL PANEL ─────────────────────
global.domain       = "https://"                  // domain 
global.apikey       = "plta_"                     // ptla_
global.capikey      = "pltc"                     // ptlc_xxx
global.egg          = "15"
global.nestid       = "5"
global.loc          = "1"

// ── API KEYS ──────────────────────────────
global.groqApiKey   = ""    // https://console.groq.com
global.geminiApiKey = ""    // https://aistudio.google.com/apikey
global.cukiApiKey   = ""    // https://cuki.biz.id (untuk .caribug)

// ── FITUR OURIN: ENERGI/LIMIT ─────────────
global.energiDefault  = 50   // Limit default per hari
global.energiPremium  = 500  // Limit premium per hari
global.energiOwner    = -1   // -1 = unlimited

// ── FITUR OURIN: REGISTRASI ───────────────
global.registrasiEnabled = false   // true = user harus daftar dulu
global.registrasiReward  = { koin: 1000, energi: 100, exp: 1000 }

// ── FITUR OURIN: GROUP PROTECTION ─────────
global.pesan = {
  antilink       : "⚠ *Antilink* — @%user% mengirim link. Pesan dihapus.",
  antilinkKick   : "⚠ *Antilink* — @%user% di-kick karena mengirim link.",
  antitagsw      : "⚠ *AntiTagSW* — Tag status dari @%user% dihapus.",
  antitoxic      : "⚠ @%user% berkata kasar. Peringatan ke %warn% dari %max%.",
  antidocument   : "⚠ *AntiDokumen* — Dokumen dari @%user% dihapus.",
  antisticker    : "⚠ *AntiStiker* — Stiker dari @%user% dihapus.",
  antimedia      : "⚠ *AntiMedia* — Media dari @%user% dihapus.",
}

// ── FITUR OTOMATIS ────────────────────────
global.autoTyping    = true
global.autoRead      = true
global.antiCall      = false    // true = tolak panggilan masuk
global.blockIfCall   = false    // true = blokir yang telepon

// ── WELCOME / GOODBYE DEFAULT ─────────────
global.welcomeDefault = false
global.goodbyeDefault = false

// ── SCHEDULER RESET LIMIT ─────────────────
global.resetHour   = 0    // Jam reset limit (0 = tengah malam)
global.resetMinute = 0

// ── DATABASE ──────────────────────────────
global.dbPath = "./database"

// ── HOT RELOAD ────────────────────────────
let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  delete require.cache[file]
  require(file)
})
