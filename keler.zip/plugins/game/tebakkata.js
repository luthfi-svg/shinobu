// plugins/tebakkata.js — Game Tebak Kata dari Ourin MD 3
const axios = require("axios");

const sessions = {}; // { chatId: { word, hint, attempts, answer } }

const KAMUS = [
  { kata: "kucing", hint: "Hewan berbulu yang suka mengeong 🐱" },
  { kata: "motor", hint: "Kendaraan beroda dua berbahan bakar" },
  { kata: "nasi", hint: "Makanan pokok orang Indonesia 🍚" },
  { kata: "hujan", hint: "Air yang turun dari langit ☔" },
  { kata: "bulan", hint: "Satelit alami bumi 🌙" },
  { kata: "matahari", hint: "Bintang di pusat tata surya ☀️" },
  { kata: "buku", hint: "Sumber ilmu yang bisa dibaca 📚" },
  { kata: "pohon", hint: "Tumbuhan besar yang punya batang keras 🌳" },
  { kata: "lautan", hint: "Hamparan air asin yang luas 🌊" },
  { kata: "gunung", hint: "Dataran tinggi berbentuk kerucut ⛰️" },
  { kata: "komputer", hint: "Mesin elektronik untuk kerja" },
  { kata: "handphone", hint: "Alat komunikasi genggam" },
  { kata: "teman", hint: "Orang yang selalu ada bersamamu" },
  { kata: "sekolah", hint: "Tempat belajar dan mencari ilmu 🏫" },
  { kata: "makanan", hint: "Sesuatu yang dimakan untuk energi" },
  { kata: "minuman", hint: "Sesuatu yang diminum untuk menghilangkan haus" },
  { kata: "sepatu", hint: "Alas kaki yang dipakai sehari-hari 👟" },
  { kata: "rumah", hint: "Tempat tinggal dan berlindung 🏠" },
];

function maskWord(word, guessed = []) {
  return word
    .split("")
    .map((l) => (guessed.includes(l) ? l : "_"))
    .join(" ");
}

let handler = async (m, { sock, text, command }) => {
  const chat = m.chat;

  if (command === "tebakkata") {
    if (sessions[chat]) {
      const s = sessions[chat];
      return m.reply(
        `🎮 Masih ada game yang berjalan!\n\nKata: ${maskWord(s.word, s.guessed)}\nHint: ${s.hint}\nKesempatan: ${s.attempts} sisa\n\nTebak huruf atau kata dengan: *.jwb <huruf/kata>*`
      );
    }
    const item = KAMUS[Math.floor(Math.random() * KAMUS.length)];
    sessions[chat] = {
      word: item.kata,
      hint: item.hint,
      guessed: [],
      attempts: 6,
    };
    return m.reply(
      `🎮 *Tebak Kata Dimulai!*\n\nKata: ${maskWord(item.kata)}\nHint: ${item.hint}\nKesempatan: 6\n\nTebak huruf atau kata: *.jwb <huruf/kata>*\nBerhenti: *.stoptebak*`
    );
  }

  if (command === "jwb") {
    const s = sessions[chat];
    if (!s) return m.reply("Tidak ada game tebak kata. Mulai dengan: *.tebakkata*");

    const jawaban = (text || "").toLowerCase().trim();
    if (!jawaban) return m.reply("Masukkan huruf atau kata!");

    // Guess full word
    if (jawaban === s.word) {
      delete sessions[chat];
      return m.reply(`🎉 *BENAR!* Jawabannya adalah *${s.word.toUpperCase()}*!\n\nKamu berhasil menebak kata dengan benar! 🏆`);
    }

    // Wrong full word guess
    if (jawaban.length > 1) {
      s.attempts--;
      if (s.attempts <= 0) {
        delete sessions[chat];
        return m.reply(`💀 *Game Over!* Jawabannya adalah *${s.word.toUpperCase()}*`);
      }
      return m.reply(`❌ Salah! Sisa kesempatan: ${s.attempts}\n\nKata: ${maskWord(s.word, s.guessed)}`);
    }

    // Single letter guess
    const letter = jawaban[0];
    if (s.guessed.includes(letter)) return m.reply(`Huruf *${letter}* sudah pernah ditebak!`);

    s.guessed.push(letter);

    if (!s.word.includes(letter)) {
      s.attempts--;
      if (s.attempts <= 0) {
        delete sessions[chat];
        return m.reply(`💀 *Game Over!* Jawabannya adalah *${s.word.toUpperCase()}*`);
      }
      return m.reply(`❌ Huruf *${letter}* tidak ada!\n\nKata: ${maskWord(s.word, s.guessed)}\nHuruf sudah tebak: ${s.guessed.join(", ")}\nSisa kesempatan: ${s.attempts}`);
    }

    const masked = maskWord(s.word, s.guessed);
    if (!masked.includes("_")) {
      delete sessions[chat];
      return m.reply(`🎉 *BENAR!* Jawabannya adalah *${s.word.toUpperCase()}*!\n\nKamu berhasil menebak semua huruf! 🏆`);
    }

    return m.reply(`✅ Huruf *${letter}* ada!\n\nKata: ${masked}\nHuruf sudah tebak: ${s.guessed.join(", ")}\nSisa kesempatan: ${s.attempts}`);
  }

  if (command === "stoptebak") {
    if (!sessions[chat]) return m.reply("Tidak ada game yang berjalan.");
    const word = sessions[chat].word;
    delete sessions[chat];
    return m.reply(`🛑 Game dihentikan. Jawabannya: *${word.toUpperCase()}*`);
  }
};

handler.command = ["tebakkata", "jwb", "stoptebak"];
handler.tags = ["game"];
handler.help = ["tebakkata", "jwb <huruf/kata>", "stoptebak"];

module.exports = handler;
