// plugins/ai-shota.js — AI dari Shota Bot MD
// Grok, Perplexity, PublicAI, TurboSeek
const axios = require("axios");

async function askPublicAI(prompt, model = "gpt-4o-mini") {
  const { data } = await axios.post(
    "https://api.publicai.io/chat/completions",
    {
      model,
      messages: [{ role: "user", content: prompt }],
      max_tokens: 1000,
    },
    {
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer public-ai-free",
      },
      timeout: 30000,
    }
  );
  return data?.choices?.[0]?.message?.content || "Tidak ada respons.";
}

async function askLennaAI(prompt) {
  const { data } = await axios.post(
    "https://lenna.ai/api/chat",
    { message: prompt, model: "gpt-4o-mini" },
    {
      headers: { "Content-Type": "application/json" },
      timeout: 30000,
    }
  );
  return data?.reply || data?.message || data?.text || "Tidak ada respons.";
}

async function askTurboSeek(prompt) {
  const { data } = await axios.get(
    `https://api.nexray.eu.cc/ai/turboseek?q=${encodeURIComponent(prompt)}`,
    { timeout: 30000 }
  );
  return data?.result || data?.answer || data?.text || "Tidak ada respons.";
}

let handler = async (m, { command, text }) => {
  if (!text) return m.reply(`*Contoh:*\n> ${m.cmd} Apa itu photosynthesis?`);

  await m.react("🤖");
  await m.reply(`🤖 *${command.toUpperCase()} AI* sedang berpikir...`);

  try {
    let result = "";

    switch (command) {
      case "grok":
        result = await askPublicAI(text, "grok-3-mini");
        break;
      case "pplx":
      case "perplexity":
        result = await askPublicAI(text, "sonar");
        break;
      case "publicai":
        result = await askPublicAI(text);
        break;
      case "lennaai":
      case "lenna":
        result = await askLennaAI(text);
        break;
      case "turboseek":
      case "turbo":
        result = await askTurboSeek(text);
        break;
      default:
        result = await askPublicAI(text);
    }

    const label = {
      grok: "🤖 Grok AI",
      pplx: "🔍 Perplexity",
      perplexity: "🔍 Perplexity",
      publicai: "🤖 Public AI",
      lennaai: "💬 Lenna AI",
      lenna: "💬 Lenna AI",
      turboseek: "⚡ TurboSeek",
      turbo: "⚡ TurboSeek",
    }[command] || "🤖 AI";

    await m.reply(`${label}\n\n${result}`);
    await m.react("✅");
  } catch (e) {
    await m.react("❌");
    m.reply("❌ AI error: " + e.message);
  }
};

handler.command = ["grok", "pplx", "perplexity", "publicai", "lennaai", "lenna", "turboseek", "turbo"];
handler.tags = ["ai"];
handler.help = ["grok <tanya>", "pplx <tanya>", "lennaai <tanya>", "turboseek <tanya>"];
module.exports = handler;
