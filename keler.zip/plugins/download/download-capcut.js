// plugins/download-capcut.js — dari Ourin MD 3
const axios = require("axios");

let handler = async (m, { sock }) => {
  const url = (m.text || "").trim();
  if (!url || !url.includes("capcut")) return m.reply(
    `✂️ *ᴄᴀᴘᴄᴜᴛ ᴅʟ*\n\n> ${m.cmd} <link capcut>\n\n*Contoh:*\n> ${m.cmd} https://www.capcut.com/t/xxx`
  );

  await m.react("🕕");
  await m.reply("⏳ Mendownload dari CapCut...");

  try {
    const { data } = await axios.get(
      `https://api.nexray.eu.cc/download/capcut?url=${encodeURIComponent(url)}`,
      { timeout: 30000 }
    );

    const r = data?.result || data;
    const dlUrl = r?.video || r?.url || r?.download_url;
    const title = r?.title || "CapCut Video";
    const music = r?.music || r?.audio;

    if (!dlUrl) throw new Error("URL download tidak ditemukan");

    await sock.sendMessage(m.chat, {
      video: { url: dlUrl },
      caption: `✂️ *CapCut Downloader*\n📌 ${title}`,
    }, { quoted: m });

    if (music) {
      await sock.sendMessage(m.chat, {
        audio: { url: music },
        mimetype: "audio/mpeg",
        fileName: `${title}_music.mp3`,
      }, { quoted: m });
    }

    await m.react("✅");
  } catch (err) {
    await m.react("❌");
    m.reply("❌ Gagal download CapCut: " + err.message);
  }
};

handler.command = ["capcut", "capcutdl", "ccdl"];
handler.tags = ["Download"];
handler.help = ["capcut <url>"];
module.exports = handler;
