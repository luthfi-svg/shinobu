// plugins/download-shota.js — Mediafire, Twitter, Douyin dari Shota Bot MD
const axios = require("axios");

const API = "https://api.nexray.eu.cc";

let handler = async (m, { sock, command, text }) => {

  // ── Mediafire ──────────────────────────
  if (command === 'mediafire' || command === 'mf') {
    if (!text || !text.includes("mediafire.com"))
      return m.reply(`*Contoh:*\n> ${m.cmd} https://www.mediafire.com/file/xxx`);
    await m.react("⏳");
    await m.reply("📥 Mengambil link Mediafire...");

    try {
      const { data } = await axios.get(
        `${API}/download/mediafire?url=${encodeURIComponent(text)}`,
        { timeout: 20000 }
      );
      const r = data?.result || data;
      if (!r?.url) throw new Error("Gagal ambil link");

      return m.reply(
        `📦 *Mediafire Downloader*\n\n` +
        `📌 Nama: *${r.filename || r.name || "File"}*\n` +
        `📦 Size: *${r.size || "-"}*\n` +
        `🔗 Link: ${r.url}`
      );
    } catch (e) {
      await m.react("❌");
      m.reply("❌ Gagal: " + e.message);
    }
  }

  // ── Twitter/X ──────────────────────────
  if (command === 'twitter' || command === 'twdl' || command === 'xdl') {
    if (!text || !/(twitter\.com|x\.com)/.test(text))
      return m.reply(`*Contoh:*\n> ${m.cmd} https://x.com/user/status/xxx`);
    await m.react("⏳");
    await m.reply("🐦 Mendownload dari Twitter/X...");

    try {
      const { data } = await axios.get(
        `${API}/download/twitter?url=${encodeURIComponent(text)}`,
        { timeout: 30000 }
      );
      const r = data?.result || data;
      const dlUrl = r?.url || r?.video || r?.hd || r?.sd;
      if (!dlUrl) throw new Error("Gagal ambil video");

      await sock.sendMessage(m.chat, {
        video: { url: dlUrl },
        caption: `🐦 *Twitter/X Downloader*\n\n${r.description || r.title || ""}`,
      }, { quoted: m.verifiedQuoted });
      await m.react("✅");
    } catch (e) {
      await m.react("❌");
      m.reply("❌ Gagal: " + e.message);
    }
  }

  // ── Douyin ─────────────────────────────
  if (command === 'douyin' || command === 'dydl') {
    if (!text || !text.includes("douyin"))
      return m.reply(`*Contoh:*\n> ${m.cmd} https://www.douyin.com/video/xxx`);
    await m.react("⏳");
    await m.reply("🎵 Mendownload dari Douyin...");

    try {
      const { data } = await axios.get(
        `${API}/download/douyin?url=${encodeURIComponent(text)}`,
        { timeout: 30000 }
      );
      const r = data?.result || data;
      const dlUrl = r?.url || r?.video;
      if (!dlUrl) throw new Error("Gagal ambil video");

      await sock.sendMessage(m.chat, {
        video: { url: dlUrl },
        caption: `🎵 *Douyin Downloader*\n\n${r.title || r.description || ""}`,
      }, { quoted: m.verifiedQuoted });
      await m.react("✅");
    } catch (e) {
      await m.react("❌");
      m.reply("❌ Gagal: " + e.message);
    }
  }

  // ── Play Store search ──────────────────
  if (command === 'playstore' || command === 'apk') {
    if (!text) return m.reply(`*Contoh:*\n> ${m.cmd} WhatsApp`);
    await m.react("🔍");

    try {
      const { data } = await axios.get(
        `${API}/search/playstore?q=${encodeURIComponent(text)}`,
        { timeout: 15000 }
      );
      const results = data?.result || data?.results || [];
      if (!results.length) return m.reply("❌ Aplikasi tidak ditemukan!");

      const app = results[0];
      const caption =
        `📱 *Play Store*\n\n` +
        `📌 Nama: *${app.title || "-"}*\n` +
        `👨‍💻 Developer: *${app.developer || "-"}*\n` +
        `⭐ Rating: *${app.score || "-"}*\n` +
        `📥 Installs: *${app.installs || "-"}*\n` +
        `💰 Harga: *${app.price || "Gratis"}*\n` +
        `📝 Deskripsi: ${(app.summary || "").slice(0, 200)}\n\n` +
        `🔗 https://play.google.com/store/apps/details?id=${app.appId || ""}`;

      if (app.icon) {
        await sock.sendMessage(m.chat, {
          image: { url: app.icon }, caption,
        }, { quoted: m.verifiedQuoted });
      } else {
        await m.reply(caption);
      }
      await m.react("✅");
    } catch (e) {
      await m.react("❌");
      m.reply("❌ Error: " + e.message);
    }
  }

  // ── Spotify Play ──────────────────────
  if (command === 'spotifyplay' || command === 'splay') {
    if (!text) return m.reply(`*Contoh:*\n> ${m.cmd} Harleys In Hawaii`);
    await m.react("🎵");

    try {
      // Search dulu
      const searchRes = await axios.get(
        `${API}/search/spotify?q=${encodeURIComponent(text)}&limit=1`,
        { timeout: 15000 }
      );
      const tracks = searchRes.data?.result || searchRes.data?.tracks || [];
      if (!tracks.length) return m.reply("❌ Lagu tidak ditemukan!");

      const track = tracks[0];
      const trackUrl = track?.url || track?.external_urls?.spotify;
      if (!trackUrl) return m.reply("❌ Gagal dapat link lagu.");

      // Download
      const dlRes = await axios.get(
        `${API}/download/spotify?url=${encodeURIComponent(trackUrl)}`,
        { timeout: 30000 }
      );
      const r = dlRes.data?.result || dlRes.data;
      const dlUrl = r?.url || r?.audio_url;
      if (!dlUrl) throw new Error("URL tidak ditemukan");

      const title = track?.name || r?.title || text;
      const artist = track?.artists?.[0]?.name || r?.artist || "";
      const thumb = track?.album?.images?.[0]?.url || r?.thumbnail;

      await sock.sendMessage(m.chat, {
        audio: { url: dlUrl },
        mimetype: "audio/mpeg",
        fileName: `${title}.mp3`,
        contextInfo: thumb ? {
          externalAdReply: {
            title, body: artist,
            thumbnailUrl: thumb,
            mediaType: 1, renderLargerThumbnail: false,
          },
        } : undefined,
      }, { quoted: m.verifiedQuoted });
      await m.react("✅");
    } catch (e) {
      await m.react("❌");
      m.reply("❌ Gagal: " + e.message);
    }
  }
};

handler.command = [
  'mediafire', 'mf',
  'twitter', 'twdl', 'xdl',
  'douyin', 'dydl',
  'playstore', 'apk',
  'spotifyplay', 'splay',
];
handler.tags = ['Download'];
handler.help = [
  'mediafire <url>',
  'twitter <url>',
  'douyin <url>',
  'playstore <nama app>',
  'spotifyplay <judul>',
];
module.exports = handler;
