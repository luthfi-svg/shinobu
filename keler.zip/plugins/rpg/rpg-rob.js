// plugins/rpg-rob.js — Rob/Rampok dari Ourin MD 3.1

if (!global.robCooldown) global.robCooldown = new Map();

function getRpgUser(sender) {
  if (!global.db.users[sender]) global.db.users[sender] = {};
  const u = global.db.users[sender];
  if (!u.rpg) u.rpg = { balance: 0, bank: 0, exp: 0, level: 1, potion: 0, diamond: 0, gold: 0, health: 100 };
  if (u.rpg.health === undefined) u.rpg.health = 100;
  return u.rpg;
}

function clockStr(ms) {
  const m = Math.floor(ms / 60000), s = Math.floor((ms % 60000) / 1000);
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
}

let handler = async (m, { sock }) => {
  const target = m.mentionedJid?.[0] || m.quoted?.sender;

  if (!target) {
    return m.reply(`Hayo, mau malak siapa nih? 🦹‍♂️🔪\nTag target yang mau dirampok hartanya!\nContoh: \`${m.cmd} @user\``);
  }
  if (target === m.sender) {
    return m.reply(`Sakit jiwa lu? Masa ngerampok dompet sendiri! 😂❌`);
  }

  const COOLDOWN = 600000; // 10 menit
  const now = Date.now();
  const last = global.robCooldown.get(m.sender);
  if (last && now - last < COOLDOWN) {
    return m.reply(`⏳ Sembunyi dulu, polisi masih nyari lu!\nCoba lagi dalam: *${clockStr(COOLDOWN - (now - last))}*`);
  }

  const robber = getRpgUser(m.sender);
  const victim = getRpgUser(target);

  if ((victim.balance || 0) < 1000) {
    return m.reply(`Yaelah, target lu miskin parah! Duitnya di bawah Rp 1.000, masa tega dirampok? Cari mangsa yang tajir dong! 😤`);
  }

  if (robber.health < 30) {
    return m.reply(`Woy bos, badan lu tinggal tulang gitu masih nekat ngerampok?! 🤒\nMinimal *30 HP*, darah lu cuma *${robber.health} HP*. Berobat sana!`);
  }

  await m.react("🦹");
  await m.reply(`*Sssstttt...* Bersembunyi di gang gelap nunggu target lewat... 🦹‍♂️🔪`);
  await new Promise((r) => setTimeout(r, 2000));

  global.robCooldown.set(m.sender, now);

  const successRate = 0.4;
  const isSuccess = Math.random() < successRate;

  if (isSuccess) {
    const maxSteal = Math.floor((victim.balance || 0) * 0.3);
    const stolen = Math.floor(Math.random() * maxSteal) + 1000;

    victim.balance -= stolen;
    robber.balance += stolen;

    await m.react("💰");
    return sock.sendMessage(m.chat, {
      text:
        `🦹 *RAMPOK SUKSES!*\n\n` +
        `@${m.sender.split("@")[0]} berhasil ngerampok @${target.split("@")[0]}!\n\n` +
        `💰 Hasil rampokan: *Rp ${stolen.toLocaleString("id-ID")}*\n` +
        `💵 Saldo kamu sekarang: *Rp ${robber.balance.toLocaleString("id-ID")}*`,
      mentions: [m.sender, target],
    }, { quoted: m });
  } else {
    const damage = Math.floor(Math.random() * 30) + 10;
    const fine = Math.floor(Math.random() * 5000) + 2000;
    robber.health = Math.max(0, robber.health - damage);
    robber.balance = Math.max(0, robber.balance - fine);

    await m.react("🚔");
    return sock.sendMessage(m.chat, {
      text:
        `🚔 *KETANGKEP SATPAM!*\n\n` +
        `@${m.sender.split("@")[0]} ketangkep waktu mau ngerampok @${target.split("@")[0]}!\n\n` +
        `🩸 HP berkurang: *-${damage}* (sisa: ${robber.health})\n` +
        `💸 Denda: *Rp ${fine.toLocaleString("id-ID")}*\n\n` +
        `_Mendingan kerja yang halal bro!_ 😂`,
      mentions: [m.sender, target],
    }, { quoted: m });
  }
};

handler.command = ["rob", "rampok", "mug"];
handler.tags = ["rpg"];
handler.help = ["rob @user"];
handler.group = true;
module.exports = handler;
