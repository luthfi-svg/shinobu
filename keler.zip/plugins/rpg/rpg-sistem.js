// plugins/rpg-sistem.js — RPG System dari Shota Bot MD
// daily, kerja, bank, deposit, withdraw, transfer, profil RPG

const cooldowns = {
  kerja: new Map(),
  daily: new Map(),
};

function clockStr(ms) {
  const h = Math.floor(ms / 3600000),
        m = Math.floor((ms % 3600000) / 60000),
        s = Math.floor((ms % 60000) / 1000);
  return h > 0 ? `${h}j ${m}m` : m > 0 ? `${m}m ${s}s` : `${s}s`;
}

function rand(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function getRpgUser(sender) {
  if (!global.db.users[sender]) global.db.users[sender] = {};
  const u = global.db.users[sender];
  if (!u.rpg) u.rpg = {
    balance: 0, bank: 0, exp: 0, level: 1,
    potion: 0, diamond: 0, gold: 0,
  };
  return u.rpg;
}

function addExp(rpg) {
  const expPerLevel = rpg.level * 1000;
  if (rpg.exp >= expPerLevel) {
    rpg.exp -= expPerLevel;
    rpg.level++;
    return true;
  }
  return false;
}

const jobList = [
  "⛏️ Penambang", "🧹 Tukang Bersih-bersih", "👷 Kuli Bangunan",
  "📦 Kurir Paket", "🍕 Pengantar Makanan", "🚕 Supir Taksi",
  "💻 Programmer", "🧪 Ilmuwan", "🎨 Seniman", "🐮 Peternak",
  "👨‍🏫 Guru Honorer", "👨‍🍳 Koki", "👨‍🔧 Montir", "📸 Fotografer",
  "🎵 Musisi Jalanan", "🚗 Sopir Ojol", "🏗️ Arsitek Junior",
];

let handler = async (m, { sock, command, args, text }) => {
  const rpg = getRpgUser(m.sender);
  const now = Date.now();

  // ── Daily ──────────────────────────────
  if (command === 'daily') {
    const COOLDOWN = 86400000;
    const last = cooldowns.daily.get(m.sender);
    if (last && now - last < COOLDOWN) {
      return m.reply(`⏳ Kamu sudah klaim hari ini!\nKembali dalam: *${clockStr(COOLDOWN - (now - last))}*`);
    }

    const uang = rand(5000, 20000);
    const exp = rand(2000, 8000);
    const potion = rand(0, 3);
    const diamond = rand(0, 2);
    const crate = Math.random() < 0.5 ? 1 : 0;

    rpg.balance += uang;
    rpg.exp += exp;
    rpg.potion += potion;
    rpg.diamond += diamond;
    const levelUp = addExp(rpg);

    cooldowns.daily.set(m.sender, now);

    return m.reply(
      `🎁 *DAILY REWARD*\n_Berhasil diklaim!_\n\n` +
      `💰 Balance: *+${uang.toLocaleString("id-ID")}*\n` +
      `✨ Exp: *+${exp.toLocaleString("id-ID")}*\n` +
      `🧪 Potion: *+${potion}*\n` +
      `💎 Diamond: *+${diamond}*\n` +
      `📦 Crate: *+${crate}*\n` +
      (levelUp ? `\n🎉 *LEVEL UP!* Sekarang level *${rpg.level}*` : "") +
      `\n\n_Jangan lupa klaim lagi besok ya!_ ✅`
    );
  }

  // ── Kerja ──────────────────────────────
  if (command === 'kerja' || command === 'work') {
    const COOLDOWN = 300000; // 5 menit
    const last = cooldowns.kerja.get(m.sender);
    if (last && now - last < COOLDOWN) {
      return m.reply(`⏳ Kamu masih lelah bekerja!\nIstirahat dulu: *${clockStr(COOLDOWN - (now - last))}*`);
    }

    const uang = rand(1000, 4000);
    const exp = rand(100, 400);
    const bonus = Math.random() < 0.1;
    const job = jobList[Math.floor(Math.random() * jobList.length)];

    rpg.balance += uang;
    rpg.exp += exp;
    if (bonus) rpg.gold = (rpg.gold || 0) + 1;
    const levelUp = addExp(rpg);

    cooldowns.kerja.set(m.sender, now);

    return m.reply(
      `💼 *LAPORAN KERJA*\nProfesi: *${job}*\n\n` +
      `💰 Gaji: *+${uang.toLocaleString("id-ID")}*\n` +
      `✨ Exp: *+${exp}*\n` +
      (bonus ? `🪙 Bonus Gold: *+1*\n` : "") +
      (levelUp ? `\n🎉 *LEVEL UP!* Sekarang level *${rpg.level}*` : "") +
      `\n\n_Kerja bagus! Lanjutkan semangatmu._ 🛠️`
    );
  }

  // ── Bank ───────────────────────────────
  if (command === 'bank') {
    return m.reply(
      `🏦 *BANK NUSANTARA*\n👤 Nasabah: ${m.pushName || "-"}\n\n` +
      `💵 Dompet: *${rpg.balance.toLocaleString("id-ID")}*\n` +
      `💳 Tabungan: *${rpg.bank.toLocaleString("id-ID")}*\n\n` +
      `*Cara Transaksi:*\n` +
      `› ${global.prefix}deposit <jumlah>\n` +
      `› ${global.prefix}tarik <jumlah>`
    );
  }

  // ── Deposit ────────────────────────────
  if (command === 'deposit' || command === 'depo') {
    const jumlah = parseInt(args[0]);
    if (!jumlah || jumlah < 1) return m.reply(`*Contoh:*\n> ${m.cmd} 10000`);
    if (rpg.balance < jumlah) return m.reply(`❌ Saldo dompet tidak cukup!\nDompet: ${rpg.balance.toLocaleString("id-ID")}`);
    rpg.balance -= jumlah;
    rpg.bank += jumlah;
    return m.reply(`✅ Berhasil deposit *${jumlah.toLocaleString("id-ID")}* ke bank.\nTabungan: *${rpg.bank.toLocaleString("id-ID")}*`);
  }

  // ── Tarik ──────────────────────────────
  if (command === 'tarik' || command === 'withdraw') {
    const jumlah = parseInt(args[0]);
    if (!jumlah || jumlah < 1) return m.reply(`*Contoh:*\n> ${m.cmd} 10000`);
    if (rpg.bank < jumlah) return m.reply(`❌ Saldo bank tidak cukup!\nBank: ${rpg.bank.toLocaleString("id-ID")}`);
    rpg.bank -= jumlah;
    rpg.balance += jumlah;
    return m.reply(`✅ Berhasil tarik *${jumlah.toLocaleString("id-ID")}* dari bank.\nDompet: *${rpg.balance.toLocaleString("id-ID")}*`);
  }

  // ── Transfer ───────────────────────────
  if (command === 'transfer' || command === 'tf') {
    const target = m.mentionedJid?.[0] || (args[0]?.replace(/[^0-9]/g,"") + "@s.whatsapp.net");
    const jumlah = parseInt(args[1] || args[0]);
    if (!target || !jumlah || jumlah < 1) {
      return m.reply(`*Contoh:*\n> ${m.cmd} @tag 10000\n> ${m.cmd} 628xxx 10000`);
    }
    if (target === m.sender) return m.reply("❌ Tidak bisa transfer ke diri sendiri!");
    if (rpg.balance < jumlah) return m.reply(`❌ Saldo tidak cukup!\nDompet: ${rpg.balance.toLocaleString("id-ID")}`);

    rpg.balance -= jumlah;
    const targetRpg = getRpgUser(target);
    targetRpg.balance += jumlah;

    return sock.sendMessage(m.chat, {
      text: `💸 *TRANSFER BERHASIL*\n\n` +
        `👤 Dari: @${m.sender.split("@")[0]}\n` +
        `👤 Ke: @${target.split("@")[0]}\n` +
        `💰 Jumlah: *${jumlah.toLocaleString("id-ID")}*\n\n` +
        `Sisa dompet: *${rpg.balance.toLocaleString("id-ID")}*`,
      mentions: [m.sender, target],
    }, { quoted: m.verifiedQuoted });
  }

  // ── Profil RPG ─────────────────────────
  if (command === 'rpg' || command === 'profilrpg') {
    const target = m.mentionedJid?.[0] || m.quoted?.sender || m.sender;
    const tRpg = getRpgUser(target);
    const expNeeded = tRpg.level * 1000;
    const bar = "█".repeat(Math.floor((tRpg.exp / expNeeded) * 8)) + "░".repeat(8 - Math.floor((tRpg.exp / expNeeded) * 8));

    return sock.sendMessage(m.chat, {
      text:
        `⚔️ *PROFIL RPG*\n\n` +
        `╭┈┈⬡「 👤 *${m.pushName || "User"}* 」\n` +
        `┃ ⭐ Level  : *${tRpg.level}*\n` +
        `┃ 📈 EXP    : ${bar} *${tRpg.exp}/${expNeeded}*\n` +
        `┃ 💰 Dompet : *${tRpg.balance.toLocaleString("id-ID")}*\n` +
        `┃ 💳 Bank   : *${tRpg.bank.toLocaleString("id-ID")}*\n` +
        `┃ 💎 Diamond: *${tRpg.diamond}*\n` +
        `┃ 🪙 Gold   : *${tRpg.gold || 0}*\n` +
        `┃ 🧪 Potion : *${tRpg.potion}*\n` +
        `╰┈┈⬡`,
      mentions: [target],
    }, { quoted: m.verifiedQuoted });
  }
};

handler.command = [
  'daily', 'kerja', 'work',
  'bank', 'deposit', 'depo',
  'tarik', 'withdraw',
  'transfer', 'tf',
  'rpg', 'profilrpg',
];
handler.tags = ['rpg'];
handler.help = [
  'daily', 'kerja',
  'bank', 'deposit <jumlah>',
  'tarik <jumlah>',
  'transfer @tag <jumlah>',
  'rpg',
];
module.exports = handler;
