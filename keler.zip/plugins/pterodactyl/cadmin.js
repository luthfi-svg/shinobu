const { generateWAMessageFromContent } = require("dekzymarket-cyber")

let handler = async (m, { sock, text, cmd }) => {
  if (!text) return m.reply(`*example:*\n${cmd} username`)

  let nomor, usernem
  const tek = text.split(",")

  if (tek.length > 1) {
    let [users, nom] = tek
    if (!users || !nom) return m.reply(`*example:*\n${cmd} username`)

    nomor = m.mentionedJid[0]
      ? m.mentionedJid[0]
      : nom.replace(/[^0-9]/g, "") + "@s.whatsapp.net"

    usernem = users.toLowerCase()
    nomor = await sock.toLid(nomor)

  } else {
    usernem = text.toLowerCase()
    nomor = m.isGroup ? m.sender : m.chat
  }

  const username = usernem
  const email = `${username}@gmail.com`
  const name = global.capital(usernem)
  const password = `${username}001`

  try {
    const res = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${apikey}`
      },
      body: JSON.stringify({
        email,
        username,
        first_name: name,
        last_name: "Admin",
        root_admin: true,
        language: "en",
        password
      })
    })

    const data = await res.json()
    if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))

    const user = data.attributes
    const target = nomor

    if (target !== m.chat) {
      m.reply(`Berhasil membuat admin panel ✅\ndata dikirim ke @${target.split("@")[0]}`)
    }

    const teks = `
*Berhasil Membuat Admin Panel ✅*
- ID User: ${user.id}
- Username: ${user.username}
- Password: ${password}
- Tanggal: ${global.tanggal(Date.now())}
- ${global.domain}
`

    let msg = generateWAMessageFromContent(target, {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: { text: teks },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "cta_copy",
                  buttonParamsJson: JSON.stringify({
                    display_text: "Copy Username",
                    copy_code: user.username
                  })
                },
                {
                  name: "cta_copy",
                  buttonParamsJson: JSON.stringify({
                    display_text: "Copy Password",
                    copy_code: password
                  })
                },
                {
                  name: "cta_url",
                  buttonParamsJson: JSON.stringify({
                    display_text: "Login Panel",
                    url: global.domain
                  })
                }
              ]
            }
          }
        }
      }
    }, { userJid: m.sender, quoted: m })

    await sock.relayMessage(target, msg.message, { messageId: msg.key.id })

  } catch (err) {
    console.error(err)
    m.reply("Terjadi kesalahan saat membuat akun admin panel.")
  }
}

handler.help = ['cadmin']
handler.tags = ['pterodactyl']
handler.command = ['cadmin']
handler.owner = true

module.exports = handler