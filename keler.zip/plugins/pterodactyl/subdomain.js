const axios = require("axios")
const { generateWAMessageFromContent } = require("dekzymarket-cyber")

let handler = async (m, { sock, text, args, command, isOwner }) => {

  if (command === "subdo" || command === "subdomain") {
    if (!text.includes("|")) return m.reply(`*example:*\n${m.cmd} hostname|ip`)

    const obj = Object.keys(global.subdomain || {})
    if (obj.length < 1) return m.reply("Tidak ada API Domain yang tersedia.")

    const [hostname, ip] = text.split("|")
    const rows = obj.map((domain, i) => ({
      title: `🌐 ${domain}`,
      description: `Result: https://${hostname.toLowerCase()}.${domain}`,
      id: `.subdomain-response ${i + 1} ${hostname.trim()}|${ip}`
    }))

    await sock.sendMessage(m.chat, {
      buttons: [{
        buttonId: "action",
        buttonText: { displayText: "Pilih Domain" },
        type: 4,
        nativeFlowInfo: {
          name: "single_select",
          paramsJson: JSON.stringify({
            title: "Pilih Domain",
            sections: [{ rows }]
          })
        }
      }],
      headerType: 1, 
      text: `\nPilih Domain Server Yang Tersedia\nTotal Domain: ${obj.length}\n`
    }, { quoted: m })

    return
  }

  if (command === "subdomain-response") {
    if (!text) return
    if (!args[0] || isNaN(args[0])) return m.reply("Domain tidak ditemukan!")

    const dom = Object.keys(global.subdomain || {})
    const domainIndex = Number(args[0]) - 1
    if (domainIndex >= dom.length || domainIndex < 0) return m.reply("Domain tidak ditemukan!")
    if (!args[1] || !args[1].includes("|")) return m.reply("Hostname/IP Tidak ditemukan!")

    const tldnya = dom[domainIndex]
    const [host, ip] = args[1].split("|").map(v => v.trim())

    const getRandom = (len = 4) => {
      const chars = "abcdefghijklmnopqrstuvwxyz0123456789"
      let res = ""
      for (let i = 0; i < len; i++) res += chars[Math.floor(Math.random() * chars.length)]
      return res
    }

    const createSub = (host, ip) => new Promise(resolve => {
      axios.post(
        `https://api.cloudflare.com/client/v4/zones/${global.subdomain[tldnya].zone}/dns_records`,
        {
          type: "A",
          name: `${host.replace(/[^a-z0-9.-]/gi, "")}.${tldnya}`,
          content: ip.replace(/[^0-9.]/gi, ""),
          ttl: 3600,
          priority: 10,
          proxied: false
        },
        {
          headers: {
            Authorization: `Bearer ${global.subdomain[tldnya].apitoken}`,
            "Content-Type": "application/json"
          }
        }
      ).then(res => {
        const data = res.data
        if (data.success) resolve({ success: true, name: data.result?.name, ip: data.result?.content })
        else resolve({ success: false, error: "Gagal membuat subdomain." })
      }).catch(err => {
        const errorMsg = err.response?.data?.errors?.[0]?.message || err.message || "Terjadi kesalahan!"
        resolve({ success: false, error: errorMsg })
      })
    })

    const domnode = `node${getRandom()}.${host}`
    let panelDomain = "", nodeDomain = ""

    for (let i = 0; i < 2; i++) {
      const subHost = i === 0 ? host.toLowerCase() : domnode
      const result = await createSub(subHost, ip)
      if (!result.success) return m.reply(result.error)
      i === 0 ? panelDomain = result.name : nodeDomain = result.name
    }

    const teks = `
Berhasil Membuat Subdomain ✅

IP VPS: \`${ip}\`
- ${panelDomain}
- ${nodeDomain}
`

    const msg = await generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: { text: teks },
            nativeFlowMessage: {
              buttons: [
                { name: "cta_copy", buttonParamsJson: `{"display_text":"Copy Subdomain Panel","copy_code":"${panelDomain}"}` },
                { name: "cta_copy", buttonParamsJson: `{"display_text":"Copy Subdomain Node","copy_code":"${nodeDomain}"}` }
              ]
            }
          }
        }
      }
    }, { userJid: m.sender, quoted: m })

    await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
  }
}


handler.tags = ["pterodactyl"]
handler.help = "subdomain"
handler.command = ["subdomain", "subdo", "subdomain-response"]
handler.owner = true

module.exports = handler

global.subdomain = {
  "skyzopedia.web.id": { zone: "0ef4ccf8a122c678c0b192fc308d7b3b", apitoken: "cfut_zsfUANZnl0sw02IPf6h3GZ1xC9Po80Pcgo26ekza3af6a697" },
  "serverweb.qzz.io": { zone: "bb19b9cd3904b603406771a56f64016e", apitoken: "cfut_tWji1gf8coCziyKdxScZuXMzgUlse7yNimpXcBrp2d3c5522" },
  "pteroweb.my.id": { zone: "714e0f2e54a90875426f8a6819f782d0", apitoken: "SbRAPRzC34ccmf4cJs-0qZ939yHe3Ko6CpolxqW4" },
  "panelwebsite.biz.id": { zone: "2d6aab40136299392d66eed44a7b1122", apitoken: "SbRAPRzC34ccmf4cJs-0qZ939yHe3Ko6CpolxqW4" },
  "privatserver.my.id": { zone: "699bb9eb65046a886399c91daacb1968", apitoken: "SbRAPRzC34ccmf4cJs-0qZ939yHe3Ko6CpolxqW4" },
  "serverku.biz.id": { zone: "4e4feaba70b41ed78295d2dcc090dd3a", apitoken: "SbRAPRzC34ccmf4cJs-0qZ939yHe3Ko6CpolxqW4" },
  "vipserver.web.id": { zone: "e305b750127749c9b80f41a9cf4a3a53", apitoken: "SbRAPRzC34ccmf4cJs-0qZ939yHe3Ko6CpolxqW4" },
  "mypanelstore.web.id": { zone: "c61c442d70392500611499c5af816532", apitoken: "SbRAPRzC34ccmf4cJs-0qZ939yHe3Ko6CpolxqW4" }
}