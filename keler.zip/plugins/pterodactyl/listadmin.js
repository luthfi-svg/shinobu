let handler = async (m) => {

  try {
    const res = await fetch(`${domain}/api/application/users`, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${apikey}`
      }
    })

    const data = await res.json()
    const users = data.data

    const adminUsers = users.filter(u => u.attributes.root_admin === true)

    if (!adminUsers || adminUsers.length < 1) {
      return m.reply("Tidak ada admin panel.")
    }

    let teks = `\nTotal Admin Panel: ${adminUsers.length}\n`

    for (const admin of adminUsers) {
      const a = admin.attributes

      teks += `
- ID User: ${a.id}
- Nama: ${a.first_name}
- Created: ${a.created_at.split("T")[0]}
`
    }

    m.reply(teks)

  } catch (err) {
    console.error(err)
    m.reply("Terjadi kesalahan saat mengambil data admin.")
  }
}

handler.help = ['listadmin']
handler.tags = ['pterodactyl']
handler.command = ['listadmin']

module.exports = handler