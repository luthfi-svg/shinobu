// plugins/grup-revoke.js — dari Ourin MD 3

let handler = async (m, { sock }) => {
  if (!m.isAdmin && !m.isOwner) return m.reply("🛡️ Admin only!");
  if (!m.isBotAdmin) return m.reply("🤖 Bot harus jadi admin!");

  try {
    await sock.groupRevokeInvite(m.chat);
    const newCode = await sock.groupInviteCode(m.chat);
    return m.reply(`✅ Link grup berhasil direset!\n\n🔗 Link baru:\nhttps://chat.whatsapp.com/${newCode}`);
  } catch (err) {
    m.reply("❌ Gagal mereset link grup: " + err.message);
  }
};

handler.command = ["revoke", "resetlink", "gruprevoke"];
handler.tags = ["group"];
handler.help = ["revoke"];
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

module.exports = handler;
