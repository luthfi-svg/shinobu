// plugins/grup-info.js — dari Ourin MD 3

let handler = async (m, { sock }) => {
  try {
    const meta = await sock.groupMetadata(m.chat);
    const admins = meta.participants.filter((p) => p.admin).map((p) => `@${p.id.split("@")[0]}`);
    const members = meta.participants.length;
    const created = new Date(meta.creation * 1000);
    const cfg = global.db.groups?.[m.chat] || {};

    const teks = `
📋 *Info Grup*

📌 Nama: *${meta.subject}*
🆔 ID: \`${m.chat}\`
👥 Total Member: *${members}*
👑 Admin: ${admins.join(", ") || "-"}
📅 Dibuat: ${global.tanggal(created)}

⚙️ *Pengaturan Grup*
• Welcome: ${cfg.welcome ? "✅" : "❌"}
• Goodbye: ${cfg.goodbye ? "✅" : "❌"}
• AntiLink: ${cfg.antilink ? "✅" : "❌"}
• AntiLink All: ${cfg.antilinkall ? "✅" : "❌"}
• AntiTagSW: ${cfg.antitagsw ? "✅" : "❌"}
• AntiToxic: ${cfg.antitoxic ? "✅" : "❌"}
• AntiViewOnce: ${cfg.antiviewonce ? "✅" : "❌"}
• AntiDelete: ${cfg.antidelete ? "✅" : "❌"}
• AntiDokumen: ${cfg.antidocument ? "✅" : "❌"}
• AntiStiker: ${cfg.antisticker ? "✅" : "❌"}
• AntiMedia: ${cfg.antimedia ? "✅" : "❌"}
• AntiBot: ${cfg.antibot ? "✅" : "❌"}
• AutoDL: ${cfg.autodl ? "✅" : "❌"}`;

    await sock.sendMessage(m.chat, {
      text: teks,
      mentions: meta.participants.filter((p) => p.admin).map((p) => p.id),
    }, { quoted: m });
  } catch (err) {
    m.reply("❌ Gagal: " + err.message);
  }
};

handler.command = ["grupinfo", "infogroup", "groupinfo", "ginfo"];
handler.tags = ["group"];
handler.help = ["grupinfo"];
handler.group = true;

module.exports = handler;
