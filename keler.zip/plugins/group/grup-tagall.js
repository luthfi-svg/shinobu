let handler = async (m, { sock, text }) => {
  if (!m.isOwner && !m.isAdmin) return m.reply("Khusus admin!")

  if (!text) {
    return m.reply(`*example:*\n${m.cmd} hai semuanya`)
  }

  try {
    await sock.sendMessage(
      m.chat,
      {
        text: "@all " + text,
        contextInfo: {
          nonJidMentions: 1
        }
      },
      { quoted: null }
    )

  } catch (err) {
    console.error("Tagall error:", err)
    m.reply("Terjadi kesalahan saat mengirim tagall.")
  }
}

handler.command = ["all", "tagall"]
handler.tags = ["group"]
handler.help = ["tagall <teks>"]
handler.group = true

module.exports = handler