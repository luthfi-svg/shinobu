// plugins/grup-link.js — dari Ourin MD 3

let handler = async (m, { sock }) => {
  if (!m.isBotAdmin) return m.reply("🤖 Bot harus jadi admin!");

  try {
    const code = await sock.groupInviteCode(m.chat);
    const meta = await sock.groupMetadata(m.chat);

    const teks = `
🔗 *Link Grup*

📌 Nama: ${meta.subject}
👥 Member: ${meta.participants.length}

🔗 https://chat.whatsapp.com/${code}`;

    return m.reply(teks);
  } catch (err) {
    m.reply("❌ Gagal mengambil link grup: " + err.message);
  }
};

handler.command = ["gruplink", "linkgrup", "invitelink", "getlink"];
handler.tags = ["group"];
handler.help = ["gruplink"];
handler.group = true;
handler.botAdmin = true;

module.exports = handler;
