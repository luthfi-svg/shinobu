const axios = require("axios")

let handler = async (m) => m

let tiktokRegex = /https?:\/\/(www\.|vt\.)?tiktok\.com\/[^\s]+/i
let githubRegex = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
let npmRegex = /https?:\/\/(www\.)?npmjs\.com\/package\/[^\s]+/i
let igRegex = /https?:\/\/(www\.)?instagram\.com\/(reel|p|tv)\/[^\s]+/i

handler.before = async function (m, { sock }) {
  if (m.isCmd) return false
  if (!m.isGroup) return false
  if (!global.db.groups[m.chat]?.autodl) return false

  let text = m.text || ""
  if (!text) return false

  // ================= TIKTOK (UPDATED) =================
  if (tiktokRegex.test(text)) {
    try {
      await m.reply("Downloading TikTok...")

      let { data } = await axios.get(
        `https://api.serverweb.qzz.io/download/tiktok-v2?apikey=skyy&url=${encodeURIComponent(text.trim())}`
      )

      if (!data || !data.result) throw "API Error"

      data = data.result
      const info = data.postinfo || {}

      const caption = `*${info.username || "-"} (@${info.unique_id || "-"})*\n\n${info.media_title || ""}`

      // ===== VIDEO =====
      if (data.video_link) {
        const videoUrl = data.video_link || data.hdDownloadUrl || data.downloadUrl

        await sock.sendMessage(
          m.chat,
          { video: { url: videoUrl }, caption },
          { quoted: m }
        )

        // ===== AUDIO =====
        if (data.downloadUrl) {
          await sock.sendMessage(
            m.chat,
            {
              audio: { url: data.downloadUrl },
              mimetype: "audio/mpeg"
            },
            { quoted: m }
          )
        }

        return true
      }

      // ===== SLIDE / IMAGE =====
      if (Array.isArray(data.items) && data.items.length) {
        let album = data.items.map(img => ({
          image: { url: img },
          caption
        }))

        await sock.sendMessage(
          m.chat,
          { album },
          { quoted: m }
        )

        if (data.downloadUrl) {
          await sock.sendMessage(
            m.chat,
            {
              audio: { url: data.downloadUrl },
              mimetype: "audio/mpeg"
            },
            { quoted: m }
          )
        }

        return true
      }

      m.reply("Media tidak ditemukan.")
    } catch (e) {
      console.error("TikTok error:", e)
      m.reply("Gagal download TikTok!")
    }

    return true
  }

  // ================= INSTAGRAM =================
  if (igRegex.test(text)) {
    try {
      await m.reply("Downloading Instagram...")

      let api = `https://api.serverweb.qzz.io/download/instagram?apikey=skyy&url=${encodeURIComponent(text)}`
      let res = await fetch(api)
      let json = await res.json()

      if (!json.status) throw "API Error"

      let results = json.result

      for (let item of results) {
        await sock.sendMessage(
          m.chat,
          {
            video: { url: item.url_download },
            caption: "Instagram Downloader ✅"
          },
          { quoted: m }
        )
      }

    } catch (e) {
      console.error("IG error:", e)
      m.reply("Gagal download Instagram!")
    }

    return true
  }

  // ================= GITHUB =================
  if (githubRegex.test(text)) {
    try {
      await m.reply("Fetching github Repositori...")

      let api = `https://api.serverweb.qzz.io/download/github?apikey=skyy&url=${encodeURIComponent(text)}`
      let res = await fetch(api)
      let json = await res.json()

      if (!json.status) throw "API Error"

      let { download, filename, mimetype } = json.result

      await sock.sendMessage(
        m.chat,
        {
          document: { url: download },
          mimetype: mimetype || "application/zip",
          fileName: filename || "github.zip",
          caption: "Github Downloader ✅"
        },
        { quoted: m }
      )

    } catch (e) {
      console.error("GitHub error:", e)
      m.reply("Gagal download repository!")
    }

    return true
  }

  // ================= NPM =================
  if (npmRegex.test(text)) {
    try {
      await m.reply("Downloading NPM package...")

      let api = `https://api.serverweb.qzz.io/download/npmdl?apikey=skyy&url=${encodeURIComponent(text)}`
      let res = await fetch(api)
      let json = await res.json()

      if (!json.status) throw "API Error"

      let { download, filename, mimetype } = json.result

      await sock.sendMessage(
        m.chat,
        {
          document: { url: download },
          mimetype: mimetype || "application/gzip",
          fileName: filename || "package.tar.gz",
          caption: "NPM Downloader ✅"
        },
        { quoted: m }
      )

    } catch (e) {
      console.error("NPM error:", e)
      m.reply("Gagal download package NPM!")
    }

    return true
  }

  return false
}

module.exports = handler