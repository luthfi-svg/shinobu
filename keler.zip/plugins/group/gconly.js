const handler = async (m, { reply, args, command, usedPrefix, db }) => {
  let status = (args[0] || "").toLowerCase();
  if (!["on", "off"].includes(status)) {
    return await reply(`Contoh: ${usedPrefix + command} on/off`);
  }

  const isEnable = status === "on";
  const dbValue = isEnable ? 1 : 0;

  try {
    if (command === "pconly") {
      global.pconly = isEnable;
      await db('settings', 'bot', 'pconly', dbValue);
      if (isEnable) {
        global.gconly = false;
        await db('settings', 'bot', 'gconly', 0);
      }
    } else if (command === "gconly") {
      global.gconly = isEnable;
      await db('settings', 'bot', 'gconly', dbValue);
      if (isEnable) {
        global.pconly = false;
        await db('settings', 'bot', 'pconly', 0);
      }
    }

    await reply(`Mode *${command.toUpperCase()}* berhasil di ${isEnable ? "aktifkan" : "matikan"}`);

  } catch (e) {
    await reply('Gagal: ' + e.message);
  }
};

handler.command = ["pconly", "gconly"]
handler.tags = ["plugins"];
handler.help = "pconly", "gconly";;
handler.owner = true;

module.exports = handler;