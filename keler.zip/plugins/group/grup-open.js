let handler = async (m, { sock, command }) => {

  if (command === "close") {
    await sock.groupSettingUpdate(m.chat, "announcement")
    return m.reply("🔒 Grup berhasil ditutup!\nSekarang hanya admin yang bisa mengirim pesan.")
  }

  if (command === "open") {
    await sock.groupSettingUpdate(m.chat, "not_announcement")
    return m.reply("🔓 Grup berhasil dibuka!\nSemua member sekarang bisa mengirim pesan.")
  }
}

handler.help = ["close", "open"]
handler.tags = ["group"]
handler.command = ["close", "open"]
handler.group = true
handler.admin = true
handler.botAdmin = true

module.exports = handler