// plugins/grup-lock.js — dari Ourin MD 3

let handler = async (m, { sock, command }) => {
  if (!m.isAdmin && !m.isOwner) return m.reply("🛡️ Admin only!");
  if (!m.isBotAdmin) return m.reply("🤖 Bot harus jadi admin!");

  try {
    if (command === "lock" || command === "gruplock") {
      await sock.groupSettingUpdate(m.chat, "announcement");
      return m.reply("🔒 Grup berhasil dikunci! Hanya admin yang bisa mengirim pesan.");
    } else {
      await sock.groupSettingUpdate(m.chat, "not_announcement");
      return m.reply("🔓 Grup berhasil dibuka! Semua member bisa mengirim pesan.");
    }
  } catch (err) {
    m.reply("❌ Gagal: " + err.message);
  }
};

handler.command = ["lock", "unlock", "gruplock", "grupunlock"];
handler.tags = ["group"];
handler.help = ["lock", "unlock"];
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

module.exports = handler;
