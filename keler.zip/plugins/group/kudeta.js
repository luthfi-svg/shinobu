const { generateWAMessageFromContent } = require("dekzymarket-cyber")

global.kudetaSession = global.kudetaSession || {}

let handler = async (m, { sock, command }) => {

  // ====== COMMAND UTAMA ======
  if (command === "kudeta") {
    if (!m.isGroup) return m.reply("❌ Khusus grup!")
    if (!m.isAdmin && !m.isOwner) return m.reply("❌ Khusus admin!")
    if (!m.isBotAdmin) return m.reply("❌ Bot harus jadi admin!")

    let sessionId = Date.now().toString()
    global.kudetaSession[m.sender] = {
      id: sessionId,
      active: true
    }

    let teks = `⚠️ *Kudeta Grup*

Apakah kamu yakin ingin mengeluarkan semua member dari grup ini?

Session: ${sessionId}`

    let msg = await generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: { text: teks },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "quick_reply",
                  buttonParamsJson: JSON.stringify({
                    display_text: "🔥 Kudeta Sekarang",
                    id: `.kudeta_confirm ${sessionId}`
                  })
                },
                {
                  name: "quick_reply",
                  buttonParamsJson: JSON.stringify({
                    display_text: "❌ Batal",
                    id: `.kudeta_cancel ${sessionId}`
                  })
                }
              ]
            }
          }
        }
      }
    }, { userJid: m.sender, quoted: m })

    return await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
  }

  // ====== KONFIRMASI ======
  if (command === "kudeta_confirm") {
    let session = global.kudetaSession[m.sender]
    let inputId = m.text.split(" ")[1]

    if (!session || !session.active || session.id !== inputId) return

    session.active = false

    if (!m.isGroup) return m.reply("❌ Khusus grup!")
    if (!m.isBotAdmin) return m.reply("❌ Bot harus jadi admin!")

    let group = await sock.groupMetadata(m.chat)
    let owners = m.sender
    let jids = await sock.toPn(owners)

    let members = group.participants
      .filter(p => p.id !== owners && p.id !== jids && p.id !== m.botNumber)
      .map(p => p.id)

    if (members.length === 0) return m.reply("❌ Tidak ada member.")

    for (let user of members) {
      await sock.groupParticipantsUpdate(m.chat, [user], "remove")
      await global.sleep(4000)
    }

    return m.reply(`✅ Berhasil mengeluarkan ${members.length} member!`)
  }

  // ====== BATAL ======
  if (command === "kudeta_cancel") {
    let session = global.kudetaSession[m.sender]
    let inputId = m.text.split(" ")[1]

    if (!session || session.id !== inputId) return

    session.active = false

    return m.reply("❌ Kudeta dibatalkan.")
  }
}

handler.help = ["kudeta"]
handler.tags = ["group"]
handler.command = ["kudeta", "kudeta_confirm", "kudeta_cancel"]
handler.group = true
handler.admin = true
handler.botAdmin = true

module.exports = handler