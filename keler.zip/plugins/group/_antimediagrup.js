// plugins/_antimediagrup.js — dari Ourin MD 3
// Menangani anti-document, anti-sticker, anti-media, anti-bot dalam grup

let handler = async (m) => m;

handler.before = async function (m, { sock }) {
  if (!m.isGroup) return false;
  if (m.isAdmin || m.isOwner) return false;

  const cfg = global.db.groups?.[m.chat] || {};
  const mtype = m.mtype || "";

  // Anti Document
  if (cfg.antidocument && mtype === "documentMessage") {
    try {
      await sock.sendMessage(m.chat, {
        delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.sender },
      });
      await sock.sendMessage(m.chat, {
        text: `⚠ *AntiDokumen* — @${m.sender.split("@")[0]} mengirim dokumen. Dihapus.`,
        mentions: [m.sender],
      });
    } catch {}
    return true;
  }

  // Anti Sticker
  if (cfg.antisticker && mtype === "stickerMessage") {
    try {
      await sock.sendMessage(m.chat, {
        delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.sender },
      });
      await sock.sendMessage(m.chat, {
        text: `⚠ *AntiStiker* — @${m.sender.split("@")[0]} mengirim stiker. Dihapus.`,
        mentions: [m.sender],
      });
    } catch {}
    return true;
  }

  // Anti Media (image/video/audio)
  if (
    cfg.antimedia &&
    /imageMessage|videoMessage|audioMessage/.test(mtype)
  ) {
    try {
      await sock.sendMessage(m.chat, {
        delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.sender },
      });
      await sock.sendMessage(m.chat, {
        text: `⚠ *AntiMedia* — @${m.sender.split("@")[0]} mengirim media. Dihapus.`,
        mentions: [m.sender],
      });
    } catch {}
    return true;
  }

  // Anti Bot
  if (cfg.antibot && m.isBaileys) {
    try {
      await sock.groupParticipantsUpdate(m.chat, [m.sender], "remove");
      await sock.sendMessage(m.chat, {
        text: `🤖 *AntiBot* — @${m.sender.split("@")[0]} terdeteksi sebagai bot dan di-kick.`,
        mentions: [m.sender],
      });
    } catch {}
    return true;
  }

  return false;
};

handler.group = true;
module.exports = handler;
