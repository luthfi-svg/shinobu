// plugins/grup-name.js — dari Ourin MD 3

let handler = async (m, { sock, text }) => {
  if (!m.isAdmin && !m.isOwner) return m.reply("🛡️ Admin only!");
  if (!m.isBotAdmin) return m.reply("🤖 Bot harus jadi admin!");
  if (!text) return m.reply(`*Contoh:*\n${m.cmd} Nama Grup Baru`);

  try {
    await sock.groupUpdateSubject(m.chat, text);
    return m.reply(`✅ Nama grup berhasil diubah menjadi *${text}*`);
  } catch (err) {
    m.reply("❌ Gagal mengubah nama grup: " + err.message);
  }
};

handler.command = ["setname", "namagrup", "grupname", "rename"];
handler.tags = ["group"];
handler.help = ["setname <nama baru>"];
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

module.exports = handler;
