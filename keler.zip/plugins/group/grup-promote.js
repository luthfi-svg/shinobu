let handler = async (m, { sock, text, command }) => {
  if (!m.isOwner && !m.isAdmin) return m.reply("Khusus admin!")

  let target

  // Ambil target dari tag
  if (m.mentionedJid && m.mentionedJid[0]) {
    target = m.mentionedJid[0]

  // Ambil dari reply
  } else if (m.quoted && m.quoted.sender) {
    target = m.quoted.sender

  // Ambil dari nomor
  } else if (text) {
    const cleaned = text.replace(/[^0-9]/g, "")
    if (cleaned) target = cleaned + "@s.whatsapp.net"
  }

  if (!target) {
    return m.reply(`*example:*\n${m.cmd} @user`)
  }

  try {
    if (command === "promote" || command === "naik") {
      await sock.groupParticipantsUpdate(m.chat, [target], "promote")
      m.reply("Berhasil menjadikan admin!")

    } else if (command === "demote" || command === "turun") {
      await sock.groupParticipantsUpdate(m.chat, [target], "demote")
      m.reply("Berhasil menurunkan admin!")
    }
  } catch (err) {
    console.error("Promote/Demote error:", err)
    m.reply("Gagal mengubah status admin. Cek hak akses bot.")
  }
}

handler.command = ["promote", "demote", "naik", "turun"]
handler.tags = ["group"]
handler.help = [
  "promote @user / nomor",
  "demote @user / nomor"
]
handler.group = true
handler.botAdmin = true

module.exports = handler