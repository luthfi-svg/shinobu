let handler = async (m) => m

let linkRegex = /https?:\/\/chat\.whatsapp\.com\/\S+|https?:\/\/whatsapp\.com\/channel\/\S+/i

handler.before = async function (m, { sock }) {

  let isLink = linkRegex.test(m.text || "")
  if (!isLink) return false
  if (!global.db.groups[m.chat]?.antilink) return false
  if (m.isAdmin || m.isOwner) return false

  try {
            const messageId = m.key.id
        const participantToDelete = m.key.participant || m.sender
        await sock.sendMessage(m.chat, {
            delete: {
                remoteJid: m.chat,
                fromMe: false,
                id: messageId,
                participant: participantToDelete
            }
        })
  } catch (err) {
    console.error("Antilink error:", err)
  }

  return true
}

handler.group = true
handler.botAdmin = true

module.exports = handler