let handler = async (m, { text }) => {
  if (!m.isOwner && !m.isAdmin) return m.reply("Khusus admin!")

  if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {}

  const status = global.db.groups[m.chat]?.welcome ? "Aktif ✅" : "Tidak Aktif ❌"

  if (!text) {
    return m.reply(`*example:*\n${m.cmd} on/off

- Group: ${m?.metadata?.subject || "Unknown"}
- Welcome Status: ${status}
`)
  }

  if (/on/i.test(text)) {
    global.db.groups[m.chat].welcome = true
    m.reply(`✅ Welcome berhasil diaktifkan di grup ${m.metadata?.subject || "Unknown"}`)
  } else if (/off/i.test(text)) {
    global.db.groups[m.chat].welcome = false
    m.reply(`❌ Welcome berhasil dimatikan di grup ${m.metadata?.subject || "Unknown"}`)
  } else {
    m.reply("Opsi Tidak Valid!\nGunakan on / off")
  }
}

handler.command = ["welcome"]
handler.tags = ["group"]
handler.help = ["welcome on/off"]
handler.group = true

module.exports = handler