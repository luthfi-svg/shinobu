// plugins/grup-desc.js — dari Ourin MD 3

let handler = async (m, { sock, text }) => {
  if (!m.isAdmin && !m.isOwner) return m.reply("🛡️ Admin only!");
  if (!m.isBotAdmin) return m.reply("🤖 Bot harus jadi admin!");

  if (text) {
    // Set deskripsi
    try {
      await sock.groupUpdateDescription(m.chat, text);
      return m.reply("✅ Deskripsi grup berhasil diperbarui!");
    } catch (err) {
      return m.reply("❌ Gagal mengubah deskripsi: " + err.message);
    }
  }

  // Tampilkan deskripsi
  const meta = await sock.groupMetadata(m.chat);
  const desc = meta.desc || "Belum ada deskripsi.";
  return m.reply(`📋 *Deskripsi Grup*\n\n${desc}`);
};

handler.command = ["desc", "setdesc", "grupdes"];
handler.tags = ["group"];
handler.help = ["desc", "setdesc <teks>"];
handler.group = true;
handler.botAdmin = true;

module.exports = handler;
