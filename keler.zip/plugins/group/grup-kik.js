let handler = async (m, { sock, text }) => {
  if (!m.isOwner && !m.isAdmin) return m.reply("Khusus admin!")

  let target

  // Ambil target dari tag
  if (m.mentionedJid && m.mentionedJid[0]) {
    target = m.mentionedJid[0]

  // Ambil dari reply
  } else if (m.quoted && m.quoted.sender) {
    target = m.quoted.sender

  // Ambil dari nomor
  } else if (text) {
    const cleaned = text.replace(/[^0-9]/g, "")
    if (cleaned) target = cleaned + "@s.whatsapp.net"
  }

  if (!target) {
    return m.reply(`*example:*\n${m.cmd} @user`)
  }

  try {
    await sock.groupParticipantsUpdate(m.chat, [target], "remove")
  } catch (err) {
    console.error("Kick error:", err)
    m.reply("Gagal mengeluarkan anggota. Coba lagi atau cek hak akses bot.")
  }
}

handler.command = ["kick", "kik"]
handler.tags = ["group"]
handler.help = ["kick @user / nomor"]
handler.group = true
handler.botAdmin = true

module.exports = handler