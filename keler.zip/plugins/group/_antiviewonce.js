// plugins/_antiviewonce.js — dari Ourin MD 3
const { downloadContentFromMessage } = require("dekzymarket-cyber");

let handler = async (m) => m;

handler.before = async function (m, { sock }) {
  if (!m.isGroup) return false;
  if (!global.db.groups[m.chat]?.antiviewonce) return false;
  if (m.isAdmin || m.isOwner) return false;

  const msg = m.message;
  const isVO =
    m.mtype === "viewOnceMessage" ||
    m.mtype === "viewOnceMessageV2" ||
    msg?.viewOnceMessage ||
    msg?.viewOnceMessageV2;

  if (!isVO) return false;

  try {
    const inner =
      msg?.viewOnceMessage?.message ||
      msg?.viewOnceMessageV2?.message ||
      msg;

    const innerType = Object.keys(inner || {}).find(
      (k) => k !== "messageContextInfo"
    );
    if (!innerType) return false;

    const media = inner[innerType];
    const type = media.mimetype?.split("/")[0] || "image";

    const stream = await downloadContentFromMessage(media, type);
    let buffer = Buffer.from([]);
    for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);

    const caption = `👁️ *ViewOnce* — Dari @${m.sender.split("@")[0]}`;

    if (type === "video") {
      await sock.sendMessage(
        m.chat,
        { video: buffer, caption },
        { quoted: m }
      );
    } else if (type === "image") {
      await sock.sendMessage(
        m.chat,
        { image: buffer, caption },
        { quoted: m }
      );
    } else if (type === "audio") {
      await sock.sendMessage(
        m.chat,
        { audio: buffer, mimetype: "audio/mpeg", ptt: true },
        { quoted: m }
      );
    }
  } catch (e) {
    console.error("AntiViewOnce error:", e);
  }

  return false;
};

handler.group = true;
module.exports = handler;
