// plugins/stalker-tiktok.js — dari Ourin MD 3
const axios = require("axios");

let handler = async (m, { sock }) => {
  const username = (m.text || "").replace("@", "").trim();
  if (!username) return m.reply(
    `🎵 *ᴛɪᴋᴛᴏᴋ sᴛᴀʟᴋᴇʀ*\n\n> ${m.cmd} <username>\n\n*Contoh:*\n> ${m.cmd} charlidamelio`
  );

  await m.react("🔍");

  try {
    const { data } = await axios.get(
      `https://api.nexray.eu.cc/stalk/tiktok?username=${encodeURIComponent(username)}`,
      { timeout: 15000 }
    );

    const r = data?.result || data;
    if (!r?.nickname) throw new Error("User tidak ditemukan");

    const teks =
      `🎵 *TikTok Stalker*\n\n` +
      `╭┈┈⬡「 👤 *PROFIL* 」\n` +
      `┃ 📛 Username: *@${r.uniqueId || username}*\n` +
      `┃ 🔤 Nama: *${r.nickname || "-"}*\n` +
      `┃ 📝 Bio: ${r.signature || "-"}\n` +
      `┃ ✅ Verified: ${r.verified ? "Ya ✓" : "Tidak"}\n` +
      `╰┈┈⬡\n\n` +
      `╭┈┈⬡「 📊 *STATISTIK* 」\n` +
      `┃ 🎥 Video: *${(r.videoCount || 0).toLocaleString("id-ID")}*\n` +
      `┃ ❤️ Likes: *${(r.heartCount || r.diggCount || 0).toLocaleString("id-ID")}*\n` +
      `┃ 👥 Followers: *${(r.followerCount || 0).toLocaleString("id-ID")}*\n` +
      `┃ 👣 Following: *${(r.followingCount || 0).toLocaleString("id-ID")}*\n` +
      `╰┈┈⬡\n\n` +
      `🔗 https://tiktok.com/@${r.uniqueId || username}`;

    const ppUrl = r.avatarLarger || r.avatar || r.avatarMedium;
    if (ppUrl) {
      const ppBuf = await axios.get(ppUrl, { responseType: "arraybuffer", timeout: 8000 })
        .then(r => Buffer.from(r.data)).catch(() => null);
      if (ppBuf) {
        await sock.sendMessage(m.chat, { image: ppBuf, caption: teks }, { quoted: m });
        return await m.react("✅");
      }
    }
    await m.reply(teks);
    await m.react("✅");
  } catch (err) {
    await m.react("❌");
    m.reply(`❌ Gagal stalk TikTok: ${err.message}`);
  }
};

handler.command = ["tiktokstalk", "ttstalk", "stalktt"];
handler.tags = ["search"];
handler.help = ["tiktokstalk <username>"];
module.exports = handler;
