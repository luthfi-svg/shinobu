// plugins/profil.js — dari Ourin MD 3

let handler = async (m, { sock }) => {
  const target = m.mentionedJid?.[0] || m.quoted?.sender || m.sender;
  const user = global.db?.users?.[target] || {};
  const settings = global.db?.settings || {};

  const isPrem =
    m.isOwner ||
    (settings.premium || []).some((p) => (typeof p === "string" ? p : p.id) === target) ||
    (settings.partner || []).some((p) => (typeof p === "string" ? p : p.id) === target);

  const isOwnerUser = (settings.owner || []).some(
    (o) => (typeof o === "string" ? o : o.id || o) === target
  ) || target.split("@")[0] === global.owner;

  const badge = isOwnerUser ? "👑 Owner" : isPrem ? "💎 Premium" : "👤 Regular";
  const energiMax = isPrem ? (global.energiPremium || 500) : (global.energiDefault || 50);

  let pp = global.thumbnail;
  try {
    pp = await sock.profilePictureUrl(target, "image");
  } catch {}

  const teks = `
👤 *Profil User*

📛 Nama: ${user.name || m.pushName || "Unknown"}
📱 Nomor: +${target.split("@")[0]}
🎖 Status: ${badge}
✅ Terdaftar: ${user.registered ? "Ya" : "Tidak"}

💰 *Ekonomi*
🪙 Koin: ${global.toRupiah(user.koin || 0)}
📈 XP: ${global.toRupiah(user.exp || 0)}
⚡ Energi: ${user.energi ?? energiMax}/${energiMax}`;

  await sock.sendMessage(m.chat, {
    image: { url: pp },
    caption: teks,
    mentions: [target],
  }, { quoted: m });
};

handler.command = ["profil", "profile", "biodata", "myprofile"];
handler.tags = ["user"];
handler.help = ["profil", "profil @tag"];

module.exports = handler;
