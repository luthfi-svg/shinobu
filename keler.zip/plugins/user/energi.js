// plugins/energi.js — Sistem Energi/Limit dari Ourin MD 3

let handler = async (m, { sock, text, command, isOwner }) => {
  const ownerOnlyCmds = ["addlimit","addenergy","resetlimit","resetenergy","setenergy","setlimit"];
  if (ownerOnlyCmds.includes(command) && !isOwner) return;

  const settings = global.db.settings || {};

  switch (command) {

    case "energi":
    case "limit":
    case "ceklimit": {
      const user = global.db.users?.[m.sender] || {};
      const max = m.isPremium
        ? (global.energiPremium || 500)
        : (global.energiDefault || 50);
      const sisa = user.energi ?? max;

      const teks = `
⚡ *Cek Energi/Limit*

👤 Nama: ${m.pushName || "-"}
💎 Status: ${m.isPremium ? "Premium" : "Regular"}
⚡ Energi: ${sisa}/${max}

_Energi reset setiap tengah malam_`;
      return m.reply(teks);
    }

    case "addlimit":
    case "addenergy": {
      if (!text) return m.reply(`*Contoh:*\n${m.cmd} @user 100`);

      const args = text.split(" ");
      const targetJid = m.mentionedJid?.[0] || args[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net";
      const amount = parseInt(args[1] || args[0]) || 50;

      if (!global.db.users[targetJid]) global.db.users[targetJid] = { energi: 0 };
      global.db.users[targetJid].energi = (global.db.users[targetJid].energi || 0) + amount;

      return sock.sendMessage(m.chat, {
        text: `✅ Berhasil menambah energi +${amount} ke @${targetJid.split("@")[0]}`,
        mentions: [targetJid],
      }, { quoted: m });
    }

    case "resetlimit":
    case "resetenergy": {

      // Reset semua user
      for (const jid in global.db.users) {
        const u = global.db.users[jid];
        const max = u.isPremium
          ? (global.energiPremium || 500)
          : (global.energiDefault || 50);
        u.energi = max;
        u.lastReset = Date.now();
      }

      return m.reply("✅ Berhasil reset energi semua user!");
    }

    case "setenergy":
    case "setlimit": {
      if (!text) return m.reply(`*Contoh:*\n${m.cmd} 50`);

      const amount = parseInt(text);
      if (isNaN(amount)) return m.reply("Masukkan angka yang valid!");

      global.energiDefault = amount;
      return m.reply(`✅ Energi default diset ke *${amount}*/hari`);
    }
  }
};

handler.command = [
  "energi", "limit", "ceklimit",
  "addlimit", "addenergy",
  "resetlimit", "resetenergy",
  "setenergy", "setlimit",
];
handler.tags = ["user"];
handler.help = [
  "energi",
  "addlimit @user <jumlah>",
  "resetlimit",
  "setenergy <jumlah>",
];

module.exports = handler;
