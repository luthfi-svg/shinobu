// plugins/fun-jodoh.js — dari Ourin MD 3

const loveQuotes = [
  "Cinta sejati tidak pernah mengenal jarak 💕",
  "Dua hati yang bersatu takkan terpisahkan 💗",
  "Kalian seperti puzzle yang sempurna 🧩",
  "Match made in heaven! ✨",
  "Chemistry-nya kuat banget! 🔥",
  "Couple goals banget sih kalian 💑",
  "Destiny brought you together 🌟",
  "Perfect match detected! 💘",
];

const compatibilityEmoji = (p) => {
  if (p >= 90) return "💕💕💕💕💕";
  if (p >= 70) return "💕💕💕💕";
  if (p >= 50) return "💕💕💕";
  if (p >= 30) return "💕💕";
  return "💕";
};

const compatibilityText = (p) => {
  if (p >= 90) return "JODOH SEJATI! 💍";
  if (p >= 70) return "Sangat Cocok! 💖";
  if (p >= 50) return "Lumayan Cocok 💗";
  if (p >= 30) return "Bisa Dicoba 💓";
  return "Butuh Usaha Lebih 💔";
};

const progressBar = (p) => {
  const filled = Math.floor(p / 10);
  return "█".repeat(filled) + "░".repeat(10 - filled);
};

let handler = async (m, { sock }) => {
  if (!m.isGroup) return m.reply("👥 Hanya bisa di grup!");

  const botNumber = sock.user?.id?.split(":")[0] + "@s.whatsapp.net";
  const meta = m.metadata || await sock.groupMetadata(m.chat).catch(() => ({ participants: [] }));
  const members = (meta.participants || [])
    .map((p) => p.id || p.jid)
    .filter((j) => j && j !== botNumber && j !== m.sender);

  if (members.length < 1) return m.reply("❌ Member grup kurang buat dijodohkan!");

  const target = members[Math.floor(Math.random() * members.length)];
  const compat = Math.floor(Math.random() * 100) + 1;
  const quote = loveQuotes[Math.floor(Math.random() * loveQuotes.length)];

  const text =
`💘 *ᴊᴏᴅᴏʜ ʀᴀɴᴅᴏᴍ*

╭┈┈⬡「 💑 *ᴘᴀsᴀɴɢᴀɴ* 」
┃ 👨 @${m.sender.split("@")[0]}
┃ ❤️
┃ 👩 @${target.split("@")[0]}
╰┈┈⬡

╭┈┈⬡「 📊 *ᴋᴇᴄᴏᴄᴏᴋᴀɴ* 」
┃ ${progressBar(compat)} *${compat}%*
┃ ${compatibilityEmoji(compat)}
┃ Status: *${compatibilityText(compat)}*
╰┈┈⬡

> _"${quote}"_`;

  await m.react("💕");
  await sock.sendMessage(m.chat, { text, mentions: [m.sender, target] }, { quoted: m });
};

handler.command = ["jodoh", "ship", "shipcouple"];
handler.tags = ["fun"];
handler.help = ["jodoh"];
handler.group = true;
module.exports = handler;
