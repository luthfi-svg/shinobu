// plugins/fun-cekjodoh.js — dari Ourin MD 3

const desc = (p) => {
  if (p >= 90) return "Jodoh banget! Langsung nikah aja! 💍";
  if (p >= 70) return "Cocok banget! 💕";
  if (p >= 50) return "Lumayan cocok~ 😊";
  if (p >= 30) return "Hmm, perlu usaha lebih 🤔";
  return "Mungkin cari yang lain? 😅";
};

let handler = async (m, { sock }) => {
  const text = (m.text || "").trim();

  // Mode @tag + @tag
  if (m.mentionedJid?.length >= 2) {
    const [p1, p2] = m.mentionedJid;
    const compat = Math.floor(Math.random() * 101);
    const bar = "█".repeat(Math.floor(compat / 10)) + "░".repeat(10 - Math.floor(compat / 10));
    return sock.sendMessage(m.chat, {
      text: `💕 *ᴄᴇᴋ ᴊᴏᴅᴏʜ*\n\n╭┈┈⬡\n┃ 👤 @${p1.split("@")[0]}\n┃ ❤️\n┃ 👤 @${p2.split("@")[0]}\n╰┈┈⬡\n\n${bar} *${compat}%*\n_${desc(compat)}_`,
      mentions: [p1, p2],
    }, { quoted: m });
  }

  // Mode nama & nama
  const parts = text.split(/[&,]/).map((s) => s.trim()).filter(Boolean);
  if (parts.length >= 2) {
    const compat = Math.floor(Math.random() * 101);
    const bar = "█".repeat(Math.floor(compat / 10)) + "░".repeat(10 - Math.floor(compat / 10));
    return m.reply(
      `💕 *ᴄᴇᴋ ᴊᴏᴅᴏʜ*\n\n╭┈┈⬡\n┃ 👤 ${parts[0]}\n┃ ❤️\n┃ 👤 ${parts[1]}\n╰┈┈⬡\n\n${bar} *${compat}%*\n_${desc(compat)}_`
    );
  }

  return m.reply(`💕 *ᴄᴇᴋ ᴊᴏᴅᴏʜ*\n\n*Contoh:*\n> ${m.cmd} Budi & Ani\n> ${m.cmd} @tag1 @tag2`);
};

handler.command = ["cekjodoh", "matchlove", "lovemeter"];
handler.tags = ["fun"];
handler.help = ["cekjodoh Budi & Ani", "cekjodoh @tag1 @tag2"];
module.exports = handler;
