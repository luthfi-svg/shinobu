// plugins/fun-primbon.js — Primbon dari Ourin MD 3
const axios = require("axios");

const ZODIAK = {
  aries:       { date: "21 Mar - 19 Apr", element: "Api 🔥",  stone: "Berlian 💎",  color: "Merah ❤️",  lucky: "1, 8, 17" },
  taurus:      { date: "20 Apr - 20 Mei", element: "Tanah 🌍", stone: "Zamrud 💚",   color: "Hijau 💚",   lucky: "2, 6, 9" },
  gemini:      { date: "21 Mei - 20 Jun", element: "Udara 💨", stone: "Agat 🪨",    color: "Kuning 💛",  lucky: "3, 12, 21" },
  cancer:      { date: "21 Jun - 22 Jul", element: "Air 💧",  stone: "Ruby 🔴",    color: "Putih ⚪",  lucky: "2, 7, 11" },
  leo:         { date: "23 Jul - 22 Ags", element: "Api 🔥",  stone: "Kuarsa 🟡",  color: "Emas 🟡",   lucky: "1, 3, 10" },
  virgo:       { date: "23 Ags - 22 Sep", element: "Tanah 🌍", stone: "Safir 💙",   color: "Coklat 🟤",  lucky: "5, 14, 23" },
  libra:       { date: "23 Sep - 22 Okt", element: "Udara 💨", stone: "Opal 🌈",    color: "Biru 💙",   lucky: "4, 6, 13" },
  scorpio:     { date: "23 Okt - 21 Nov", element: "Air 💧",  stone: "Topaz 🟠",   color: "Hitam ⚫",  lucky: "1, 9, 18" },
  sagittarius: { date: "22 Nov - 21 Des", element: "Api 🔥",  stone: "Turquoise 🩵",color: "Ungu 💜",   lucky: "3, 7, 15" },
  capricorn:   { date: "22 Des - 19 Jan", element: "Tanah 🌍", stone: "Garnet 🔴",  color: "Abu 🩶",    lucky: "2, 4, 8" },
  aquarius:    { date: "20 Jan - 18 Feb", element: "Udara 💨", stone: "Ametis 💜",  color: "Biru Muda 🩵",lucky: "4, 7, 11" },
  pisces:      { date: "19 Feb - 20 Mar", element: "Air 💧",  stone: "Aquamarine 💎",color: "Hijau Laut 🩵",lucky: "3, 9, 12" },
};

const RAMALAN = [
  "Hari ini energi positif mengalir deras ke arahmu! ✨",
  "Peluang besar menanti, jangan lewatkan! 💫",
  "Waktunya introspeksi dan merenung 🌙",
  "Hubunganmu dengan orang sekitar akan semakin erat 💕",
  "Rezeki datang dari arah tak terduga! 💰",
  "Tetap sabar, semuanya akan indah pada waktunya 🌸",
  "Hati-hati dalam mengambil keputusan penting hari ini ⚠️",
  "Kreativitasmu sedang di puncak, manfaatkan! 🎨",
  "Seseorang spesial akan hadir dalam hidupmu 💖",
  "Jaga kesehatan, istirahat yang cukup! 🌙",
];

let handler = async (m, { command, text }) => {

  // ── Zodiak ──────────────────────────
  if (command === "zodiak") {
    const sign = (text || "").toLowerCase().trim();
    const data = ZODIAK[sign];

    if (!sign) {
      const list = Object.keys(ZODIAK).join(", ");
      return m.reply(`♈ *ᴢᴏᴅɪᴀᴋ*\n\n> Masukkan tanda zodiak!\n\n*Zodiak tersedia:*\n${list}\n\n*Contoh:*\n> ${m.cmd} aries`);
    }
    if (!data) return m.reply(`❌ Zodiak *${sign}* tidak dikenal!\n\nCoba: aries, taurus, gemini, cancer, leo, virgo, libra, scorpio, sagittarius, capricorn, aquarius, pisces`);

    const ramalan = RAMALAN[Math.floor(Math.random() * RAMALAN.length)];
    const love = Math.floor(Math.random() * 101);
    const work = Math.floor(Math.random() * 101);
    const health = Math.floor(Math.random() * 101);

    return m.reply(
      `♈ *${sign.toUpperCase()}*\n\n` +
      `╭┈┈⬡「 📅 *INFO* 」\n` +
      `┃ 📆 Tanggal: ${data.date}\n` +
      `┃ 🌊 Elemen: ${data.element}\n` +
      `┃ 💎 Batu: ${data.stone}\n` +
      `┃ 🎨 Warna: ${data.color}\n` +
      `┃ 🍀 Lucky: ${data.lucky}\n` +
      `╰┈┈⬡\n\n` +
      `╭┈┈⬡「 🔮 *RAMALAN HARI INI* 」\n` +
      `┃ ❤️ Cinta: ${"█".repeat(Math.floor(love/10))}░${"".repeat(0)} *${love}%*\n` +
      `┃ 💼 Karir: ${"█".repeat(Math.floor(work/10))}░${"".repeat(0)} *${work}%*\n` +
      `┃ 💪 Sehat: ${"█".repeat(Math.floor(health/10))}░${"".repeat(0)} *${health}%*\n` +
      `╰┈┈⬡\n\n` +
      `> 🔮 ${ramalan}`
    );
  }

  // ── Tafsir Mimpi ─────────────────────
  if (command === "tafsirmimpi" || command === "mimpi") {
    if (!text) return m.reply(`😴 *ᴛᴀꜰsɪʀ ᴍɪᴍᴘɪ*\n\n> Ceritakan mimpimu!\n\n*Contoh:*\n> ${m.cmd} mimpi terbang`);

    const tafsir = [
      `Mimpi tentang *${text}* menandakan akan ada perubahan besar dalam hidupmu! ✨`,
      `Mimpi *${text}* merupakan tanda akan datangnya rezeki yang tidak terduga 💰`,
      `Mimpi *${text}* menunjukkan bahwa kamu sedang diuji kesabaranmu, tetap kuat! 💪`,
      `Mimpi *${text}* adalah pertanda baik, sesuatu yang kamu tunggu akan segera terwujud 🌟`,
      `Mimpi *${text}* menandakan seseorang rindu padamu dari jauh 💕`,
      `Mimpi *${text}* berarti kamu perlu lebih memperhatikan orang-orang terdekatmu 🤗`,
      `Mimpi *${text}* menandakan ada masalah yang perlu segera kamu selesaikan 🔧`,
      `Mimpi *${text}* adalah sinyal bahwa intuisimu sedang tajam, percayai dirimu! 🧠`,
    ];
    const result = tafsir[Math.floor(Math.random() * tafsir.length)];
    return m.reply(`😴 *ᴛᴀꜰsɪʀ ᴍɪᴍᴘɪ*\n\n> Mimpi: _${text}_\n\n${result}`);
  }

  // ── Nomor Hoki ───────────────────────
  if (command === "nomorhoki" || command === "luckynum") {
    const nums = Array.from({ length: 7 }, () => Math.floor(Math.random() * 99) + 1);
    const lucky4D = Array.from({ length: 4 }, () => Math.floor(Math.random() * 10)).join("");
    return m.reply(
      `🍀 *ɴᴏᴍᴏʀ ʜᴏᴋɪ*\n\n` +
      `╭┈┈⬡\n` +
      `┃ 🎯 Lucky 2D: *${nums[0]}-${nums[1]}*\n` +
      `┃ 🎯 Lucky 3D: *${nums[2]}-${nums[3]}-${nums[4]}*\n` +
      `┃ 🎯 Lucky 4D: *${lucky4D}*\n` +
      `┃ 🍀 Lucky Set: *${nums.join(", ")}*\n` +
      `╰┈┈⬡\n\n` +
      `> _Semoga hoki ya!_ 🤞`
    );
  }
};

handler.command = ["zodiak", "tafsirmimpi", "mimpi", "nomorhoki", "luckynum"];
handler.tags = ["fun"];
handler.help = ["zodiak <tanda>", "tafsirmimpi <cerita>", "nomorhoki"];
module.exports = handler;
