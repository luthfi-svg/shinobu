// plugins/fun-pertanyaan.js — Tanya Bot dari Ourin MD 3.1
// akankah, apakah, dimana, kapan, mengapa, bagaimana, berapa, bisakah, haruskah, siapa

const ANSWERS = {
  akankah: [
    "Ya, pasti akan terjadi!", "Tidak, sepertinya tidak akan.", "Mungkin akan, mungkin tidak.",
    "InsyaAllah akan terjadi!", "Hmm, sulit diprediksi.", "Pasti! Yakin saja!",
    "Kayaknya nggak deh.", "Akan terjadi kalau kamu mau berusaha.", "Suatu saat nanti, pasti.",
    "Nggak akan, maaf.", "Tentu akan! Tunggu saja!", "Hmm, aku ragu.",
    "Akan! Percaya sama proses!", "Kemungkinannya kecil.", "Pasti akan, aku yakin!",
    "Nggak akan, cari yang lain aja.", "Akan, tapi butuh waktu.", "InsyaAllah!",
    "Kalau jodoh, pasti akan.", "Akan terjadi di saat yang tepat!",
  ],
  apakah: [
    "Ya, tentu saja!", "Tidak, sepertinya tidak.", "Mungkin saja, coba lagi nanti.",
    "Hmm... aku rasa iya.", "Aku ragu, tapi bisa jadi.", "Pasti! 100%!",
    "Tidak mungkin.", "Bisa jadi, siapa yang tau?", "Menurutku sih iya.",
    "Wah, kayaknya nggak deh.", "Tentu, kenapa tidak?", "Aku nggak tau, coba tanya yang lain.",
    "Ya ampun, pasti lah!", "Hmm... sepertinya tidak.", "Aku yakin iya!",
    "Nggak mungkin banget.", "Mungkin, tapi jangan berharap terlalu tinggi.", "Iya dong!",
    "Nggak, maaf ya.", "Bisa! Semangat!",
  ],
  dimana: [
    "Di dekatmu!", "Jauh di sana.", "Di tempat yang tidak kamu duga.", "Di hatimu.",
    "Di sekitar sini.", "Hmm, coba cari di kamar.", "Di luar sana, menunggumu.",
    "Di tempat yang sama denganmu.", "Di suatu tempat yang indah.", "Di balik pintu.",
    "Di sebelah kirimu.", "Di depan matamu!", "Jauh banget, di luar negeri mungkin?",
    "Di tempat yang penuh kenangan.", "Di mana-mana!", "Di dunia maya.",
    "Di alam mimpi.", "Di tempat rahasia.", "Hmm, susah dijelaskan lokasinya.",
    "Di tempat yang akan membuatmu bahagia.",
  ],
  kapan: [
    "Besok mungkin?", "Tahun depan kayaknya.", "3 hari lagi!", "Hmm, masih lama sih.",
    "Sebentar lagi kok!", "Kalau sudah waktunya, pasti terjadi.", "Bulan depan!",
    "Entah kapan, yang penting sabar.", "Dalam waktu dekat!", "10 tahun lagi mungkin?",
    "Nggak lama lagi!", "Kalau jodoh, pasti ketemu.", "Hmm, susah diprediksi.",
    "Minggu depan!", "Kalau usahanya lebih keras, lebih cepat!", "Pas waktunya tepat.",
    "Secepatnya, tenang aja.", "Ntar kalo udah siap.", "Dalam hitungan hari!",
    "Saat kamu sudah siap menerimanya.",
  ],
  mengapa: [
    "Karena memang sudah takdirnya begitu.", "Hmm, pertanyaan bagus! Aku juga bingung.",
    "Karena itulah cara kerjanya.", "Karena Tuhan berkehendak demikian.",
    "Aku nggak tau, cari di Google aja.", "Karena ya gitu aja.", "Mungkin karena kebetulan?",
    "Karena dunia memang penuh misteri.", "Hmm, sulit dijelaskan sih.",
    "Karena alam semesta bekerja dengan cara yang misterius.", "Aku juga penasaran, kenapa ya?",
    "Karena hal tersebut memang seharusnya terjadi.",
    "Pertanyaan yang bagus! Sayangnya aku nggak punya jawabannya.",
    "Karena itulah keunikan hidup.", "Karena setiap hal punya alasannya masing-masing.",
    "Hmm... aku butuh waktu untuk memikirkannya.", "Karena begitulah logikanya.",
    "Aku rasa karena memang harus begitu.", "Karena segala sesuatu saling berhubungan.",
    "Nah itu aku juga mikir!",
  ],
  bagaimana: [
    "Dengan usaha dan doa.", "Pelan-pelan saja, jangan terburu-buru.", "Caranya unik, coba eksplorasi sendiri.",
    "Ikuti alurnya saja.", "Dengan cara yang tidak terduga.", "Step by step pasti bisa.",
    "Coba tanya orang yang lebih ahli.", "Dengan kesabaran ekstra.", "Mudah saja, percaya diri aja.",
    "Ikuti kata hatimu.", "Dengan banyak belajar dan mencoba.", "Hmm, butuh strategi khusus.",
    "Santai aja, nanti ketemu jalannya.", "Dengan kerja sama yang baik.", "Coba dari hal kecil dulu.",
    "Caranya ada di dalam dirimu sendiri.", "Dengan tekad yang kuat.", "Ikuti instingmu.",
    "Perlahan tapi pasti.", "Dengan niat yang tulus.",
  ],
  berapa: [
    "Sedikit saja, jangan khawatir.", "Banyak banget!", "Lumayan, tapi worth it.",
    "Cuma sedikit kok.", "Bisa jadi banyak, bisa jadi sedikit.", "Pas-pasan aja.",
    "Lebih dari yang kamu kira!", "Nggak terlalu banyak.", "Sangat banyak, hati-hati.",
    "Secukupnya saja.", "Hmm, sulit dihitung pastinya.", "Mungkin sekitar setengahnya.",
    "Lebih sedikit dari ekspektasimu.", "Banyak sekali, sampai nggak terhitung.",
    "Hanya beberapa saja.", "Tergantung usahamu.", "Cukup untuk membuatmu senang.",
    "Sangat sedikit, tapi berkualitas.", "Melimpah!", "Pas kebutuhan saja.",
  ],
  bisakah: [
    "Bisa, kalau kamu mau usaha!", "Sayangnya tidak bisa.", "Tentu bisa, kenapa tidak?",
    "Mungkin bisa dengan bantuan orang lain.", "Bisa banget!", "Hmm, agak sulit sih.",
    "Pasti bisa kalau yakin!", "Nggak bisa, maaf ya.", "Coba saja, siapa tau bisa.",
    "Bisa, asal sabar.", "Tentu saja bisa!", "Aku ragu kamu bisa.",
    "Bisa, percaya pada dirimu sendiri.", "Sangat mungkin bisa.", "Bisa kok, jangan menyerah!",
    "Hmm, kemungkinan kecil.", "Bisa banget asal niat.", "Coba dulu, baru tau bisa atau tidak.",
    "Bisa, dengan kerja keras.", "Yakin bisa!",
  ],
  haruskah: [
    "Ya, sebaiknya begitu.", "Tidak harus, terserah kamu.", "Sebaiknya iya, demi kebaikanmu.",
    "Nggak perlu juga sih.", "Iya, supaya lebih baik.", "Tergantung situasinya.",
    "Sebaiknya dipikirkan dulu.", "Tidak wajib, tapi disarankan.", "Ya, demi masa depanmu.",
    "Nggak harus, tapi boleh.", "Iya, supaya tidak menyesal.", "Tidak perlu terburu-buru.",
    "Sebaiknya iya.", "Coba pikirkan baik-baik dulu.", "Iya, demi kenyamananmu.",
    "Tidak ada paksaan, ikuti kata hati.", "Sebaiknya dilakukan.", "Bisa ya, bisa tidak.",
    "Iya, agar lebih tenang.", "Terserah keputusanmu.",
  ],
  siapa: [
    "Seseorang yang kamu kenal baik.", "Orang yang tidak kamu duga.", "Mungkin dirimu sendiri.",
    "Seseorang yang dekat denganmu.", "Orang asing yang akan kamu temui.", "Sahabatmu sendiri.",
    "Hmm, masih rahasia.", "Orang yang sudah lama kamu kenal.", "Seseorang yang spesial.",
    "Aku tidak bisa memberitahu, rahasia!", "Orang yang selalu mendukungmu.", "Mungkin keluarga sendiri.",
    "Seseorang dari masa lalu.", "Orang baru yang akan kamu temui.", "Bisa jadi siapa saja.",
    "Orang yang kamu sayangi.", "Seseorang yang tidak terduga.", "Hmm, tunggu waktunya tiba.",
    "Orang yang selama ini ada di sekitarmu.", "Itu kamu sendiri!",
  ],
};

const KEY_ALIAS = {
  akankah: "akankah", akan: "akankah", will: "akankah",
  apakah: "apakah", apa: "apakah",
  dimana: "dimana", where: "dimana", mana: "dimana",
  kapan: "kapan", when: "kapan",
  mengapa: "mengapa", kenapa: "mengapa", why: "mengapa",
  bagaimana: "bagaimana", gimana: "bagaimana", how: "bagaimana",
  berapa: "berapa", howmuch: "berapa",
  bisakah: "bisakah", bisa: "bisakah", can: "bisakah",
  haruskah: "haruskah", harus: "haruskah", should: "haruskah",
  siapa: "siapa", who: "siapa",
};

let handler = async (m, { command }) => {
  const key = KEY_ALIAS[command] || command;
  const list = ANSWERS[key];
  if (!list) return;

  if (!m.text) return m.reply(`*Contoh:*\n> ${m.cmd} aku akan sukses?`);

  const jawaban = list[Math.floor(Math.random() * list.length)];
  return m.reply(`🔮 *${command.toUpperCase()}*\n\n❓ ${m.text}\n\n💬 _${jawaban}_`);
};

handler.command = Object.keys(KEY_ALIAS);
handler.tags = ["fun"];
handler.help = ["akankah <pertanyaan>", "apakah <pertanyaan>", "kapan <pertanyaan>", "mengapa <pertanyaan>"];
module.exports = handler;
