// plugins/fun-truthdare.js — dari Ourin MD 3

const TRUTH = [
  "Apa hal paling memalukan yang pernah kamu lakukan?",
  "Pernah boong ke orang tua? Bohongnya tentang apa?",
  "Siapa orang yang paling kamu sukai di grup ini?",
  "Apa hal yang paling kamu sesali dalam hidup?",
  "Pernah stalking mantan? Sampai sejauh mana?",
  "Apa fantasy tergila yang kamu punya?",
  "Kalau bisa kembali ke masa lalu, momen apa yang mau kamu ubah?",
  "Pernah nangis gara-gara game? Game apa?",
  "Apa hal terbodoh yang pernah kamu lakuin karena suka sama seseorang?",
  "Pernah nge-ghosting seseorang? Kenapa?",
  "Siapa gebetan pertamamu? Masih suka nggak?",
  "Apa kebiasaan aneh yang kamu punya tapi malu ngakuinnya?",
  "Pernah ketahuan ngobrol soal seseorang ke orang itu sendiri?",
  "Hal apa yang bikin kamu insecure?",
  "Pernah pura-pura sakit biar nggak masuk sekolah/kerja?",
];

const DARE = [
  "Kirim foto selfie sekarang dengan ekspresi paling aneh!",
  "Tulis 'I love you' ke kontak pertama di HP kamu!",
  "Ceritakan mimpi terburuk yang pernah kamu alami!",
  "Kirim voice note dengan suara hewan favoritmu!",
  "Tag 3 orang di grup ini dan bilang hal positif tentang mereka!",
  "Tulis status WA yang memalukan selama 5 menit!",
  "Kirim foto lama yang paling memalukan!",
  "Nyanyikan 1 bait lagu tapi direkam dan dikirim ke sini!",
  "Ceritakan hal paling konyol yang pernah kamu lakuin di depan umum!",
  "Minta maaf ke seseorang yang pernah kamu sakiti lewat chat sekarang!",
  "Ganti nama display kamu jadi sesuatu yang aneh selama 10 menit!",
  "Ketuk pintu kamar tetangga dan bilang 'Misi, ada yang jatuh nggak?' lalu kabur!",
  "Screenshot chat paling bucin yang kamu punya dan kirim di sini!",
  "Telepon seseorang dan bilang 'Kangen deh' terus tutup!",
  "Posting foto polos (no filter) ke story WA sekarang!",
];

let handler = async (m, { command }) => {
  if (command === "truth") {
    const q = TRUTH[Math.floor(Math.random() * TRUTH.length)];
    return m.reply(`🤍 *ᴛʀᴜᴛʜ*\n\n\`\`\`${q}\`\`\``);
  }
  if (command === "dare") {
    const d = DARE[Math.floor(Math.random() * DARE.length)];
    return m.reply(`🔴 *ᴅᴀʀᴇ*\n\n\`\`\`${d}\`\`\``);
  }
  // truthordare
  const pick = Math.random() > 0.5 ? "TRUTH" : "DARE";
  const item = pick === "TRUTH"
    ? TRUTH[Math.floor(Math.random() * TRUTH.length)]
    : DARE[Math.floor(Math.random() * DARE.length)];
  const emoji = pick === "TRUTH" ? "🤍" : "🔴";
  return m.reply(`${emoji} *${pick}*\n\n\`\`\`${item}\`\`\``);
};

handler.command = ["truth", "dare", "truthordare", "tod"];
handler.tags = ["fun"];
handler.help = ["truth", "dare", "truthordare"];
module.exports = handler;
