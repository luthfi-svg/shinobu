const {
    writeFileSync,
    readFileSync,
    unlinkSync,
    existsSync,
    mkdirSync
} = require('fs');
const {
    join
} = require('path');
const axios = require('axios');
const FormData = require('form-data');

let handler = async (m, {
    conn,
    usedPrefix,
    command
}) => {
    let tmpPath

    try {
        let q = m.quoted ? m.quoted : m
        let mime = (q.msg || q).mimetype || ''

        if (!/video/.test(mime)) {
            return m.reply(`Reply video yang ingin di HD atau dengan caption ${usedPrefix + command}`)
        }

        await global.loading(m, conn)

        let tmpDir = join(process.cwd(), 'tmp')
        if (!existsSync(tmpDir)) mkdirSync(tmpDir, {
            recursive: true
        })

        tmpPath = join(tmpDir, `${Date.now()}.mp4`)

        let media = await q.download()
        if (!media) return m.reply('Gagal download video.')

        writeFileSync(tmpPath, media)

        const form = new FormData()

        // ⚠️ JANGAN DIUBAH (sesuai curl kamu)
        form.append('video', readFileSync(tmpPath), {
            filename: 'video.mp4'
        })
        form.append('apikey', 'kyujir')

        let {
            data
        } = await axios.post(
            'https://api.theresav.biz.id/tools/winkvideo',
            form, {
                headers: {
                    ...form.getHeaders()
                },
                maxBodyLength: Infinity,
                maxContentLength: Infinity
            }
        )

        if (!data?.status) {
            return m.reply('Gagal memproses video.')
        }

        let resultUrl = data?.result?.url || data?.result
        if (!resultUrl) return m.reply('API tidak mengembalikan URL.')

        await conn.sendFile(
            m.chat,
            resultUrl,
            'hd.mp4',
            '✨ HD Video Ultra',
            m
        )

    } catch (e) {
        console.error(e)
        m.reply('Error processing video')
    } finally {
        try {
            if (tmpPath && existsSync(tmpPath)) unlinkSync(tmpPath)
        } catch {}

        global.loading(m, conn, true)
    }
}

handler.help = ['hdvideo', 'hdvid']
handler.tags = ['tools']
handler.command = /^(hd(video|vid))$/i

module.exports = handler