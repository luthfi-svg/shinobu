// plugins/tools/convert-to-commonjs.js
const fs = require('fs');
const path = require('path');

const handler = async (m, { sock, text, reply, usedPrefix, command }) => {
    
    // Cek apakah ada file yang dilampirkan atau reply ke file
    const q = m.quoted || m;
    const isFile = q.document || q.file;
    
    if (!isFile && !text) {
        return reply(`📝 *Cara Penggunaan:*\n\n` +
            `1. Reply file .js dengan caption:\n` +
            `${usedPrefix + command}\n\n` +
            `2. Atau kirim file .js langsung dengan caption:\n` +
            `${usedPrefix + command}\n\n` +
            `3. Atau kirim teks kode langsung:\n` +
            `${usedPrefix + command} <kode>\n\n` +
            `*Contoh:*\n${usedPrefix + command} import axios from 'axios'\n\nexport default handler`);
    }

    try {
        let code = '';
        let fileName = 'converted.js';

        // Jika ada file yang dilampirkan
        if (isFile) {
            const buffer = await q.download();
            code = buffer.toString('utf-8');
            fileName = q.fileName || q.document?.fileName || 'converted.js';
        } else if (text) {
            // Jika teks langsung
            code = text;
        }

        if (!code) {
            return reply('❌ Tidak ada kode yang ditemukan!');
        }

        // Proses konversi
        const converted = convertToCommonJS(code);

        // Kirim hasil
        const outputFileName = fileName.replace(/\.js$/, '') + '_cjs.js';
        
        await sock.sendMessage(
            m.chat,
            {
                document: Buffer.from(converted, 'utf-8'),
                fileName: outputFileName,
                mimetype: 'application/javascript',
                caption: `✅ *Berhasil dikonversi ke CommonJS!*\n\n` +
                        `📁 File: ${outputFileName}\n` +
                        `📊 Ukuran: ${(converted.length / 1024).toFixed(2)} KB\n\n` +
                        `📝 *Hasil Konversi:*\n\`\`\`javascript\n${converted.slice(0, 500)}${converted.length > 500 ? '\n...' : ''}\n\`\`\``
            },
            { quoted: m }
        );

    } catch (e) {
        console.error(e);
        reply(`❌ Error: ${e.message}`);
    }
};

function convertToCommonJS(code) {
    let result = code;

    // 1. Konversi import statements
    // import something from 'module' → const something = require('module')
    result = result.replace(/import\s+(\w+)\s+from\s+['"]([^'"]+)['"]/g, (match, name, module) => {
        return `const ${name} = require('${module}')`;
    });

    // import { something } from 'module' → const { something } = require('module')
    result = result.replace(/import\s*\{([^}]+)\}\s*from\s+['"]([^'"]+)['"]/g, (match, imports, module) => {
        return `const { ${imports.trim()} } = require('${module}')`;
    });

    // import * as something from 'module' → const something = require('module')
    result = result.replace(/import\s+\*\s+as\s+(\w+)\s+from\s+['"]([^'"]+)['"]/g, (match, name, module) => {
        return `const ${name} = require('${module}')`;
    });

    // import something, { something2 } from 'module' → const something = require('module'); const { something2 } = require('module')
    result = result.replace(/import\s+(\w+)\s*,\s*\{([^}]+)\}\s+from\s+['"]([^'"]+)['"]/g, (match, defaultImport, namedImports, module) => {
        return `const ${defaultImport} = require('${module}'); const { ${namedImports.trim()} } = require('${module}')`;
    });

    // 2. Konversi export default → module.exports
    result = result.replace(/export\s+default\s+(\w+)/g, (match, name) => {
        return `module.exports = ${name}`;
    });

    // export default { ... } → module.exports = { ... }
    result = result.replace(/export\s+default\s*\{([^}]*)\}/g, (match, content) => {
        return `module.exports = {${content}}`;
    });

    // export const something → exports.something
    result = result.replace(/export\s+const\s+(\w+)\s*=\s*([^;]+);?/g, (match, name, value) => {
        return `exports.${name} = ${value};`;
    });

    // export let something → exports.something
    result = result.replace(/export\s+let\s+(\w+)\s*=\s*([^;]+);?/g, (match, name, value) => {
        return `exports.${name} = ${value};`;
    });

    // export function something → exports.something = function
    result = result.replace(/export\s+function\s+(\w+)\s*\(([^)]*)\)\s*\{/g, (match, name, params) => {
        return `exports.${name} = function(${params}) {`;
    });

    // export async function something → exports.something = async function
    result = result.replace(/export\s+async\s+function\s+(\w+)\s*\(([^)]*)\)\s*\{/g, (match, name, params) => {
        return `exports.${name} = async function(${params}) {`;
    });

    // export class something → exports.something = class
    result = result.replace(/export\s+class\s+(\w+)/g, (match, name) => {
        return `exports.${name} = class ${name}`;
    });

    // 3. Tambahkan 'use strict' di awal jika belum ada
    if (!result.startsWith("'use strict'") && !result.startsWith('"use strict"')) {
        result = "'use strict';\n\n" + result;
    }

    // 4. Clean up: hapus import.meta dan __dirname/__filename polyfill jika diperlukan
    if (result.includes('import.meta')) {
        result = result.replace(/import\.meta/g, 'process.env');
    }

    return result;
}

handler.help = ['convert2cjs', 'toCJS'];
handler.tags = ['tools'];
handler.command = ['convert2cjs', 'tocjs', 'cjs'];
handler.owner = true;

module.exports = handler;