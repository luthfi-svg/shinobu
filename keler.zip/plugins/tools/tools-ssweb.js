// plugins/tools-ssweb.js — dari Ourin MD 3
const axios = require("axios");

let handler = async (m, { sock }) => {
  let url = (m.text || "").trim();

  if (!url) return m.reply(
    `📸 *sᴄʀᴇᴇɴsʜᴏᴛ ᴡᴇʙ*\n\n` +
    `> Screenshot halaman website\n\n` +
    `> *Contoh:*\n` +
    `> ${m.cmd} https://google.com\n` +
    `> ${m.cmd} github.com --mobile`
  );

  let mode = "desktop";
  if (/--mobile|--hp/i.test(url)) {
    mode = "mobile";
    url = url.replace(/--mobile|--hp/gi, "").trim();
  }
  if (!url.startsWith("http")) url = "https://" + url;

  await m.react("🕕");
  await m.reply("🕕 Mengambil screenshot...");

  try {
    const width = mode === "mobile" ? 720 : 1920;
    const apiUrl = `https://image.thum.io/get/width/${width}/crop/1080/noanimate/${url}`;
    const res = await axios.get(apiUrl, { responseType: "arraybuffer", timeout: 30000 });
    const buf = Buffer.from(res.data);

    await m.react("✅");
    await sock.sendMessage(m.chat, {
      image: buf,
      caption: `📸 *Screenshot Web*\n\n🔗 URL: ${url}\n📱 Mode: ${mode}`,
    }, { quoted: m });
  } catch (err) {
    await m.react("❌");
    m.reply("❌ Gagal screenshot: " + err.message);
  }
};

handler.command = ["ssweb", "screenshot", "ss", "webss"];
handler.tags = ["tools"];
handler.help = ["ssweb <url>"];
module.exports = handler;
