const { downloadContentFromMessage } = require("dekzymarket-cyber")

let handler = async (m, { sock }) => {
  if (!m.quoted) {
    return m.reply(`Reply pesannya!`)
  }

  let msg = m.quoted.message || m.quoted

  if (!msg.viewOnce && m.quoted.mtype !== "viewOnceMessageV2") {
    return m.reply("Pesan itu bukan sekali lihat!")
  }

  let mesages = msg?.videoMessage || msg?.imageMessage || msg?.audioMessage || msg
  let type = mesages.mimetype.split("/")[0]

  let media = await downloadContentFromMessage(mesages, type)
  let buffer = Buffer.from([])

  for await (const chunk of media) {
    buffer = Buffer.concat([buffer, chunk])
  }

  const cap = mesages?.caption ? `\`Text Message:\` ${mesages.caption}` : ""

  if (/video/.test(type)) {
    await sock.sendMessage(m.chat, { video: buffer, caption: cap }, { quoted: m })
  } else if (/image/.test(type)) {
    await sock.sendMessage(m.chat, { image: buffer, caption: cap }, { quoted: m })
  } else if (/audio/.test(type)) {
    await sock.sendMessage(
      m.chat,
      { audio: buffer, mimetype: "audio/mpeg", ptt: true },
      { quoted: m }
    )
  }
}

handler.command = ["rvo", "readviewonce"]
handler.tags = ["tools"]
handler.help = ["rvo (reply view once)"]

module.exports = handler