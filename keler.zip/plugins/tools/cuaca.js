// plugins/cuaca.js — dari Ourin MD 3
const axios = require("axios");

let handler = async (m, { text }) => {
  if (!text) return m.reply(`*Contoh:*\n${m.cmd} Jakarta`);

  await m.reply("🌤 Mengecek cuaca...");

  try {
    const { data } = await axios.get(
      `https://wttr.in/${encodeURIComponent(text)}?format=j1`
    );

    const current = data.current_condition?.[0];
    const area = data.nearest_area?.[0];
    const today = data.weather?.[0];

    if (!current) return m.reply("❌ Kota tidak ditemukan!");

    const city = area?.areaName?.[0]?.value || text;
    const country = area?.country?.[0]?.value || "";
    const temp = current.temp_C;
    const feels = current.FeelsLikeC;
    const humidity = current.humidity;
    const wind = current.windspeedKmph;
    const desc = current.weatherDesc?.[0]?.value || "";
    const maxTemp = today?.maxtempC || "-";
    const minTemp = today?.mintempC || "-";

    const weatherEmoji = (desc) => {
      const d = desc.toLowerCase();
      if (d.includes("sunny") || d.includes("clear")) return "☀️";
      if (d.includes("cloud")) return "☁️";
      if (d.includes("rain") || d.includes("drizzle")) return "🌧️";
      if (d.includes("thunder") || d.includes("storm")) return "⛈️";
      if (d.includes("snow")) return "❄️";
      if (d.includes("fog") || d.includes("mist")) return "🌫️";
      return "🌤️";
    };

    const teks = `
${weatherEmoji(desc)} *Cuaca ${city}${country ? ", " + country : ""}*

🌡 Suhu: ${temp}°C (Terasa ${feels}°C)
📊 Maks/Min: ${maxTemp}°C / ${minTemp}°C
💧 Kelembaban: ${humidity}%
💨 Kecepatan Angin: ${wind} km/h
📋 Kondisi: ${desc}

_Data dari wttr.in_`;

    return m.reply(teks);
  } catch (err) {
    m.reply("❌ Gagal mengambil data cuaca: " + err.message);
  }
};

handler.command = ["cuaca", "weather", "wtr"];
handler.tags = ["tools"];
handler.help = ["cuaca <kota>"];

module.exports = handler;
