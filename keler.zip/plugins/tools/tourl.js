const { generateWAMessageFromContent } = require("dekzymarket-cyber")
const { CatBox } = require("../../lib/screaper.js")

let handler = async (m, { sock }) => {
  let mime = m.mime || ""

  if (!/image|video|audio|application/.test(mime)) {
    return m.reply(`Kirim/reply media dengan ketik ${m.cmd}`)
  }

  try {
    let qmsg = m.quoted ? m.quoted : m
    let buffer = await qmsg.download()

    let url = await CatBox(buffer)
    if (!url) return m.reply("Upload gagal!")

    let msg = await generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: {
              text: `✅ Media berhasil diupload!\n\nMedia URL:\n${url}`
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "cta_copy",
                  buttonParamsJson: JSON.stringify({
                    display_text: "Copy URL",
                    copy_code: url
                  })
                }
              ]
            }
          }
        }
      }
    }, { userJid: m.sender, quoted: m })

    await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

  } catch (e) {
    console.log(e)
    m.reply("Terjadi kesalahan saat upload media")
  }
}

handler.tags = ["tools"]
handler.help = "tourl"
handler.command = ["tourl", "upload"]

module.exports = handler