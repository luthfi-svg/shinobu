// plugins/tools-caribug.js — Cari Bug Kode dari Ourin MD 3.1
const axios = require("axios");

let handler = async (m, { args, text }) => {
  let code = m.quoted?.text || text || (args || []).join(" ");

  if (!code) {
    return m.reply(
      `🐛 *ᴄᴀʀɪ ʙᴜɢ*\n\n` +
      `> Analisa kode untuk cari bug & error\n\n` +
      `*Cara pakai:*\n` +
      `> \`${m.cmd} <kode>\`\n` +
      `> atau reply pesan berisi kode\n\n` +
      `*Contoh:*\n` +
      `> \`${m.cmd} function test() { retrun 1 }\``
    );
  }

  await m.react("🕕");

  try {
    const apikey = global.cukiApiKey || "";
    if (!apikey) throw new Error("API key belum diset");

    const res = await axios.get("https://api.cuki.biz.id/api/aicode/caribug", {
      params: { apikey, code, language: "auto" },
      timeout: 60000,
    });

    const data = res.data;
    if (!data.success || !data.data) throw new Error("Gagal menganalisa kode dari server");

    const info = data.data;
    const meta = info.metadata;
    const bugInfo = info.bugsFound;

    let txt = `🐛 *ʜᴀsɪʟ ᴀɴᴀʟɪsᴀ ʙᴜɢ*\n\n`;
    txt += `*Bahasa:* ${meta.detectedLanguage}\n`;
    txt += `*Tingkat:* ${meta.severityInfo.level} ${meta.severityInfo.icon}\n`;
    txt += `*Bug Ditemukan:* ${bugInfo.total}\n\n`;

    if (bugInfo.summary) txt += `*📝 Ringkasan:*\n${bugInfo.summary}\n\n`;
    if (info.codeAnalysis?.fixed?.code) {
      txt += `*✨ Kode Perbaikan:*\n\`\`\`${meta.detectedLanguage}\n${info.codeAnalysis.fixed.code}\n\`\`\`\n\n`;
    }
    if (bugInfo.details?.length) {
      txt += `*📌 Detail:*\n`;
      bugInfo.details.forEach((d) => { txt += `- ${d.type || d.description}\n`; });
    }

    await m.react("✅");
    return m.reply(txt.trim());
  } catch (err) {
    // ── Fallback: cek syntax JS lokal kalau API gak tersedia ──
    try {
      new Function(code);
      await m.react("✅");
      return m.reply(
        `🐛 *ᴄᴀʀɪ ʙᴜɢ* _(mode lokal)_\n\n` +
        `✅ Tidak ditemukan syntax error pada kode JavaScript ini.\n\n` +
        `_Catatan: Analisa logika/AI tidak tersedia (API key belum diset di config.js)_`
      );
    } catch (syntaxErr) {
      await m.react("☢");
      return m.reply(
        `🐛 *ᴄᴀʀɪ ʙᴜɢ* _(mode lokal)_\n\n` +
        `❌ *Syntax Error Ditemukan!*\n\n` +
        `\`\`\`${syntaxErr.message}\`\`\`\n\n` +
        `_Catatan: Analisa lanjutan butuh API key di config.js (global.cukiApiKey)_`
      );
    }
  }
};

handler.command = ["caribug", "debug", "findbug"];
handler.tags = ["tools"];
handler.help = ["caribug <kode>", "caribug (reply kode)"];
module.exports = handler;
