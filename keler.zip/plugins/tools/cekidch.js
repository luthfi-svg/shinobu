const { generateWAMessageFromContent } = require("dekzymarket-cyber")

let handler = async (m, { sock, text }) => {
  if (!text) return m.reply(`*example:*\n${m.cmd} https://whatsapp.com/channel/xxx`)
  if (!text.includes("https://whatsapp.com/channel/") && !text.includes("@newsletter")) return m.reply(`*example:*\n${m.cmd} https://whatsapp.com/channel/xxx`)

  let result = text.trim(), opsi = "jid"
  if (text.includes("https://whatsapp.com/channel/")) result = text.split("https://whatsapp.com/channel/")[1], opsi = "invite"

  let res = await sock.newsletterMetadata(opsi, result)
    if (!res.id || !res.id.includes("@")) return m.reply("ID Channel tidak ditemukan atau Link tidak valid!")
  let teks = `\nWhatsApp Channel Metadata 🌐\n\n- Nama: ${res.name}\n- Total Pengikut: ${global.toRupiah(res.subscribers)}\n- ID: ${res.id}\n- https://whatsapp.com/channel/${res.invite}`

  let msg = await generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: { text: teks },
          nativeFlowMessage: {
            buttons: [{
              name: "cta_copy",
              buttonParamsJson: JSON.stringify({ display_text: "Copy Channel ID", copy_code: res.id })
            }]
          }
        }
      }
    }
  }, { userJid: m.sender, quoted: m })

  await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
}

handler.help = "cekidch"
handler.command = ["cekidch", "sch", "idch"]
handler.tags = ["tools"]

module.exports = handler