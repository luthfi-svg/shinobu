let handler = async (m, { sock }) => {
if (!m.quoted) return m.reply("Reply pesan!")
if (!m.quoted?.fakeObj?.message) return m.reply("Code tidak ditemukan")
const quo = JSON.stringify(m.quoted.fakeObj.message, null, 2)
return m.reply(quo)
}

handler.owner = true
handler.tags = "owner"
handler.help = "q"
handler.command = ["ambilq", "q", "msg"]

module.exports = handler