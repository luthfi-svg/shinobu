const fs = require("fs")
const path = require("path")

let handler = async (m, { sock, text }) => {

  if (!text) {
    return sock.sendMessage(
      m.chat,
      { text: `*example:*\n${m.cmd} ping.js` },
      { quoted: m }
    )
  }

  let pluginDir = "./plugins"
  let filePath = path.join(pluginDir, text.trim())

  if (!fs.existsSync(filePath)) {
    return sock.sendMessage(
      m.chat,
      { text: `File plugin *${text}* tidak ditemukan!\nKetik .listplugin untuk melihat semua file plugin` },
      { quoted: m }
    )
  }

  fs.unlinkSync(filePath)

  await sock.sendMessage(
    m.chat,
    { text: `✅ Plugin *${text.trim()}* berhasil dihapus` },
    { quoted: m }
  )
}

handler.tags = "Owner"
handler.help = "delplugin"
handler.command = ["delplugin", "delp"]
handler.owner = true

module.exports = handler