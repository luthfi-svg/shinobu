const handler = async (m, { reply, args, usedPrefix, command, db }) => {

  const fiturList = [
    "autotyping", // 1
    "autoread",   // 2
    "readsw",     // 3
    "pconly",     // 4
    "gconly",     // 5
    "anticall"    // 6
  ];

  const action = args[0] ? args[0].toLowerCase() : '';
  
  if (action !== 'on' && action !== 'off') {
    let teks = `*SETTINGS BOT*\n\n`;
    
    fiturList.forEach((key, index) => {
      const status = global[key] ? "ON" : "OFF";
      teks += `[${index + 1}] ${key} : *${status}*\n`;
    });

    teks += `\n*Used:*`;
    teks += `\n› ${usedPrefix + command} on <nomor>`;
    teks += `\n› ${usedPrefix + command} off <nomor>`;
    teks += `\n\n*Example:*`;
    teks += `\n› ${usedPrefix + command} on/off 1`;
    teks += `\n› ${usedPrefix + command} on/off 1 2`;
    
    return reply(teks);
  }

  const indexes = args.slice(1); 
  if (indexes.length === 0) {
    return reply(`Masukkan nomor fitur!\nContoh: *${usedPrefix + command} ${action} 1*`);
  }

  const isEnable = action === 'on'; 
  const dbValue = isEnable ? 1 : 0; 
  
  const success = [];
  const failed = [];

  for (const strIndex of indexes) {
    const i = parseInt(strIndex) - 1; 
    const key = fiturList[i];

    if (!key) {
      failed.push(strIndex); 
      continue;
    }

    global[key] = isEnable;

    try {
      await db('settings', 'bot', key, dbValue);
      success.push(key);
    } catch (e) {
      console.error(`Gagal update ${key}:`, e);
      failed.push(`${key}(DB Error)`);
    }
  }

  let msg = `*STATUS UPDATE*\n\n`;
  if (success.length > 0) {
    msg += `Berhasil di *${action.toUpperCase()}*:\n- ${success.join('\n- ')}\n`;
  }
  if (failed.length > 0) {
    msg += `\nGagal/Tidak Valid:\n- ${failed.join(', ')}`;
  }

  reply(msg);
};

handler.command = ["statusbot", "setbot", "settings"];
handler.owner = true;

module.exports = handler;