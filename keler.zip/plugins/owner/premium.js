// plugins/premium.js — dari Ourin MD 3
// Kelola user premium, partner, banned

let handler = async (m, { sock, text, command, isOwner }) => {
  const ownerOnlyCmds = ["addpremium","adprem","delpremium","delprem","listpremium","lprem","ban","banned","unban","listban","listbanned"];
  if (ownerOnlyCmds.includes(command) && !isOwner) return;

  const settings = global.db.settings;
  if (!settings.premium) settings.premium = [];
  if (!settings.partner) settings.partner = [];
  if (!settings.banned) settings.banned = [];

  let target =
    m.mentionedJid?.[0] ||
    (m.quoted?.sender) ||
    (text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : null);

  if (target && /@s\.whatsapp\.net/.test(target)) {
    target = await sock.toLid(target).catch(() => target);
  }

  switch (command) {

    // ═══ PREMIUM ═══
    case "addpremium":
    case "adprem": {
      if (!target) return m.reply(`*Contoh:*\n${m.cmd} @tag / 628xxx`);
      if (settings.premium.some((p) => (typeof p === "string" ? p : p.id) === target)) {
        return m.reply("User itu sudah premium!");
      }
      settings.premium.push({ id: target, since: Date.now() });
      if (global.db.users?.[target]) global.db.users[target].isPremium = true;
      return sock.sendMessage(m.chat, {
        text: `💎 @${target.split("@")[0]} berhasil ditambahkan sebagai Premium ✅`,
        mentions: [target],
      }, { quoted: m });
    }

    case "delpremium":
    case "delprem": {
      if (!target) return m.reply(`*Contoh:*\n${m.cmd} @tag / 628xxx`);
      const before = settings.premium.length;
      settings.premium = settings.premium.filter(
        (p) => (typeof p === "string" ? p : p.id) !== target
      );
      if (settings.premium.length === before) return m.reply("User itu bukan premium!");
      if (global.db.users?.[target]) global.db.users[target].isPremium = false;
      return sock.sendMessage(m.chat, {
        text: `❌ @${target.split("@")[0]} dihapus dari Premium`,
        mentions: [target],
      }, { quoted: m });
    }

    case "listpremium":
    case "lprem": {
      if (!settings.premium.length) return m.reply("Belum ada user premium.");
      let teks = `💎 *Daftar Premium*\n\n`;
      for (const p of settings.premium) {
        const id = typeof p === "string" ? p : p.id;
        teks += `- @${id.split("@")[0]}\n`;
      }
      return sock.sendMessage(m.chat, {
        text: teks,
        mentions: settings.premium.map((p) => (typeof p === "string" ? p : p.id)),
      }, { quoted: m });
    }

    // ═══ BANNED ═══
    case "ban":
    case "banned": {
      if (!target) return m.reply(`*Contoh:*\n${m.cmd} @tag / 628xxx`);
      if (settings.banned.includes(target)) return m.reply("User itu sudah dibanned!");
      settings.banned.push(target);
      return sock.sendMessage(m.chat, {
        text: `🚫 @${target.split("@")[0]} berhasil dibanned ✅`,
        mentions: [target],
      }, { quoted: m });
    }

    case "unban": {
      if (!target) return m.reply(`*Contoh:*\n${m.cmd} @tag / 628xxx`);
      if (!settings.banned.includes(target)) return m.reply("User itu tidak dibanned!");
      settings.banned = settings.banned.filter((b) => b !== target);
      return sock.sendMessage(m.chat, {
        text: `✅ @${target.split("@")[0]} berhasil di-unban`,
        mentions: [target],
      }, { quoted: m });
    }

    case "listban":
    case "listbanned": {
      if (!settings.banned.length) return m.reply("Tidak ada user yang dibanned.");
      let teks = `🚫 *Daftar Banned*\n\n`;
      settings.banned.forEach((b) => { teks += `- @${b.split("@")[0]}\n`; });
      return sock.sendMessage(m.chat, {
        text: teks,
        mentions: settings.banned,
      }, { quoted: m });
    }

    // ═══ BENEFIT PREMIUM ═══
    case "benefitpremium":
    case "infoprem": {
      const teks = `
💎 *Keuntungan Premium*

✅ Limit harian lebih banyak (${global.energiPremium || 500}/hari)
✅ Akses fitur eksklusif premium
✅ Request fitur baru
✅ Priority support dari owner
✅ Bebas dari limit & cooldown

📩 Hubungi owner untuk upgrade!`;
      return m.reply(teks);
    }

    // ═══ CEK STATUS ═══
    case "cekprem":
    case "cekstatus": {
      const isPrem = m.isPremium;
      const user = global.db.users?.[m.sender] || {};
      const teks = `
📊 *Status Akun*

👤 Nama: ${m.pushName || "-"}
💎 Premium: ${isPrem ? "✅ Ya" : "❌ Tidak"}
⚡ Energi: ${user.energi ?? "-"}/${isPrem ? (global.energiPremium || 500) : (global.energiDefault || 50)}
🪙 Koin: ${user.koin || 0}
📈 XP: ${user.exp || 0}`;
      return m.reply(teks);
    }
  }
};

handler.command = [
  "addpremium", "adprem",
  "delpremium", "delprem",
  "listpremium", "lprem",
  "ban", "banned",
  "unban",
  "listban", "listbanned",
  "benefitpremium", "infoprem",
  "cekprem", "cekstatus",
];
handler.tags = ["owner"];
handler.help = [
  "addpremium @user",
  "delpremium @user",
  "listpremium",
  "ban @user",
  "unban @user",
  "listban",
  "benefitpremium",
  "cekprem",
];
handler.owner = false; // Handled per-command above

module.exports = handler;
