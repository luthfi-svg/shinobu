const axios = require("axios")

let handler = async (m) => {
  if (!isOwner) return m.reply(mess.owner)

  m.reply("Memproses hapus semua user & server...")

  try {
    const headers = {
      Authorization: "Bearer " + apikey,
      "Content-Type": "application/json",
      Accept: "application/json"
    }

    const users = (await axios.get(`${domain}/api/application/users`, { headers })).data.data
    const servers = (await axios.get(`${domain}/api/application/servers`, { headers })).data.data

    let total = 0

    for (const user of users) {
      if (user.attributes.root_admin) continue

      const userID = user.attributes.id
      const userServers = servers.filter(s => s.attributes.user === userID)

      for (const srv of userServers) {
        await axios.delete(`${domain}/api/application/servers/${srv.attributes.id}`, { headers })
        total++
      }

      await axios.delete(`${domain}/api/application/users/${userID}`, { headers })
    }

    m.reply(`Berhasil hapus ${total} server & user panel non-admin ✅`)

  } catch (err) {
    console.error(err)
    m.reply("Error: " + err.message)
  }
}

handler.command = ['delpanel-all']
handler.tags = ["plugins"];
handler.help = 'delpanel-all';
handler.owner = true

module.exports = handler