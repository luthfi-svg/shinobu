const fs = require("fs")
const path = require("path")

let handler = async (m, { sock, text }) => {

  let pluginDir = "./plugins"

  if (!text || !m.quoted) {
    return m.reply(`Format tidak valid!\nContoh: \`${m.cmd}\` namafile.js dengan reply code atau file.js`)
  }

  let filename = text.trim()
  if (!filename.endsWith(".js") && !filename.endsWith(".cjs")) {
    return sock.sendMessage(
      m.chat,
      { text: "Format file wajib .js atau .cjs" },
      { quoted: m }
    )
  }

  let filePath = path.join(pluginDir, filename)

  if (m.quoted || m) {
    let downloader = m?.quoted?.text || m?.quoted?.download() || m?.download() || null
    if (!downloader) return m.reply(`Format tidak valid!\nContoh: \`${m.cmd}\` namafile.js dengan reply code atau file.js`)
    let buffer = downloader

    fs.writeFileSync(filePath, buffer)
    await sock.sendMessage(
      m.chat,
      { text: `✅ Plugin *${filename}* berhasil disimpan` },
      { quoted: m }
    )
    return
  }

  if (!m.quoted || !m.quoted.text) {
    return sock.sendMessage(
      m.chat,
      { text: "Reply pesan kode plugin atau kirim file plugin." },
      { quoted: m }
    )
  }

  fs.writeFileSync(filePath, m.quoted.text)
  await sock.sendMessage(
    m.chat,
    { text: `✅ Plugin ${filename} berhasil disimpan` },
    { quoted: m }
  )
}

handler.tags = "owner"
handler.help = "saveplugin"
handler.command = ["saveplugin", "sp", "sv", "svp"]
handler.owner = true

module.exports = handler