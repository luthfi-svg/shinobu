// plugins/menu-sub.js — Handler untuk button Lihat Semua Menu & Lihat Kategori
const { generateWAMessageFromContent } = require("dekzymarket-cyber");

const CAT = {
  main:        { emoji: "✦", label: "ᴍᴀɪɴ" },
  owner:       { emoji: "♛", label: "ᴏᴡɴᴇʀ" },
  group:       { emoji: "✿", label: "ɢʀᴏᴜᴘ" },
  download:    { emoji: "⬇", label: "ᴅᴏᴡɴʟᴏᴀᴅ" },
  tools:       { emoji: "⚙", label: "ᴛᴏᴏʟs" },
  ai:          { emoji: "◈", label: "ᴀɪ" },
  user:        { emoji: "◉", label: "ᴜsᴇʀ" },
  game:        { emoji: "◈", label: "ɢᴀᴍᴇ" },
  fun:         { emoji: "❋", label: "ꜰᴜɴ" },
  search:      { emoji: "⊕", label: "sᴇᴀʀᴄʜ" },
  sticker:     { emoji: "◆", label: "sᴛɪᴄᴋᴇʀ" },
  religi:      { emoji: "☽", label: "ʀᴇʟɪɢɪ" },
  info:        { emoji: "◎", label: "ɪɴꜰᴏ" },
  convert:     { emoji: "↻", label: "ᴄᴏɴᴠᴇʀᴛ" },
  pterodactyl: { emoji: "⬡", label: "ᴘᴀɴᴇʟ" },
};

const CAT_ORDER = ["main","owner","group","fun","game","download","tools","ai","search","sticker","religi","info","user","convert","store","pterodactyl","random"];

function collectCategories() {
  const toArr = v => !v ? [] : Array.isArray(v) ? v : [v];
  let cats = {};
  for (let file in global.plugins) {
    const plug = global.plugins[file];
    if (!plug) continue;
    const tags = toArr(plug.tags);
    const cmds = plug.help ? toArr(plug.help) : toArr(plug.command);
    if (!tags.length || !cmds.length) continue;
    for (const rawTag of tags) {
      const key = String(rawTag).toLowerCase();
      if (!cats[key]) cats[key] = new Set();
      cmds.forEach(c => { if (c) cats[key].add(c.toString().split(" ")[0]); });
    }
  }
  return cats;
}

function toBold(t) {
  const m = {A:"𝗔",B:"𝗕",C:"𝗖",D:"𝗗",E:"𝗘",F:"𝗙",G:"𝗚",H:"𝗛",I:"𝗜",J:"𝗝",K:"𝗞",L:"𝗟",M:"𝗠",N:"𝗡",O:"𝗢",P:"𝗣",Q:"𝗤",R:"𝗥",S:"𝗦",T:"𝗧",U:"𝗨",V:"𝗩",W:"𝗪",X:"𝗫",Y:"𝗬",Z:"𝗭"," ":" "};
  return t.toUpperCase().split("").map(c => m[c] || c).join("");
}

let handler = async (m, { sock, command }) => {
  const cats = collectCategories();
  const sorted = [
    ...CAT_ORDER.filter(k => cats[k]),
    ...Object.keys(cats).filter(k => !CAT_ORDER.includes(k)).sort(),
  ];

  // ── .listmenu → Semua command dalam 1 teks ──
  if (command === "listmenu") {
    let txt = `🌲 *Semua Menu ${global.botname}*\n\n`;
    for (const key of sorted) {
      const cfg = CAT[key] || { emoji: "◈", label: key.toUpperCase() };
      const cmds = Array.from(cats[key]).sort();
      txt += `╭━━━━ ${cfg.emoji} ${toBold(cfg.label)}\n`;
      txt += cmds.map(c => `┃  ⌬ ${global.prefix}${c}`).join("\n");
      txt += `\n╰━━━━━━━━━━━━━━━━⬣\n\n`;
    }
    return sock.sendMessage(m.chat, { text: txt }, { quoted: m });
  }

  // ── .kategori → List kategori + button pilih ──
  if (command === "kategori") {
    // Build sections untuk list message
    const sections = [{
      title: "📂 Pilih Kategori",
      rows: sorted.map(key => {
        const cfg = CAT[key] || { emoji: "◈", label: key };
        const count = cats[key].size;
        return {
          title: `${cfg.emoji} ${key.toUpperCase()}`,
          description: `${count} command tersedia`,
          rowId: `${global.prefix}cat_${key}`,
        };
      }),
    }];

    try {
      const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
          message: {
            messageContextInfo: {},
            interactiveMessage: {
              header: { title: "📋 Kategori Menu", hasMediaAttachment: false },
              body: { text: `Pilih kategori yang ingin kamu lihat:\n\n${sorted.map((k, i) => {
                const cfg = CAT[k] || { emoji: "◈", label: k };
                return `${cfg.emoji} *${k.toUpperCase()}* — ${cats[k].size} cmd`;
              }).join("\n")}` },
              footer: { text: `${global.botname} v${global.versibot}` },
              nativeFlowMessage: {
                messageParamsJson: "",
                buttons: sorted.slice(0, 3).map(key => {
                  const cfg = CAT[key] || { emoji: "◈", label: key };
                  return {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                      display_text: `${cfg.emoji} ${key.toUpperCase()} (${cats[key].size} cmd)`,
                      id: `${global.prefix}cat_${key}`,
                    }),
                  };
                }),
              },
            },
          },
        },
      }, { userJid: sock.user?.jid || m.sender });

      await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    } catch {
      // Fallback teks
      let txt = `📋 *Kategori Menu*\n\n`;
      sorted.forEach((k, i) => {
        const cfg = CAT[k] || { emoji: "◈", label: k };
        txt += `${cfg.emoji} *${k.toUpperCase()}* — ${cats[k].size} command\n`;
      });
      txt += `\nKetik \`${global.prefix}cat_<kategori>\` untuk lihat isi`;
      await sock.sendMessage(m.chat, { text: txt }, { quoted: m });
    }
  }

  // ── .cat_xxx → Lihat isi kategori tertentu ──
  if (command.startsWith("cat_")) {
    const key = command.replace("cat_", "");
    if (!cats[key]) return m.reply(`❌ Kategori *${key}* tidak ditemukan!`);
    const cfg = CAT[key] || { emoji: "◈", label: key.toUpperCase() };
    const cmds = Array.from(cats[key]).sort();
    let txt = `${cfg.emoji} *${key.toUpperCase()}*\n`;
    txt += `Total: ${cmds.length} command\n\n`;
    txt += `╭━━━━ ${cfg.emoji} ${toBold(cfg.label)}\n`;
    txt += cmds.map(c => `┃  ⌬ ${global.prefix}${c}`).join("\n");
    txt += `\n╰━━━━━━━━━━━━━━━━⬣`;
    return sock.sendMessage(m.chat, { text: txt }, { quoted: m });
  }
};

handler.command = [
  "listmenu", "kategori",
  ...Object.keys(CAT).map(k => `cat_${k}`),
  "cat_store", "cat_random", "cat_fun", "cat_game",
  "cat_search", "cat_info", "cat_religi", "cat_sticker",
  "cat_convert", "cat_user",
];
handler.tags = ["main"];
handler.help = ["listmenu", "kategori"];
module.exports = handler;
