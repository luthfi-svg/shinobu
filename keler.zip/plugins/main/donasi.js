// plugins/donasi.js — dari Ourin MD 3

let handler = async (m, { sock }) => {
  const teks = `
💝 *Donasi*

Terima kasih sudah menggunakan bot ini!
Jika ingin mendukung perkembangan bot, bisa donasi melalui:

*E-Wallet:*
• Dana: ${global.dana || "Belum diset"}
• OVO: ${global.ovo || "Belum diset"}
• GoPay: ${global.gopay || "Belum diset"}

*Manfaat Donasi:*
• Mendukung server agar tetap online
• Fitur baru lebih cepat rilis
• Priority support

Donasi berapapun sangat berarti 🙏`;

  if (global.qris) {
    await sock.sendMessage(m.chat, {
      image: { url: global.qris },
      caption: teks,
    }, { quoted: m });
  } else {
    await m.reply(teks);
  }
};

handler.command = ["donasi", "donate"];
handler.tags = ["main"];
handler.help = ["donasi"];

module.exports = handler;
