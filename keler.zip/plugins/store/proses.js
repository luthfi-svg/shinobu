let handler = async (m, { sock, text, command }) => {
  if (!text) return m.reply(`*example:*\n${m.cmd} jasa install panel`)
  const isDone = command === "done"

  const message = {
    interactiveMessage: {
      nativeFlowMessage: {
        buttons: [
          {
            name: "review_and_pay",
            buttonParamsJson: JSON.stringify({
              currency: "IDR",
              total_amount: {
                value: 999999900,
                offset: 100
              },
              reference_id: `${Date.now()}`,
              type: "physical-goods",
              payment_status: "captured",
              payment_timestamp: Math.floor(Date.now() / 1000),
              order: {
                status: "completed",
                subtotal: {
                  value: 0,
                  offset: 100
                },
                order_type: "PAYMENT_REQUEST",
                items: [
                  {
                    retailer_id: `custom-${Date.now()}`,
                    name: text,
                    amount: {
                      value: 999999900,
                      offset: 100
                    },
                    quantity: 1
                  }
                ]
              },
              additional_note: text,
              native_payment_methods: [],
              share_payment_status: false,
              is_soft_deleted: false
            })
          }
        ]
      }
    }
  }

  await sock.relayMessage(m.chat, message, {
    userJid: m.chat
  })
}

handler.command = ["proses", "done"]
handler.tags = ["store"]
handler.help = ["proses <teks>", "done <teks>"]
handler.owner = true

module.exports = handler