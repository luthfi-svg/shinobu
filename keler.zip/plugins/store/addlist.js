let handler = async (m, { text, command }) => {
  global.db.settings = global.db.settings || {}
  global.db.settings.list = global.db.settings.list || {}

  const list = global.db.settings.list

  if (command === "addlist") {
    if (!text) return m.reply(`*example:*\n${m.cmd} key@text`)

    let [key, ...resArr] = text.split("@")
    if (!key || resArr.length === 0) return m.reply(`*example:*\n${m.cmd} key@text`)

    let response = resArr.join("@").trim()
    key = key.trim().toLowerCase()

    if (list[key]) {
      return m.reply(`⚠️ Key *${key}* sudah ada.`)
    }

    list[key] = response
    return m.reply(`✅ Berhasil menambahkan list\n• Key: *${key}*\n• Respon: *${response}*`)
  }

  if (command === "list") {
    let data = Object.keys(list)

    if (data.length === 0) {
      return m.reply("❌ Belum ada list.")
    }

    let teks = `📋 *Daftar List Respon:*\n`
    teks += data.map((key, i) => `${i + 1}. ${key}`).join("\n")

    return m.reply(teks)
  }

  if (command === "dellist") {
    if (!text) return m.reply(`*example:*\n${m.cmd} key`)

    let key = text.trim().toLowerCase()

    if (!list[key]) {
      return m.reply(`❌ Key *${key}* tidak ditemukan.`)
    }

    delete list[key]
    return m.reply(`✅ Berhasil menghapus list *${key}*`)
  }
}

handler.help = ["addlist", "list", "dellist"]
handler.tags = ["store"]
handler.command = ["addlist", "list", "dellist"]

module.exports = handler