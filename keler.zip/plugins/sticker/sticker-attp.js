// plugins/sticker-attp.js — Text To Sticker dari Ourin MD 3
const axios = require("axios");
const fs = require("fs");
const path = require("path");
const { writeExifImg } = require("../../lib/sticker.js");

let handler = async (m, { sock }) => {
  const text = (m.text || "").trim();
  if (!text) return m.reply(
    `🖼️ *ᴛᴇxᴛ ᴛᴏ sᴛɪᴄᴋᴇʀ*\n\n> ${m.cmd} <teks>\n\n*Contoh:*\n> ${m.cmd} Shinobu MD\n> ${m.cmd} Hello World!`
  );

  await m.react("🕕");

  try {
    // Pakai API teks ke gambar animasi
    const encodedText = encodeURIComponent(text);
    const apiUrl = `https://api.popcat.xyz/texttospeech?text=${encodedText}`; 
    // Fallback: render teks sebagai sticker teks via carbon-like API
    const imgUrl = `https://api.ryzendesu.vip/api/sticker/attp?text=${encodedText}`;

    const res = await axios.get(imgUrl, { responseType: "arraybuffer", timeout: 20000 });
    const buf = Buffer.from(res.data);

    const tmpPath = path.join(process.cwd(), "tmp", `attp_${Date.now()}.webp`);
    if (!fs.existsSync(path.dirname(tmpPath))) fs.mkdirSync(path.dirname(tmpPath), { recursive: true });

    // Kalau sudah webp, langsung kirim
    const fileType = buf.slice(0, 4).toString("hex");
    if (fileType.startsWith("5249")) {
      // RIFF = webp
      const stickerBuf = await writeExifImg(buf, {
        packname: global.packname || "Shinobu MD",
        author: global.author || "Owner",
      }).catch(() => buf);
      fs.writeFileSync(tmpPath, stickerBuf);
      await sock.sendMessage(m.chat, { sticker: { url: tmpPath } }, { quoted: m });
      fs.unlinkSync(tmpPath);
    } else {
      await sock.sendMessage(m.chat, { image: buf, caption: `🖼️ ${text}` }, { quoted: m });
    }

    await m.react("✅");
  } catch (err) {
    await m.react("❌");
    m.reply("❌ Gagal buat sticker teks: " + err.message);
  }
};

handler.command = ["attp", "tts2sticker", "textsticker"];
handler.tags = ["sticker"];
handler.help = ["attp <teks>"];
module.exports = handler;
