import "./lib/myfunction.js";
import "./config.js";

import {
  makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  jidDecode,
  generateMessageID,
  generateWAMessage,
  generateWAMessageFromContent,
  downloadContentFromMessage,
  fetchLatestWaWebVersion
} from "dekzymarket-cyber";
import chalk from "chalk";
import Pino from "pino";
import fs from "fs";
import path from "path";
import crypto from "crypto";
import readline from "readline";
import { imageToWebp, writeExifImg } from "./lib/sticker.js";
import FileType from "file-type";
import { loadPlugins, watchPlugins } from "./lib/pluginLoader.js";
import serialize from "./lib/serialize.js";
import handler from "./handler.js";
import { fileURLToPath } from "url";
import { dirname } from "path";
import axios from "axios";
import nodeCron from "node-cron";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

global.plugins = await loadPlugins();
const pluginFolder = path.join(__dirname, "./plugins");
watchPlugins(pluginFolder);
const { default: loadDatabase } = await import("./lib/configDatabase.js");
global.loadDatabase = loadDatabase;
const { default: DataBase } = await import("./lib/database.js");
const database = new DataBase();
global.groupMetadataCache = new Map();

async function InputNumber(promptText) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise((resolve) => { rl.question(promptText, (a) => { rl.close(); resolve(a); }); });
}
const delayMs = (ms) => new Promise((r) => setTimeout(r, ms));

// Flag global supaya pairing code cuma diminta sekali per proses,
// walaupun koneksi sempat putus-nyambung sebelum berhasil login.
global.isPairingInProgress = false;

// ── Load DB ──────────────────────────────
;(async () => {
  const load = (await database.read()) || {};
  global.db = { users: load.users || {}, groups: load.groups || {}, settings: load.settings || {} };
  await database.write(global.db);
  setInterval(() => database.write(global.db), 5000);
})();

// ── Reset Energi Scheduler ───────────────
try {
  nodeCron.schedule(`${global.resetMinute || 0} ${global.resetHour || 0} * * *`, () => {
    console.log(chalk.yellow("[Scheduler] Reset energi harian..."));
    for (const jid in global.db?.users || {}) {
      const u = global.db.users[jid];
      const max = u?.isPremium ? (global.energiPremium || 500) : (global.energiDefault || 50);
      u.energi = max; u.limit = max; u.lastReset = Date.now();
    }
  }, { timezone: "Asia/Jakarta" });
} catch {}

async function startBot() {
  const { state, saveCreds } = await useMultiFileAuthState("./session");
  const { version } = await fetchLatestWaWebVersion();

  const sock = makeWASocket({
    logger: Pino({ level: "silent" }),
    auth: state,
    version,
    printQRInTerminal: false,
    // Browser fingerprint yang stabil untuk pairing code (device "Ubuntu/Chrome"
    // jauh lebih jarang ditolak WhatsApp dibanding default "Baileys").
    browser: ["Ubuntu", "Chrome", "120.0.0.0"],
    syncFullHistory: false,
    markOnlineOnConnect: true,
    generateHighQualityLinkPreview: true,
    getMessage: async () => undefined,
    cachedGroupMetadata: async (jid) => {
      if (!global.groupMetadataCache.has(jid)) {
        const m = await sock.groupMetadata(jid).catch(() => {});
        global.groupMetadataCache.set(jid, m); return m;
      }
      return global.groupMetadataCache.get(jid);
    },
  });

  // ── Pairing Code ─────────────────────────
  // Cuma jalan kalau sesi belum ke-register DAN belum ada request
  // pairing yang sedang berjalan (mencegah minta kode dobel saat reconnect).
  if (!sock.authState.creds.registered && !global.isPairingInProgress) {
    global.isPairingInProgress = true;

    (async () => {
      let pn = global.pairingNumber || await InputNumber(chalk.blue("\nInput WhatsApp Number (format: 628xxxx):\n"));
      pn = String(pn).replace(/[^0-9]/g, "");

      if (!pn || pn.length < 8) {
        console.log(chalk.red("\n❌ Nomor WhatsApp tidak valid. Cek global.pairingNumber di config.js"));
        global.isPairingInProgress = false;
        return;
      }

      // Baileys butuh socket siap dulu sebelum request pairing code,
      // jadi tunggu sebentar sambil retry kalau masih gagal.
      const requestCode = async (attempt = 1) => {
        try {
          await delayMs(attempt === 1 ? 3000 : 2000);
          const code = await sock.requestPairingCode(pn);
          const formatted = code?.match(/.{1,4}/g)?.join("-") || code;
          console.log(chalk.blue("\n📩 Pairing Code:"), chalk.bold.white(formatted));
          console.log(chalk.gray("Buka WhatsApp > Perangkat Tertaut > Tautkan dengan nomor telepon, lalu masukkan kode di atas.\n"));
        } catch (err) {
          console.log(chalk.red(`❌ Gagal ambil pairing code (percobaan ${attempt}/3):`), err?.message || err);
          if (attempt < 3) return requestCode(attempt + 1);
          console.log(chalk.red("Pairing gagal terus. Hapus folder ./session lalu coba jalankan ulang bot."));
        }
      };

      await requestCode();
      global.isPairingInProgress = false;
    })();
  }

  sock.public = global.mode !== "self";
  sock.toLid = async (i) => i;
  sock.toPn = async (i) => i;
  sock.ev.on("creds.update", await saveCreds);

  // ── Messages ─────────────────────────
  sock.ev.on("messages.upsert", async (chatUpdate) => {
    try {
      const { messages, type } = chatUpdate;
      // "notify" = pesan baru masuk real-time. Tipe lain (mis. "append")
      // adalah history sync lama — diabaikan supaya bot tidak "membalas"
      // chat basi setelah reconnect, dan supaya respon terasa lebih cepat.
      if (type && type !== "notify") return;
      if (!messages || !messages.length) return;

      for (const raw of messages) {
        try {
          if (!raw?.message) continue;
          const m = await serialize(sock, raw);
          if (!sock.public && !m.isOwner) continue;
          if (m.isBaileys) continue;
          handler(sock, m).catch((e) => console.error(chalk.red("[Handler Error]"), e));
        } catch (innerErr) {
          console.error(chalk.red("[Serialize Error]"), innerErr);
        }
      }
    } catch (err) {
      console.error(chalk.red("[Messages Upsert Error]"), err);
    }
  });

  // ── Anti Call ────────────────────────
  sock.ev.on("call", async (calls) => {
    for (const call of calls) {
      if (call.status !== "offer") continue;
      if (global.antiCall || global.db?.settings?.antiCall) {
        await sock.rejectCall(call.id, call.from).catch(() => {});
        await sock.sendMessage(call.from, { text: "🚫 JANGAN TELEPON NOMOR INI!" }).catch(() => {});
        if (global.blockIfCall) await sock.updateBlockStatus(call.from, "block").catch(() => {});
      }
    }
  });

  // ── Group Participant Update (Welcome/Goodbye) ─
  sock.ev.on("group-participants.update", async ({ id, participants, action, author }) => {
    try {
      const meta = await sock.groupMetadata(id);
      global.groupMetadataCache.set(id, meta);
      const cfg = global.db.groups?.[id] || {};
      const totalMember = meta.participants.length;

      for (const ptcp of participants) {
        let participant = ptcp?.phoneNumber || ptcp?.id || ptcp?.lid || ptcp || "";
        const userTag = `@${participant.split("@")[0]}`;
        let text = "", title = "";

        // Download foto profil sebagai buffer
        let thumbBuf = null;
        try {
          const ppUrl = await sock.profilePictureUrl(participant, "image");
          const res = await axios.get(ppUrl, { responseType: "arraybuffer", timeout: 5000 });
          thumbBuf = Buffer.from(res.data);
        } catch {
          // Coba fallback ke thumbnail global
          try {
            const res = await axios.get(global.thumbnail, { responseType: "arraybuffer", timeout: 5000 });
            thumbBuf = Buffer.from(res.data);
          } catch {}
        }

        if (action === "add" && cfg.welcome) {
          text = `Haii ${userTag} 👋\nSelamat datang di *${meta.subject}*!\nTotal Member: *${totalMember}*`;
          title = "Welcome";
        } else if (action === "remove" && cfg.goodbye) {
          text = `Selamat tinggal ${userTag} 👋\nTotal Member: *${totalMember}*`;
          title = "Goodbye";
        } else if (action === "promote") {
          text = `@${(author||"").split("@")[0]} menjadikan ${userTag} sebagai Admin ✅`;
          title = "Promote";
        } else if (action === "demote") {
          text = `@${(author||"").split("@")[0]} menurunkan ${userTag} dari Admin ❌`;
          title = "Demote";
        }

        if (!text) continue;

        const externalAdReply = {
          title,
          renderLargerThumbnail: true,
          mediaType: 1,
        };
        if (thumbBuf) externalAdReply.thumbnail = thumbBuf;

        await sock.sendMessage(id, {
          text,
          contextInfo: {
            mentionedJid: [participant, author].filter(Boolean),
            externalAdReply,
          },
        });
      }
    } catch {}
  });

  // ── Connection ────────────────────────
  sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      if (statusCode !== DisconnectReason.loggedOut) {
        console.log(chalk.yellow("Koneksi terputus, mencoba menyambung ulang..."));
        global.isPairingInProgress = false;
        setTimeout(() => startBot(), 2000); // beri jeda supaya tidak reconnect terlalu agresif
      } else {
        console.log(chalk.red("Logged Out. Hapus folder ./session lalu pairing ulang."));
      }
    }
    if (connection === "open") {
      console.log(chalk.green(`\n✅ ${global.botname} Connected!\n`));
      try {
        await sock.newsletterFollow("120363405316618186@newsletter");
        await sock.newsletterFollow("120363427915199733@newsletter");
        console.log(chalk.cyan("✅ Auto follow channel berhasil!"));
      } catch (e) {
        console.error("❌ Experiencing an error when following a channel", e);
      }
    }
  });

  // ── Helper methods ────────────────────
  sock.decodeJid = (jid) => {
    if (!jid) return jid;
    if (/:\d+@/gi.test(jid)) { const d = jidDecode(jid)||{}; return d.user && d.server ? `${d.user}@${d.server}` : jid; }
    return jid;
  };

  sock.downloadMediaMessage = async (m, type, filename = "") => {
    if (!m || !(m.url || m.directPath)) return Buffer.alloc(0);
    const stream = await downloadContentFromMessage(m, type);
    let buffer = Buffer.from([]);
    for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
    if (filename) await fs.promises.writeFile(filename, buffer);
    return filename && fs.existsSync(filename) ? filename : buffer;
  };

  sock.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
    const quoted = message.msg ? message.msg : message;
    const mime = (message.msg || message).mimetype || "";
    const messageType = message.mtype ? message.mtype.replace(/Message/gi, "") : mime.split("/")[0];
    const fil = Date.now();
    const stream = await downloadContentFromMessage(quoted, messageType);
    let buffer = Buffer.from([]);
    for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
    const type = await FileType.fromBuffer(buffer);
    const trueFileName = attachExtension ? `./tmp/${fil}.${type.ext}` : filename;
    if (!fs.existsSync("./tmp")) fs.mkdirSync("./tmp", { recursive: true });
    fs.writeFileSync(trueFileName, buffer);
    return trueFileName;
  };

  sock.sendSticker = async (jid, p, quoted, options = {}) => {
    let buff = Buffer.isBuffer(p) ? p
      : /^https?:\/\//.test(p) ? await global.getBuffer(p)
      : fs.existsSync(p) ? fs.readFileSync(p) : Buffer.alloc(0);
    const buffer = (options.packname || options.author) ? await writeExifImg(buff, options) : await imageToWebp(buff);
    const tmpPath = `./tmp/${crypto.randomBytes(6).readUIntLE(0,6).toString(36)}.webp`;
    if (!fs.existsSync("./tmp")) fs.mkdirSync("./tmp", { recursive: true });
    fs.writeFileSync(tmpPath, buffer);
    await sock.sendMessage(jid, { sticker: { url: tmpPath }, ...options }, { quoted });
    fs.unlinkSync(tmpPath);
    return buffer;
  };

  sock.sendAlbum = async function(jid, content, quoted) {
    const array = content.albumMessage;
    const album = await generateWAMessageFromContent(jid, {
      messageContextInfo: { messageSecret: crypto.randomBytes(32) },
      albumMessage: { expectedImageCount: array.filter(a=>a.image).length, expectedVideoCount: array.filter(a=>a.video).length },
    }, { userJid: quoted.sender, quoted, upload: sock.waUploadToServer });
    await sock.relayMessage(jid, album.message, { messageId: album.key.id });
    for (let item of array) {
      const img = await generateWAMessage(jid, item, { upload: sock.waUploadToServer });
      img.message.messageContextInfo = {
        messageSecret: crypto.randomBytes(32),
        messageAssociation: { associationType: 1, parentMessageKey: album.key },
      };
      await sock.relayMessage(jid, img.message, { messageId: img.key.id });
    }
    return album;
  };

  return sock;
}

startBot();
process.on("uncaughtException", (err) => { console.error("Caught:", err); });
