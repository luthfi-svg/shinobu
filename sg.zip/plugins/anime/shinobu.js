// plugins/anime/shinobu.js — Random Shinobu anime picture (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Shinobu
 * 🔧 Fungsi     : Random gambar Shinobu anime
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

let handler = async (m, { sock }) => {
  try {
    await m.reply("⏳ *Getting Shinobu...*");

    const response = await axios.get("https://api.waifu.im/search?included_tags=shinobu", {
      timeout: 15000
    }).catch(async () => {
      // Fallback
      return { data: { images: [{ url: "https://cdn.waifu.im/shinobu.jpg" }] } };
    });

    const imageUrl = response.data.images?.[0]?.url || "https://i.imgur.com/default.jpg";

    await sock.sendMessage(
      m.chat,
      {
        image: { url: imageUrl },
        caption: `💜 *Shinobu Oshino*\n\n_From Monogatari Series_`
      },
      { quoted: m }
    );

    await m.react("✅");

  } catch (e) {
    console.error(e);
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["shinobu"];
handler.tags = ["anime"];
handler.command = /^(shinobu)$/i;
handler.limit = true;

export default handler;
