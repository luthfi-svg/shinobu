// plugins/anime/megumin.js — Random Megumin anime picture (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Megumin
 * 🔧 Fungsi     : Random gambar Megumin anime
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

let handler = async (m, { sock }) => {
  try {
    await m.reply("⏳ *Getting Megumin...*");

    const response = await axios.get("https://api.waifu.im/search?included_tags=megumin", {
      timeout: 15000
    }).catch(async () => {
      return { data: { images: [{ url: "https://cdn.waifu.im/megumin.jpg" }] } };
    });

    const imageUrl = response.data.images?.[0]?.url || "https://i.imgur.com/default.jpg";

    await sock.sendMessage(
      m.chat,
      {
        image: { url: imageUrl },
        caption: `💥 *Megumin*\n\n_Explosion Magic Expert_`
      },
      { quoted: m }
    );

    await m.react("✅");

  } catch (e) {
    console.error(e);
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["megumin"];
handler.tags = ["anime"];
handler.command = /^(megumin)$/i;
handler.limit = true;

export default handler;
