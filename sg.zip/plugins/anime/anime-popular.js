// plugins/anime/anime-popular.js — Popular Anime (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Popular Anime
 * 🔧 Fungsi     : Anime populer
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

let handler = async (m, { text, usedPrefix, command }) => {
  try {
    await m.reply("⏳ Loading anime...");
    
    // Anime API simulation
    await m.reply(
      `🎌 *Popular Anime*\n\n` +
      `📝 Title: Anime Content\n` +
      `⭐ Rating: 8.5/10\n` +
      `🎬 Type: Anime populer\n\n` +
      `🎯 SHINOBU MD v1.2`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["popularanime", "animepopular"];
handler.tags = ['anime'];
handler.command = /^(popularanime|animepopular)$/i;

export default handler;
