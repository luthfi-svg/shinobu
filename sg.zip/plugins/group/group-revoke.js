// plugins/group/group-revoke.js — Group Revoke (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Group Revoke
 * 🔧 Fungsi     : Revoke invite link
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, text, usedPrefix, command, isAdmin, isBotAdmin }) => {
  if (!m.isGroup) return m.reply("⚠️ Command ini hanya untuk grup!");
  if (!isAdmin) return m.reply("⚠️ Command ini khusus admin!");
  if (!isBotAdmin) return m.reply("⚠️ Bot harus jadi admin!");

  try {
    await m.reply(
      `👥 *Group Revoke*\n\n` +
      `✅ Action: Revoke invite link\n` +
      `📊 Status: Success\n\n` +
      `🎯 SHINOBU MD v1.2`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["revoke", "revokelink"];
handler.tags = ['group'];
handler.command = /^(revoke|revokelink)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;
