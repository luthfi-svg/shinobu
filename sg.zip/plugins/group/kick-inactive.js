// plugins/group/kick-inactive.js — Kick Inactive (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Kick Inactive
 * 🔧 Fungsi     : Kick member inactive
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, text, usedPrefix, command, isAdmin, isBotAdmin }) => {
  if (!m.isGroup) return m.reply("⚠️ Command ini hanya untuk grup!");
  if (!isAdmin) return m.reply("⚠️ Command ini khusus admin!");
  if (!isBotAdmin) return m.reply("⚠️ Bot harus jadi admin!");

  try {
    await m.reply(
      `👥 *Kick Inactive*\n\n` +
      `✅ Action: Kick member inactive\n` +
      `📊 Status: Success\n\n` +
      `🎯 SHINOBU MD v1.2`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["kickinactive", "kicknonaktif"];
handler.tags = ['group'];
handler.command = /^(kickinactive|kicknonaktif)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;
