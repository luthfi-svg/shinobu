// plugins/group/antidelete.js — Anti delete message (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Anti Delete
 * 🔧 Fungsi     : Forward deleted messages
 * ⚡ By Shinobu
 * ─────────────────────────
 */

// Store messages temporarily
global.messageStore = global.messageStore || {};

let handler = async (m) => {
  return true;
};

handler.before = async function (m, { sock }) {
  if (!m.isGroup) return;

  // Store all messages
  if (m.message && m.key) {
    global.messageStore[m.key.id] = {
      message: m.message,
      sender: m.sender,
      chat: m.chat,
      time: Date.now()
    };
  }

  // Detect deleted messages
  if (m.messageType === "protocolMessage" && m.message?.protocolMessage?.type === 0) {
    const deletedKey = m.message.protocolMessage.key;
    const stored = global.messageStore[deletedKey.id];

    if (stored) {
      const sender = stored.sender;
      const senderNumber = sender.split("@")[0];

      await sock.sendMessage(
        m.chat,
        {
          text: 
            `🗑️ *Anti Delete*\n\n` +
            `@${senderNumber} menghapus pesan:\n\n` +
            `"${stored.message?.conversation || stored.message?.extendedTextMessage?.text || "[Media]"}"\n\n` +
            `⏰ ${new Date(stored.time).toLocaleString("id-ID")}`,
          mentions: [sender]
        }
      );

      delete global.messageStore[deletedKey.id];
    }
  }

  // Cleanup old messages (older than 1 hour)
  const now = Date.now();
  for (const key in global.messageStore) {
    if (now - global.messageStore[key].time > 3600000) {
      delete global.messageStore[key];
    }
  }

  return true;
};

handler.group = true;

export default handler;
