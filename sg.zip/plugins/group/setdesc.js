// plugins/group/setdesc.js — Set group description (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Set Group Description
 * 🔧 Fungsi     : Ganti deskripsi group
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, text, usedPrefix, command }) => {
  if (!m.isGroup) {
    return m.reply("❌ Command ini hanya bisa digunakan di group!");
  }

  if (!m.isAdmin && !m.isOwner) {
    return m.reply("❌ Command ini hanya untuk admin group!");
  }

  if (!m.isBotAdmin) {
    return m.reply("❌ Bot harus jadi admin!");
  }

  if (!text) {
    return m.reply(
      `Contoh penggunaan:\n${usedPrefix + command} <deskripsi baru>\n\n` +
      `Contoh:\n` +
      `${usedPrefix + command} Welcome to our awesome group!`
    );
  }

  try {
    await sock.groupUpdateDescription(m.chat, text);
    
    await m.reply(
      `✅ *Group Description Updated*\n\n` +
      `📝 New Description:\n${text}\n\n` +
      `⏰ ${new Date().toLocaleString("id-ID")}`
    );

    await m.react("✅");

  } catch (e) {
    console.error(e);
    await m.reply(`❌ Gagal ganti deskripsi: ${e.message}`);
  }
};

handler.help = ["setdesc <text>"];
handler.tags = ["group"];
handler.command = /^(setdesc|setdescription|setdesk)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;
