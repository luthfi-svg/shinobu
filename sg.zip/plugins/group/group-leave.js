// plugins/group/group-leave.js — Group Leave (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Group Leave
 * 🔧 Fungsi     : Keluar dari grup
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, text, usedPrefix, command, isAdmin, isBotAdmin }) => {
  if (!m.isGroup) return m.reply("⚠️ Command ini hanya untuk grup!");
  if (!isAdmin) return m.reply("⚠️ Command ini khusus admin!");
  if (!isBotAdmin) return m.reply("⚠️ Bot harus jadi admin!");

  try {
    await m.reply(
      `👥 *Group Leave*\n\n` +
      `✅ Action: Keluar dari grup\n` +
      `📊 Status: Success\n\n` +
      `🎯 SHINOBU MD v1.2`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["leave", "leavegrup"];
handler.tags = ['group'];
handler.command = /^(leave|leavegrup)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;
