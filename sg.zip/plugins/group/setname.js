// plugins/group/setname.js — Set group name/subject (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Set Group Name
 * 🔧 Fungsi     : Ganti nama group
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, text, usedPrefix, command }) => {
  if (!m.isGroup) {
    return m.reply("❌ Command ini hanya bisa digunakan di group!");
  }

  if (!m.isAdmin && !m.isOwner) {
    return m.reply("❌ Command ini hanya untuk admin group!");
  }

  if (!m.isBotAdmin) {
    return m.reply("❌ Bot harus jadi admin!");
  }

  if (!text) {
    return m.reply(
      `Contoh penggunaan:\n${usedPrefix + command} <nama baru>\n\n` +
      `Contoh:\n` +
      `${usedPrefix + command} Best Group Ever`
    );
  }

  try {
    await sock.groupUpdateSubject(m.chat, text);
    
    await m.reply(
      `✅ *Group Name Updated*\n\n` +
      `📝 New Name: ${text}\n` +
      `⏰ ${new Date().toLocaleString("id-ID")}`
    );

    await m.react("✅");

  } catch (e) {
    console.error(e);
    await m.reply(`❌ Gagal ganti nama: ${e.message}`);
  }
};

handler.help = ["setname <text>"];
handler.tags = ["group"];
handler.command = /^(setname|setsubject|setnamegc)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;
