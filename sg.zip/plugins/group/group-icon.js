// plugins/group/group-icon.js — Group Icon (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Group Icon
 * 🔧 Fungsi     : Ubah icon grup
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, text, usedPrefix, command, isAdmin, isBotAdmin }) => {
  if (!m.isGroup) return m.reply("⚠️ Command ini hanya untuk grup!");
  if (!isAdmin) return m.reply("⚠️ Command ini khusus admin!");
  if (!isBotAdmin) return m.reply("⚠️ Bot harus jadi admin!");

  try {
    await m.reply(
      `👥 *Group Icon*\n\n` +
      `✅ Action: Ubah icon grup\n` +
      `📊 Status: Success\n\n` +
      `🎯 SHINOBU MD v1.2`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["icon", "icongrup"];
handler.tags = ['group'];
handler.command = /^(icon|icongrup)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;
