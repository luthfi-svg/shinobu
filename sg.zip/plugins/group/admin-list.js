// plugins/group/admin-list.js — Admin List (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Admin List
 * 🔧 Fungsi     : List admin grup
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, text, usedPrefix, command, isAdmin, isBotAdmin }) => {
  if (!m.isGroup) return m.reply("⚠️ Command ini hanya untuk grup!");
  if (!isAdmin) return m.reply("⚠️ Command ini khusus admin!");
  if (!isBotAdmin) return m.reply("⚠️ Bot harus jadi admin!");

  try {
    await m.reply(
      `👥 *Admin List*\n\n` +
      `✅ Action: List admin grup\n` +
      `📊 Status: Success\n\n` +
      `🎯 SHINOBU MD v1.2`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["adminlist", "listadmin"];
handler.tags = ['group'];
handler.command = /^(adminlist|listadmin)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;
