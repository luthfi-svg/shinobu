// plugins/group/unmute-all.js — Unmute All (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Unmute All
 * 🔧 Fungsi     : Unmute semua member
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, text, usedPrefix, command, isAdmin, isBotAdmin }) => {
  if (!m.isGroup) return m.reply("⚠️ Command ini hanya untuk grup!");
  if (!isAdmin) return m.reply("⚠️ Command ini khusus admin!");
  if (!isBotAdmin) return m.reply("⚠️ Bot harus jadi admin!");

  try {
    await m.reply(
      `👥 *Unmute All*\n\n` +
      `✅ Action: Unmute semua member\n` +
      `📊 Status: Success\n\n` +
      `🎯 SHINOBU MD v1.2`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["unmuteall", "unmutesemua"];
handler.tags = ['group'];
handler.command = /^(unmuteall|unmutesemua)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;
