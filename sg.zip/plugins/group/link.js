// plugins/group/link.js — Get group invite link (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Group Link
 * 🔧 Fungsi     : Dapatkan link invite group
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock }) => {
  if (!m.isGroup) {
    return m.reply("❌ Command ini hanya bisa digunakan di group!");
  }

  if (!m.isAdmin && !m.isOwner) {
    return m.reply("❌ Command ini hanya untuk admin group!");
  }

  if (!m.isBotAdmin) {
    return m.reply("❌ Bot harus jadi admin!");
  }

  try {
    const code = await sock.groupInviteCode(m.chat);
    const link = `https://chat.whatsapp.com/${code}`;
    
    await m.reply(
      `🔗 *Group Invite Link*\n\n` +
      `📝 Link: ${link}\n\n` +
      `_Klik link untuk join group_`
    );

    await m.react("✅");

  } catch (e) {
    console.error(e);
    await m.reply(`❌ Gagal get link: ${e.message}`);
  }
};

handler.help = ["link"];
handler.tags = ["group"];
handler.command = /^(link|linkgc|linkgroup)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;
