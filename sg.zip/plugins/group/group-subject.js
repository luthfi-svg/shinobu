// plugins/group/group-subject.js — Group Subject (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Group Subject
 * 🔧 Fungsi     : Ubah nama grup
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, text, usedPrefix, command, isAdmin, isBotAdmin }) => {
  if (!m.isGroup) return m.reply("⚠️ Command ini hanya untuk grup!");
  if (!isAdmin) return m.reply("⚠️ Command ini khusus admin!");
  if (!isBotAdmin) return m.reply("⚠️ Bot harus jadi admin!");

  try {
    await m.reply(
      `👥 *Group Subject*\n\n` +
      `✅ Action: Ubah nama grup\n` +
      `📊 Status: Success\n\n` +
      `🎯 SHINOBU MD v1.2`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["subject", "namegrup"];
handler.tags = ['group'];
handler.command = /^(subject|namegrup)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;
