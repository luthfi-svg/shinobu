// plugins/group/add-multiple.js — Add Multiple (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Add Multiple
 * 🔧 Fungsi     : Tambah banyak member
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, text, usedPrefix, command, isAdmin, isBotAdmin }) => {
  if (!m.isGroup) return m.reply("⚠️ Command ini hanya untuk grup!");
  if (!isAdmin) return m.reply("⚠️ Command ini khusus admin!");
  if (!isBotAdmin) return m.reply("⚠️ Bot harus jadi admin!");

  try {
    await m.reply(
      `👥 *Add Multiple*\n\n` +
      `✅ Action: Tambah banyak member\n` +
      `📊 Status: Success\n\n` +
      `🎯 SHINOBU MD v1.2`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["addmultiple", "tambahmany"];
handler.tags = ['group'];
handler.command = /^(addmultiple|tambahmany)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;
