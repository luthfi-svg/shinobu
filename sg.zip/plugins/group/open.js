// plugins/group/open.js — Buka group (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Open Group
 * 🔧 Fungsi     : Buka group agar semua member bisa kirim pesan
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock }) => {
  if (!m.isGroup) {
    return m.reply("❌ Command ini hanya bisa digunakan di group!");
  }

  if (!m.isAdmin && !m.isOwner) {
    return m.reply("❌ Command ini hanya untuk admin group!");
  }

  if (!m.isBotAdmin) {
    return m.reply("❌ Bot harus jadi admin!");
  }

  try {
    await sock.groupSettingUpdate(m.chat, "not_announcement");
    
    await m.reply(
      `✅ *Group Opened*\n\n` +
      `🔓 Group sekarang terbuka\n` +
      `👥 Semua member bisa kirim pesan\n` +
      `⏰ ${new Date().toLocaleString("id-ID")}`
    );

    await m.react("✅");

  } catch (e) {
    console.error(e);
    await m.reply(`❌ Gagal buka group: ${e.message}`);
  }
};

handler.help = ["open"];
handler.tags = ["group"];
handler.command = /^(open|buka)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;
