// plugins/group/add.js — Add member ke group (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Add Member
 * 🔧 Fungsi     : Tambahkan member ke group
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, text, usedPrefix, command }) => {
  if (!m.isGroup) {
    return m.reply("❌ Command ini hanya bisa digunakan di group!");
  }

  if (!m.isAdmin && !m.isOwner) {
    return m.reply("❌ Command ini hanya untuk admin group!");
  }

  if (!m.isBotAdmin) {
    return m.reply("❌ Bot harus jadi admin untuk add member!");
  }

  if (!text) {
    return m.reply(
      `Contoh penggunaan:\n${usedPrefix + command} 628xxx\n\n` +
      `Bisa juga tambah beberapa:\n` +
      `${usedPrefix + command} 628xxx 628yyy`
    );
  }

  try {
    const numbers = text.match(/\d+/g);
    
    if (!numbers || numbers.length === 0) {
      return m.reply("❌ Format nomor tidak valid!");
    }

    await m.reply("⏳ *Adding Members...*\n\nMohon tunggu...");

    const results = [];

    for (const number of numbers) {
      const jid = number + "@s.whatsapp.net";
      
      try {
        const result = await sock.groupParticipantsUpdate(m.chat, [jid], "add");
        results.push({ number, status: "✅ Berhasil" });
      } catch (e) {
        let status = "❌ Gagal";
        
        if (e.message.includes("403")) {
          status = "⚠️ Privacy setting tidak mengizinkan";
        } else if (e.message.includes("409")) {
          status = "⚠️ Sudah ada di group";
        }
        
        results.push({ number, status });
      }
    }

    let resultText = `📊 *Add Member Results*\n\n`;
    
    for (const result of results) {
      resultText += `${result.status} - ${result.number}\n`;
    }
    
    resultText += `\n⏰ ${new Date().toLocaleString("id-ID")}`;

    await m.reply(resultText);
    await m.react("✅");

  } catch (e) {
    console.error(e);
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["add <number>"];
handler.tags = ["group"];
handler.command = /^(add|addmember)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;
