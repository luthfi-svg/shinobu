// plugins/group/welcome.js — Welcome & goodbye message (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Welcome & Goodbye
 * 🔧 Fungsi     : Auto send message saat ada yang join/leave
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock }) => {
  // This is a before handler that triggers on group participant updates
  return true;
};

handler.before = async function (m, { sock }) {
  // Only process group participant updates
  if (!m.isGroup) return;
  if (m.messageType !== "participantUpdate") return;

  try {
    const { participants, action } = m.participantUpdate || {};
    
    if (!participants || !action) return;

    const groupMetadata = await sock.groupMetadata(m.chat);
    const groupName = groupMetadata.subject;

    for (const participant of participants) {
      const number = participant.split("@")[0];
      
      if (action === "add") {
        // Welcome message
        await sock.sendMessage(
          m.chat,
          {
            text: 
              `👋 *Welcome!*\n\n` +
              `Selamat datang @${number}\n` +
              `di group *${groupName}*\n\n` +
              `Jangan lupa baca deskripsi group ya!`,
            mentions: [participant]
          }
        );
      } else if (action === "remove") {
        // Goodbye message
        await sock.sendMessage(
          m.chat,
          {
            text: 
              `👋 *Goodbye!*\n\n` +
              `@${number} telah keluar\n` +
              `dari group *${groupName}*\n\n` +
              `Semoga sukses selalu!`,
            mentions: [participant]
          }
        );
      }
    }

  } catch (e) {
    console.error("Welcome/Goodbye error:", e);
  }

  return true;
};

handler.group = true;

export default handler;
