// plugins/group/demote.js — Demote admin jadi member biasa (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Demote Admin
 * 🔧 Fungsi     : Turunkan admin jadi member biasa
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, text }) => {
  if (!m.isGroup) {
    return m.reply("❌ Command ini hanya bisa digunakan di group!");
  }

  if (!m.isAdmin && !m.isOwner) {
    return m.reply("❌ Command ini hanya untuk admin group!");
  }

  if (!m.isBotAdmin) {
    return m.reply("❌ Bot harus jadi admin untuk demote member!");
  }

  let target;
  
  if (m.quoted) {
    target = m.quoted.sender;
  } else if (text) {
    target = text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
  } else if (m.mentionedJid && m.mentionedJid[0]) {
    target = m.mentionedJid[0];
  } else {
    return m.reply(
      `Cara pakai:\n` +
      `• Tag orangnya\n` +
      `• Reply pesannya\n` +
      `• Ketik nomor`
    );
  }

  try {
    await sock.groupParticipantsUpdate(m.chat, [target], "demote");
    
    await m.reply(
      `✅ *Admin Demoted*\n\n` +
      `👤 User: @${target.split("@")[0]}\n` +
      `👥 Status: Member\n` +
      `⏰ ${new Date().toLocaleString("id-ID")}`
    );

    await m.react("✅");

  } catch (e) {
    console.error(e);
    await m.reply(`❌ Demote gagal: ${e.message}`);
  }
};

handler.help = ["demote <@user>"];
handler.tags = ["group"];
handler.command = /^(demote|unadmin)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;
