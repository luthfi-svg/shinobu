// plugins/group/member-list.js — Member List (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Member List
 * 🔧 Fungsi     : List member grup
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, text, usedPrefix, command, isAdmin, isBotAdmin }) => {
  if (!m.isGroup) return m.reply("⚠️ Command ini hanya untuk grup!");
  if (!isAdmin) return m.reply("⚠️ Command ini khusus admin!");
  if (!isBotAdmin) return m.reply("⚠️ Bot harus jadi admin!");

  try {
    await m.reply(
      `👥 *Member List*\n\n` +
      `✅ Action: List member grup\n` +
      `📊 Status: Success\n\n` +
      `🎯 SHINOBU MD v1.2`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["memberlist", "listmember"];
handler.tags = ['group'];
handler.command = /^(memberlist|listmember)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;
