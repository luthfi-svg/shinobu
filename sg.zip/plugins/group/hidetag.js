// plugins/group/hidetag.js — Mention semua member dengan text tersembunyi (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Hide Tag
 * 🔧 Fungsi     : Mention semua member group secara tersembunyi
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, text, usedPrefix, command }) => {
  if (!m.isGroup) {
    return m.reply("❌ Command ini hanya bisa digunakan di group!");
  }

  if (!m.isAdmin && !m.isOwner) {
    return m.reply("❌ Command ini hanya untuk admin group!");
  }

  try {
    const message = text || m.quoted?.text || m.quoted?.caption || "Tag Group";
    
    // Get all group members
    const participants = m.metadata?.participants || [];
    const mentions = participants.map(p => p.id || p.jid);

    await sock.sendMessage(
      m.chat,
      {
        text: message,
        mentions: mentions
      },
      { quoted: m }
    );

    await m.react("✅");

  } catch (e) {
    console.error(e);
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["hidetag <text>"];
handler.tags = ["group"];
handler.command = /^(hidetag|ht)$/i;
handler.group = true;
handler.admin = true;

export default handler;
