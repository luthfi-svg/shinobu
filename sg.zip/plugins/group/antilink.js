// plugins/group/antilink.js — Auto kick member yang kirim link group (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Anti Link
 * 🔧 Fungsi     : Auto kick member yang share link group lain
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, isAdmin, isBotAdmin }) => {
  // This is a before handler
  return true;
};

handler.before = async function (m, { sock, isAdmin, isBotAdmin }) {
  if (!m.isGroup) return;
  if (isAdmin) return; // Admin boleh kirim link
  if (!isBotAdmin) return; // Bot harus admin untuk kick

  const text = m.text || m.caption || "";
  
  // Check for group links
  const linkRegex = /chat\.whatsapp\.com\/([0-9A-Za-z]{20,24})/i;
  
  if (linkRegex.test(text)) {
    try {
      // Delete message
      await sock.sendMessage(m.chat, { delete: m.key });
      
      // Warn user
      await m.reply(
        `⚠️ *Anti Link Detected*\n\n` +
        `@${m.sender.split("@")[0]} jangan share link group!\n\n` +
        `_Member akan di-kick jika mengulangi_`,
        { mentions: [m.sender] }
      );
      
      // Optional: Kick after warning
      // await sock.groupParticipantsUpdate(m.chat, [m.sender], "remove");
      
    } catch (e) {
      console.error("Antilink error:", e);
    }
  }

  return true;
};

handler.group = true;

export default handler;
