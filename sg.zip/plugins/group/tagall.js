// plugins/group/tagall.js — Tag semua member dengan list (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Tag All
 * 🔧 Fungsi     : Tag semua member dengan list nama
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, text, usedPrefix, command }) => {
  if (!m.isGroup) {
    return m.reply("❌ Command ini hanya bisa digunakan di group!");
  }

  if (!m.isAdmin && !m.isOwner) {
    return m.reply("❌ Command ini hanya untuk admin group!");
  }

  try {
    const message = text || "Tag All Members";
    const participants = m.metadata?.participants || [];
    
    let tagText = `📢 *${message}*\n\n`;
    const mentions = [];

    for (const participant of participants) {
      const jid = participant.id || participant.jid;
      mentions.push(jid);
      
      const number = jid.split("@")[0];
      tagText += `• @${number}\n`;
    }

    tagText += `\n_Total: ${participants.length} members_`;

    await sock.sendMessage(
      m.chat,
      {
        text: tagText,
        mentions: mentions
      },
      { quoted: m }
    );

    await m.react("✅");

  } catch (e) {
    console.error(e);
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["tagall <text>"];
handler.tags = ["group"];
handler.command = /^(tagall|tag)$/i;
handler.group = true;
handler.admin = true;

export default handler;
