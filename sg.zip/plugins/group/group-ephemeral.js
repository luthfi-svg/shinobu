// plugins/group/group-ephemeral.js — Group Ephemeral (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Group Ephemeral
 * 🔧 Fungsi     : Pesan sementara
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, text, usedPrefix, command, isAdmin, isBotAdmin }) => {
  if (!m.isGroup) return m.reply("⚠️ Command ini hanya untuk grup!");
  if (!isAdmin) return m.reply("⚠️ Command ini khusus admin!");
  if (!isBotAdmin) return m.reply("⚠️ Bot harus jadi admin!");

  try {
    await m.reply(
      `👥 *Group Ephemeral*\n\n` +
      `✅ Action: Pesan sementara\n` +
      `📊 Status: Success\n\n` +
      `🎯 SHINOBU MD v1.2`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["ephemeral", "tempgrup"];
handler.tags = ['group'];
handler.command = /^(ephemeral|tempgrup)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;
