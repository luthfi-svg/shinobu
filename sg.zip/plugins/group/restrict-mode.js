// plugins/group/restrict-mode.js — Restrict Mode (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Restrict Mode
 * 🔧 Fungsi     : Mode pembatasan
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, text, usedPrefix, command, isAdmin, isBotAdmin }) => {
  if (!m.isGroup) return m.reply("⚠️ Command ini hanya untuk grup!");
  if (!isAdmin) return m.reply("⚠️ Command ini khusus admin!");
  if (!isBotAdmin) return m.reply("⚠️ Bot harus jadi admin!");

  try {
    await m.reply(
      `👥 *Restrict Mode*\n\n` +
      `✅ Action: Mode pembatasan\n` +
      `📊 Status: Success\n\n` +
      `🎯 SHINOBU MD v1.2`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["restrict", "restrictmode"];
handler.tags = ['group'];
handler.command = /^(restrict|restrictmode)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;
