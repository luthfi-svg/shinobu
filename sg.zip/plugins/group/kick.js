// plugins/group/kick.js — Kick member dari group (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Kick Member
 * 🔧 Fungsi     : Remove member dari group
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, text, command }) => {
  if (!m.isGroup) {
    return m.reply("❌ Command ini hanya bisa digunakan di group!");
  }

  if (!m.isAdmin && !m.isOwner) {
    return m.reply("❌ Command ini hanya untuk admin group!");
  }

  if (!m.isBotAdmin) {
    return m.reply("❌ Bot harus jadi admin untuk kick member!");
  }

  // Get target user
  let target;
  
  if (m.quoted) {
    target = m.quoted.sender;
  } else if (text) {
    target = text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
  } else if (m.mentionedJid && m.mentionedJid[0]) {
    target = m.mentionedJid[0];
  } else {
    return m.reply(
      `Cara pakai:\n` +
      `• Tag orangnya\n` +
      `• Reply pesannya\n` +
      `• Ketik nomor: .${command} 628xxx`
    );
  }

  // Check if target is owner
  const ownerJid = global.owner[0] + "@s.whatsapp.net";
  if (target === ownerJid) {
    return m.reply("❌ Tidak bisa kick owner bot!");
  }

  // Check if target is admin
  const groupMetadata = await sock.groupMetadata(m.chat);
  const admins = groupMetadata.participants.filter(p => p.admin).map(p => p.id);
  
  if (admins.includes(target)) {
    return m.reply("❌ Tidak bisa kick admin group!");
  }

  try {
    await sock.groupParticipantsUpdate(m.chat, [target], "remove");
    
    await m.reply(
      `✅ *Member Kicked*\n\n` +
      `👤 User: @${target.split("@")[0]}\n` +
      `⏰ ${new Date().toLocaleString("id-ID")}`
    );

    await m.react("✅");

  } catch (e) {
    console.error(e);
    await m.reply(
      `❌ *Kick Failed*\n\n` +
      `Error: ${e.message}\n\n` +
      `Possible reasons:\n` +
      `• User sudah keluar dari group\n` +
      `• Bot bukan admin\n` +
      `• Target adalah admin`
    );
  }
};

handler.help = ["kick <@user>"];
handler.tags = ["group"];
handler.command = /^(kick|remove)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;
