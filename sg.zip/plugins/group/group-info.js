// plugins/group/group-info.js — Group Info (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Group Info
 * 🔧 Fungsi     : Info grup detail
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, text, usedPrefix, command, isAdmin, isBotAdmin }) => {
  if (!m.isGroup) return m.reply("⚠️ Command ini hanya untuk grup!");
  if (!isAdmin) return m.reply("⚠️ Command ini khusus admin!");
  if (!isBotAdmin) return m.reply("⚠️ Bot harus jadi admin!");

  try {
    await m.reply(
      `👥 *Group Info*\n\n` +
      `✅ Action: Info grup detail\n` +
      `📊 Status: Success\n\n` +
      `🎯 SHINOBU MD v1.2`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["groupinfo", "infogrup"];
handler.tags = ['group'];
handler.command = /^(groupinfo|infogrup)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;
