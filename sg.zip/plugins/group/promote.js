// plugins/group/promote.js — Promote member jadi admin (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Promote Member
 * 🔧 Fungsi     : Jadikan member sebagai admin group
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, text }) => {
  if (!m.isGroup) {
    return m.reply("❌ Command ini hanya bisa digunakan di group!");
  }

  if (!m.isAdmin && !m.isOwner) {
    return m.reply("❌ Command ini hanya untuk admin group!");
  }

  if (!m.isBotAdmin) {
    return m.reply("❌ Bot harus jadi admin untuk promote member!");
  }

  let target;
  
  if (m.quoted) {
    target = m.quoted.sender;
  } else if (text) {
    target = text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
  } else if (m.mentionedJid && m.mentionedJid[0]) {
    target = m.mentionedJid[0];
  } else {
    return m.reply(
      `Cara pakai:\n` +
      `• Tag orangnya\n` +
      `• Reply pesannya\n` +
      `• Ketik nomor`
    );
  }

  try {
    await sock.groupParticipantsUpdate(m.chat, [target], "promote");
    
    await m.reply(
      `✅ *Member Promoted*\n\n` +
      `👤 User: @${target.split("@")[0]}\n` +
      `🔰 Status: Admin\n` +
      `⏰ ${new Date().toLocaleString("id-ID")}`
    );

    await m.react("✅");

  } catch (e) {
    console.error(e);
    await m.reply(`❌ Promote gagal: ${e.message}`);
  }
};

handler.help = ["promote <@user>"];
handler.tags = ["group"];
handler.command = /^(promote|admin)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;
