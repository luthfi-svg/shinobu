// plugins/group/resetlink.js — Reset group invite link (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Reset Link
 * 🔧 Fungsi     : Reset link invite group (link lama jadi invalid)
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock }) => {
  if (!m.isGroup) {
    return m.reply("❌ Command ini hanya bisa digunakan di group!");
  }

  if (!m.isAdmin && !m.isOwner) {
    return m.reply("❌ Command ini hanya untuk admin group!");
  }

  if (!m.isBotAdmin) {
    return m.reply("❌ Bot harus jadi admin!");
  }

  try {
    await sock.groupRevokeInvite(m.chat);
    const newCode = await sock.groupInviteCode(m.chat);
    const newLink = `https://chat.whatsapp.com/${newCode}`;
    
    await m.reply(
      `✅ *Link Reset Successfully*\n\n` +
      `🔗 New Link: ${newLink}\n\n` +
      `⚠️ Link lama sudah tidak berlaku\n` +
      `⏰ ${new Date().toLocaleString("id-ID")}`
    );

    await m.react("✅");

  } catch (e) {
    console.error(e);
    await m.reply(`❌ Gagal reset link: ${e.message}`);
  }
};

handler.help = ["resetlink", "revoke"];
handler.tags = ["group"];
handler.command = /^(resetlink|revoke|revokelink)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;
