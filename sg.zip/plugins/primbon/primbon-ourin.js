// plugins/primbon-ourin.js — Primbon dari Ourin MD 3.1 (api.siputzx.my.id)
import axios from "axios";

const API_BASE = "https://api.siputzx.my.id/api/primbon";

let handler = async (m, { command, args, text }) => {

  // ── Arti Nama ──────────────────────────
  if (command === "artinama" || command === "namameaning" || command === "artinamaku") {
    if (!text) return m.reply(`📛 *ᴀʀᴛɪ ɴᴀᴍᴀ*\n\n> Masukkan nama\n\n\`Contoh: ${m.cmd} putu\``);
    await m.react("📛");
    try {
      const { data } = await axios.get(`${API_BASE}/artinama?nama=${encodeURIComponent(text)}`, { timeout: 30000 });
      if (!data?.status || !data?.data) { await m.react("❌"); return m.reply("❌ *Gagal*\n\n> Tidak dapat menganalisa nama"); }
      const r = data.data;
      await m.react("✅");
      return m.reply(`📛 *ᴀʀᴛɪ ɴᴀᴍᴀ*\n\n> Nama: *${r.nama}*\n\n${r.arti}\n\n> _${r.catatan}_`);
    } catch (e) {
      await m.react("☢"); return m.reply("❌ Error: " + e.message);
    }
  }

  // ── Potensi Penyakit ────────────────────
  if (command === "potensipenyakit" || command === "cekpenyakit" || command === "penyakit") {
    if (args.length < 3) return m.reply(`🏥 *ᴘᴏᴛᴇɴsɪ ᴘᴇɴʏᴀᴋɪᴛ*\n\n> Format: tgl bln thn\n\n\`Contoh: ${m.cmd} 12 05 1998\``);
    const [tgl, bln, thn] = args;
    await m.react("🏥");
    try {
      const { data } = await axios.get(`${API_BASE}/cek_potensi_penyakit?tgl=${tgl}&bln=${bln}&thn=${thn}`, { timeout: 30000 });
      if (!data?.status || !data?.data) { await m.react("❌"); return m.reply("❌ *Gagal*\n\n> Gagal menganalisa"); }
      const r = data.data;
      await m.react("✅");
      return m.reply(
        `🏥 *ᴘᴏᴛᴇɴsɪ ᴘᴇɴʏᴀᴋɪᴛ*\n\n> Tanggal: *${tgl}-${bln}-${thn}*\n\n` +
        `📊 *Elemen:*\n${r.sektor}\n\n⚠️ *Potensi:*\n${r.elemen}\n\n> _${r.catatan}_`
      );
    } catch (e) {
      await m.react("☢"); return m.reply("❌ Error: " + e.message);
    }
  }

  // ── Sifat Usaha/Bisnis ──────────────────
  if (command === "sifatusahabisnis" || command === "usahabisnis" || command === "sifatbisnis") {
    if (args.length < 3) return m.reply(`💼 *sɪꜰᴀᴛ ᴜsᴀʜᴀ/ʙɪsɴɪs*\n\n> Format: tgl bln thn\n\n\`Contoh: ${m.cmd} 1 1 2000\``);
    const [tgl, bln, thn] = args;
    await m.react("💼");
    try {
      const { data } = await axios.get(`${API_BASE}/sifat_usaha_bisnis?tgl=${tgl}&bln=${bln}&thn=${thn}`, { timeout: 30000 });
      if (!data?.status || !data?.data) { await m.react("❌"); return m.reply("❌ *Gagal*\n\n> Gagal menganalisa"); }
      const r = data.data;
      await m.react("✅");
      return m.reply(`💼 *sɪꜰᴀᴛ ᴜsᴀʜᴀ/ʙɪsɴɪs*\n\n> Lahir: *${r.hari_lahir}*\n\n📊 *Analisa:*\n${r.usaha}\n\n> _${r.catatan}_`);
    } catch (e) {
      await m.react("☢"); return m.reply("❌ Error: " + e.message);
    }
  }

  // ── Kecocokan Nama Pasangan ─────────────
  if (command === "kecocokannamapasangan" || command === "cocoknama" || command === "matchname") {
    if (args.length < 2) return m.reply(`💕 *ᴋᴇᴄᴏᴄᴏᴋᴀɴ ɴᴀᴍᴀ*\n\n> Format: nama1 nama2\n\n\`Contoh: ${m.cmd} putu keyla\``);
    const [nama1, nama2] = args;
    await m.react("💕");
    try {
      const { data } = await axios.get(`${API_BASE}/kecocokan_nama_pasangan?nama1=${encodeURIComponent(nama1)}&nama2=${encodeURIComponent(nama2)}`, { timeout: 30000 });
      if (!data?.status || !data?.data) { await m.react("❌"); return m.reply("❌ *Gagal*\n\n> Gagal menganalisa"); }
      const r = data.data;
      await m.react("✅");
      return m.reply(
        `💕 *ᴋᴇᴄᴏᴄᴏᴋᴀɴ ɴᴀᴍᴀ ᴘᴀsᴀɴɢᴀɴ*\n\n> 👤 ${r.nama_anda}\n> 💑 ${r.nama_pasangan}\n\n` +
        `✅ *Sisi Positif:*\n${r.sisi_positif}\n\n❌ *Sisi Negatif:*\n${r.sisi_negatif}\n\n> _${r.catatan}_`
      );
    } catch (e) {
      await m.react("☢"); return m.reply("❌ Error: " + e.message);
    }
  }
};

handler.command = [
  "artinama", "namameaning", "artinamaku",
  "potensipenyakit", "cekpenyakit", "penyakit",
  "sifatusahabisnis", "usahabisnis", "sifatbisnis",
  "kecocokannamapasangan", "cocoknama", "matchname",
];
handler.tags = ["primbon"];
handler.help = [
  "artinama <nama>",
  "potensipenyakit <tgl> <bln> <thn>",
  "sifatusahabisnis <tgl> <bln> <thn>",
  "kecocokannamapasangan <nama1> <nama2>",
];
export default handler;