// plugins/maker/fakektp.js — Fake E-KTP Generator (SHINOBU MD)
/**
 * ───「 SHINOBU MD 」───
 * 📝 Plugin     : Fake E-KTP Generator
 * 🔗 API        : SynoxCloud API
 * 🎨 Design     : Super Rapi & Estetik
 * ⚠️ Warning    : JANGAN UNTUK BERBUAT ANEH!
 * ⚡ By Shinobu
 * ─────────────────────────
 */

"use strict";

import axios from "axios";

const API_BASE = "https://api.synoxcloud.xyz/canvas/e-ktp";
const REQUEST_TIMEOUT_MS = 30000;

/**
 * Generate E-KTP.
 */
async function generateEktp(params) {
  let res;
  try {
    res = await axios.get(API_BASE, {
      params,
      timeout: REQUEST_TIMEOUT_MS,
      responseType: "arraybuffer",
      validateStatus: () => true,
    });
  } catch (err) {
    if (err.code === "ECONNABORTED") {
      throw new Error("⏰ Timeout! Server terlalu lama merespon.");
    }
    throw new Error(`🌐 Gagal menghubungi server: ${err.message}`);
  }

  const contentType = String(res.headers["content-type"] || "").toLowerCase();

  if (res.status !== 200) {
    let errMsg = `📡 HTTP ${res.status} - ${res.statusText || "Request gagal"}`;
    if (contentType.includes("application/json")) {
      try {
        const parsed = JSON.parse(Buffer.from(res.data).toString("utf-8"));
        errMsg = parsed?.message || parsed?.error || errMsg;
      } catch {}
    }
    throw new Error(errMsg);
  }

  if (!contentType.startsWith("image/")) {
    throw new Error("🎨 Response bukan gambar! Format tidak sesuai.");
  }

  const buffer = Buffer.from(res.data);
  if (!buffer.length) throw new Error("📄 File gambar kosong!");

  return { buffer, mime: contentType };
}

function buildMenuText(prefix) {
  return (
    `╭══════════════════════════════╮\n` +
    `   🪪  *FAKE E-KTP GENERATOR*  🪪\n` +
    `╰══════════════════════════════╯\n\n` +
    `  📌 *Deskripsi:*\n` +
    `  › Generate kartu E-KTP custom\n` +
    `  › dengan data sendiri.\n` +
    `  › Hasil gambar HD & realistis!\n\n` +
    `╭──────────────────────────────╮\n` +
    `  📋 *FORMAT LENGKAP:*\n` +
    `╰──────────────────────────────╯\n\n` +
    `  ${prefix}fakektp provinsi|kota|nik|\n` +
    `  nama|ttl|jenis_kelamin|\n` +
    `  golongan_darah|alamat|\n` +
    `  rt_rw|kel_desa|kecamatan|\n` +
    `  agama|status|pekerjaan|\n` +
    `  kewarganegaraan|masa_berlaku|\n` +
    `  terbuat|pas_photo\n\n` +
    `╭──────────────────────────────╮\n` +
    `  📝 *CONTOH DORAEMON:*\n` +
    `╰──────────────────────────────╯\n\n` +
    `  ${prefix}fakektp prefektur tokyo|\n` +
    `  nerima|2112090309120001|\n` +
    `  doraemon|matsushiba, 03-09-\n` +
    `  2112|laki-laki|Dorayaki|\n` +
    `  rumah keluarga nobi no. 7|\n` +
    `  005/002|nerima|tsukimidai|\n` +
    `  Dorayakisme|menikah dengan\n` +
    `  michan|robot pembantu masa\n` +
    `  depan|WNA|seumur hidup|\n` +
    `  03-09-2112|https://k.top4top.\n` +
    `  io/p_3816oexr91.jpg\n\n` +
    `╭──────────────────────────────╮\n` +
    `  📝 *CONTOH SIMPLE:*\n` +
    `╰──────────────────────────────╯\n\n` +
    `  ${prefix}fakektp jawa barat|\n` +
    `  bandung|1234567890123456|\n` +
    `  shinobu|bandung, 01-01-2000|\n` +
    `  perempuan|O|jl. anime no. 1|\n` +
    `  001/002|konoha|konohagakure|\n` +
    `  islam|kawin|shinobi|WNI|\n` +
    `  seumur hidup|01-01-2020|\n` +
    `  https://foto.jpg\n\n` +
    `╭──────────────────────────────╮\n` +
    `  📋 *18 FIELD DATA:*\n` +
    `╰──────────────────────────────╯\n\n` +
    `  ① Provinsi    ⑩ Kelurahan\n` +
    `  ② Kota        ⑪ Kecamatan\n` +
    `  ③ NIK (16)    ⑫ Agama\n` +
    `  ④ Nama        ⑬ Status\n` +
    `  ⑤ TTL         ⑭ Pekerjaan\n` +
    `  ⑥ Kelamin     ⑮ WNI/WNA\n` +
    `  ⑦ Darah       ⑯ Masa berlaku\n` +
    `  ⑧ Alamat      ⑰ Tgl dibuat\n` +
    `  ⑨ RT/RW       ⑱ URL Foto\n\n` +
    `╭──────────────────────────────╮\n` +
    `  ⚠️  *WARNING!*\n` +
    `  JANGAN UNTUK BERBUAT ANEH!\n` +
    `  Hanya untuk hiburan/prank!\n` +
    `╰──────────────────────────────╯\n\n` +
    `  ⚡ *By Shinobu*  |  🪪 *v1.0*`
  );
}

let handler = async (m, { text, command, sock }) => {
  const prefix = global.prefix || ".";

  // Tampilkan menu kalo gak ada input
  if (!text || !text.trim()) {
    return sock.sendMessage(
      m.chat,
      { text: buildMenuText(prefix) },
      { quoted: m.verifiedQuoted }
    );
  }

  const raw = text.trim();
  const parts = raw.split("|").map(v => v.trim());

  // Validasi jumlah data
  if (parts.length < 18) {
    return sock.sendMessage(
      m.chat,
      {
        text:
          `╭──────────────────────────────╮\n` +
          `  ⚠️  *DATA KURANG LENGKAP!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  📊 Terisi : ${parts.length}/18 field\n` +
          `  📋 Kurang : ${18 - parts.length} field lagi\n\n` +
          `  💡 *Tips:*\n` +
          `  Pisahkan data dengan "|"\n` +
          `  Total harus 18 field!\n\n` +
          `  Ketik *${prefix}fakektp* untuk\n` +
          `  melihat format lengkap.\n\n` +
          `  ⚡ *By Shinobu*`
      },
      { quoted: m.verifiedQuoted }
    );
  }

  const [
    provinsi, kota, nik, nama, ttl,
    jenis_kelamin, golongan_darah, alamat,
    rt_rw, kel_desa, kecamatan, agama,
    status, pekerjaan, kewarganegaraan,
    masa_berlaku, terbuat, pas_photo
  ] = parts;

  // Validasi NIK
  if (!nik.match(/^\d{16}$/)) {
    return sock.sendMessage(
      m.chat,
      {
        text:
          `╭──────────────────────────────╮\n` +
          `  ⚠️  *NIK TIDAK VALID!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  🆔 NIK harus 16 digit angka!\n\n` +
          `  ✗ Kamu input : ${nik}\n` +
          `  ✓ Seharusnya : 2112090309120001\n\n` +
          `  💡 *Tips:*\n` +
          `  Cek lagi NIK yang kamu masukkan!\n\n` +
          `  ⚡ *By Shinobu*`
      },
      { quoted: m.verifiedQuoted }
    );
  }

  // Validasi foto
  if (!pas_photo.startsWith("http")) {
    return sock.sendMessage(
      m.chat,
      {
        text:
          `╭──────────────────────────────╮\n` +
          `  ⚠️  *URL FOTO INVALID!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  🖼️ URL foto harus diawali\n` +
          `  dengan http/https!\n\n` +
          `  ✗ Kamu input : ${pas_photo || "(kosong)"}\n` +
          `  ✓ Seharusnya : https://foto.jpg\n\n` +
          `  💡 *Tips:*\n` +
          `  Upload foto ke Top4Top dulu!\n` +
          `  Ketik .upload (reply foto)\n\n` +
          `  ⚡ *By Shinobu*`
      },
      { quoted: m.verifiedQuoted }
    );
  }

  // Reaksi loading
  await sock.sendMessage(m.chat, { react: { text: "🪪", key: m.key } });

  // Kirim progress
  await sock.sendMessage(
    m.chat,
    {
      text:
        `╭──────────────────────────────╮\n` +
        `  🪪  *MEMBUAT E-KTP...*\n` +
        `╰──────────────────────────────╯\n\n` +
        `  👤 Nama    : ${nama}\n` +
        `  🏙️  Kota    : ${kota}\n` +
        `  🆔 NIK     : ${nik}\n` +
        `  📍 Prov    : ${provinsi}\n` +
        `  🩸 Darah   : ${golongan_darah}\n` +
        `  💍 Status  : ${status}\n\n` +
        `  ⏳ Tunggu sebentar...\n\n` +
        `  ⚡ *By Shinobu*`
    },
    { quoted: m.verifiedQuoted }
  );

  try {
    // Build params
    const params = {
      provinsi, kota, nik, nama, ttl,
      jenis_kelamin, golongan_darah, alamat,
      rt_rw, kel_desa, kecamatan, agama,
      status, pekerjaan, kewarganegaraan,
      masa_berlaku, terbuat, pas_photo
    };

    // Generate E-KTP
    const { buffer, mime } = await generateEktp(params);

    // Kirim hasil
    await sock.sendMessage(
      m.chat,
      {
        image: buffer,
        mimetype: mime,
        caption:
          `╭══════════════════════════════╮\n` +
          `  🪪  *FAKE E-KTP BERHASIL!*  🪪\n` +
          `╰══════════════════════════════╯\n\n` +
          `  👤 *Nama*       : ${nama}\n` +
          `  🏙️  *Kota*       : ${kota}\n` +
          `  🆔 *NIK*        : ${nik}\n` +
          `  🎂 *TTL*        : ${ttl}\n` +
          `  🚻 *Kelamin*    : ${jenis_kelamin}\n` +
          `  🩸 *Darah*      : ${golongan_darah}\n` +
          `  📍 *Alamat*     : ${alamat}\n` +
          `  🏘️  *RT/RW*      : ${rt_rw}\n` +
          `  🏠 *Desa*       : ${kel_desa}\n` +
          `  🏢 *Kecamatan*  : ${kecamatan}\n` +
          `  🕌 *Agama*      : ${agama}\n` +
          `  💍 *Status*     : ${status}\n` +
          `  💼 *Kerja*      : ${pekerjaan}\n` +
          `  🌍 *WN*         : ${kewarganegaraan}\n` +
          `  📅 *Berlaku*    : ${masa_berlaku}\n` +
          `  🗓️  *Dibuat*     : ${terbuat}\n\n` +
          `╭──────────────────────────────╮\n` +
          `  ⚠️  *WARNING!*\n` +
          `  JANGAN UNTUK BERBUAT ANEH!\n` +
          `  Hanya untuk hiburan/prank!\n` +
          `╰──────────────────────────────╯\n\n` +
          `  ⚡ *By Shinobu*  |  🪪 *Fake KTP*`
      },
      { quoted: m.verifiedQuoted }
    );

    await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

  } catch (error) {
    console.error("[FAKE KTP ERROR]", error);
    await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });

    let errorMsg =
      `╭──────────────────────────────╮\n` +
      `  ❌  *GENERATE GAGAL!*\n` +
      `╰──────────────────────────────╯\n\n` +
      `  📡 *Error:* ${error.message}\n\n`;

    if (error.message.includes("Timeout")) {
      errorMsg +=
        `  💡 *Solusi:*\n` +
        `  › Coba lagi nanti\n` +
        `  › Server sedang sibuk\n`;
    } else if (error.message.includes("429")) {
      errorMsg +=
        `  💡 *Solusi:*\n` +
        `  › Rate limit terlewati\n` +
        `  › Tunggu 1 menit\n`;
    } else {
      errorMsg +=
        `  💡 *Solusi:*\n` +
        `  › Cek lagi data yang diinput\n` +
        `  › Pastikan URL foto valid\n` +
        `  › Coba lagi nanti\n`;
    }

    errorMsg += `\n  ⚡ *By Shinobu*`;

    await sock.sendMessage(
      m.chat,
      { text: errorMsg },
      { quoted: m.verifiedQuoted }
    );
  }
};

handler.command = ["fakektp"];
handler.tags = ["maker"];
handler.help = ["fakektp <data>"];
handler.limit = true;

export default handler;