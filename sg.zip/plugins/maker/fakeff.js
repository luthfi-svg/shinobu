// plugins/maker/fakeff.js — Fake Free Fire Lobby Generator (SynoxCloud API)
"use strict";

import axios from "axios";

const API_FAKEFF = "https://api.synoxcloud.xyz/canvas/fakeff";
const REQUEST_TIMEOUT_MS = 30000;
const MAX_USERNAME_LENGTH = 20;
const MAX_LOBBY_LENGTH = 2;

/**
 * Memanggil endpoint /canvas/fakeff.
 * Membuat fake lobby Free Fire dengan username dan nomor lobby.
 * Response API ini berupa binary image langsung.
 */
async function generateFakeFF(params) {
  let res;
  try {
    res = await axios.get(API_FAKEFF, {
      params,
      timeout: REQUEST_TIMEOUT_MS,
      responseType: "arraybuffer",
      validateStatus: () => true,
    });
  } catch (err) {
    if (err.code === "ECONNABORTED") {
      throw new Error("Timeout saat menghubungi server fake FF.");
    }
    throw new Error(`Gagal menghubungi server: ${err.message}`);
  }

  const contentType = String(res.headers["content-type"] || "").toLowerCase();

  if (res.status !== 200) {
    let errMsg = `HTTP ${res.status} - ${res.statusText || "Request gagal"}`;
    if (contentType.includes("application/json")) {
      try {
        const parsed = JSON.parse(Buffer.from(res.data).toString("utf-8"));
        errMsg = parsed?.message || parsed?.error || errMsg;
      } catch {
        // abaikan
      }
    }
    throw new Error(errMsg);
  }

  if (!contentType.startsWith("image/")) {
    throw new Error("Response API bukan image (format tidak sesuai ekspektasi).");
  }

  const buffer = Buffer.from(res.data);
  if (!buffer.length) {
    throw new Error("File gambar hasil generate kosong.");
  }

  return { buffer, mime: contentType };
}

function buildUsageText(command) {
  return (
    `🎮 *Fake Free Fire Lobby Generator*\n\n` +
    `Buat fake lobby Free Fire dengan\n` +
    `username dan nomor lobby custom.\n\n` +
    `*Cara Pakai:*\n` +
    `${command} <username>|<nomor_lobby>\n\n` +
    `*Contoh:*\n` +
    `${command} KAMEK-FARZZ|30\n` +
    `${command} Lordsaurus|99\n` +
    `${command} ProPlayer|50\n\n` +
    `*Batas karakter:*\n` +
    `• Username: ${MAX_USERNAME_LENGTH} karakter\n` +
    `• Nomor Lobby: ${MAX_LOBBY_LENGTH} digit (1-99)\n\n` +
    `*Catatan:* Hasil untuk hiburan/prank saja.\n` +
    `Jangan digunakan untuk penipuan!`
  );
}

let handler = async (m, { text, command, sock }) => {
  // Validasi input
  if (!text || !text.trim()) {
    return sock.sendMessage(
      m.chat,
      { text: buildUsageText(command) },
      { quoted: m.verifiedQuoted }
    );
  }

  const raw = text.trim();
  const parts = raw.split("|").map(s => s.trim());

  const username = parts[0] || "";
  const lobby = parts[1] || "";

  // Validasi username
  if (!username) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Username wajib diisi!\n\nContoh: ${command} KAMEK-FARZZ|30` },
      { quoted: m.verifiedQuoted }
    );
  }

  if (username.length > MAX_USERNAME_LENGTH) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Username terlalu panjang (${username.length}/${MAX_USERNAME_LENGTH} karakter).` },
      { quoted: m.verifiedQuoted }
    );
  }

  // Validasi nomor lobby
  if (!lobby) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Nomor lobby wajib diisi!\n\nContoh: ${command} KAMEK-FARZZ|30` },
      { quoted: m.verifiedQuoted }
    );
  }

  if (!lobby.match(/^\d{1,2}$/)) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Nomor lobby harus angka 1-2 digit!\n\nContoh: 30, 50, 99` },
      { quoted: m.verifiedQuoted }
    );
  }

  const lobbyNum = parseInt(lobby);
  if (lobbyNum < 1 || lobbyNum > 99) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Nomor lobby harus antara 1-99!` },
      { quoted: m.verifiedQuoted }
    );
  }

  // Build params
  let params = {
    username: username,
    lobby: lobby
  };

  // Kirim pesan proses
  await sock.sendMessage(
    m.chat,
    {
      text:
        `🎮 *Membuat Fake FF Lobby...*\n\n` +
        `• Username: ${username}\n` +
        `• Lobby: ${lobby}\n\n` +
        `_Tunggu sebentar..._`
    },
    { quoted: m.verifiedQuoted }
  );

  try {
    // Generate fake FF
    const { buffer, mime } = await generateFakeFF(params);

    // Kirim hasil
    await sock.sendMessage(
      m.chat,
      {
        image: buffer,
        mimetype: mime,
        caption:
          `🎮 *FAKE FREE FIRE LOBBY*\n\n` +
          `• Username: ${username}\n` +
          `• Lobby: ${lobby}\n\n` +
          `_Hasil untuk hiburan/prank saja._ ⚠️\n` +
          `_Jangan digunakan untuk penipuan!_`,
      },
      { quoted: m.verifiedQuoted }
    );
  } catch (err) {
    await sock
      .sendMessage(
        m.chat,
        { text: `❌ Gagal membuat fake FF lobby.\n\n*Alasan:* ${err.message}` },
        { quoted: m.verifiedQuoted }
      )
      .catch(() => {});
  }
};

handler.command = ["fakeff", "ff", "freefire", "lobbyff", "fflobby"];
handler.tags = ["maker"];
handler.help = ["fakeff <username>|<nomor_lobby>"];

export default handler;