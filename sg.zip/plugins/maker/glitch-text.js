// plugins/maker/glitch-text.js — Glitch Text (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Glitch Text
 * 🔧 Fungsi     : Buat text glitch
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `🎨 *Glitch Text*\n\n` +
      `Contoh: ${usedPrefix + command} <text>\n\n` +
      `Fungsi: Buat text glitch`
    );
  }

  try {
    await m.reply("⏳ Creating...");
    
    // Maker simulation
    await m.reply(
      `✅ *Created Successfully*\n\n` +
      `🎨 Type: Glitch Text\n` +
      `📝 Text: ${text}\n\n` +
      `🎯 SHINOBU MD v1.2`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["glitchtext", "textglitch"];
handler.tags = ['maker'];
handler.command = /^(glitchtext|textglitch)$/i;

export default handler;
