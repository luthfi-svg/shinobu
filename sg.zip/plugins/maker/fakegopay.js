// plugins/maker/fakegopay.js — Fake Gopay Generator
/**
 * ───「 FEATURE AUTHOR 」───
 * 👤 Author     : Lynx Decode
 * 📞 Contact    : +62 882-5804-1396
 * 📢 Channel    : https://whatsapp.com/channel/0029VbAnuii6GcGCu73oep1i
 * ⚠️ Note       : Keep credit to respect the creator!
 * ─────────────────────────
 * 📝 Plugin: Fake Gopay Generator
 */

"use strict";

import axios from "axios";

async function generateFakeGopay(saldo, koin) {
  const apiUrl = `https://api.cmnty.web.id/maker/fake-gopay?saldo=${encodeURIComponent(saldo)}&koin=${encodeURIComponent(koin)}`;

  const res = await axios.get(apiUrl, {
    timeout: 30000,
    responseType: "arraybuffer",
    validateStatus: () => true,
  });

  if (res.status !== 200) {
    throw new Error(`Server API merespon dengan HTTP ${res.status}`);
  }

  const contentType = String(res.headers["content-type"] || "").toLowerCase();

  if (!contentType.startsWith("image/")) {
    throw new Error("Response bukan gambar");
  }

  const buffer = Buffer.from(res.data);
  if (!buffer.length) throw new Error("File gambar kosong");

  return buffer;
}

function buildUsageText(prefix, command) {
  return (
    `┌˚₊ ๑│ FAKE GOPAY │๑˚₊ ❌\n` +
    `┇ \n` +
    `│ ❌ *Format salah! Gunakan:*\n` +
    `│ ${prefix + command} 890000|159\n` +
    `┇ \n` +
    `└˚₊ ๑ ────────────── ๑˚₊\n` +
    `> © ERINE-AI`
  );
}

let handler = async (m, { text, command, sock }) => {
  const prefix = global.prefix || ".";

  let [saldo, koin] = text.split("|").map(v => v.trim());

  // Validasi input
  if (!saldo || !koin) {
    return sock.sendMessage(
      m.chat,
      { text: buildUsageText(prefix, command) },
      { quoted: m.verifiedQuoted }
    );
  }

  // Validasi saldo harus angka
  if (isNaN(saldo)) {
    return sock.sendMessage(
      m.chat,
      {
        text:
          `┌˚₊ ๑│ FAKE GOPAY │๑˚₊ ❌\n` +
          `┇ \n` +
          `│ ❌ *Saldo harus angka!*\n` +
          `┇ \n` +
          `└˚₊ ๑ ────────────── ๑˚₊\n` +
          `> © ERINE-AI`
      },
      { quoted: m.verifiedQuoted }
    );
  }

  // Validasi koin harus angka
  if (isNaN(koin)) {
    return sock.sendMessage(
      m.chat,
      {
        text:
          `┌˚₊ ๑│ FAKE GOPAY │๑˚₊ ❌\n` +
          `┇ \n` +
          `│ ❌ *Koin harus angka!*\n` +
          `┇ \n` +
          `└˚₊ ๑ ────────────── ๑˚₊\n` +
          `> © ERINE-AI`
      },
      { quoted: m.verifiedQuoted }
    );
  }

  // Reaksi loading
  await sock.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

  try {
    const buffer = await generateFakeGopay(saldo, koin);

    let caption =
      `┌˚₊ ๑│ FAKE GOPAY │๑˚₊ 🎨\n` +
      `┇ \n` +
      `│ ✅ *Berhasil dibuat!*\n` +
      `│ 💰 Saldo: Rp${saldo}\n` +
      `│ 🪙 Koin: ${koin}\n` +
      `┇ \n` +
      `└˚₊ ๑ ────────────── ๑˚₊\n` +
      `> © ERINE-AI`;

    await sock.sendMessage(
      m.chat,
      {
        image: buffer,
        caption: caption,
      },
      { quoted: m.verifiedQuoted }
    );

    await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

  } catch (error) {
    console.error("[FAKE GOPAY ERROR]", error);
    await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    await sock.sendMessage(
      m.chat,
      {
        text:
          `┌˚₊ ๑│ FAKE GOPAY │๑˚₊ ❌\n` +
          `┇ \n` +
          `│ ❌ *Terjadi kesalahan saat memproses API.*\n` +
          `│ \n` +
          `│ *Detail:* ${error.message || String(error)}\n` +
          `┇ \n` +
          `└˚₊ ๑ ────────────── ๑˚₊\n` +
          `> © ERINE-AI`
      },
      { quoted: m.verifiedQuoted }
    );
  }
};

handler.command = ["fakegopay"];
handler.tags = ["maker"];
handler.help = ["fakegopay <saldo|koin>"];
handler.limit = true;

export default handler;