// plugins/maker/fakeml.js — Fake Mobile Legends Generator (SynoxCloud API)
"use strict";

import axios from "axios";
import FormData from "form-data";

const API_FAKEML = "https://api.synoxcloud.xyz/canvas/fakeml";
const API_CATBOX = "https://api.synoxcloud.xyz/uploader/catbox";
const REQUEST_TIMEOUT_MS = 30000;
const UPLOAD_TIMEOUT_MS = 15000;
const MAX_USERNAME_LENGTH = 20;
const MAX_RANK_LENGTH = 30;
const MAX_BORDER_LENGTH = 2;
const URL_REGEX = /^https?:\/\/.+\.(jpg|jpeg|png|gif|webp)(\?.*)?$/i;

// List rank ML yang valid
const VALID_RANKS = [
  "warrior", "elite", "master", "grandmaster",
  "epic", "legend", "mythic", "mythical glory",
  "mythical honor", "mythical immortal"
];

/**
 * Mengecek apakah string adalah URL gambar valid.
 */
function isImageUrl(str) {
  return URL_REGEX.test(str);
}

/**
 * Upload file ke Catbox.moe melalui SynoxCloud API.
 */
async function uploadToCatbox(buffer, fileName = "avatar.jpg") {
  try {
    const form = new FormData();
    form.append("file", buffer, fileName);

    const res = await axios.post(API_CATBOX, form, {
      headers: form.getHeaders(),
      timeout: UPLOAD_TIMEOUT_MS,
      validateStatus: () => true,
    });

    if (res.status === 200 && res.data) {
      let url = null;
      
      if (typeof res.data === "string") {
        url = res.data.trim();
      } else if (res.data.url) {
        url = res.data.url;
      } else if (res.data.result) {
        url = res.data.result;
      } else if (res.data.link) {
        url = res.data.link;
      } else if (res.data.data && res.data.data.url) {
        url = res.data.data.url;
      }

      if (url && url.startsWith("http")) {
        console.log("Catbox upload success:", url);
        return url;
      }
    }

    throw new Error("Response Catbox tidak valid");
  } catch (err) {
    if (err.message.includes("Response Catbox")) {
      throw err;
    }
    throw new Error(`Upload ke Catbox gagal: ${err.message}`);
  }
}

/**
 * Mendapatkan URL avatar dari reply gambar.
 */
async function getAvatarFromReply(sock, m) {
  const quotedMsg = m.verifiedQuoted || m.quoted;
  
  if (quotedMsg && quotedMsg.mtype === "imageMessage") {
    try {
      const media = await sock.downloadMediaMessage(quotedMsg);
      if (media) {
        const url = await uploadToCatbox(media, `ml_avatar_${Date.now()}.jpg`);
        return url;
      }
    } catch (err) {
      console.error("Failed to process reply image:", err.message);
      throw new Error(`Gagal upload avatar: ${err.message}`);
    }
  }
  
  return null;
}

/**
 * Memanggil endpoint /canvas/fakeml.
 * Generate Fake Mobile Legends dengan avatar, username, rank, dan border.
 */
async function generateFakeML(params) {
  let res;
  try {
    res = await axios.get(API_FAKEML, {
      params,
      timeout: REQUEST_TIMEOUT_MS,
      responseType: "arraybuffer",
      validateStatus: () => true,
    });
  } catch (err) {
    if (err.code === "ECONNABORTED") {
      throw new Error("Timeout saat menghubungi server fake ML.");
    }
    throw new Error(`Gagal menghubungi server: ${err.message}`);
  }

  const contentType = String(res.headers["content-type"] || "").toLowerCase();

  if (res.status !== 200) {
    let errMsg = `HTTP ${res.status} - ${res.statusText || "Request gagal"}`;
    if (contentType.includes("application/json")) {
      try {
        const parsed = JSON.parse(Buffer.from(res.data).toString("utf-8"));
        errMsg = parsed?.message || parsed?.error || errMsg;
      } catch {
        // abaikan
      }
    }
    throw new Error(errMsg);
  }

  if (!contentType.startsWith("image/")) {
    throw new Error("Response API bukan image (format tidak sesuai ekspektasi).");
  }

  const buffer = Buffer.from(res.data);
  if (!buffer.length) {
    throw new Error("File gambar hasil generate kosong.");
  }

  return { buffer, mime: contentType };
}

function buildUsageText(command) {
  return (
    `🎮 *Fake Mobile Legends Generator*\n\n` +
    `Buat fake profile Mobile Legends\n` +
    `dengan avatar, username, rank, dan border.\n\n` +
    `*Cara Pakai:*\n` +
    `${command} <username>|<rank>|<border>|<url_avatar>\n\n` +
    `*Atau dengan reply foto:*\n` +
    `${command} <username>|<rank>|<border> (reply foto untuk avatar)\n\n` +
    `*Contoh:*\n` +
    `${command} Saurus|epic|16|https://d.top4top.io/p_38200eohz1.jpg\n` +
    `${command} Lordsaurus|mythic|20\n` +
    `${command} ProPlayer|legend|10 (reply foto)\n\n` +
    `*Rank Tersedia:*\n` +
    `warrior, elite, master, grandmaster,\n` +
    `epic, legend, mythic, mythical glory,\n` +
    `mythical honor, mythical immortal\n\n` +
    `*Border:* 1-99 (angka border card)\n` +
    `*Batas karakter:*\n` +
    `• Username: ${MAX_USERNAME_LENGTH} karakter\n` +
    `• Rank: ${MAX_RANK_LENGTH} karakter\n` +
    `• Border: ${MAX_BORDER_LENGTH} digit\n\n` +
    `*Format URL avatar:* https://...jpg/png/gif\n` +
    `*Prioritas avatar:* Reply gambar > Input URL > Tanpa avatar\n` +
    `*Upload:* Reply gambar diupload ke Catbox.moe\n` +
    `*Catatan:* Hasil untuk hiburan/prank saja.`
  );
}

let handler = async (m, { text, command, sock }) => {
  // Validasi input
  if (!text || !text.trim()) {
    return sock.sendMessage(
      m.chat,
      { text: buildUsageText(command) },
      { quoted: m.verifiedQuoted }
    );
  }

  const raw = text.trim();
  const parts = raw.split("|").map(s => s.trim());

  const username = parts[0] || "";
  const rank = parts[1] || "";
  const border = parts[2] || "";
  const urlAvatar = parts[3] || "";

  // Validasi username
  if (!username) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Username wajib diisi!\n\nContoh: ${command} Saurus|epic|16|https://avatar.jpg` },
      { quoted: m.verifiedQuoted }
    );
  }

  if (username.length > MAX_USERNAME_LENGTH) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Username terlalu panjang (${username.length}/${MAX_USERNAME_LENGTH} karakter).` },
      { quoted: m.verifiedQuoted }
    );
  }

  // Validasi rank
  if (!rank) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Rank wajib diisi!\n\nContoh: ${command} Saurus|epic|16` },
      { quoted: m.verifiedQuoted }
    );
  }

  if (rank.length > MAX_RANK_LENGTH) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Rank terlalu panjang (${rank.length}/${MAX_RANK_LENGTH} karakter).` },
      { quoted: m.verifiedQuoted }
    );
  }

  // Validasi border
  if (!border) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Border wajib diisi!\n\nContoh: ${command} Saurus|epic|16` },
      { quoted: m.verifiedQuoted }
    );
  }

  if (!border.match(/^\d{1,2}$/)) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Border harus angka 1-2 digit!\n\nContoh: 16, 20, 99` },
      { quoted: m.verifiedQuoted }
    );
  }

  const borderNum = parseInt(border);
  if (borderNum < 1 || borderNum > 99) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Border harus antara 1-99!` },
      { quoted: m.verifiedQuoted }
    );
  }

  // Ambil URL avatar dari reply gambar (prioritas utama)
  let finalAvatarUrl = "";
  let avatarSource = "";

  // Cek reply gambar dulu
  try {
    const replyAvatarUrl = await getAvatarFromReply(sock, m);
    
    if (replyAvatarUrl) {
      finalAvatarUrl = replyAvatarUrl;
      avatarSource = "Reply Gambar (Catbox)";
    }
  } catch (err) {
    return sock.sendMessage(
      m.chat,
      { text: `❌ ${err.message}` },
      { quoted: m.verifiedQuoted }
    );
  }

  // Kalo gak ada reply, cek input URL
  if (!finalAvatarUrl && urlAvatar) {
    if (!isImageUrl(urlAvatar)) {
      return sock.sendMessage(
        m.chat,
        { text: `⚠️ URL avatar tidak valid!\n\nFormat: https://...jpg/png/gif\n\nContoh: https://d.top4top.io/p_38200eohz1.jpg` },
        { quoted: m.verifiedQuoted }
      );
    }
    finalAvatarUrl = urlAvatar;
    avatarSource = "URL Input";
  }

  // Kalo gak ada keduanya
  if (!finalAvatarUrl) {
    avatarSource = "Tanpa Avatar";
  }

  // Capitalize rank
  const displayRank = rank.charAt(0).toUpperCase() + rank.slice(1).toLowerCase();

  // Build params
  let params = {};
  params.username = username;
  params.rank = rank.toLowerCase();
  params.border = border;
  if (finalAvatarUrl) params.avatar = finalAvatarUrl;

  // Kirim pesan proses
  await sock.sendMessage(
    m.chat,
    {
      text:
        `🎮 *Membuat Fake ML Profile...*\n\n` +
        `• Username: ${username}\n` +
        `• Rank: ${displayRank}\n` +
        `• Border: ${border}\n` +
        `• Avatar: ${avatarSource}\n\n` +
        `_Tunggu sebentar..._`
    },
    { quoted: m.verifiedQuoted }
  );

  try {
    // Generate fake ML
    const { buffer, mime } = await generateFakeML(params);

    // Kirim hasil
    await sock.sendMessage(
      m.chat,
      {
        image: buffer,
        mimetype: mime,
        caption:
          `🎮 *FAKE MOBILE LEGENDS*\n\n` +
          `• Username: ${username}\n` +
          `• Rank: ${displayRank}\n` +
          `• Border: ${border}\n` +
          `• Avatar: ${avatarSource}\n\n` +
          `_Hasil untuk hiburan/prank saja._ ⚠️\n` +
          `_Jangan digunakan untuk penipuan!_`,
      },
      { quoted: m.verifiedQuoted }
    );
  } catch (err) {
    await sock
      .sendMessage(
        m.chat,
        { text: `❌ Gagal membuat fake ML profile.\n\n*Alasan:* ${err.message}` },
        { quoted: m.verifiedQuoted }
      )
      .catch(() => {});
  }
};

handler.command = ["fakeml", "ml", "mobilelegend", "mlbb"];
handler.tags = ["maker"];
handler.help = ["fakeml <username>|<rank>|<border>|<url_avatar>"];

export default handler;