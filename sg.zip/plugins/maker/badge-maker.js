// plugins/maker/badge-maker.js — Badge Maker (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Badge Maker
 * 🔧 Fungsi     : Buat badge
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `🎨 *Badge Maker*\n\n` +
      `Contoh: ${usedPrefix + command} <text>\n\n` +
      `Fungsi: Buat badge`
    );
  }

  try {
    await m.reply("⏳ Creating...");
    
    // Maker simulation
    await m.reply(
      `✅ *Created Successfully*\n\n` +
      `🎨 Type: Badge Maker\n` +
      `📝 Text: ${text}\n\n` +
      `🎯 SHINOBU MD v1.2`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["badgemaker", "buatbadge"];
handler.tags = ['maker'];
handler.command = /^(badgemaker|buatbadge)$/i;

export default handler;
