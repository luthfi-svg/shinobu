// plugins/maker/carbon.js — Generate code screenshot (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Carbon Code Screenshot
 * 🔧 Fungsi     : Generate beautiful code screenshot
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

let handler = async (m, { sock, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `Contoh penggunaan:\n${usedPrefix + command} <code>\n\n` +
      `Contoh:\n` +
      `${usedPrefix + command} console.log("Hello World");\n\n` +
      `Atau reply code dengan caption:\n` +
      `${usedPrefix + command}`
    );
  }

  let code = text;
  
  // If replying to message, use quoted text
  if (m.quoted && m.quoted.text) {
    code = m.quoted.text;
  }

  try {
    await m.reply("⏳ *Generating Code Screenshot...*\n\nMohon tunggu...");

    // Use Carbon API
    const apiUrl = `https://carbonara.solopov.dev/api/cook`;
    
    const response = await axios.post(
      apiUrl,
      {
        code: code,
        backgroundColor: "#1F2937",
        theme: "monokai",
        language: "auto",
        paddingVertical: "56px",
        paddingHorizontal: "56px",
        dropShadow: true,
        windowTheme: "sharp"
      },
      {
        responseType: "arraybuffer",
        timeout: 30000
      }
    );

    const imageBuffer = Buffer.from(response.data);

    await sock.sendMessage(
      m.chat,
      {
        image: imageBuffer,
        caption: `✅ *Carbon Code Screenshot*\n\n📝 Code length: ${code.length} chars`
      },
      { quoted: m }
    );

    await m.react("✅");

  } catch (e) {
    console.error(e);
    await m.reply(
      `❌ *Carbon Error*\n\n` +
      `Gagal generate: ${e.message}\n\n` +
      `Tips:\n` +
      `• Pastikan code tidak terlalu panjang\n` +
      `• Coba lagi beberapa saat`
    );
  }
};

handler.help = ["carbon <code>"];
handler.tags = ["maker"];
handler.command = /^(carbon|carbonara)$/i;
handler.limit = true;

export default handler;
