// plugins/maker/quote-maker.js — Quote Maker (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Quote Maker
 * 🔧 Fungsi     : Buat quote aesthetic
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `🎨 *Quote Maker*\n\n` +
      `Contoh: ${usedPrefix + command} <text>\n\n` +
      `Fungsi: Buat quote aesthetic`
    );
  }

  try {
    await m.reply("⏳ Creating...");
    
    // Maker simulation
    await m.reply(
      `✅ *Created Successfully*\n\n` +
      `🎨 Type: Quote Maker\n` +
      `📝 Text: ${text}\n\n` +
      `🎯 SHINOBU MD v1.2`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["quotemaker", "buatquote"];
handler.tags = ['maker'];
handler.command = /^(quotemaker|buatquote)$/i;

export default handler;
