// plugins/maker/fakestory.js — Fake Story Generator (SynoxCloud API)
"use strict";

import axios from "axios";

const API_BASE = "https://api.synoxcloud.xyz/canvas/fakestory";
const REQUEST_TIMEOUT_MS = 30000;
const MAX_NICKNAME_LENGTH = 30;
const MAX_TEXT_LENGTH = 200;
const URL_REGEX = /^https?:\/\/.+\.(jpg|jpeg|png|gif|webp)(\?.*)?$/i;

/**
 * Mengecek apakah string adalah URL gambar valid.
 */
function isImageUrl(str) {
  return URL_REGEX.test(str);
}

/**
 * Memanggil endpoint /canvas/fakestory.
 * Generate realistic story-style image dengan nickname, text, dan foto profil.
 * Response API ini berupa binary image langsung.
 */
async function generateFakeStory(params) {
  let res;
  try {
    res = await axios.get(API_BASE, {
      params,
      timeout: REQUEST_TIMEOUT_MS,
      responseType: "arraybuffer",
      validateStatus: () => true,
    });
  } catch (err) {
    if (err.code === "ECONNABORTED") {
      throw new Error("Timeout saat menghubungi server fake story.");
    }
    throw new Error(`Gagal menghubungi server: ${err.message}`);
  }

  const contentType = String(res.headers["content-type"] || "").toLowerCase();

  if (res.status !== 200) {
    let errMsg = `HTTP ${res.status} - ${res.statusText || "Request gagal"}`;
    if (contentType.includes("application/json")) {
      try {
        const parsed = JSON.parse(Buffer.from(res.data).toString("utf-8"));
        errMsg = parsed?.message || parsed?.error || errMsg;
      } catch {
        // abaikan
      }
    }
    throw new Error(errMsg);
  }

  if (!contentType.startsWith("image/")) {
    throw new Error("Response API bukan image (format tidak sesuai ekspektasi).");
  }

  const buffer = Buffer.from(res.data);
  if (!buffer.length) {
    throw new Error("File gambar hasil generate kosong.");
  }

  return { buffer, mime: contentType };
}

function buildUsageText(command) {
  return (
    `📸 *Fake Story Generator*\n\n` +
    `Buat fake story Instagram/WA dengan\n` +
    `nama, teks, dan foto profil custom.\n\n` +
    `*Cara Pakai:*\n` +
    `${command} <nickname>|<teks>|<url_foto>\n\n` +
    `*Contoh:*\n` +
    `${command} Saurus|Haii haloo|https://c.top4top.io/p_3815w0ycy1.jpg\n` +
    `${command} Lordsaurus|Happy weekend!|https://c.top4top.io/p_3815w0ycy1.jpg\n\n` +
    `*Batas karakter:*\n` +
    `• Nickname: ${MAX_NICKNAME_LENGTH} karakter\n` +
    `• Teks: ${MAX_TEXT_LENGTH} karakter\n\n` +
    `*Format URL foto:* https://...jpg/png/gif\n` +
    `*Note:* Kosongkan URL foto jika tidak ingin pakai foto\n` +
    `*Catatan:* Hasil untuk hiburan/prank saja.`
  );
}

let handler = async (m, { text, command, sock }) => {
  // Validasi input
  if (!text || !text.trim()) {
    return sock.sendMessage(
      m.chat,
      { text: buildUsageText(command) },
      { quoted: m.verifiedQuoted }
    );
  }

  const raw = text.trim();
  const parts = raw.split("|").map(s => s.trim());

  const nickname = parts[0] || "";
  const storyText = parts[1] || "";
  const ppUrl = parts[2] || "";

  // Validasi nickname
  if (!nickname) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Nickname wajib diisi!\n\nContoh: ${command} Saurus|Haii haloo|https://foto.jpg` },
      { quoted: m.verifiedQuoted }
    );
  }

  if (nickname.length > MAX_NICKNAME_LENGTH) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Nickname terlalu panjang (${nickname.length}/${MAX_NICKNAME_LENGTH} karakter).` },
      { quoted: m.verifiedQuoted }
    );
  }

  // Validasi teks
  if (!storyText) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Teks story wajib diisi!\n\nContoh: ${command} Saurus|Haii haloo|https://foto.jpg` },
      { quoted: m.verifiedQuoted }
    );
  }

  if (storyText.length > MAX_TEXT_LENGTH) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Teks terlalu panjang (${storyText.length}/${MAX_TEXT_LENGTH} karakter).` },
      { quoted: m.verifiedQuoted }
    );
  }

  // Validasi URL foto
  if (ppUrl && !isImageUrl(ppUrl)) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ URL foto tidak valid!\n\nFormat: https://...jpg/png/gif\n\nContoh: https://c.top4top.io/p_3815w0ycy1.jpg` },
      { quoted: m.verifiedQuoted }
    );
  }

  // Build params
  let params = {};
  params.nickname = nickname;
  params.text = storyText;
  if (ppUrl) params.pp = ppUrl;

  // Kirim pesan proses
  await sock.sendMessage(
    m.chat,
    {
      text:
        `📸 *Membuat Fake Story...*\n\n` +
        `• Nickname: ${nickname}\n` +
        `• Teks: ${storyText}\n` +
        `• Foto: ${ppUrl ? "Custom" : "Tanpa Foto"}\n\n` +
        `_Tunggu sebentar..._`
    },
    { quoted: m.verifiedQuoted }
  );

  try {
    // Generate fake story
    const { buffer, mime } = await generateFakeStory(params);

    // Kirim hasil
    await sock.sendMessage(
      m.chat,
      {
        image: buffer,
        mimetype: mime,
        caption:
          `📸 *FAKE STORY*\n\n` +
          `• Nickname: ${nickname}\n` +
          `• Teks: ${storyText}\n` +
          `• Foto: ${ppUrl ? "Custom" : "Tanpa Foto"}\n\n` +
          `_Hasil untuk hiburan/prank saja._`,
      },
      { quoted: m.verifiedQuoted }
    );
  } catch (err) {
    await sock
      .sendMessage(
        m.chat,
        { text: `❌ Gagal membuat fake story.\n\n*Alasan:* ${err.message}` },
        { quoted: m.verifiedQuoted }
      )
      .catch(() => {});
  }
};

handler.command = ["fakestory", "story", "storywa", "storyig"];
handler.tags = ["maker"];
handler.help = ["fakestory <nickname>|<teks>|<url_foto>"];

export default handler;