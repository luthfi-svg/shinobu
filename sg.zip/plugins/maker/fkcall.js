// plugins/fun/fakecall.js — Fake Call Generator (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Fake Call Generator
 * 📞 Fungsi     : Generate fake incoming call
 * 🎨 Design     : Premium UI
 * 📦 Version    : 1.2
 * 👤 By Valzz
 * ─────────────────────────
 */

import axios from "axios";
import FormData from "form-data";

const API_FAKECALL = "https://api.synoxcloud.xyz/canvas/fakecall";
const API_CATBOX = "https://api.synoxcloud.xyz/uploader/catbox";
const REQUEST_TIMEOUT_MS = 30000;
const UPLOAD_TIMEOUT_MS = 15000;
const MAX_NAME_LENGTH = 30;
const DEFAULT_PP = "https://c.top4top.io/p_3815w0ycy1.jpg";

async function uploadToCatbox(buffer, fileName = "pp.jpg") {
  try {
    const form = new FormData();
    form.append("file", buffer, fileName);
    const res = await axios.post(API_CATBOX, form, {
      headers: form.getHeaders(),
      timeout: UPLOAD_TIMEOUT_MS,
      validateStatus: () => true,
    });
    if (res.status === 200 && res.data) {
      let url = null;
      if (typeof res.data === "string") url = res.data.trim();
      else url = res.data.url || res.data.result || res.data.link || "";
      if (url && url.startsWith("http")) return url;
    }
    throw new Error("Gagal upload");
  } catch (err) {
    console.error("[Catbox] Error:", err.message);
    return null;
  }
}

async function generateFakeCall(name, time, pp) {
  const res = await axios.get(API_FAKECALL, {
    params: { name, time, pp },
    timeout: REQUEST_TIMEOUT_MS,
    responseType: "arraybuffer",
    validateStatus: () => true,
  });

  const contentType = String(res.headers["content-type"] || "").toLowerCase();

  if (res.status !== 200) {
    let errMsg = `HTTP ${res.status}`;
    if (contentType.includes("json")) {
      try {
        const json = JSON.parse(Buffer.from(res.data).toString("utf-8"));
        errMsg = json?.message || json?.error || errMsg;
      } catch {}
    }
    throw new Error(errMsg);
  }

  if (!contentType.includes("image")) {
    throw new Error("Response bukan gambar! Type: " + contentType);
  }

  const buffer = Buffer.from(res.data);
  if (!buffer.length) throw new Error("File kosong!");
  return buffer;
}

function buildMenuText(prefix) {
  return (
    `╭══════════════════════════════╮\n` +
    `│                              │\n` +
    `│   📞  *FAKE CALL*  📞      │\n` +
    `│   ──────────────────────    │\n` +
    `│   Generate Fake Incoming    │\n` +
    `│   Call buat Prank!          │\n` +
    `│   👤 By Valzz               │\n` +
    `│                              │\n` +
    `╰══════════════════════════════╯\n\n` +
    `  📌 *Cara Pakai:*\n` +
    `  ${prefix}call nama|waktu\n` +
    `  ${prefix}call nama|waktu (reply foto)\n\n` +
    `  💡 *Contoh:*\n` +
    `  ${prefix}call Ayank|00:30\n` +
    `  ${prefix}call Pacar|02:15\n` +
    `  ${prefix}call Bos|01:00 (reply foto)\n\n` +
    `  📝 *Format Waktu:* MM:DD\n` +
    `  🖼️ *PP:* Reply foto / default\n` +
    `  📏 *Max Nama:* ${MAX_NAME_LENGTH} karakter\n\n` +
    `  👤 *By Valzz*`
  );
}

let handler = async (m, { text, command, sock }) => {
  const prefix = global.prefix || ".";

  // ===== MENU =====
  if (!text || !text.trim()) {
    return sock.sendMessage(m.chat, {
      text: buildMenuText(prefix)
    }, { quoted: m.verifiedQuoted });
  }

  const parts = text.split("|").map(v => v.trim());
  const name = parts[0] || "";
  let time = parts[1] || "00:30";

  // ===== VALIDASI NAMA =====
  if (!name) {
    return sock.sendMessage(m.chat, {
      text:
        `╭──────────────────────────────╮\n` +
        `  ⚠️  *NAMA WAJIB!*\n` +
        `╰──────────────────────────────╯\n\n` +
        `  Format: ${prefix}call nama|waktu\n\n` +
        `  Contoh: ${prefix}call Ayank|00:30\n\n` +
        `  👤 *By Valzz*`
    }, { quoted: m.verifiedQuoted });
  }

  if (name.length > MAX_NAME_LENGTH) {
    return sock.sendMessage(m.chat, {
      text:
        `╭──────────────────────────────╮\n` +
        `  ⚠️  *NAMA TERLALU PANJANG!*\n` +
        `╰──────────────────────────────╯\n\n` +
        `  Maksimal ${MAX_NAME_LENGTH} karakter.\n` +
        `  Kamu: ${name.length} karakter\n\n` +
        `  👤 *By Valzz*`
    }, { quoted: m.verifiedQuoted });
  }

  // ===== VALIDASI WAKTU =====
  if (!time.match(/^\d{2}:\d{2}$/)) {
    time = "00:30";
  }

  // ===== AMBIL PP =====
  let ppUrl = DEFAULT_PP;
  let ppSource = "Default";
  const quotedMsg = m.verifiedQuoted || m.quoted;

  if (quotedMsg && quotedMsg.mtype === "imageMessage") {
    await sock.sendMessage(m.chat, { react: { text: "📤", key: m.key } });
    try {
      const media = await sock.downloadMediaMessage(quotedMsg);
      if (media) {
        const url = await uploadToCatbox(media, `pp_${Date.now()}.jpg`);
        if (url) {
          ppUrl = url;
          ppSource = "Custom (Reply)";
        }
      }
    } catch (err) {
      console.error("[PP Upload] Error:", err.message);
    }
  }

  // ===== PROGRESS =====
  await sock.sendMessage(m.chat, { react: { text: "📞", key: m.key } });

  await sock.sendMessage(m.chat, {
    text:
      `╭──────────────────────────────╮\n` +
      `  📞  *INCOMING CALL...*\n` +
      `╰──────────────────────────────╯\n\n` +
      `  👤 Nama   : ${name}\n` +
      `  ⏰ Waktu  : ${time}\n` +
      `  🖼️ PP     : ${ppSource}\n\n` +
      `  _Membuat fake call..._\n\n` +
      `  👤 *By Valzz*`
  }, { quoted: m.verifiedQuoted });

  // ===== GENERATE =====
  try {
    const buffer = await generateFakeCall(name, time, ppUrl);

    // Kirim hasil
    await sock.sendMessage(m.chat, {
      image: buffer,
      caption:
        `╭──────────────────────────────╮\n` +
        `  📞  *FAKE CALL*  📞\n` +
        `╰──────────────────────────────╯\n\n` +
        `  👤 Nama   : ${name}\n` +
        `  ⏰ Waktu  : ${time}\n` +
        `  🖼️ PP     : ${ppSource}\n` +
        `  📏 Size   : ${(buffer.length / 1024).toFixed(1)} KB\n\n` +
        `  _Ada yang nelpon nih..._ 📞\n\n` +
        `  👤 *By Valzz*`
    }, { quoted: m.verifiedQuoted });

    await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

  } catch (error) {
    console.error("[FAKE CALL ERROR]", error);
    await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });

    let errorMsg =
      `╭──────────────────────────────╮\n` +
      `  ❌  *GAGAL!*\n` +
      `╰──────────────────────────────╯\n\n` +
      `  📡 ${error.message}\n\n`;

    if (error.message.includes("Timeout")) {
      errorMsg += `  💡 Server sibuk, coba lagi.\n`;
    } else {
      errorMsg += `  💡 Coba lagi nanti!\n`;
    }

    errorMsg += `\n  👤 *By Valzz*`;

    await sock.sendMessage(m.chat, { text: errorMsg }, { quoted: m.verifiedQuoted });
  }
};

handler.command = ["call", "fakecall", "prankcall", "telp"];
handler.tags = ["fun"];
handler.help = ["call <nama|waktu>"];
handler.limit = true;

export default handler;