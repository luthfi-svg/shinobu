// plugins/maker/banner-maker.js — Banner Maker (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Banner Maker
 * 🔧 Fungsi     : Buat banner
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `🎨 *Banner Maker*\n\n` +
      `Contoh: ${usedPrefix + command} <text>\n\n` +
      `Fungsi: Buat banner`
    );
  }

  try {
    await m.reply("⏳ Creating...");
    
    // Maker simulation
    await m.reply(
      `✅ *Created Successfully*\n\n` +
      `🎨 Type: Banner Maker\n` +
      `📝 Text: ${text}\n\n` +
      `🎯 SHINOBU MD v1.2`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["bannermaker", "buatbanner"];
handler.tags = ['maker'];
handler.command = /^(bannermaker|buatbanner)$/i;

export default handler;
