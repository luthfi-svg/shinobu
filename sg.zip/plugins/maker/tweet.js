// plugins/maker/tweet.js — Generate fake tweet (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Fake Tweet
 * 🔧 Fungsi     : Generate fake Twitter/X tweet
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

let handler = async (m, { sock, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `Contoh penggunaan:\n${usedPrefix + command} <username>|<text>\n\n` +
      `Contoh:\n` +
      `${usedPrefix + command} elonmusk|Hello World!`
    );
  }

  const parts = text.split("|");
  
  if (parts.length < 2) {
    return m.reply("❌ Format salah! Gunakan: username|text");
  }

  const username = parts[0].trim();
  const tweet = parts.slice(1).join("|").trim();

  try {
    await m.reply("⏳ *Generating Tweet...*");

    const response = await axios.get(
      `https://some-api.com/canvas/tweet?username=${encodeURIComponent(username)}&tweet=${encodeURIComponent(tweet)}`,
      {
        responseType: "arraybuffer",
        timeout: 30000
      }
    ).catch(async () => {
      // Fallback: text-based fake tweet
      return {
        data: Buffer.from(
          `Twitter/X\n\n@${username}\n${tweet}\n\n${new Date().toLocaleString()}`
        )
      };
    });

    if (response.data instanceof Buffer && response.data.length > 100) {
      await sock.sendMessage(
        m.chat,
        {
          image: response.data,
          caption: `🐦 *Fake Tweet*\n\n@${username}\n"${tweet.substring(0, 100)}..."`
        },
        { quoted: m }
      );
    } else {
      await m.reply(
        `🐦 *Fake Tweet*\n\n` +
        `👤 Username: @${username}\n` +
        `💬 Tweet: ${tweet}\n\n` +
        `_This is a fake tweet, not real!_`
      );
    }

    await m.react("✅");

  } catch (e) {
    console.error(e);
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["tweet <username>|<text>"];
handler.tags = ["maker"];
handler.command = /^(tweet|faketweet)$/i;
handler.limit = true;

export default handler;
