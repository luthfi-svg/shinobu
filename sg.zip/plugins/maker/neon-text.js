// plugins/maker/neon-text.js — Neon Text (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Neon Text
 * 🔧 Fungsi     : Buat text neon
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `🎨 *Neon Text*\n\n` +
      `Contoh: ${usedPrefix + command} <text>\n\n` +
      `Fungsi: Buat text neon`
    );
  }

  try {
    await m.reply("⏳ Creating...");
    
    // Maker simulation
    await m.reply(
      `✅ *Created Successfully*\n\n` +
      `🎨 Type: Neon Text\n` +
      `📝 Text: ${text}\n\n` +
      `🎯 SHINOBU MD v1.2`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["neontext", "textneon"];
handler.tags = ['maker'];
handler.command = /^(neontext|textneon)$/i;

export default handler;
