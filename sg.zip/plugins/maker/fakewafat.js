// plugins/maker/fakewafat.js — Fake Wafat Generator (SynoxCloud API)
"use strict";

import axios from "axios";
import FormData from "form-data";

const API_FAKEWAFAT = "https://api.synoxcloud.xyz/canvas/fakewafat";
const API_CATBOX = "https://api.synoxcloud.xyz/uploader/catbox";
const REQUEST_TIMEOUT_MS = 30000;
const UPLOAD_TIMEOUT_MS = 15000;
const MAX_NAME_LENGTH = 50;
const MAX_YEAR_LENGTH = 4;
const URL_REGEX = /^https?:\/\/.+\.(jpg|jpeg|png|gif|webp)(\?.*)?$/i;

/**
 * Mengecek apakah string adalah URL gambar valid.
 */
function isImageUrl(str) {
  return URL_REGEX.test(str);
}

/**
 * Upload file ke Catbox.moe melalui SynoxCloud API.
 * Menghasilkan direct link permanen.
 */
async function uploadToCatbox(buffer, fileName = "image.jpg") {
  try {
    const form = new FormData();
    form.append("file", buffer, fileName);

    const res = await axios.post(API_CATBOX, form, {
      headers: form.getHeaders(),
      timeout: UPLOAD_TIMEOUT_MS,
      validateStatus: () => true,
    });

    if (res.status === 200 && res.data) {
      let url = null;
      
      if (typeof res.data === "string") {
        url = res.data.trim();
      } else if (res.data.url) {
        url = res.data.url;
      } else if (res.data.result) {
        url = res.data.result;
      } else if (res.data.link) {
        url = res.data.link;
      } else if (res.data.data && res.data.data.url) {
        url = res.data.data.url;
      }

      if (url && url.startsWith("http")) {
        console.log("Catbox upload success:", url);
        return url;
      }
    }

    throw new Error("Response Catbox tidak valid");
  } catch (err) {
    if (err.message.includes("Response Catbox")) {
      throw err;
    }
    throw new Error(`Upload ke Catbox gagal: ${err.message}`);
  }
}

/**
 * Mendapatkan URL foto dari reply gambar (upload ke Catbox).
 */
async function getImageFromReply(sock, m) {
  const quotedMsg = m.verifiedQuoted || m.quoted;
  
  if (quotedMsg && quotedMsg.mtype === "imageMessage") {
    try {
      const media = await sock.downloadMediaMessage(quotedMsg);
      if (media) {
        const url = await uploadToCatbox(media, `wafat_${Date.now()}.jpg`);
        return url;
      }
    } catch (err) {
      console.error("Failed to process reply image:", err.message);
      throw new Error(`Gagal upload foto: ${err.message}`);
    }
  }
  
  return null;
}

/**
 * Memanggil endpoint /canvas/fakewafat.
 * Generate Fake Wafat dengan foto, nama, tahun lahir, dan tahun wafat.
 * Response API ini berupa binary image langsung.
 */
async function generateFakeWafat(params) {
  let res;
  try {
    res = await axios.get(API_FAKEWAFAT, {
      params,
      timeout: REQUEST_TIMEOUT_MS,
      responseType: "arraybuffer",
      validateStatus: () => true,
    });
  } catch (err) {
    if (err.code === "ECONNABORTED") {
      throw new Error("Timeout saat menghubungi server fake wafat.");
    }
    throw new Error(`Gagal menghubungi server: ${err.message}`);
  }

  const contentType = String(res.headers["content-type"] || "").toLowerCase();

  if (res.status !== 200) {
    let errMsg = `HTTP ${res.status} - ${res.statusText || "Request gagal"}`;
    if (contentType.includes("application/json")) {
      try {
        const parsed = JSON.parse(Buffer.from(res.data).toString("utf-8"));
        errMsg = parsed?.message || parsed?.error || errMsg;
      } catch {
        // abaikan
      }
    }
    throw new Error(errMsg);
  }

  if (!contentType.startsWith("image/")) {
    throw new Error("Response API bukan image (format tidak sesuai ekspektasi).");
  }

  const buffer = Buffer.from(res.data);
  if (!buffer.length) {
    throw new Error("File gambar hasil generate kosong.");
  }

  return { buffer, mime: contentType };
}

function buildUsageText(command) {
  return (
    `🕊️ *Fake Wafat Generator*\n\n` +
    `Generate fake wafat/pemakaman\n` +
    `dengan foto, nama, tahun lahir & wafat.\n\n` +
    `*Cara Pakai:*\n` +
    `${command} <nama>|<tahun_lahir>|<tahun_wafat>|<url_foto>\n\n` +
    `*Atau dengan reply foto:*\n` +
    `${command} <nama>|<tahun_lahir>|<tahun_wafat> (reply foto)\n\n` +
    `*Contoh:*\n` +
    `${command} Bwa bwa pekerja|2013|2022|https://b.top4top.io/p_38235zels1.jpg\n` +
    `${command} Nama orang|1990|2024\n` +
    `${command} Nama orang|1990|2024 (reply foto)\n\n` +
    `*Batas karakter:*\n` +
    `• Nama: ${MAX_NAME_LENGTH} karakter\n` +
    `• Tahun: ${MAX_YEAR_LENGTH} digit\n\n` +
    `*Format URL foto:* https://...jpg/png/gif\n` +
    `*Prioritas foto:* Reply gambar > Input URL > Tanpa foto\n` +
    `*Upload:* Reply gambar diupload ke Catbox.moe\n` +
    `*Catatan:* Hanya untuk hiburan!\n` +
    `Jangan digunakan untuk hal tidak pantas!`
  );
}

let handler = async (m, { text, command, sock }) => {
  // Validasi input
  if (!text || !text.trim()) {
    return sock.sendMessage(
      m.chat,
      { text: buildUsageText(command) },
      { quoted: m.verifiedQuoted }
    );
  }

  const raw = text.trim();
  const parts = raw.split("|").map(s => s.trim());

  const nama = parts[0] || "";
  const lahir = parts[1] || "";
  const wafat = parts[2] || "";
  const urlFoto = parts[3] || "";

  // Validasi nama
  if (!nama) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Nama wajib diisi!\n\nContoh: ${command} Bwa bwa pekerja|2013|2022|https://foto.jpg` },
      { quoted: m.verifiedQuoted }
    );
  }

  if (nama.length > MAX_NAME_LENGTH) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Nama terlalu panjang (${nama.length}/${MAX_NAME_LENGTH} karakter).` },
      { quoted: m.verifiedQuoted }
    );
  }

  // Validasi tahun lahir
  if (!lahir) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Tahun lahir wajib diisi!\n\nContoh: ${command} Nama|1990|2024` },
      { quoted: m.verifiedQuoted }
    );
  }

  if (!lahir.match(/^\d{4}$/)) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Tahun lahir harus 4 digit angka!\n\nContoh: 1990, 2013, 2000` },
      { quoted: m.verifiedQuoted }
    );
  }

  // Validasi tahun wafat
  if (!wafat) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Tahun wafat wajib diisi!\n\nContoh: ${command} Nama|1990|2024` },
      { quoted: m.verifiedQuoted }
    );
  }

  if (!wafat.match(/^\d{4}$/)) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Tahun wafat harus 4 digit angka!\n\nContoh: 2024, 2022, 2020` },
      { quoted: m.verifiedQuoted }
    );
  }

  // Validasi tahun wafat > tahun lahir
  if (parseInt(wafat) <= parseInt(lahir)) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Tahun wafat harus lebih besar dari tahun lahir!` },
      { quoted: m.verifiedQuoted }
    );
  }

  // Ambil URL foto dari reply gambar (prioritas utama)
  let finalFotoUrl = "";
  let fotoSource = "";

  // Cek reply gambar dulu
  try {
    const replyImageUrl = await getImageFromReply(sock, m);
    
    if (replyImageUrl) {
      finalFotoUrl = replyImageUrl;
      fotoSource = "Reply Gambar (Catbox)";
    }
  } catch (err) {
    return sock.sendMessage(
      m.chat,
      { text: `❌ ${err.message}` },
      { quoted: m.verifiedQuoted }
    );
  }

  // Kalo gak ada reply, cek input URL
  if (!finalFotoUrl && urlFoto) {
    if (!isImageUrl(urlFoto)) {
      return sock.sendMessage(
        m.chat,
        { text: `⚠️ URL foto tidak valid!\n\nFormat: https://...jpg/png/gif\n\nContoh: https://b.top4top.io/p_38235zels1.jpg` },
        { quoted: m.verifiedQuoted }
      );
    }
    finalFotoUrl = urlFoto;
    fotoSource = "URL Input";
  }

  // Kalo gak ada keduanya
  if (!finalFotoUrl) {
    fotoSource = "Tanpa Foto";
  }

  // Build params
  let params = {};
  params.nama = nama;
  params.lahir = lahir;
  params.wafat = wafat;
  if (finalFotoUrl) params.fotourl = finalFotoUrl;

  // Hitung umur
  const umur = parseInt(wafat) - parseInt(lahir);

  // Kirim pesan proses
  await sock.sendMessage(
    m.chat,
    {
      text:
        `🕊️ *Membuat Fake Wafat...*\n\n` +
        `• Nama: ${nama}\n` +
        `• Lahir: ${lahir}\n` +
        `• Wafat: ${wafat}\n` +
        `• Umur: ${umur} tahun\n` +
        `• Foto: ${fotoSource}\n\n` +
        `_Tunggu sebentar..._`
    },
    { quoted: m.verifiedQuoted }
  );

  try {
    // Generate fake wafat
    const { buffer, mime } = await generateFakeWafat(params);

    // Kirim hasil
    await sock.sendMessage(
      m.chat,
      {
        image: buffer,
        mimetype: mime,
        caption:
          `🕊️ *FAKE WAFAT*\n\n` +
          `• Nama: ${nama}\n` +
          `• Lahir: ${lahir}\n` +
          `• Wafat: ${wafat}\n` +
          `• Umur: ${umur} tahun\n` +
          `• Foto: ${fotoSource}\n\n` +
          `_Hanya untuk hiburan!_ ⚠️\n` +
          `_Jangan digunakan untuk hal tidak pantas!_`,
      },
      { quoted: m.verifiedQuoted }
    );
  } catch (err) {
    await sock
      .sendMessage(
        m.chat,
        { text: `❌ Gagal membuat fake wafat.\n\n*Alasan:* ${err.message}` },
        { quoted: m.verifiedQuoted }
      )
      .catch(() => {});
  }
};

handler.command = ["fakewafat", "wafat", "fakewafat", "meninggal"];
handler.tags = ["maker"];
handler.help = ["fakewafat <nama>|<tahun_lahir>|<tahun_wafat>|<url_foto>"];

export default handler;