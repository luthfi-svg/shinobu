// plugins/maker/ttqc.js — TikTok Quote Chat Generator (SynoxCloud API)
"use strict";

import axios from "axios";
import FormData from "form-data";

const API_TTQC = "https://api.synoxcloud.xyz/canvas/ttqc";
const API_CATBOX = "https://api.synoxcloud.xyz/uploader/catbox";
const REQUEST_TIMEOUT_MS = 30000;
const UPLOAD_TIMEOUT_MS = 15000;
const MAX_USERNAME_LENGTH = 30;
const MAX_TEXT_LENGTH = 200;
const URL_REGEX = /^https?:\/\/.+\.(jpg|jpeg|png|gif|webp)(\?.*)?$/i;

/**
 * Mengecek apakah string adalah URL gambar valid.
 */
function isImageUrl(str) {
  return URL_REGEX.test(str);
}

/**
 * Upload file ke Catbox.moe melalui SynoxCloud API.
 * Menghasilkan direct link permanen.
 */
async function uploadToCatbox(buffer, fileName = "avatar.jpg") {
  try {
    const form = new FormData();
    form.append("file", buffer, fileName);

    const res = await axios.post(API_CATBOX, form, {
      headers: form.getHeaders(),
      timeout: UPLOAD_TIMEOUT_MS,
      validateStatus: () => true,
    });

    if (res.status === 200 && res.data) {
      let url = null;
      
      if (typeof res.data === "string") {
        url = res.data.trim();
      } else if (res.data.url) {
        url = res.data.url;
      } else if (res.data.result) {
        url = res.data.result;
      } else if (res.data.link) {
        url = res.data.link;
      } else if (res.data.data && res.data.data.url) {
        url = res.data.data.url;
      }

      if (url && url.startsWith("http")) {
        console.log("Catbox upload success:", url);
        return url;
      }
    }

    throw new Error("Response Catbox tidak valid");
  } catch (err) {
    if (err.message.includes("Response Catbox")) {
      throw err;
    }
    throw new Error(`Upload ke Catbox gagal: ${err.message}`);
  }
}

/**
 * Mendapatkan URL avatar dari reply gambar (upload ke Catbox).
 */
async function getAvatarFromReply(sock, m) {
  const quotedMsg = m.verifiedQuoted || m.quoted;
  
  if (quotedMsg && quotedMsg.mtype === "imageMessage") {
    try {
      const media = await sock.downloadMediaMessage(quotedMsg);
      if (media) {
        const url = await uploadToCatbox(media, `avatar_${Date.now()}.jpg`);
        return url;
      }
    } catch (err) {
      console.error("Failed to process reply image:", err.message);
      throw new Error(`Gagal upload avatar: ${err.message}`);
    }
  }
  
  return null;
}

/**
 * Memanggil endpoint /canvas/ttqc.
 * Generate screenshot chat TikTok dengan username, teks, dan avatar.
 * Response API ini berupa binary image langsung.
 */
async function generateTTQC(params) {
  let res;
  try {
    res = await axios.get(API_TTQC, {
      params,
      timeout: REQUEST_TIMEOUT_MS,
      responseType: "arraybuffer",
      validateStatus: () => true,
    });
  } catch (err) {
    if (err.code === "ECONNABORTED") {
      throw new Error("Timeout saat menghubungi server TTQC.");
    }
    throw new Error(`Gagal menghubungi server: ${err.message}`);
  }

  const contentType = String(res.headers["content-type"] || "").toLowerCase();

  if (res.status !== 200) {
    let errMsg = `HTTP ${res.status} - ${res.statusText || "Request gagal"}`;
    if (contentType.includes("application/json")) {
      try {
        const parsed = JSON.parse(Buffer.from(res.data).toString("utf-8"));
        errMsg = parsed?.message || parsed?.error || errMsg;
      } catch {
        // abaikan
      }
    }
    throw new Error(errMsg);
  }

  if (!contentType.startsWith("image/")) {
    throw new Error("Response API bukan image (format tidak sesuai ekspektasi).");
  }

  const buffer = Buffer.from(res.data);
  if (!buffer.length) {
    throw new Error("File gambar hasil generate kosong.");
  }

  return { buffer, mime: contentType };
}

function buildUsageText(command) {
  return (
    `🎵 *TikTok Quote Chat Generator*\n\n` +
    `Generate screenshot chat TikTok\n` +
    `dengan username, teks, dan avatar custom.\n\n` +
    `*Cara Pakai:*\n` +
    `${command} <username>|<teks>|<url_avatar>\n\n` +
    `*Atau dengan reply foto:*\n` +
    `${command} <username>|<teks> (reply foto untuk avatar)\n\n` +
    `*Contoh:*\n` +
    `${command} Saurus|Just friend kok cemburu😹|https://c.top4top.io/p_3827ycihz1.jpg\n` +
    `${command} Lordsaurus|Halo semua! 👋\n` +
    `${command} Saurus|Apa kabar bestie? 😘 (reply foto)\n\n` +
    `*Batas karakter:*\n` +
    `• Username: ${MAX_USERNAME_LENGTH} karakter\n` +
    `• Teks: ${MAX_TEXT_LENGTH} karakter\n\n` +
    `*Format URL avatar:* https://...jpg/png/gif\n` +
    `*Prioritas avatar:* Reply gambar > Input URL > Tanpa avatar\n` +
    `*Upload:* Reply gambar diupload ke Catbox.moe\n` +
    `*Support:* Emoji ✅\n` +
    `*Catatan:* Hasil untuk hiburan/prank saja.`
  );
}

let handler = async (m, { text, command, sock }) => {
  // Validasi input
  if (!text || !text.trim()) {
    return sock.sendMessage(
      m.chat,
      { text: buildUsageText(command) },
      { quoted: m.verifiedQuoted }
    );
  }

  const raw = text.trim();
  const parts = raw.split("|").map(s => s.trim());

  const username = parts[0] || "";
  const chatText = parts[1] || "";
  const urlAvatar = parts[2] || "";

  // Validasi username
  if (!username) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Username wajib diisi!\n\nContoh: ${command} Saurus|Just friend kok cemburu😹|https://avatar.jpg` },
      { quoted: m.verifiedQuoted }
    );
  }

  if (username.length > MAX_USERNAME_LENGTH) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Username terlalu panjang (${username.length}/${MAX_USERNAME_LENGTH} karakter).` },
      { quoted: m.verifiedQuoted }
    );
  }

  // Validasi teks
  if (!chatText) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Teks chat wajib diisi!\n\nContoh: ${command} Saurus|Just friend kok cemburu😹` },
      { quoted: m.verifiedQuoted }
    );
  }

  if (chatText.length > MAX_TEXT_LENGTH) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Teks terlalu panjang (${chatText.length}/${MAX_TEXT_LENGTH} karakter).` },
      { quoted: m.verifiedQuoted }
    );
  }

  // Ambil URL avatar dari reply gambar (prioritas utama)
  let finalAvatarUrl = "";
  let avatarSource = "";

  // Cek reply gambar dulu
  try {
    const replyAvatarUrl = await getAvatarFromReply(sock, m);
    
    if (replyAvatarUrl) {
      finalAvatarUrl = replyAvatarUrl;
      avatarSource = "Reply Gambar (Catbox)";
    }
  } catch (err) {
    return sock.sendMessage(
      m.chat,
      { text: `❌ ${err.message}` },
      { quoted: m.verifiedQuoted }
    );
  }

  // Kalo gak ada reply, cek input URL
  if (!finalAvatarUrl && urlAvatar) {
    if (!isImageUrl(urlAvatar)) {
      return sock.sendMessage(
        m.chat,
        { text: `⚠️ URL avatar tidak valid!\n\nFormat: https://...jpg/png/gif\n\nContoh: https://c.top4top.io/p_3827ycihz1.jpg` },
        { quoted: m.verifiedQuoted }
      );
    }
    finalAvatarUrl = urlAvatar;
    avatarSource = "URL Input";
  }

  // Kalo gak ada keduanya
  if (!finalAvatarUrl) {
    avatarSource = "Tanpa Avatar";
  }

  // Build params
  let params = {};
  params.username = username;
  params.text = chatText;
  if (finalAvatarUrl) params.avatar = finalAvatarUrl;

  // Kirim pesan proses
  await sock.sendMessage(
    m.chat,
    {
      text:
        `🎵 *Membuat TikTok Chat...*\n\n` +
        `• Username: ${username}\n` +
        `• Teks: ${chatText}\n` +
        `• Avatar: ${avatarSource}\n\n` +
        `_Tunggu sebentar..._`
    },
    { quoted: m.verifiedQuoted }
  );

  try {
    // Generate TTQC
    const { buffer, mime } = await generateTTQC(params);

    // Kirim hasil
    await sock.sendMessage(
      m.chat,
      {
        image: buffer,
        mimetype: mime,
        caption:
          `🎵 *TIKTOK CHAT*\n\n` +
          `• Username: ${username}\n` +
          `• Teks: ${chatText}\n` +
          `• Avatar: ${avatarSource}\n\n` +
          `_Hasil untuk hiburan/prank saja._`,
      },
      { quoted: m.verifiedQuoted }
    );
  } catch (err) {
    await sock
      .sendMessage(
        m.chat,
        { text: `❌ Gagal membuat TikTok chat.\n\n*Alasan:* ${err.message}` },
        { quoted: m.verifiedQuoted }
      )
      .catch(() => {});
  }
};

handler.command = ["ttqc", "tiktokchat", "ttchat", "tiktokqc"];
handler.tags = ["maker"];
handler.help = ["ttqc <username>|<teks>|<url_avatar>"];

export default handler;