// plugins/maker/bratvid.js — Brat Video Generator (SynoxCloud API)
/**
 * ───「 FEATURE AUTHOR 」───
 * 📝 Plugin     : Brat Video Generator
 * 🔗 API        : SynoxCloud API
 * 📱 Support    : Termux Friendly
 * ─────────────────────────
 */

"use strict";

import axios from "axios";

const API_BASE = "https://api.synoxcloud.xyz/canvas/bratvid";
const REQUEST_TIMEOUT_MS = 60000; // 1 menit
const MAX_TEXT_LENGTH = 100;

/**
 * Generate Brat Video menggunakan SynoxCloud API.
 */
async function generateBratVideo(text) {
  let res;
  try {
    res = await axios.get(API_BASE, {
      params: { text },
      timeout: REQUEST_TIMEOUT_MS,
      responseType: "arraybuffer",
      validateStatus: () => true,
    });
  } catch (err) {
    if (err.code === "ECONNABORTED") {
      throw new Error("Timeout! Server terlalu lama merespon.");
    }
    throw new Error(`Gagal menghubungi server: ${err.message}`);
  }

  const contentType = String(res.headers["content-type"] || "").toLowerCase();

  if (res.status !== 200) {
    let errMsg = `HTTP ${res.status} - ${res.statusText || "Request gagal"}`;
    if (contentType.includes("application/json")) {
      try {
        const parsed = JSON.parse(Buffer.from(res.data).toString("utf-8"));
        errMsg = parsed?.message || parsed?.error || errMsg;
      } catch {}
    }
    throw new Error(errMsg);
  }

  if (!contentType.startsWith("video/")) {
    throw new Error("Response bukan video (format tidak sesuai).");
  }

  const buffer = Buffer.from(res.data);
  if (!buffer.length) throw new Error("File video kosong.");

  return { buffer, mime: contentType };
}

function buildUsageText(prefix, command) {
  return (
    `🎥 *Brat Video Generator*\n\n` +
    `Buat video Brat aesthetic\n` +
    `putih hitam dengan teks custom.\n\n` +
    `*Cara Pakai:*\n` +
    `${prefix + command} <teks>\n\n` +
    `*Contoh:*\n` +
    `${prefix + command} Bang kapan nikah🗿\n` +
    `${prefix + command} Halo semuanya!\n` +
    `${prefix + command} Aku suka bot ini\n` +
    `${prefix + command} Nama saya adalah...\n\n` +
    `*Batas:* ${MAX_TEXT_LENGTH} karakter\n` +
    `*Timeout:* 60 detik\n` +
    `*Note:* Hasil video MP4 putih hitam`
  );
}

let handler = async (m, { text, command, sock }) => {
  const prefix = global.prefix || ".";

  // Validasi input
  if (!text || !text.trim()) {
    return sock.sendMessage(
      m.chat,
      { text: buildUsageText(prefix, command) },
      { quoted: m.verifiedQuoted }
    );
  }

  const teks = text.trim();

  // Validasi panjang teks
  if (teks.length > MAX_TEXT_LENGTH) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Teks terlalu panjang! Maksimal ${MAX_TEXT_LENGTH} karakter.` },
      { quoted: m.verifiedQuoted }
    );
  }

  // Reaksi loading
  await sock.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

  // Kirim pesan proses
  await sock.sendMessage(
    m.chat,
    {
      text:
        `🎥 *Membuat Brat Video...*\n\n` +
        `📝 Teks: *${teks}*\n\n` +
        `_Tunggu sebentar..._`
    },
    { quoted: m.verifiedQuoted }
  );

  try {
    // Generate video
    const { buffer, mime } = await generateBratVideo(teks);

    // Kirim video
    await sock.sendMessage(
      m.chat,
      {
        video: buffer,
        mimetype: mime,
        caption:
          `🎥 *BRAT VIDEO*\n\n` +
          `📝 Teks: *${teks}*\n\n` +
          `_Generated with SynoxCloud API_\n` +
          `_#BratVideo #Aesthetic_`
      },
      { quoted: m.verifiedQuoted }
    );

    await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

  } catch (error) {
    console.error("[BRAT VIDEO ERROR]", error);
    await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });

    let errorMsg =
      `❌ *Gagal Membuat Video!*\n\n` +
      `*Alasan:* ${error.message || "Unknown error"}\n\n`;

    // Tips berdasarkan error
    if (error.message.includes("Timeout")) {
      errorMsg += `💡 *Tips:*\n` +
        `• Coba teks lebih pendek\n` +
        `• Server mungkin sibuk\n`;
    } else if (error.message.includes("HTTP 429")) {
      errorMsg += `💡 *Tips:*\n` +
        `• Rate limit, tunggu beberapa saat\n`;
    } else if (error.message.includes("HTTP 500")) {
      errorMsg += `💡 *Tips:*\n` +
        `• Server API error, coba lagi nanti\n`;
    } else {
      errorMsg += `💡 Coba lagi dengan teks berbeda!\n`;
    }

    errorMsg += `\n_Gunakan .bratvid <teks>_`;

    await sock.sendMessage(
      m.chat,
      { text: errorMsg },
      { quoted: m.verifiedQuoted }
    );
  }
};

handler.command = ["bratvid", "bratvideo", "brat"];
handler.tags = ["maker"];
handler.help = ["bratvid <teks>"];
handler.limit = true;

export default handler;