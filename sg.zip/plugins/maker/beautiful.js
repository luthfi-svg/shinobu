// plugins/maker/beautiful.js — Beautiful profile frame (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Beautiful Frame
 * 🔧 Fungsi     : Tambahkan frame beautiful ke foto profil
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

let handler = async (m, { sock, usedPrefix, command }) => {
  let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : m.sender;
  
  try {
    await m.reply("⏳ *Creating Frame...*");

    // Get profile picture
    let ppUrl;
    try {
      ppUrl = await sock.profilePictureUrl(who, "image");
    } catch {
      ppUrl = "https://i.ibb.co/3Fh9V6p/avatar-contact.png";
    }

    // Apply beautiful frame using API
    const response = await axios.get(
      `https://some-api.com/canvas/beautiful?image=${encodeURIComponent(ppUrl)}`,
      {
        responseType: "arraybuffer",
        timeout: 30000
      }
    ).catch(async () => {
      // Fallback: just send original pp with caption
      return { data: (await axios.get(ppUrl, { responseType: "arraybuffer" })).data };
    });

    const imageBuffer = Buffer.from(response.data);

    await sock.sendMessage(
      m.chat,
      {
        image: imageBuffer,
        caption: `✨ *Beautiful Frame*\n\n👤 User: @${who.split("@")[0]}`,
        mentions: [who]
      },
      { quoted: m }
    );

    await m.react("✅");

  } catch (e) {
    console.error(e);
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["beautiful @user"];
handler.tags = ["maker"];
handler.command = /^(beautiful|cantik)$/i;
handler.limit = true;

export default handler;
