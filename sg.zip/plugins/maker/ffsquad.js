// plugins/maker/ffsquad.js — Fake Lobby FF Squad (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Fake Lobby FF Squad
 * 🎮 Game       : Free Fire
 * 🎨 Design     : Premium UI
 * 📦 Version    : 1.2
 * ⚡ By Shinobu
 * ─────────────────────────
 */

"use strict";

import axios from "axios";

const API_BASE = "https://api-nanzz.my.id/docs/api/maker/fake-lobby-ff-squad.php";
const REQUEST_TIMEOUT_MS = 30000;

async function generateFFSquad(nama1, nama2, nama3, nama4) {
  const apiUrl = `${API_BASE}?nama1=${encodeURIComponent(nama1)}&nama2=${encodeURIComponent(nama2)}&nama3=${encodeURIComponent(nama3)}&nama4=${encodeURIComponent(nama4)}`;
  
  const res = await axios.get(apiUrl, {
    timeout: REQUEST_TIMEOUT_MS,
    responseType: "arraybuffer",
    validateStatus: () => true,
  });

  if (res.status !== 200) throw new Error(`HTTP ${res.status}`);
  
  const contentType = res.headers["content-type"] || "";
  if (!contentType.includes("image")) throw new Error("Response bukan gambar!");
  
  const buffer = Buffer.from(res.data);
  if (!buffer.length) throw new Error("File kosong!");
  
  return buffer;
}

function buildMenuText(prefix) {
  return (
    `╭══════════════════════════════╮\n` +
    `│                              │\n` +
    `│   🔫  *FAKE FF SQUAD*  🔫  │\n` +
    `│   ──────────────────────    │\n` +
    `│   Generate Lobby FF 4 Player│\n` +
    `│   Shinobu MD v1.2 📦        │\n` +
    `│                              │\n` +
    `╰══════════════════════════════╯\n\n` +
    `  📌 *Format:*\n` +
    `  ${prefix}ffsquad nama1|nama2|nama3|nama4\n\n` +
    `  💡 *Contoh:*\n` +
    `  ${prefix}ffsquad Nanzz|Azzam|Rizky|Budi\n` +
    `  ${prefix}ffsquad Pro|Noob|Sultan|Rusher\n\n` +
    `  📝 *Note:*\n` +
    `  › 4 nama wajib diisi\n` +
    `  › Pisahkan dengan "|"\n` +
    `  › Hasil gambar HD\n\n` +
    `  ⚡ *Shinobu MD v1.2*`
  );
}

let handler = async (m, { text, command, sock }) => {
  const prefix = global.prefix || ".";

  // Tampilkan menu kalo gak ada input
  if (!text || !text.trim()) {
    return sock.sendMessage(m.chat, { text: buildMenuText(prefix) }, { quoted: m.verifiedQuoted });
  }

  const names = text.split("|").map(v => v.trim()).filter(Boolean);

  // Validasi jumlah nama
  if (names.length !== 4) {
    return sock.sendMessage(m.chat, {
      text:
        `╭──────────────────────────────╮\n` +
        `  ⚠️  *FORMAT SALAH!*\n` +
        `╰──────────────────────────────╯\n\n` +
        `  Harus *4 nama*!\n` +
        `  Kamu input: *${names.length}* nama\n\n` +
        `  📌 Contoh:\n` +
        `  ${prefix}ffsquad Nanzz|Azzam|Rizky|Budi\n\n` +
        `  ⚡ *Shinobu MD v1.2*`
    }, { quoted: m.verifiedQuoted });
  }

  const [nama1, nama2, nama3, nama4] = names;

  // Progress
  await sock.sendMessage(m.chat, { react: { text: "🔫", key: m.key } });

  await sock.sendMessage(m.chat, {
    text:
      `╭──────────────────────────────╮\n` +
      `  🔫  *MEMBUAT LOBBY FF...*\n` +
      `╰──────────────────────────────╯\n\n` +
      `  👤 ${nama1}\n` +
      `  👤 ${nama2}\n` +
      `  👤 ${nama3}\n` +
      `  👤 ${nama4}\n\n` +
      `  _Tunggu sebentar..._\n\n` +
      `  ⚡ *Shinobu MD v1.2*`
  }, { quoted: m.verifiedQuoted });

  try {
    const buffer = await generateFFSquad(nama1, nama2, nama3, nama4);

    const caption =
      `╭──────────────────────────────╮\n` +
      `  🔫  *FAKE FF SQUAD*  🔫\n` +
      `╰──────────────────────────────╯\n\n` +
      `  ✅ *Lobby Berhasil Dibuat!*\n\n` +
      `  👤 *Player 1:* ${nama1}\n` +
      `  👤 *Player 2:* ${nama2}\n` +
      `  👤 *Player 3:* ${nama3}\n` +
      `  👤 *Player 4:* ${nama4}\n\n` +
      `  🎮 *Status:* Ready!\n` +
      `  📏 *Size:* ${(buffer.length / 1024).toFixed(1)} KB\n\n` +
      `  ⚡ *Shinobu MD v1.2*`;

    await sock.sendMessage(m.chat, {
      image: buffer,
      caption
    }, { quoted: m.verifiedQuoted });

    await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

  } catch (error) {
    console.error("[FFSQUAD ERROR]", error);
    await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });

    let errorMsg =
      `╭──────────────────────────────╮\n` +
      `  ❌  *GAGAL!*\n` +
      `╰──────────────────────────────╯\n\n` +
      `  📡 ${error.message}\n\n`;

    if (error.message.includes("Timeout")) {
      errorMsg += `  💡 Server sibuk, coba lagi.\n`;
    } else {
      errorMsg += `  💡 Coba lagi nanti!\n`;
    }

    errorMsg += `\n  ⚡ *Shinobu MD v1.2*`;

    await sock.sendMessage(m.chat, { text: errorMsg }, { quoted: m.verifiedQuoted });
  }
};

handler.command = ["ffsquad"];
handler.tags = ["maker"];
handler.help = ["ffsquad <nama1|nama2|nama3|nama4>"];
handler.limit = true;

export default handler;