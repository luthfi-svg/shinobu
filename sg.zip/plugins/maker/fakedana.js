// plugins/maker/fakedana.js — Fake Dana Generator
/**
 * ───「 FEATURE AUTHOR 」───
 * 👤 Author     : Lynx Decode (converted to Common JS)
 * 📝 Plugin     : Fake Dana Maker
 * ─────────────────────────
 */

"use strict";

import axios from "axios";

global.fakedana3_cd = global.fakedana3_cd || {};

async function generateFakeDana(nominal) {
  const apiUrl = `https://api-xemoz-official.my.id/api/maker/fake-dana.php?nominal=${encodeURIComponent(nominal)}`;

  const res = await axios.get(apiUrl, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'Referer': 'https://api-xemoz-official.my.id/',
      'Accept': 'image/png,image/jpeg,image/webp,image/*,*/*;q=0.8',
      'Connection': 'keep-alive'
    },
    timeout: 30000,
    responseType: "arraybuffer",
    validateStatus: () => true,
  });

  if (res.status !== 200) {
    throw new Error(`Server API merespon dengan HTTP ${res.status}`);
  }

  const contentType = String(res.headers["content-type"] || "").toLowerCase();
  
  if (!contentType.startsWith("image/")) {
    throw new Error("Response bukan gambar");
  }

  const buffer = Buffer.from(res.data);
  if (!buffer.length) throw new Error("File gambar kosong");

  return buffer;
}

function buildUsageText(prefix, command) {
  return (
    `┌˚₊ ๑│ ꜰ ᴀ ᴋ ᴇ  ᴅ ᴀ ɴ ᴀ │๑˚₊ 💸\n` +
    `┇ \n` +
    `│ ❌ *Nominalnya berapa cuy?*\n` +
    `│ \n` +
    `│ 📌 *Cara pakai:*\n` +
    `│ ❦ ${prefix + command} 150000\n` +
    `┇ \n` +
    `└˚₊ ๑ ────────────── ๑˚₊\n` +
    `> © ERINE-AI`
  );
}

let handler = async (m, { text, command, sock }) => {
  const prefix = global.prefix || ".";
  let userCd = global.fakedana3_cd[m.sender] || [];
  let now = Date.now();

  // Filter cooldown yang masih aktif
  userCd = userCd.filter(time => now - time < 120000);

  // Cek limit 5x dalam 2 menit
  if (userCd.length >= 5) {
    let remaining = Math.ceil((120000 - (now - userCd[0])) / 1000);
    return sock.sendMessage(
      m.chat,
      {
        text:
          `┌˚₊ ๑│ ᴄ ᴏ ᴏ ʟ ᴅ ᴏ ᴡ ɴ │๑˚₊ ⏳\n` +
          `┇ \n` +
          `│ ❌ *Limit penggunaan tercapai!*\n` +
          `│ Lu udah make fitur ini 5 kali dalam 2 menit terakhir.\n` +
          `│ \n` +
          `│ ⏱️ *Tunggu ${remaining} detik lagi* ya cuy biar IP lu ga diblokir API.\n` +
          `┇ \n` +
          `└˚₊ ๑ ────────────── ๑˚₊\n` +
          `> © ERINE-AI`
      },
      { quoted: m.verifiedQuoted }
    );
  }

  // Validasi input
  if (!text) {
    return sock.sendMessage(
      m.chat,
      { text: buildUsageText(prefix, command) },
      { quoted: m.verifiedQuoted }
    );
  }

  // Validasi angka
  if (isNaN(text)) {
    return sock.sendMessage(
      m.chat,
      {
        text:
          `❌ *Masukkan angka yang valid cuy, jangan pakai huruf/simbol!*\n\n` +
          `> © ERINE-AI`
      },
      { quoted: m.verifiedQuoted }
    );
  }

  // Tambah cooldown
  userCd.push(now);
  global.fakedana3_cd[m.sender] = userCd;

  // Reaksi loading
  await sock.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

  try {
    const nominal = text.trim();
    const buffer = await generateFakeDana(nominal);

    let caption =
      `┌˚₊ ๑│ ꜰ ᴀ ᴋ ᴇ  ᴅ ᴀ ɴ ᴀ │๑˚₊ 💸\n` +
      `┇ \n` +
      `│ ✅ *Berhasil membuat struk Fake Dana!*\n` +
      `│ 💰 *Nominal:* Rp ${nominal}\n` +
      `┇ \n` +
      `└˚₊ ๑ ────────────── ๑˚₊\n` +
      `> © ERINE-AI`;

    await sock.sendMessage(
      m.chat,
      {
        image: buffer,
        caption: caption,
      },
      { quoted: m.verifiedQuoted }
    );

    await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

  } catch (error) {
    console.error("[FAKEDANA ERROR]", error);
    await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    await sock.sendMessage(
      m.chat,
      {
        text:
          `┌˚₊ ๑│ ꜱ ʏ ꜱ ᴛ ᴇ ᴍ  ᴇ ʀ ʀ ᴏ ʀ │๑˚₊ ❌\n` +
          `┇ Gagal membuat fake dana.\n` +
          `┇ \n` +
          `┇ *Detail:*\n` +
          `┇ ${error.message || String(error)}\n` +
          `└˚₊ ๑ ────────────── ๑˚₊\n` +
          `> © ERINE-AI`
      },
      { quoted: m.verifiedQuoted }
    );
  }
};

handler.command = ["fakedana"];
handler.tags = ["maker"];
handler.help = ["fakedana <nominal>"];
handler.limit = true;

export default handler;