// plugins/maker/quotemaker.js — Generate quote aesthetic (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Quote Maker
 * 🔧 Fungsi     : Buat gambar quote aesthetic
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

let handler = async (m, { sock, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `Contoh penggunaan:\n${usedPrefix + command} <teks>|<author>\n\n` +
      `Contoh:\n` +
      `${usedPrefix + command} Hidup adalah pilihan|Anonymous\n` +
      `${usedPrefix + command} Tetap semangat!|Myself\n\n` +
      `Atau tanpa author:\n` +
      `${usedPrefix + command} Quotes keren\n\n` +
      `Tips: Gunakan | untuk pisahkan quote dan author`
    );
  }

  try {
    await m.reply("⏳ *Generating Quote...*\n\nSedang buat gambar...");

    // Parse text
    const parts = text.split("|");
    const quoteText = parts[0].trim();
    const author = parts[1]?.trim() || "Anonymous";

    if (quoteText.length > 200) {
      return m.reply(
        `❌ *Text Terlalu Panjang*\n\n` +
        `Panjang: ${quoteText.length} karakter\n` +
        `Max: 200 karakter`
      );
    }

    // Try multiple quote maker APIs
    let imageBuffer;

    try {
      // API 1: QuoteMaker
      const res1 = await axios.get(
        `https://api.quotable.io/quotes/render?text=${encodeURIComponent(quoteText)}&author=${encodeURIComponent(author)}`,
        {
          responseType: "arraybuffer",
          timeout: 30000
        }
      );
      imageBuffer = Buffer.from(res1.data);
    } catch {
      // API 2: Alternative quote maker
      try {
        const res2 = await axios.post(
          "https://quotes-generator-api.herokuapp.com/api/generate",
          {
            quote: quoteText,
            author: author,
            theme: "modern"
          },
          {
            responseType: "arraybuffer",
            timeout: 30000
          }
        );
        imageBuffer = Buffer.from(res2.data);
      } catch {
        // API 3: Simple canvas-based
        const res3 = await axios.get(
          `https://dummyimage.com/800x600/000000/ffffff.png&text=${encodeURIComponent(quoteText)}`,
          {
            responseType: "arraybuffer",
            timeout: 30000
          }
        );
        imageBuffer = Buffer.from(res3.data);
      }
    }

    if (!imageBuffer || imageBuffer.length < 1000) {
      throw new Error("Gagal generate gambar");
    }

    await sock.sendMessage(
      m.chat,
      {
        image: imageBuffer,
        caption: 
          `✅ *Quote Maker*\n\n` +
          `📝 Quote: ${quoteText.substring(0, 50)}...\n` +
          `✍️ Author: ${author}`
      },
      { quoted: m }
    );

    await m.react("✅");

  } catch (e) {
    console.error(e);
    await m.reply(
      `❌ *Quote Maker Error*\n\n` +
      `Gagal generate quote: ${e.message}\n\n` +
      `Tips:\n` +
      `• Gunakan teks yang tidak terlalu panjang\n` +
      `• Pisahkan quote dan author dengan |\n` +
      `• Contoh: Hidup indah|Anonim`
    );
  }
};

handler.help = ["quotemaker <text>|<author>"];
handler.tags = ["maker"];
handler.command = /^(quotemaker|quotemake|qmaker)$/i;
handler.limit = true;

export default handler;
