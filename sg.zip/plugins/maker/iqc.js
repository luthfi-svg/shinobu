// plugins/maker/iqc.js — iPhone Context Menu Generator (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : iPhone Context Menu
 * 🔗 API        : SynoxCloud API
 * 📱 Fungsi     : Generate fake iPhone chat bubble
 * 📦 Version    : 1.2
 * 👤 By Valzz
 * ─────────────────────────
 */

import axios from "axios";

const API_BASE = "https://api.synoxcloud.xyz/canvas/iqc";
const REQUEST_TIMEOUT_MS = 30000;
const MAX_TEXT_LENGTH = 100;

async function generateIQC(params) {
  // Bersihin params dari undefined/null
  const cleanParams = {};
  for (const key in params) {
    if (params[key] !== undefined && params[key] !== null) {
      cleanParams[key] = params[key];
    }
  }

  const res = await axios.get(API_BASE, {
    params: cleanParams,
    timeout: REQUEST_TIMEOUT_MS,
    responseType: "arraybuffer",
    validateStatus: () => true,
    headers: {
      'User-Agent': 'Mozilla/5.0',
      'Accept': 'image/*',
    },
  });

  const contentType = String(res.headers["content-type"] || "").toLowerCase();

  if (res.status !== 200) {
    let errMsg = `HTTP ${res.status}`;
    if (contentType.includes("json")) {
      try {
        const json = JSON.parse(Buffer.from(res.data).toString("utf-8"));
        errMsg = json?.message || json?.error || errMsg;
      } catch {}
    }
    throw new Error(errMsg);
  }

  if (!contentType.includes("image")) {
    throw new Error("Response bukan gambar! Type: " + contentType);
  }

  const buffer = Buffer.from(res.data);
  if (!buffer.length) throw new Error("File kosong!");
  return { buffer, mime: contentType };
}

function buildMenuText(prefix) {
  return (
    `╭══════════════════════════════╮\n` +
    `│   📱  *iPHONE CHAT*  📱    │\n` +
    `│   ──────────────────────    │\n` +
    `│   iPhone Context Menu      │\n` +
    `│   👤 By Valzz              │\n` +
    `╰══════════════════════════════╯\n\n` +
    `  📌 *Cara Pakai:*\n` +
    `  ${prefix}iqc teks|jam|baterai\n\n` +
    `  💡 *Contoh:*\n` +
    `  ${prefix}iqc Halo! Namaku saurus\n` +
    `  ${prefix}iqc Halo|09:41|80\n` +
    `  ${prefix}iqc Lagi ngapain?|12:00|50\n\n` +
    `  📝 *Default:*\n` +
    `  Jam: 09:41 | Baterai: 80\n\n` +
    `  👤 *By Valzz*`
  );
}

let handler = async (m, { text, command, sock }) => {
  const prefix = global.prefix || ".";

  if (!text || !text.trim()) {
    return sock.sendMessage(m.chat, {
      text: buildMenuText(prefix)
    }, { quoted: m.verifiedQuoted });
  }

  const parts = text.split("|").map(v => v.trim());
  const chatText = parts[0] || "";
  const time = parts[1] || "09:41";
  const baterai = parts[2] || "80";

  if (!chatText) {
    return sock.sendMessage(m.chat, {
      text: `⚠️ Teks wajib!\n\nFormat: ${prefix}iqc teks|jam|baterai\n\n👤 *By Valzz*`
    }, { quoted: m.verifiedQuoted });
  }

  if (chatText.length > MAX_TEXT_LENGTH) {
    return sock.sendMessage(m.chat, {
      text: `⚠️ Max ${MAX_TEXT_LENGTH} karakter!\n\n👤 *By Valzz*`
    }, { quoted: m.verifiedQuoted });
  }

  let bat = parseInt(baterai);
  if (isNaN(bat) || bat < 0 || bat > 100) {
    bat = 80; // Default kalo invalid
  }

  await sock.sendMessage(m.chat, { react: { text: "📱", key: m.key } });

  await sock.sendMessage(m.chat, {
    text:
      `╭──────────────────────────────╮\n` +
      `  📱  *MEMBUAT iPHONE CHAT...*\n` +
      `╰──────────────────────────────╯\n\n` +
      `  💬 ${chatText}\n` +
      `  ⏰ ${time} | 🔋 ${bat}%\n\n` +
      `  _Tunggu sebentar..._\n\n` +
      `  👤 *By Valzz*`
  }, { quoted: m.verifiedQuoted });

  try {
    const params = {
      text: encodeURIComponent(chatText),
      time,
      baterai: bat,
      operator: "tampilkan",
      wifi: "tampilkan",
    };

    const { buffer, mime } = await generateIQC(params);

    await sock.sendMessage(m.chat, {
      image: buffer,
      mimetype: mime,
      caption:
        `╭──────────────────────────────╮\n` +
        `  ✅  *iPHONE CHAT SIAP!*\n` +
        `╰──────────────────────────────╯\n\n` +
        `  💬 ${chatText}\n` +
        `  ⏰ ${time} | 🔋 ${bat}%\n` +
        `  📏 ${(buffer.length / 1024).toFixed(1)} KB\n\n` +
        `  👤 *By Valzz*`
    }, { quoted: m.verifiedQuoted });

    await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

  } catch (error) {
    console.error("[IQC ERROR]", error);
    await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });

    let errorMsg =
      `╭──────────────────────────────╮\n` +
      `  ❌  *GAGAL!*\n` +
      `╰──────────────────────────────╯\n\n` +
      `  📡 ${error.message}\n\n`;

    if (error.message.includes("Timeout")) {
      errorMsg += `  💡 Server sibuk, coba lagi.\n`;
    } else if (error.message.includes("HTTP 429")) {
      errorMsg += `  💡 Rate limit, tunggu sebentar.\n`;
    } else {
      errorMsg += `  💡 Coba lagi nanti!\n`;
    }

    errorMsg += `\n  👤 *By Valzz*`;

    await sock.sendMessage(m.chat, { text: errorMsg }, { quoted: m.verifiedQuoted });
  }
};

handler.command = ["iqc", "iphonechat", "ipcontext"];
handler.tags = ["maker"];
handler.help = ["iqc <teks|jam|baterai>"];
handler.limit = true;

export default handler;