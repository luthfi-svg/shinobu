// plugins/maker/pakustadz.js — Pak Ustadz Text Generator (SynoxCloud API)
/**
 * ───「 FEATURE AUTHOR 」───
 * 📝 Plugin     : Pak Ustadz Generator
 * 🔗 API        : SynoxCloud API
 * 📱 Fungsi     : Bikin kata-kata ala ustadz
 * ─────────────────────────
 */

"use strict";

import axios from "axios";

const API_BASE = "https://api.synoxcloud.xyz/canvas/pakustadz";
const REQUEST_TIMEOUT_MS = 30000;
const MAX_TEXT_LENGTH = 200;

/**
 * Generate gambar Pak Ustadz.
 */
async function generatePakUstadz(teks) {
  let res;
  try {
    res = await axios.get(API_BASE, {
      params: { teks },
      timeout: REQUEST_TIMEOUT_MS,
      responseType: "arraybuffer",
      validateStatus: () => true,
    });
  } catch (err) {
    if (err.code === "ECONNABORTED") {
      throw new Error("Timeout! Server terlalu lama merespon.");
    }
    throw new Error(`Gagal menghubungi server: ${err.message}`);
  }

  const contentType = String(res.headers["content-type"] || "").toLowerCase();

  if (res.status !== 200) {
    let errMsg = `HTTP ${res.status} - ${res.statusText || "Request gagal"}`;
    if (contentType.includes("application/json")) {
      try {
        const parsed = JSON.parse(Buffer.from(res.data).toString("utf-8"));
        errMsg = parsed?.message || parsed?.error || errMsg;
      } catch {}
    }
    throw new Error(errMsg);
  }

  if (!contentType.startsWith("image/")) {
    throw new Error("Response bukan gambar (format tidak sesuai).");
  }

  const buffer = Buffer.from(res.data);
  if (!buffer.length) throw new Error("File gambar kosong.");

  return { buffer, mime: contentType };
}

function buildUsageText(prefix, command) {
  return (
    `👳‍♂️ *Pak Ustadz Generator*\n\n` +
    `Bikin kata-kata ala ustadz\n` +
    `dengan teks custom.\n\n` +
    `*Cara Pakai:*\n` +
    `${prefix + command} <teks>\n\n` +
    `*Contoh:*\n` +
    `${prefix + command} Pak ustad, apa hukumnya menyukai anime?\n` +
    `${prefix + command} Ustad, bolehkah pacaran?\n` +
    `${prefix + command} Bagaimana hukumnya main game?\n` +
    `${prefix + command} Kenapa hidup ini berat?\n\n` +
    `*Batas:* ${MAX_TEXT_LENGTH} karakter\n` +
    `*Note:* Hasil gambar PNG, cocok buat meme!`
  );
}

let handler = async (m, { text, command, sock }) => {
  const prefix = global.prefix || ".";

  // Validasi input
  if (!text || !text.trim()) {
    return sock.sendMessage(
      m.chat,
      { text: buildUsageText(prefix, command) },
      { quoted: m.verifiedQuoted }
    );
  }

  const teks = text.trim();

  // Validasi panjang teks
  if (teks.length > MAX_TEXT_LENGTH) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Teks terlalu panjang! Maksimal ${MAX_TEXT_LENGTH} karakter.` },
      { quoted: m.verifiedQuoted }
    );
  }

  // Reaksi loading
  await sock.sendMessage(m.chat, { react: { text: "👳‍♂️", key: m.key } });

  // Kirim pesan proses
  await sock.sendMessage(
    m.chat,
    {
      text:
        `👳‍♂️ *Membuat Pak Ustadz...*\n\n` +
        `📝 Teks: *${teks}*\n\n` +
        `_Tunggu sebentar..._`
    },
    { quoted: m.verifiedQuoted }
  );

  try {
    // Generate gambar
    const { buffer, mime } = await generatePakUstadz(teks);

    // Kirim hasil
    await sock.sendMessage(
      m.chat,
      {
        image: buffer,
        mimetype: mime,
        caption:
          `👳‍♂️ *PAK USTADZ*\n\n` +
          `📝 *Pertanyaan:*\n${teks}\n\n` +
          `_Generated with SynoxCloud API_\n` +
          `_#PakUstadz #MemeIslami_`
      },
      { quoted: m.verifiedQuoted }
    );

    await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

  } catch (error) {
    console.error("[PAK USTADZ ERROR]", error);
    await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });

    let errorMsg =
      `❌ *Gagal Membuat Gambar!*\n\n` +
      `*Alasan:* ${error.message || "Unknown error"}\n\n`;

    if (error.message.includes("Timeout")) {
      errorMsg += `💡 Server sibuk, coba lagi nanti.\n`;
    } else if (error.message.includes("HTTP 429")) {
      errorMsg += `💡 Rate limit, tunggu beberapa saat.\n`;
    } else if (error.message.includes("HTTP 500")) {
      errorMsg += `💡 Server error, coba lagi nanti.\n`;
    } else {
      errorMsg += `💡 Coba lagi dengan teks berbeda!\n`;
    }

    errorMsg += `\n_Gunakan .pakustadz <teks>_`;

    await sock.sendMessage(
      m.chat,
      { text: errorMsg },
      { quoted: m.verifiedQuoted }
    );
  }
};

handler.command = ["pakustadz", "ustadz", "ustad"];
handler.tags = ["maker"];
handler.help = ["pakustadz <teks>"];
handler.limit = true;

export default handler;