// plugins/maker/nulis.js — Generate tulisan tangan (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Nulis (Tulisan Tangan)
 * 🔧 Fungsi     : Generate tulisan tangan di buku
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

let handler = async (m, { sock, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `Contoh penggunaan:\n${usedPrefix + command} Halo, ini tulisan tangan!\n\n` +
      `Tips:\n` +
      `• Gunakan kalimat pendek-pendek\n` +
      `• Pisahkan dengan enter untuk baris baru\n` +
      `• Max ~200 karakter\n\n` +
      `Contoh:\n` +
      `${usedPrefix + command} Selamat pagi!\n` +
      `Semoga harimu menyenangkan`
    );
  }

  if (text.length > 300) {
    return m.reply(
      `❌ *Teks Terlalu Panjang*\n\n` +
      `Panjang: ${text.length} karakter\n` +
      `Max: 300 karakter\n\n` +
      `Gunakan teks yang lebih pendek!`
    );
  }

  try {
    await m.reply("⏳ *Generating...*\n\nSedang buat tulisan tangan, tunggu sebentar...");

    // API for handwriting generation
    const apis = [
      // API 1: Salism API
      `https://api.salism.xyz/nulis?text=${encodeURIComponent(text)}`,
      
      // API 2: Zenzapis
      `https://zenzapis.xyz/api/nulis?text=${encodeURIComponent(text)}&apikey=free`,
      
      // API 3: Alternative
      `https://api.lolhuman.xyz/api/nulis?apikey=free&text=${encodeURIComponent(text)}`
    ];

    let imageBuffer;
    let apiError;

    for (const api of apis) {
      try {
        const response = await axios.get(api, {
          responseType: "arraybuffer",
          timeout: 30000
        });

        imageBuffer = Buffer.from(response.data);
        
        // Validate image
        if (imageBuffer.length > 5000) {
          break; // Success
        }
      } catch (e) {
        apiError = e.message;
        continue; // Try next API
      }
    }

    if (!imageBuffer || imageBuffer.length < 5000) {
      throw new Error(apiError || "Semua API gagal");
    }

    // Send handwriting image
    await sock.sendMessage(
      m.chat,
      {
        image: imageBuffer,
        caption: 
          `✅ *Tulisan Tangan*\n\n` +
          `📝 Text: ${text.substring(0, 50)}${text.length > 50 ? "..." : ""}\n` +
          `📏 Length: ${text.length} karakter`
      },
      { quoted: m }
    );

    await m.react("✅");

  } catch (e) {
    console.error(e);
    await m.reply(
      `❌ *Nulis Error*\n\n` +
      `Gagal generate tulisan tangan: ${e.message}\n\n` +
      `Tips:\n` +
      `• Gunakan teks yang lebih pendek\n` +
      `• Hindari karakter special berlebihan\n` +
      `• Coba lagi beberapa saat`
    );
  }
};

handler.help = ["nulis <teks>"];
handler.tags = ["maker"];
handler.command = /^(nulis|tulis)$/i;
handler.limit = true;
handler.premium = false;

export default handler;
