// plugins/maker/fakeffduo.js — Fake FF Duo Maker
/**
 * ───「 FEATURE AUTHOR 」───
 * 👤 Author     : Lynx Decode
 * 📞 Contact    : +62 882-5804-1396
 * 📢 Channel    : https://whatsapp.com/channel/0029VbAnuii6GcGCu73oep1i
 * ⚠️ Note       : Keep credit to respect the creator!
 * ─────────────────────────
 * 📝 Plugin: Fake FF Duo Maker
 */

"use strict";

import axios from "axios";

async function generateFakeFFDuo(name1, name2) {
  const apiUrl = `https://restapi.jagoanproject.web.id/api/maker/fakeffduo?name1=${encodeURIComponent(name1)}&name2=${encodeURIComponent(name2)}`;
  
  const res = await axios.get(apiUrl, {
    headers: {
      'Authorization': 'Bearer Lynxdecode'
    },
    timeout: 30000,
    responseType: "arraybuffer",
    validateStatus: () => true,
  });

  const contentType = String(res.headers["content-type"] || "").toLowerCase();

  if (res.status !== 200) {
    let errMsg = `HTTP ${res.status} - Request gagal`;
    if (contentType.includes("application/json")) {
      try {
        const json = JSON.parse(Buffer.from(res.data).toString("utf-8"));
        errMsg = json?.message || json?.error || errMsg;
      } catch {}
    }
    throw new Error(errMsg);
  }

  // Jika response JSON (ada URL)
  if (contentType.includes("application/json")) {
    const json = JSON.parse(Buffer.from(res.data).toString("utf-8"));
    if (!json.status || !json.data || !json.data.result || !json.data.result.url) {
      throw new Error("Gagal mendapatkan URL dari respon API.");
    }
    // Download gambar dari URL
    const imgRes = await axios.get(json.data.result.url, {
      responseType: "arraybuffer",
      timeout: 30000,
    });
    return Buffer.from(imgRes.data);
  }

  // Jika response langsung image
  if (contentType.startsWith("image/")) {
    const buffer = Buffer.from(res.data);
    if (!buffer.length) throw new Error("File gambar kosong.");
    return buffer;
  }

  throw new Error("Format response tidak dikenali.");
}

function buildUsageText(prefix, command) {
  return (
    `┌˚₊ ๑│ ғ ᴀ ᴋ ᴇ  ғ ғ  ᴅ ᴜ ᴏ │๑˚₊ ⚠️\n` +
    `┇ \n` +
    `│ ❌ *Format salah!*\n` +
    `│ \n` +
    `│ 📌 *Cara pakai:*\n` +
    `│ ${prefix + command} nama1|nama2\n` +
    `│ \n` +
    `│ 📌 *Contoh:*\n` +
    `│ ${prefix + command} Erine|Lynx\n` +
    `┇ \n` +
    `└˚₊ ๑ ────────────── ๑˚₊\n` +
    `> © ERINE-AI`
  );
}

let handler = async (m, { text, command, sock }) => {
  const prefix = global.prefix || ".";

  if (!text || !text.includes("|")) {
    return sock.sendMessage(
      m.chat,
      { text: buildUsageText(prefix, command) },
      { quoted: m.verifiedQuoted }
    );
  }

  let [name1, name2] = text.split("|").map(v => v.trim());

  if (!name1 || !name2) {
    return sock.sendMessage(
      m.chat,
      {
        text:
          `┌˚₊ ๑│ s ʏ s ᴛ ᴇ ᴍ  ᴇ ʀ ʀ ᴏ ʀ │๑˚₊ ❌\n` +
          `┇ Nama 1 dan Nama 2 wajib diisi!\n` +
          `└˚₊ ๑ ────────────── ๑˚₊\n` +
          `> © ERINE-AI`
      },
      { quoted: m.verifiedQuoted }
    );
  }

  await sock.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

  try {
    const buffer = await generateFakeFFDuo(name1, name2);

    let caption =
      `┌˚₊ ๑│ ғ ᴀ ᴋ ᴇ  ғ ғ  ᴅ ᴜ ᴏ │๑˚₊ 🎮\n` +
      `┇ \n` +
      `│ 👤 *Player 1:* ${name1}\n` +
      `│ 👤 *Player 2:* ${name2}\n` +
      `┇ \n` +
      `└˚₊ ๑ ────────────── ๑˚₊\n` +
      `> © ERINE-AI`;

    await sock.sendMessage(
      m.chat,
      {
        image: buffer,
        caption: caption,
      },
      { quoted: m.verifiedQuoted }
    );

    await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

  } catch (error) {
    console.error("[FAKE FF DUO ERROR]", error);
    await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    await sock.sendMessage(
      m.chat,
      {
        text:
          `┌˚₊ ๑│ s ʏ s ᴛ ᴇ ᴍ  ᴇ ʀ ʀ ᴏ ʀ │๑˚₊ ❌\n` +
          `┇ Terjadi kesalahan sistem.\n` +
          `┇ *Detail:* ${error.message || String(error)}\n` +
          `└˚₊ ๑ ────────────── ๑˚₊\n` +
          `> © ERINE-AI`
      },
      { quoted: m.verifiedQuoted }
    );
  }
};

handler.command = ["fakeffduo", "ffduo"];
handler.tags = ["maker"];
handler.help = ["fakeffduo <nama1|nama2>"];
handler.limit = true;

export default handler;