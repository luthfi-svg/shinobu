// plugins/maker/fakedev.js — Fake Developer Card Generator All Version (SynoxCloud API)
"use strict";

import axios from "axios";

const API_BASES = {
  v1: "https://api.synoxcloud.xyz/canvas/fakedev",
  v2: "https://api.synoxcloud.xyz/canvas/fakedev-2",
  v3: "https://api.synoxcloud.xyz/canvas/fakedev-3",
};

const REQUEST_TIMEOUT_MS = 30000;
const MAX_TEXT_LENGTH = 30;
const URL_REGEX = /^https?:\/\/.+\.(jpg|jpeg|png|gif|webp)(\?.*)?$/i;

/**
 * Mengecek apakah string adalah URL gambar valid.
 */
function isImageUrl(str) {
  return URL_REGEX.test(str);
}

/**
 * Memanggil endpoint API fakedev.
 */
async function generateFakeDev(version, params) {
  const apiBase = API_BASES[version];
  if (!apiBase) throw new Error(`Versi ${version} tidak tersedia.`);

  let res;
  try {
    res = await axios.get(apiBase, {
      params,
      timeout: REQUEST_TIMEOUT_MS,
      responseType: "arraybuffer",
      validateStatus: () => true,
    });
  } catch (err) {
    if (err.code === "ECONNABORTED") {
      throw new Error("Timeout saat menghubungi server fake dev.");
    }
    throw new Error(`Gagal menghubungi server: ${err.message}`);
  }

  const contentType = String(res.headers["content-type"] || "").toLowerCase();

  if (res.status !== 200) {
    let errMsg = `HTTP ${res.status} - ${res.statusText || "Request gagal"}`;
    if (contentType.includes("application/json")) {
      try {
        const parsed = JSON.parse(Buffer.from(res.data).toString("utf-8"));
        errMsg = parsed?.message || parsed?.error || errMsg;
      } catch {
        // abaikan
      }
    }
    throw new Error(errMsg);
  }

  if (!contentType.startsWith("image/")) {
    throw new Error("Response API bukan image (format tidak sesuai ekspektasi).");
  }

  const buffer = Buffer.from(res.data);
  if (!buffer.length) {
    throw new Error("File gambar hasil generate kosong.");
  }

  return { buffer, mime: contentType };
}

function buildUsageText(command) {
  return (
    `💻 *Fake Developer Card Generator*\n\n` +
    `*Versi Tersedia:*\n` +
    `• V1 - Kartu developer aesthetic (nama + username)\n` +
    `• V2 - Kartu developer dengan badge centang biru\n` +
    `• V3 - Kartu developer dengan teks melingkar\n\n` +
    `*Cara Pakai V1:*\n` +
    `${command} v1 <nama>|<username>|<url_foto>\n` +
    `Contoh:\n` +
    `${command} v1 @lordsaurus|saurus ganteng|https://c.top4top.io/p_3815w0ycy1.jpg\n\n` +
    `*Cara Pakai V2:*\n` +
    `${command} v2 <nama>|<url_foto>\n` +
    `Contoh:\n` +
    `${command} v2 Lordsaurus|https://b.top4top.io/p_3816r4vq71.jpg\n\n` +
    `*Cara Pakai V3:*\n` +
    `${command} v3 <teks_melingkar>|<nama>|<url_foto>\n` +
    `Contoh:\n` +
    `${command} v3 SAURUS OFFICIAL|LORDSAURUS|https://b.top4top.io/p_38247f1hr1.jpg\n\n` +
    `*Batas panjang teks:* ${MAX_TEXT_LENGTH} karakter\n` +
    `*Format URL foto:* https://...jpg/png/gif\n` +
    `*Note:* Kosongkan URL foto jika tidak ingin pakai foto\n` +
    `*Catatan:* Hasil untuk hiburan/display saja.`
  );
}

let handler = async (m, { text, command, sock }) => {
  // Validasi input
  if (!text || !text.trim()) {
    return sock.sendMessage(
      m.chat,
      { text: buildUsageText(command) },
      { quoted: m.verifiedQuoted }
    );
  }

  const args = text.trim().split(/\s+/);
  const version = args[0].toLowerCase();

  // Validasi versi
  if (!["v1", "v2", "v3"].includes(version)) {
    return sock.sendMessage(
      m.chat,
      {
        text:
          `⚠️ Versi tidak valid!\n\n` +
          `Gunakan: v1, v2, atau v3\n\n` +
          buildUsageText(command)
      },
      { quoted: m.verifiedQuoted }
    );
  }

  // Ambil sisa teks setelah versi
  const remainingText = args.slice(1).join(" ");

  if (!remainingText) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Teks tidak boleh kosong!\n\n${buildUsageText(command)}` },
      { quoted: m.verifiedQuoted }
    );
  }

  // Parse berdasarkan versi
  let params = {};
  let captionText = "";

  if (version === "v1") {
    const parts = remainingText.split("|").map(s => s.trim());
    const text1 = parts[0] || "";
    const text2 = parts[1] || "";
    const urlFoto = parts[2] || "";

    if (!text1) {
      return sock.sendMessage(
        m.chat,
        { text: `⚠️ Nama (text1) wajib diisi!\n\nContoh: ${command} v1 @lordsaurus|saurus|https://foto.jpg` },
        { quoted: m.verifiedQuoted }
      );
    }

    if (text1.length > MAX_TEXT_LENGTH || text2.length > MAX_TEXT_LENGTH) {
      return sock.sendMessage(
        m.chat,
        { text: `⚠️ Teks maksimal ${MAX_TEXT_LENGTH} karakter per field.` },
        { quoted: m.verifiedQuoted }
      );
    }

    // Validasi URL foto
    if (urlFoto && !isImageUrl(urlFoto)) {
      return sock.sendMessage(
        m.chat,
        { text: `⚠️ URL foto tidak valid!\n\nFormat: https://...jpg/png/gif\n\nContoh: https://c.top4top.io/p_3815w0ycy1.jpg` },
        { quoted: m.verifiedQuoted }
      );
    }

    params = {};
    if (urlFoto) params.urlfoto = urlFoto;
    if (text1) params.text1 = text1;
    if (text2) params.text2 = text2;

    captionText = `💻 *FAKE DEV V1*\n• Nama: ${text1}\n• Username: ${text2 || "-"}\n• Foto: ${urlFoto ? "Custom" : "Tanpa Foto"}`;

  } else if (version === "v2") {
    const parts = remainingText.split("|").map(s => s.trim());
    const teks = parts[0] || "";
    const urlFoto = parts[1] || "";

    if (!teks) {
      return sock.sendMessage(
        m.chat,
        { text: `⚠️ Nama wajib diisi!\n\nContoh: ${command} v2 Lordsaurus|https://foto.jpg` },
        { quoted: m.verifiedQuoted }
      );
    }

    if (teks.length > MAX_TEXT_LENGTH) {
      return sock.sendMessage(
        m.chat,
        { text: `⚠️ Nama maksimal ${MAX_TEXT_LENGTH} karakter.` },
        { quoted: m.verifiedQuoted }
      );
    }

    // Validasi URL foto
    if (urlFoto && !isImageUrl(urlFoto)) {
      return sock.sendMessage(
        m.chat,
        { text: `⚠️ URL foto tidak valid!\n\nFormat: https://...jpg/png/gif` },
        { quoted: m.verifiedQuoted }
      );
    }

    params = {};
    if (urlFoto) params.urlfoto = urlFoto;
    if (teks) params.teks = teks;

    captionText = `💻 *FAKE DEV V2*\n• Nama: ${teks}\n• Verified: ✅\n• Foto: ${urlFoto ? "Custom" : "Tanpa Foto"}`;

  } else if (version === "v3") {
    const parts = remainingText.split("|").map(s => s.trim());
    const text1 = parts[0] || "";
    const text2 = parts[1] || "";
    const urlFoto = parts[2] || "";

    if (!text1 || !text2) {
      return sock.sendMessage(
        m.chat,
        { text: `⚠️ Kedua teks wajib diisi!\n\nContoh: ${command} v3 SAURUS|LORD|https://foto.jpg` },
        { quoted: m.verifiedQuoted }
      );
    }

    if (text1.length > MAX_TEXT_LENGTH || text2.length > MAX_TEXT_LENGTH) {
      return sock.sendMessage(
        m.chat,
        { text: `⚠️ Teks maksimal ${MAX_TEXT_LENGTH} karakter per field.` },
        { quoted: m.verifiedQuoted }
      );
    }

    // Validasi URL foto
    if (urlFoto && !isImageUrl(urlFoto)) {
      return sock.sendMessage(
        m.chat,
        { text: `⚠️ URL foto tidak valid!\n\nFormat: https://...jpg/png/gif` },
        { quoted: m.verifiedQuoted }
      );
    }

    params = {};
    if (urlFoto) params.image = urlFoto;
    if (text1) params.text1 = text1;
    if (text2) params.text2 = text2;

    captionText = `💻 *FAKE DEV V3*\n• Circle: ${text1}\n• Nama: ${text2}\n• Foto: ${urlFoto ? "Custom" : "Tanpa Foto"}`;
  }

  // Kirim pesan proses
  await sock.sendMessage(
    m.chat,
    { text: `💻 *Membuat Fake Dev ${version.toUpperCase()}...*\n\n_Tunggu sebentar..._` },
    { quoted: m.verifiedQuoted }
  );

  try {
    // Generate fake dev
    const { buffer, mime } = await generateFakeDev(version, params);

    // Kirim hasil
    await sock.sendMessage(
      m.chat,
      {
        image: buffer,
        mimetype: mime,
        caption: `${captionText}\n\n_Generated with Fake Dev ${version.toUpperCase()}_`,
      },
      { quoted: m.verifiedQuoted }
    );
  } catch (err) {
    await sock
      .sendMessage(
        m.chat,
        { text: `❌ Gagal membuat fake dev ${version.toUpperCase()}.\n\n*Alasan:* ${err.message}` },
        { quoted: m.verifiedQuoted }
      )
      .catch(() => {});
  }
};

handler.command = ["fakedev", "developer", "devcard"];
handler.tags = ["maker"];
handler.help = ["fakedev <v1|v2|v3> <teks>|<url_foto>"];

export default handler;