let handler = async (m, { sock }) => {

  const rows = []
  rows.push({
    title: `Hapus Semua`,
    description: `Hapus semua server panel`,
    id: `.delpanel-all`
  })

  try {
    const response = await fetch(`${domain}/api/application/servers`, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${apikey}`,
      },
    })

    const result = await response.json()
    const servers = result.data

    if (!servers || servers.length === 0) {
      return m.reply("Tidak ada server panel!")
    }

    for (const server of servers) {
      const s = server.attributes

      const ram = s.limits.memory === 0
        ? "Unlimited"
        : s.limits.memory >= 1024
        ? `${Math.floor(s.limits.memory / 1024)} GB`
        : `${s.limits.memory} MB`

      const disk = s.limits.disk === 0
        ? "Unlimited"
        : s.limits.disk >= 1024
        ? `${Math.floor(s.limits.disk / 1024)} GB`
        : `${s.limits.disk} MB`

      const cpu = s.limits.cpu === 0
        ? "Unlimited"
        : `${s.limits.cpu}%`

      rows.push({
        title: `${s.name} || ID:${s.id}`,
        description: `Ram ${ram} || Disk ${disk} || CPU ${cpu}`,
        id: `.delpanel-response ${s.id}`
      })
    }

    await sock.sendMessage(m.chat, {
      buttons: [{
        buttonId: 'action',
        buttonText: { displayText: 'Pilih Server' },
        type: 4,
        nativeFlowInfo: {
          name: 'single_select',
          paramsJson: JSON.stringify({
            title: 'Pilih Server',
            sections: [{
              rows: rows.map(v => ({
                title: v.title,
                description: v.description,
                id: v.id
              }))
            }]
          })
        }
      }],
      headerType: 1,
      viewOnce: true,
      text: `\nPilih Server Panel Yang Ingin Dihapus\n`
    }, { quoted: m })

  } catch (err) {
    console.error(err)
    m.reply("Terjadi kesalahan saat mengambil data server.")
  }
}

handler.help = ['delpanel']
handler.tags = ['pterodactyl']
handler.command = ['delpanel']
handler.owner = true

export default handler;