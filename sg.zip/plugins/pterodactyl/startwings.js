import { Client } from "ssh2"

let handler = async (m, { text, cmd }) => {
  if (!text) return m.reply(`*example:*\n${m.cmd} ipvps|pwvps|token`)

  let t = text.split("|")
  if (t.length < 3) return m.reply(`*example:*\n${m.cmd} ipvps|pwvps|token`)

  let ipvps = t[0].trim()
  let passwd = t[1].trim()
  let token = t[2].trim()

  const connSettings = {
    host: ipvps,
    port: 22,
    username: "root",
    password: passwd
  }

  const command = `${token} && systemctl start wings`

  const ssh = new Client()

  ssh.on("ready", () => {
    ssh.exec(command, (err, stream) => {
      if (err) {
        m.reply("Gagal menjalankan perintah di VPS")
        ssh.end()
        return
      }

      stream.on("close", async () => {
        await m.reply("Berhasil Menjalankan Wings Node Panel Pterodactyl ✅")
        ssh.end()
      })

      stream.on("data", (data) => {
        console.log("STDOUT:", data.toString())
        stream.write("y\n")
        stream.write("systemctl start wings\n")
      })

      stream.stderr.on("data", (data) => {
        console.log("STDERR:", data.toString())
        m.reply("Terjadi error:\n" + data.toString())
      })
    })
  })

  ssh.on("error", (err) => {
    console.log("SSH Error:", err.message)
    m.reply("Gagal terhubung ke VPS: IP atau password salah.")
  })

  ssh.connect(connSettings)
}

handler.help = ['startwings']
handler.tags = ['pterodactyl']
handler.command = ['startwings', 'configurewings']

export default handler;