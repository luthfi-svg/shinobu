// plugins/pterodactyl/installpanel.js — Auto Install Panel (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Auto Install Pterodactyl Panel
 * 🖥️ Fungsi     : Install panel + wings otomatis via SSH
 * 👤 By Valzz
 * ─────────────────────────
 */

import { generateWAMessageFromContent } from "dekzymarket-cyber";
import { Client } from "ssh2";

let handler = async (m, { sock, text, command }) => {
  const prefix = global.prefix || ".";

  if (!text) {
    return sock.sendMessage(m.chat, {
      text:
        `╭──────────────────────────────╮\n` +
        `  🖥️  *INSTALL PANEL*\n` +
        `╰──────────────────────────────╯\n\n` +
        `  📌 *Format:*\n` +
        `  ${prefix}installpanel ipvps|pwvps|panel.com|node.com|ram\n\n` +
        `  💡 *Contoh:*\n` +
        `  ${prefix}installpanel 123.456.789|pass123|panel.domain.com|node.domain.com|4096\n\n` +
        `  📝 *Keterangan:*\n` +
        `  ① IP VPS\n` +
        `  ② Password Root VPS\n` +
        `  ③ Domain Panel\n` +
        `  ④ Domain Node\n` +
        `  ⑤ RAM Server (MB)\n\n` +
        `  👤 *By Valzz*`
    }, { quoted: m.verifiedQuoted });
  }

  let vii = text.split("|");
  if (vii.length < 5) {
    return sock.sendMessage(m.chat, {
      text: `⚠️ Data kurang!\n\nFormat: ${prefix}installpanel ipvps|pwvps|panel.com|node.com|ram\n\n👤 *By Valzz*`
    }, { quoted: m.verifiedQuoted });
  }

  const jids = m.chat;
  const pass = "admin001";
  let passwordPanel = pass;
  const domainpanel = vii[2];
  const domainnode = vii[3];
  const ramserver = vii[4];
  const deletemysql = `\n`;
  const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`;

  const ress = new Client();
  const connSettings = {
    host: vii[0],
    port: '22',
    username: 'root',
    password: vii[1],
    readyTimeout: 30000,
  };

  async function instalWings() {
    ress.exec(commandPanel, async (err, stream) => {
      if (err) {
        console.error('Wings installation error:', err);
        await sock.sendMessage(m.chat, {
          text: `❌ Gagal memulai instalasi Wings: ${err.message}\n\n👤 *By Valzz*`
        }, { quoted: m.verifiedQuoted });
        return ress.end();
      }

      stream.on('close', async (code, signal) => {
        await InstallNodes();
      }).on('data', async (data) => {
        const dataStr = data.toString();
        console.log('Wings Install: ' + dataStr);

        if (dataStr.includes('Input 0-6')) stream.write('1\n');
        else if (dataStr.includes('(y/N)')) stream.write('y\n');
        else if (dataStr.includes('Enter the panel address')) stream.write(`${domainpanel}\n`);
        else if (dataStr.includes('Database host username')) stream.write('admin\n');
        else if (dataStr.includes('Database host password')) stream.write('admin\n');
        else if (dataStr.includes('Set the FQDN to use for Let\'s Encrypt')) stream.write(`${domainnode}\n`);
        else if (dataStr.includes('Enter email address for Let\'s Encrypt')) stream.write('admin@gmail.com\n');
      }).stderr.on('data', async (data) => {
        console.error('Wings Install Error: ' + data);
      });
    });
  }

  async function InstallNodes() {
    ress.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', async (err, stream) => {
      if (err) throw err;

      stream.on('close', async (code, signal) => {
        const cmdCfg = `cd /var/www/pterodactyl && php artisan p:node:configuration 1 > /etc/pterodactyl/config.yml && chmod 600 /etc/pterodactyl/config.yml && systemctl restart wings`;

        ress.exec(cmdCfg, async (err3) => {
          if (err3) {
            return sock.sendMessage(m.chat, {
              text: `❌ ${err3.message}\n\n👤 *By Valzz*`
            }, { quoted: m.verifiedQuoted });
          }

          let teks =
            `╭──────────────────────────────╮\n` +
            `  ✅  *INSTALL BERHASIL!*\n` +
            `╰──────────────────────────────╯\n\n` +
            `  👤 Username : admin\n` +
            `  🔑 Password : ${passwordPanel}\n` +
            `  🌐 Domain   : ${domainpanel}\n\n` +
            `  ⚠️ Silahkan setting IP allocation\n` +
            `  di node yang sudah dibuat.\n\n` +
            `  👤 *By Valzz*`;

          let msg = await generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
              message: {
                interactiveMessage: {
                  body: { text: teks },
                  nativeFlowMessage: {
                    buttons: [
                      {
                        name: "cta_url",
                        buttonParamsJson: `{"display_text":"🔗 Login Panel","url":"https://${domainpanel}"}`
                      }
                    ]
                  }
                }
              }
            }
          }, { userJid: m.sender, quoted: m });

          await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
          ress.end();
        });

      }).on('data', async (data) => {
        const dataStr = data.toString();
        console.log(dataStr);
        if (dataStr.includes("Masukkan nama lokasi:")) stream.write('Singapore\n');
        if (dataStr.includes("Masukkan deskripsi lokasi:")) stream.write('Node By Valzz\n');
        if (dataStr.includes("Masukkan domain:")) stream.write(`${domainnode}\n`);
        if (dataStr.includes("Masukkan nama node:")) stream.write('Node Valzz\n');
        if (dataStr.includes("Masukkan RAM (dalam MB):")) stream.write(`${ramserver}\n`);
        if (dataStr.includes("Masukkan jumlah maksimum disk space (dalam MB):")) stream.write(`${ramserver}\n`);
        if (dataStr.includes("Masukkan Locid:")) stream.write('1\n');
      }).stderr.on('data', async (data) => {
        console.log('Stderr : ' + data);
      });
    });
  }

  async function instalPanel() {
    ress.exec(commandPanel, (err, stream) => {
      if (err) throw err;

      stream.on('close', async (code, signal) => {
        await instalWings();
      }).on('data', async (data) => {
        const dataStr = data.toString();
        if (dataStr.includes('Input 0-6')) stream.write('0\n');
        if (dataStr.includes('(y/N)')) stream.write('y\n');
        if (dataStr.includes('Database name (panel)')) stream.write('\n');
        if (dataStr.includes('Database username (pterodactyl)')) stream.write('admin\n');
        if (dataStr.includes('Password (press enter to use randomly generated password)')) stream.write('admin\n');
        if (dataStr.includes('Select timezone [Europe/Stockholm]')) stream.write('Asia/Jakarta\n');
        if (dataStr.includes('Provide the email address')) stream.write('admin@gmail.com\n');
        if (dataStr.includes('Email address for the initial admin account')) stream.write('admin@gmail.com\n');
        if (dataStr.includes('Username for the initial admin account')) stream.write('admin\n');
        if (dataStr.includes('First name for the initial admin account')) stream.write('admin\n');
        if (dataStr.includes('Last name for the initial admin account')) stream.write('admin\n');
        if (dataStr.includes('Password for the initial admin account')) stream.write(`${passwordPanel}\n`);
        if (dataStr.includes('Set the FQDN of this panel (panel.example.com)')) stream.write(`${domainpanel}\n`);
        if (dataStr.includes('Do you want to automatically configure UFW')) stream.write('y\n');
        if (dataStr.includes('Do you want to automatically configure HTTPS using Let\'s Encrypt')) stream.write('y\n');
        if (dataStr.includes('Select the appropriate number [1-2]')) stream.write('1\n');
        if (dataStr.includes('I agree that this HTTPS request is performed')) stream.write('y\n');
        if (dataStr.includes('Proceed anyways')) stream.write('y\n');
        if (dataStr.includes('(yes/no)')) stream.write('y\n');
        if (dataStr.includes('Initial configuration completed')) stream.write('y\n');
        if (dataStr.includes('Still assume SSL?')) stream.write('y\n');
        if (dataStr.includes('Please read the Terms of Service')) stream.write('y\n');
        if (dataStr.includes('(A)gree/(C)ancel:')) stream.write('A\n');
        console.log('Logger: ' + dataStr);
      }).stderr.on('data', (data) => {
        console.log('STDERR: ' + data);
      });
    });
  }

  ress.on('ready', async () => {
    await sock.sendMessage(m.chat, {
      text:
        `╭──────────────────────────────╮\n` +
        `  🚀  *PROSES INSTALLASI*\n` +
        `╰──────────────────────────────╯\n\n` +
        `  🌐 IP      : ${vii[0]}\n` +
        `  📱 Domain  : ${domainpanel}\n\n` +
        `  ⏳ Mohon tunggu 1-10 menit\n` +
        `  hingga proses selesai...\n\n` +
        `  👤 *By Valzz*`
    }, { quoted: m.verifiedQuoted });

    ress.exec(deletemysql, async (err, stream) => {
      if (err) throw err;
      stream.on('close', async (code, signal) => {
        await instalPanel();
      }).on('data', async (data) => {
        await stream.write('\t');
        await stream.write('\n');
        console.log(data.toString());
      }).stderr.on('data', async (data) => {
        console.log('Stderr : ' + data);
      });
    });
  });

  ress.on('error', (err) => {
    console.error('SSH Connection Error:', err);
    sock.sendMessage(m.chat, {
      text:
        `╭──────────────────────────────╮\n` +
        `  ❌  *KONEKSI GAGAL!*\n` +
        `╰──────────────────────────────╯\n\n` +
        `  📡 ${err.message}\n\n` +
        `  💡 Cek IP & Password VPS!\n\n` +
        `  👤 *By Valzz*`
    }, { quoted: m.verifiedQuoted });
  });

  ress.connect(connSettings);
};

handler.tags = ["pterodactyl"];
handler.command = ["installpanel"];
handler.owner = true;

export default handler;