let handler = async (m, { sock }) => {

  try {
    const res = await fetch(`${domain}/api/application/users`, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${apikey}`
      }
    })

    const data = await res.json()
    const users = data.data

    const adminUsers = users.filter(u => u.attributes.root_admin === true)

    if (!adminUsers || adminUsers.length < 1) {
      return m.reply("Tidak ada admin panel.")
    }

    const rows = []

    for (const admin of adminUsers) {
      const a = admin.attributes

      rows.push({
        title: `${a.first_name} || ID:${a.id}`,
        description: `Created: ${a.created_at.split("T")[0]}`,
        id: `.deladmin-response ${a.id}`
      })
    }

    await sock.sendMessage(m.chat, {
      buttons: [{
        buttonId: 'action',
        buttonText: { displayText: 'Pilih User' },
        type: 4,
        nativeFlowInfo: {
          name: 'single_select',
          paramsJson: JSON.stringify({
            title: 'Pilih User',
            sections: [{
              rows
            }]
          })
        }
      }],
      headerType: 1,
      viewOnce: true,
      text: `\nPilih Admin Panel Yang Ingin Dihapus\n`
    }, { quoted: m })

  } catch (err) {
    console.error(err)
    m.reply("Terjadi kesalahan saat mengambil data admin.")
  }
}

handler.help = ['deladmin']
handler.tags = ['pterodactyl']
handler.command = ['deladmin']
handler.owner = true

export default handler;