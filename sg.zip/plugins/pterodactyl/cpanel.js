import { generateWAMessageFromContent } from "dekzymarket-cyber"

let handler = async (m, { sock, text, command, isOwner }) => {
  if (!isOwner) return m.reply(mess.owner)
  if (!text) return m.reply(`*example:*\n${m.cmd} username`)

  let nomor, usernem
  let tek = text.split(",")

  if (tek.includes(",")) {
    let [users, nom] = tek.map(t => t.trim())
    if (!users || !nom) return m.reply(`*example:*\n${m.cmd} username`)
    nomor = m.mentionedJid[0] ? m.mentionedJid[0] : nom.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
    nomor = await sock.toLid(nomor)
    usernem = users.toLowerCase()
  } else {
    usernem = text.toLowerCase()
    nomor = m.isGroup ? m.sender : m.chat
  }

  const resourceMap = {
    "1gb": { ram: "1000", disk: "1000", cpu: "40" },
    "2gb": { ram: "2000", disk: "1000", cpu: "60" },
    "3gb": { ram: "3000", disk: "2000", cpu: "80" },
    "4gb": { ram: "4000", disk: "2000", cpu: "100" },
    "5gb": { ram: "5000", disk: "3000", cpu: "120" },
    "6gb": { ram: "6000", disk: "3000", cpu: "140" },
    "7gb": { ram: "7000", disk: "4000", cpu: "160" },
    "8gb": { ram: "8000", disk: "4000", cpu: "180" },
    "9gb": { ram: "9000", disk: "5000", cpu: "200" },
    "10gb": { ram: "10000", disk: "5000", cpu: "220" },
    "unlimited": { ram: "0", disk: "0", cpu: "0" },
    "unli": { ram: "0", disk: "0", cpu: "0" }
  }

  let { ram, disk, cpu } = resourceMap[command] || { ram: "0", disk: "0", cpu: "0" }

  let username = usernem.toLowerCase()
  let email = username + "@gmail.com"
  let name = global.capital(username) + " Server"
  let password = username + "001"

  try {
    let f = await fetch(domain + "/api/application/users", {
      method: "POST",
      headers: { "Accept": "application/json", "Content-Type": "application/json", "Authorization": "Bearer " + apikey },
      body: JSON.stringify({ email, username, first_name: name, last_name: "Server", language: "en", password })
    })

    let data = await f.json()
    if (data.errors) return m.reply("Error: " + JSON.stringify(data.errors[0], null, 2))
    let user = data.attributes

    let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/${egg}`, {
      method: "GET",
      headers: { "Accept": "application/json", "Content-Type": "application/json", "Authorization": "Bearer " + apikey }
    })

    let data2 = await f1.json()
    let startup_cmd = data2.attributes.startup

    let f2 = await fetch(domain + "/api/application/servers", {
      method: "POST",
      headers: { "Accept": "application/json", "Content-Type": "application/json", "Authorization": "Bearer " + apikey },
      body: JSON.stringify({
        name,
        description: global.tanggal(Date.now()),
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
        startup: startup_cmd,
        environment: { INST: "npm", USER_UPLOAD: "0", AUTO_UPDATE: "0", CMD_RUN: "npm start" },
        limits: { memory: ram, swap: 0, disk, io: 500, cpu },
        feature_limits: { databases: 5, backups: 5, allocations: 5 },
        deploy: { locations: [parseInt(loc)], dedicated_ip: false, port_range: [] }
      })
    })

    let result = await f2.json()
    if (result.errors) return m.reply("Error: " + JSON.stringify(result.errors[0], null, 2))

    let server = result.attributes
    let orang = nomor

    if (orang !== m.chat) {
      await m.reply(`Berhasil membuat akun panel ✅\ndata dikirim ke @${nomor.split("@")[0]}`)
    }

    let teks = `
*Behasil Membuat Server Panel ✅*
- Server ID: ${server.id}
- Username: ${user.username}
- Password: ${password}
- Tanggal: ${global.tanggal(Date.now())}
- Ram: ${ram == "0" ? "Unlimited" : ram / 1000 + "GB"}
- Disk: ${disk == "0" ? "Unlimited" : disk / 1000 + "GB"}
- CPU: ${cpu == "0" ? "Unlimited" : cpu + "%"}
- Panel: ${global.domain}
`

    let msg = await generateWAMessageFromContent(orang, {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: { text: teks },
            nativeFlowMessage: {
              buttons: [
                { name: "cta_copy", buttonParamsJson: `{"display_text":"Copy Username","copy_code":"${user.username}"}` },
                { name: "cta_copy", buttonParamsJson: `{"display_text":"Copy Password","copy_code":"${password}"}` },
                { name: "cta_url", buttonParamsJson: `{"display_text":"Login Panel","url":"${global.domain}"}` }
              ]
            }
          }
        }
      }
    }, { userJid: m.sender, quoted: m })

    await sock.relayMessage(orang, msg.message, { messageId: msg.key.id })

  } catch (err) {
    return m.reply("Terjadi kesalahan: " + err.message)
  }
}

handler.help = "1gb - .unlimited"
handler.command = ["1gb","2gb","3gb","4gb","5gb","6gb","7gb","8gb","9gb","10gb","unlimited","unli"]
handler.tags = ["pterodactyl"]
handler.owner = true

export default handler;