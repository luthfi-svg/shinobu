import { Client } from "ssh2"
import net from "net"

let handler = async (m, { text }) => {
  if (!text) return m.reply(`*example:*\n${m.cmd} ipvps|pwvps`)

  let [ipvps, passwd] = text.split("|")
  if (!ipvps || !passwd) return m.reply(`*example:*\n${m.cmd} ipvps|pwvps`)

  const delay = ms => new Promise(res => setTimeout(res, ms))

  function waitForSSH(host, port = 22, timeout = 300) {
    return new Promise((resolve, reject) => {
      let elapsed = 0
      const interval = setInterval(() => {
        const socket = new net.Socket()
        socket.setTimeout(2000)
        socket.on("connect", () => { clearInterval(interval); socket.destroy(); resolve(true) })
        socket.on("error", () => socket.destroy())
        socket.on("timeout", () => socket.destroy())
        socket.connect(port, host)
        elapsed += 2
        if (elapsed >= timeout) {
          clearInterval(interval)
          reject(new Error("VPS tidak merespon SSH setelah reboot"))
        }
      }, 2000)
    })
  }

  const conn = new Client()

  conn.on("ready", async () => {
    try {
      await m.reply("♻️ VPS sedang direstart...")
      conn.exec("reboot", () => {})
      conn.end()

      await delay(10000)
      await m.reply("⏳ Menunggu VPS aktif kembali (SSH)...")
      await waitForSSH(ipvps)
      await m.reply("✅ VPS sudah aktif, lanjut uninstall panel...")

      const conn2 = new Client()

      conn2.on("ready", () => {
        const cmd = `bash <(curl -s https://pterodactyl-installer.se)`

        conn2.exec(cmd, { pty: true }, (err, stream) => {
          if (err) return m.reply("❌ Gagal menjalankan uninstall")

          stream.on("data", data => {
            let d = data.toString()
            console.log("UNINSTALL:", d)
            if (d.includes("Input 0-6")) stream.write("6\n")
            if (d.includes("(y/N)") || d.includes("(Y)es/(N)o")) stream.write("y\n")
            if (d.includes("panel user")) stream.write("\n")
            if (d.includes("panel database")) stream.write("\n")
          })

          stream.on("close", async () => {
            await m.reply("🧹 Membersihkan database...")

            const cleardb = `
sudo dpkg --configure -a
sudo DEBIAN_FRONTEND=noninteractive apt-get purge -y mariadb-server mariadb-client mariadb-common mysql-common mysql-server-core-* mysql-client-core-*
sudo apt-get autoremove -y
sudo rm -rf /var/lib/mysql /etc/mysql
echo "DONE"
`.trim()

            conn2.exec(cleardb, { pty: true }, (err2, stream2) => {
              if (err2) return m.reply("❌ Gagal cleardb")

              stream2.on("data", data => console.log("CLEARDB:", data.toString()))

              stream2.on("close", async () => {
                await m.reply("✅ Uninstall panel + Cleardb berhasil!\n🔄 VPS reboot ulang...")
                conn2.exec("reboot", () => {})
                conn2.end()
              })
            })
          })
        })
      })

      conn2.on("error", err => m.reply(`❌ SSH Error:\n${err.message}`))
      conn2.connect({ host: ipvps, port: 22, username: "root", password: passwd })

    } catch (e) {
      m.reply(`❌ Error:\n${e.message}`)
    }
  })

  conn.on("error", err => m.reply(`❌ Gagal koneksi:\n${err.message}`))
  conn.connect({ host: ipvps, port: 22, username: "root", password: passwd })
}

handler.help = "uninstallpanel"
handler.command = ["uninstallpanel", "uninstalpanel"]
handler.tags = ["pterodactyl"]
handler.owner = true

export default handler;