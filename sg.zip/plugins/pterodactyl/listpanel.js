let handler = async (m) => {
  try {
    const res = await fetch(`${domain}/api/application/servers`, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${apikey}`,
      },
    })

    const result = await res.json()
    const servers = result.data

    if (!servers || servers.length === 0) {
      return m.reply("Tidak ada server panel.")
    }

    let messageText = `\nTotal Server Panel: ${servers.length}\n`

    for (const server of servers) {
      const s = server.attributes

      const ram = s.limits.memory === 0
        ? "Unlimited"
        : s.limits.memory >= 1024
        ? `${Math.floor(s.limits.memory / 1024)} GB`
        : `${s.limits.memory} MB`

      const disk = s.limits.disk === 0
        ? "Unlimited"
        : s.limits.disk >= 1024
        ? `${Math.floor(s.limits.disk / 1024)} GB`
        : `${s.limits.disk} MB`

      const cpu = s.limits.cpu === 0
        ? "Unlimited"
        : `${s.limits.cpu}%`

      messageText += `
- ID Server: ${s.id}
- Nama: ${s.name}
- RAM: ${ram}
- Disk: ${disk}
- CPU: ${cpu}
- Created: ${s.created_at.split("T")[0]}
`
    }

    m.reply(messageText)

  } catch (err) {
    console.error(err)
    m.reply("Terjadi kesalahan saat mengambil data server.")
  }
}

handler.help = ['listpanel']
handler.tags = ['pterodactyl']
handler.command = ['listpanel', 'listserver']

export default handler;