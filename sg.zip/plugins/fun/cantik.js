// plugins/fun/cantik.js — Cek tingkat kecantikan (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Cek Cantik
 * 🔧 Fungsi     : Cek tingkat kecantikan random
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock }) => {
  let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : m.sender;
  
  const percentage = Math.floor(Math.random() * 100) + 1;
  
  let status;
  if (percentage >= 90) {
    status = "Cantik banget! 😍";
  } else if (percentage >= 75) {
    status = "Cantik! 🌟";
  } else if (percentage >= 60) {
    status = "Lumayan cantik 😊";
  } else if (percentage >= 40) {
    status = "Biasa aja 😐";
  } else {
    status = "Kurang cantik 😅";
  }

  await sock.sendMessage(
    m.chat,
    {
      text: 
        `💄 *Cek Cantik*\n\n` +
        `👤 Nama: @${who.split("@")[0]}\n` +
        `✨ Tingkat Kecantikan: ${percentage}%\n` +
        `📊 Status: ${status}\n\n` +
        `_Random check, just for fun!_`,
      mentions: [who]
    },
    { quoted: m }
  );
};

handler.help = ["cantik @user"];
handler.tags = ["fun"];
handler.command = /^(cantik|cekcantik)$/i;
handler.limit = false;

export default handler;
