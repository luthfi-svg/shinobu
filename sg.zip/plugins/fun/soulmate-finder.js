// plugins/fun/soulmate-finder.js — Soulmate Finder (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Soulmate Finder
 * 🔧 Fungsi     : Cari jodoh
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Soulmate Finder*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["soulmate", "carijodoh"];
handler.tags = ['fun'];
handler.command = /^(soulmate|carijodoh)$/i;

export default handler;
