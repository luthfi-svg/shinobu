// plugins/fun/daily-wisdom.js — Daily Wisdom (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Daily Wisdom
 * 🔧 Fungsi     : Kebijaksanaan harian
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Daily Wisdom*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["wisdom", "kebijaksanaan"];
handler.tags = ['fun'];
handler.command = /^(wisdom|kebijaksanaan)$/i;

export default handler;
