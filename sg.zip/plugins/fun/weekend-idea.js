// plugins/fun/weekend-idea.js — Weekend Idea (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Weekend Idea
 * 🔧 Fungsi     : Ide weekend
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  await m.reply(
    `✨ *Weekend Idea*\n\n` +
    `📝 Content generated\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["weekendidea", "ideweekend"];
handler.tags = ['fun'];
handler.command = /^(weekendidea|ideweekend)$/i;

export default handler;
