// plugins/fun/crush-detector.js — Crush Detector (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Crush Detector
 * 🔧 Fungsi     : Deteksi gebetan
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Crush Detector*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["crushdetect", "gebetan"];
handler.tags = ['fun'];
handler.command = /^(crushdetect|gebetan)$/i;

export default handler;
