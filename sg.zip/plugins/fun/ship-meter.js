// plugins/fun/ship-meter.js — Ship Meter (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Ship Meter
 * 🔧 Fungsi     : Ukur chemistry 2 orang
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Ship Meter*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["shipmeter", "chemistry"];
handler.tags = ['fun'];
handler.command = /^(shipmeter|chemistry)$/i;

export default handler;
