// plugins/fun/toxic.js — Cek tingkat toxic (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Cek Toxic
 * 🔧 Fungsi     : Cek tingkat toxic random
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock }) => {
  let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : m.sender;
  
  const percentage = Math.floor(Math.random() * 100) + 1;
  
  let status;
  if (percentage >= 90) {
    status = "TOXIC BANGET! ☠️";
  } else if (percentage >= 75) {
    status = "Lumayan toxic 😈";
  } else if (percentage >= 50) {
    status = "Agak toxic 😏";
  } else if (percentage >= 25) {
    status = "Sedikit toxic 😊";
  } else {
    status = "Gak toxic 😇";
  }

  await sock.sendMessage(
    m.chat,
    {
      text: 
        `☠️ *Cek Toxic*\n\n` +
        `👤 Nama: @${who.split("@")[0]}\n` +
        `💀 Tingkat Toxic: ${percentage}%\n` +
        `📊 Status: ${status}\n\n` +
        `_Random check, just for fun!_`,
      mentions: [who]
    },
    { quoted: m }
  );
};

handler.help = ["toxic @user"];
handler.tags = ["fun"];
handler.command = /^(toxic|cektoxic)$/i;
handler.limit = false;

export default handler;
