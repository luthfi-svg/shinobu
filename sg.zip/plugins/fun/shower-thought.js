// plugins/fun/shower-thought.js — Shower Thought (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Shower Thought
 * 🔧 Fungsi     : Pemikiran shower
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Shower Thought*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["showerthought", "pikiranshower"];
handler.tags = ['fun'];
handler.command = /^(showerthought|pikiranshower)$/i;

export default handler;
