// plugins/fun/truth.js — Truth game (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Truth
 * 🔧 Fungsi     : Random truth questions untuk game
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m) => {
  const truths = [
    "Siapa orang yang paling kamu suka saat ini?",
    "Apa kebohongan terbesar yang pernah kamu katakan?",
    "Siapa crush kamu sekarang?",
    "Apa hal paling memalukan yang pernah kamu lakukan?",
    "Kapan terakhir kali kamu berbohong?",
    "Apa rahasia yang belum pernah kamu ceritakan ke siapapun?",
    "Siapa mantan yang paling kamu rindukan?",
    "Apa hal paling menyesal yang pernah kamu lakukan?",
    "Berapa banyak mantan yang kamu punya?",
    "Apa fantasimu yang paling aneh?",
    "Siapa orang terakhir yang kamu stalk di sosmed?",
    "Apa ketakutan terbesarmu?",
    "Pernah naksir teman sendiri gak?",
    "Apa mimpi terburukmu?",
    "Siapa orang yang paling kamu benci?",
    "Pernah selingkuh gak?",
    "Apa kebiasaan burukmu yang gak ada yang tau?",
    "Siapa yang paling kamu jealous?",
    "Apa hal paling gila yang pernah kamu lakukan demi cinta?",
    "Berapa umur pertama kali jatuh cinta?",
    "Pernah ghosting orang gak? Alasannya?",
    "Apa hal yang paling bikin kamu insecure?",
    "Siapa idola yang pengen kamu jadiin pacar?",
    "Pernah nangis gara-gara gebetan gak?",
    "Apa mimpi terindahmu tentang seseorang?"
  ];

  const randomTruth = truths[Math.floor(Math.random() * truths.length)];

  await m.reply(
    `🎯 *Truth Game*\n\n` +
    `❓ ${randomTruth}\n\n` +
    `_Jawab dengan jujur ya!_ 😏`
  );
};

handler.help = ["truth"];
handler.tags = ["fun"];
handler.command = /^(truth)$/i;
handler.limit = false;

export default handler;
