// plugins/fun/jadian.js — Random jadian dari member group (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Jadian
 * 🔧 Fungsi     : Random 2 member untuk jadian
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock }) => {
  if (!m.isGroup) {
    return m.reply("❌ Command ini hanya untuk group!");
  }

  try {
    const participants = m.metadata?.participants || [];
    
    if (participants.length < 2) {
      return m.reply("❌ Member kurang dari 2!");
    }

    const shuffled = participants.sort(() => Math.random() - 0.5);
    const p1 = shuffled[0].id;
    const p2 = shuffled[1].id;

    const percentage = Math.floor(Math.random() * 100) + 1;

    let status;
    if (percentage >= 90) {
      status = "JODOH BANGET! 💕💕💕";
    } else if (percentage >= 70) {
      status = "Cocok banget! 💑";
    } else if (percentage >= 50) {
      status = "Lumayan cocok 👫";
    } else {
      status = "Kurang cocok 💔";
    }

    await sock.sendMessage(
      m.chat,
      {
        text: 
          `💕 *JADIAN ALERT!*\n\n` +
          `@${p1.split("@")[0]} ❤️ @${p2.split("@")[0]}\n\n` +
          `💯 Kecocokan: ${percentage}%\n` +
          `📊 Status: ${status}\n\n` +
          `_Selamat ya! 🎉_`,
        mentions: [p1, p2]
      },
      { quoted: m }
    );

  } catch (e) {
    console.error(e);
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["jadian"];
handler.tags = ["fun"];
handler.command = /^(jadian|jadiin)$/i;
handler.group = true;
handler.limit = false;

export default handler;
