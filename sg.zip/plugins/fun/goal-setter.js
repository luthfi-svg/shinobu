// plugins/fun/goal-setter.js — Goal Setter (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Goal Setter
 * 🔧 Fungsi     : Set goal
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  await m.reply(
    `✨ *Goal Setter*\n\n` +
    `📝 Content generated\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["goalsetter", "setgoal"];
handler.tags = ['fun'];
handler.command = /^(goalsetter|setgoal)$/i;

export default handler;
