// plugins/fun/neko.js — Random neko anime picture (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Neko
 * 🔧 Fungsi     : Random gambar neko anime
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

let handler = async (m, { sock }) => {
  try {
    await m.reply("⏳ *Getting Neko...*");

    const response = await axios.get("https://api.waifu.pics/sfw/neko", {
      timeout: 15000
    });

    const imageUrl = response.data.url;

    await sock.sendMessage(
      m.chat,
      {
        image: { url: imageUrl },
        caption: `🐱 *Random Neko*\n\n_Powered by waifu.pics_`
      },
      { quoted: m }
    );

    await m.react("✅");

  } catch (e) {
    console.error(e);
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["neko"];
handler.tags = ["fun"];
handler.command = /^(neko)$/i;
handler.limit = true;

export default handler;
