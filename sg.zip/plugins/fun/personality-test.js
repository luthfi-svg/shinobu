// plugins/fun/personality-test.js — Personality Test (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Personality Test
 * 🔧 Fungsi     : Test kepribadian
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Personality Test*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["personalitytest", "teskepribadian"];
handler.tags = ['fun'];
handler.command = /^(personalitytest|teskepribadian)$/i;

export default handler;
