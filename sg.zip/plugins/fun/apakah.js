// plugins/fun/apakah.js — Random yes/no question game (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Apakah
 * 🔧 Fungsi     : Jawab pertanyaan "apakah" dengan random answer
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `Contoh penggunaan:\n${usedPrefix + command} <pertanyaan>\n\n` +
      `Contoh:\n` +
      `${usedPrefix + command} aku ganteng?\n` +
      `${usedPrefix + command} dia suka sama aku?`
    );
  }

  const answers = [
    "Iya",
    "Tidak",
    "Mungkin",
    "Bisa jadi",
    "Sepertinya iya",
    "Sepertinya tidak",
    "Pasti iya dong!",
    "Jangan harap!",
    "Kemungkinan besar iya",
    "Kemungkinan besar tidak",
    "Sudah pasti!",
    "Mustahil!",
    "Coba tanya lagi nanti",
    "Rahasia~",
    "50:50",
    "Absolutely!",
    "No way!",
    "Tentu saja!",
    "Jangan bermimpi!",
    "Ask again later"
  ];

  const randomAnswer = answers[Math.floor(Math.random() * answers.length)];
  const confidence = Math.floor(Math.random() * 100) + 1;

  await m.reply(
    `❓ *Pertanyaan:*\n${text}\n\n` +
    `💡 *Jawaban:* ${randomAnswer}\n` +
    `📊 *Confidence:* ${confidence}%`
  );
};

handler.help = ["apakah <pertanyaan>"];
handler.tags = ["fun"];
handler.command = /^(apakah|apasih)$/i;
handler.limit = false;

export default handler;
