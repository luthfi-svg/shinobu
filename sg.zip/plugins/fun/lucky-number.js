// plugins/fun/lucky-number.js — Lucky Number (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Lucky Number
 * 🔧 Fungsi     : Angka keberuntungan
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Lucky Number*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["luckynumber", "angkahoki"];
handler.tags = ['fun'];
handler.command = /^(luckynumber|angkahoki)$/i;

export default handler;
