// plugins/fun/deep-thought.js — Deep Thought (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Deep Thought
 * 🔧 Fungsi     : Pemikiran mendalam
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Deep Thought*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["deepthought", "pikiranmendalam"];
handler.tags = ['fun'];
handler.command = /^(deepthought|pikiranmendalam)$/i;

export default handler;
