// plugins/fun/financial-advice.js — Financial Advice (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Financial Advice
 * 🔧 Fungsi     : Nasihat keuangan
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Financial Advice*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["financialadvice", "nasihatkeuangan"];
handler.tags = ['fun'];
handler.command = /^(financialadvice|nasihatkeuangan)$/i;

export default handler;
