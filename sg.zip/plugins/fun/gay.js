// plugins/fun/gay.js — Cek tingkat gay (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Cek Gay
 * 🔧 Fungsi     : Cek tingkat gay random (just for fun)
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock }) => {
  let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : m.sender;
  
  const percentage = Math.floor(Math.random() * 100) + 1;
  
  let status;
  if (percentage >= 80) {
    status = "Wah... 🏳️‍🌈";
  } else if (percentage >= 60) {
    status = "Lumayan 😏";
  } else if (percentage >= 40) {
    status = "Biasa aja 😐";
  } else {
    status = "Aman 😊";
  }

  await sock.sendMessage(
    m.chat,
    {
      text: 
        `🏳️‍🌈 *Cek Gay*\n\n` +
        `👤 Nama: @${who.split("@")[0]}\n` +
        `💯 Tingkat: ${percentage}%\n` +
        `📊 Status: ${status}\n\n` +
        `_Just for fun, don't take it seriously!_`,
      mentions: [who]
    },
    { quoted: m }
  );
};

handler.help = ["gay @user"];
handler.tags = ["fun"];
handler.command = /^(gay|cekgay)$/i;
handler.limit = false;

export default handler;
