// plugins/fun/lucky-color.js — Lucky Color (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Lucky Color
 * 🔧 Fungsi     : Warna keberuntungan
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Lucky Color*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["luckycolor", "warnahoki"];
handler.tags = ['fun'];
handler.command = /^(luckycolor|warnahoki)$/i;

export default handler;
