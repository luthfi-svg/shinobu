// plugins/fun-motivasi.js — dari Shota Bot MD

const motivasiList = [
  "Langkah kecil membuka jalan besar.\n~Anonim",
  "Satu napas tenang menata ulang dunia.\n~Anonim",
  "A journey of a thousand miles begins with a single step.\n~Lao Tzu",
  "Hati yang tabah tak gentar pada badai.\n~Anonim",
  "Di balik senyum, ada lautan cerita.\n~Anonim",
  "You have power over your mind — not outside events.\n~Marcus Aurelius",
  "Kecilkan ego, besarkan cinta.\n~Anonim",
  "Rasa syukur mengubah sedikit menjadi cukup.\n~Anonim",
  "Jumlah luka bukan ukuran kelemahanmu.\n~Anonim",
  "Cahaya pagi tak tanya kenapa kau terlambat.\n~Anonim",
  "Diam bukan tandanya kalah, melainkan menimbang.\n~Anonim",
  "Kamu bukan bayang-bayang masa lalu; kau mungkin cahaya esok.\n~Anonim",
  "Mimpi itu peta, usaha adalah langkah.\n~Anonim",
  "Bukan soal seberapa keras jatuhnya, tapi seberapa cepat bangkitnya.\n~Anonim",
  "Mulailah dari mana kamu berada, gunakan apa yang kamu punya.\n~Arthur Ashe",
  "Percayalah pada dirimu sendiri, itulah rahasianya.\n~Anonim",
  "Setiap hari adalah kesempatan baru untuk menjadi lebih baik.\n~Anonim",
  "Jangan hitung hari-harinya, buat setiap hari berarti.\n~Muhammad Ali",
  "Kesuksesan adalah jumlah dari usaha-usaha kecil yang diulang setiap hari.\n~Robert Collier",
  "Berani bermimpi, berani berusaha, berani gagal, dan berani bangkit.\n~Anonim",
];

const bacotan = [
  "Kamu suka kopi nggak? Aku sih suka. Kopi itu ibarat kamu, pahit tapi bikin candu.",
  "Gajian itu kayak mantan, bisanya cuman lewat sebentar aja.",
  "Google itu hebat ya? Tapi sehebat-hebatnya Google nggak bisa nemuin jodoh kita.",
  "Selelah-lelahnya bekerja, lebih lelah lagi kalau nganggur.",
  "Netizen kalau senam jempol di ponsel nggak pakai pendinginan, pantes komennya bikin panas.",
  "Jodoh memang nggak kemana, tapi saingannya ada dimana-mana.",
  "Masih berharap dan terus berharap, lama-lama aku jadi juara harapan.",
  "Manusia boleh berencana, tapi akhirnya saldo juga yang menentukan.",
  "Statusnya rohani, kelakuannya rohalus.",
  "Kita hidup di masa kalau salah kena marah, pas bener dibilang tumben.",
  "Nggak ada bahu pacar? Tenang, masih ada bahu jalan buat nyandar.",
  "Selingkuh bukan karena ada niat, tapi karena pacarmu masih laku.",
  "Mencintai dirimu itu wajar, yang gak wajar mencintai dirimu aja terus.",
  "Jomblo tidak perlu malu, bukan berarti tidak laku, tapi memang tidak ada yang mau.",
  "Kalau doamu belum terkabul, ingatlah bahwa yang berdoa bukan cuma kamu.",
];

let handler = async (m, { command }) => {
  if (command === 'motivasi' || command === 'motifasi') {
    const q = motivasiList[Math.floor(Math.random() * motivasiList.length)];
    await m.react('💪');
    return m.reply(`💪 *MOTIVASI HARI INI*\n\n_"${q}"_`);
  }
  // gombal/bacot
  const q = bacotan[Math.floor(Math.random() * bacotan.length)];
  await m.react('😂');
  return m.reply(`😂 *BACOT QUOTES*\n\n_"${q}"_`);
};

handler.command = ['motivasi', 'motifasi', 'bacot'];
handler.tags = ['fun'];
handler.help = ['motivasi', 'bacot'];
export default handler;