// plugins/fun/age-calculator.js — Age Calculator (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Age Calculator
 * 🔧 Fungsi     : Hitung umur
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Age Calculator*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["agecalc", "hitungumur"];
handler.tags = ['fun'];
handler.command = /^(agecalc|hitungumur)$/i;

export default handler;
