// plugins/fun/morning-routine.js — Morning Routine (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Morning Routine
 * 🔧 Fungsi     : Rutinitas pagi
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  await m.reply(
    `✨ *Morning Routine*\n\n` +
    `📝 Content generated\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["morningroutine", "rutinitaspagi"];
handler.tags = ['fun'];
handler.command = /^(morningroutine|rutinitaspagi)$/i;

export default handler;
