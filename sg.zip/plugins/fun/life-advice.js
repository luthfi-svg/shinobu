// plugins/fun/life-advice.js — Life Advice (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Life Advice
 * 🔧 Fungsi     : Nasihat hidup
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Life Advice*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["lifeadvice", "nasihathidup"];
handler.tags = ['fun'];
handler.command = /^(lifeadvice|nasihathidup)$/i;

export default handler;
