// plugins/fun/weird-fact.js — Weird Fact (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Weird Fact
 * 🔧 Fungsi     : Fakta aneh
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Weird Fact*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["weirdfact", "faktaaneh"];
handler.tags = ['fun'];
handler.command = /^(weirdfact|faktaaneh)$/i;

export default handler;
