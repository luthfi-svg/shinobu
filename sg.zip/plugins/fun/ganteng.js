// plugins/fun/ganteng.js — Cek tingkat ketampanan (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Cek Ganteng
 * 🔧 Fungsi     : Cek tingkat ketampanan random
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock }) => {
  let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : m.sender;
  
  const percentage = Math.floor(Math.random() * 100) + 1;
  
  let status;
  if (percentage >= 90) {
    status = "Ganteng banget! 🤩";
  } else if (percentage >= 75) {
    status = "Ganteng! ✨";
  } else if (percentage >= 60) {
    status = "Lumayan ganteng 😊";
  } else if (percentage >= 40) {
    status = "Biasa aja 😐";
  } else {
    status = "Kurang ganteng 😅";
  }

  await sock.sendMessage(
    m.chat,
    {
      text: 
        `🎩 *Cek Ganteng*\n\n` +
        `👤 Nama: @${who.split("@")[0]}\n` +
        `✨ Tingkat Ketampanan: ${percentage}%\n` +
        `📊 Status: ${status}\n\n` +
        `_Random check, just for fun!_`,
      mentions: [who]
    },
    { quoted: m }
  );
};

handler.help = ["ganteng @user"];
handler.tags = ["fun"];
handler.command = /^(ganteng|cekganteng)$/i;
handler.limit = false;

export default handler;
