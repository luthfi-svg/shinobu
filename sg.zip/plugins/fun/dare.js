// plugins/fun/dare.js — Dare game (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Dare
 * 🔧 Fungsi     : Random dare challenges untuk game
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m) => {
  const dares = [
    "Chat crush kamu dan bilang 'Aku kangen'",
    "Post foto ugly mu di status",
    "Kirim voice note nyanyi lagu kesukaan",
    "Chat mantan dan bilang 'Aku masih sayang'",
    "Ganti foto profil pake foto masa kecil selama 1 hari",
    "DM random orang dan bilang 'Kamu cantik/ganteng'",
    "Telepon crush dan bilang ada yang mau diomongn, lalu tutup",
    "Post status embarrassing tentang diri sendiri",
    "Kirim chat 'I love you' ke kontak no 7",
    "Screenshot chat sama crush lalu post",
    "Nyanyi lalu kirim voice note ke group",
    "Minta maaf ke orang yang pernah kamu sakiti",
    "Chat gebetan dan ajak jalan",
    "Ganti nama jadi 'Aku jelek' selama 5 jam",
    "Voice note teriak 'Aku ganteng/cantik' 5 kali",
    "Post foto random di galeri ke status",
    "DM orang yang kamu suka dan bilang 'Hai, aku suka sama kamu'",
    "Kirim chat 'Good morning/night sayang' ke crush",
    "Bilang ke group chat sesuatu yang embarrassing",
    "Follow 10 random orang di Instagram",
    "Chat orang yang belum pernah chat dan ngobrol 10 menit",
    "Post video joget tiktok di status",
    "Ganti bio jadi 'Aku suka {nama crush}' selama 1 hari",
    "Voice note bilang 'Aku sayang kalian semua' dengan nada lebay",
    "Screenshot DM terakhir dan post (sensor kalau perlu)"
  ];

  const randomDare = dares[Math.floor(Math.random() * dares.length)];

  await m.reply(
    `🎯 *Dare Game*\n\n` +
    `💀 ${randomDare}\n\n` +
    `_Berani terima challenge?_ 😈`
  );
};

handler.help = ["dare"];
handler.tags = ["fun"];
handler.command = /^(dare)$/i;
handler.limit = false;

export default handler;
