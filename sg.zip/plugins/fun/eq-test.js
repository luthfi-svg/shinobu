// plugins/fun/eq-test.js — EQ Test (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : EQ Test
 * 🔧 Fungsi     : Test kecerdasan emosional
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *EQ Test*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["eqtest", "teseq"];
handler.tags = ['fun'];
handler.command = /^(eqtest|teseq)$/i;

export default handler;
