// plugins/fun/did-you-know.js — Did You Know (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Did You Know
 * 🔧 Fungsi     : Tahukah kamu
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Did You Know*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["didyouknow", "tahukahkamu"];
handler.tags = ['fun'];
handler.command = /^(didyouknow|tahukahkamu)$/i;

export default handler;
