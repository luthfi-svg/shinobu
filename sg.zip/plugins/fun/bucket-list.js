// plugins/fun/bucket-list.js — Bucket List Idea (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Bucket List Idea
 * 🔧 Fungsi     : Ide bucket list
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Bucket List Idea*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["bucketlist", "idebucketlist"];
handler.tags = ['fun'];
handler.command = /^(bucketlist|idebucketlist)$/i;

export default handler;
