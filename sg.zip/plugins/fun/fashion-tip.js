// plugins/fun/fashion-tip.js — Fashion Tip (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Fashion Tip
 * 🔧 Fungsi     : Tips fashion
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Fashion Tip*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["fashiontip", "tipsfashion"];
handler.tags = ['fun'];
handler.command = /^(fashiontip|tipsfashion)$/i;

export default handler;
