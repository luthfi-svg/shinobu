// plugins/fun/yoga-tip.js — Yoga Tip (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Yoga Tip
 * 🔧 Fungsi     : Tips yoga harian
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  await m.reply(
    `✨ *Yoga Tip*\n\n` +
    `📝 Content generated\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["yogatip", "tipsyoga"];
handler.tags = ['fun'];
handler.command = /^(yogatip|tipsyoga)$/i;

export default handler;
