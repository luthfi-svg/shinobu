// plugins/fun/waifu.js — Random waifu anime picture (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Waifu
 * 🔧 Fungsi     : Random gambar waifu anime
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

let handler = async (m, { sock }) => {
  try {
    await m.reply("⏳ *Getting Waifu...*");

    const response = await axios.get("https://api.waifu.pics/sfw/waifu", {
      timeout: 15000
    });

    const imageUrl = response.data.url;

    await sock.sendMessage(
      m.chat,
      {
        image: { url: imageUrl },
        caption: `✨ *Random Waifu*\n\n_Powered by waifu.pics_`
      },
      { quoted: m }
    );

    await m.react("✅");

  } catch (e) {
    console.error(e);
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["waifu"];
handler.tags = ["fun"];
handler.command = /^(waifu)$/i;
handler.limit = true;

export default handler;
