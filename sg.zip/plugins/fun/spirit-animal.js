// plugins/fun/spirit-animal.js — Spirit Animal (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Spirit Animal
 * 🔧 Fungsi     : Hewan spiritmu
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Spirit Animal*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["spiritanimal", "hewanspirit"];
handler.tags = ['fun'];
handler.command = /^(spiritanimal|hewanspirit)$/i;

export default handler;
