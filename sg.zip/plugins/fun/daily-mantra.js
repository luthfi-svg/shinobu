// plugins/fun/daily-mantra.js — Daily Mantra (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Daily Mantra
 * 🔧 Fungsi     : Mantra harian
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Daily Mantra*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["mantra", "mantraharian"];
handler.tags = ['fun'];
handler.command = /^(mantra|mantraharian)$/i;

export default handler;
