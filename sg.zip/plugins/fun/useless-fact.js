// plugins/fun/useless-fact.js — Useless Fact (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Useless Fact
 * 🔧 Fungsi     : Fakta tidak berguna
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Useless Fact*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["uselessfact", "faktatakberguna"];
handler.tags = ['fun'];
handler.command = /^(uselessfact|faktatakberguna)$/i;

export default handler;
