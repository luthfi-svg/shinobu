// plugins/fun/career-advice.js — Career Advice (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Career Advice
 * 🔧 Fungsi     : Nasihat karir
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Career Advice*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["careeradvice", "nasihatkarir"];
handler.tags = ['fun'];
handler.command = /^(careeradvice|nasihatkarir)$/i;

export default handler;
