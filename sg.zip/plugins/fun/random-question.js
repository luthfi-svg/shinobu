// plugins/fun/random-question.js — Random Question (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Random Question
 * 🔧 Fungsi     : Pertanyaan random
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Random Question*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["randomq", "pertanyaanrandom"];
handler.tags = ['fun'];
handler.command = /^(randomq|pertanyaanrandom)$/i;

export default handler;
