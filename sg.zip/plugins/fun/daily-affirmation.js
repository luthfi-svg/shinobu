// plugins/fun/daily-affirmation.js — Daily Affirmation (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Daily Affirmation
 * 🔧 Fungsi     : Afirmasi harian
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Daily Affirmation*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["affirmation", "afirmasiharian"];
handler.tags = ['fun'];
handler.command = /^(affirmation|afirmasiharian)$/i;

export default handler;
