// plugins/fun/dice.js — Dice roll game (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Dice Roll
 * 🔧 Fungsi     : Roll dice game
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text }) => {
  const sides = text ? parseInt(text) : 6;
  
  if (sides < 2 || sides > 100) {
    return m.reply("❌ Gunakan 2-100 sisi untuk dice!");
  }

  const result = Math.floor(Math.random() * sides) + 1;

  const diceEmoji = {
    1: "⚀",
    2: "⚁",
    3: "⚂",
    4: "⚃",
    5: "⚄",
    6: "⚅"
  };

  await m.reply(
    `🎲 *DICE ROLL*\n\n` +
    `${diceEmoji[result] || "🎲"}\n\n` +
    `Hasil: *${result}*\n` +
    `Dari: D${sides}`
  );
};

handler.help = ["dice [sides]"];
handler.tags = ["fun"];
handler.command = /^(dice|roll)$/i;
handler.limit = false;

export default handler;
