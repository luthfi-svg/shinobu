// plugins/fun/night-routine.js — Night Routine (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Night Routine
 * 🔧 Fungsi     : Rutinitas malam
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  await m.reply(
    `✨ *Night Routine*\n\n` +
    `📝 Content generated\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["nightroutine", "rutinitasmalam"];
handler.tags = ['fun'];
handler.command = /^(nightroutine|rutinitasmalam)$/i;

export default handler;
