// plugins/fun/icebreaker.js — Ice Breaker (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Ice Breaker
 * 🔧 Fungsi     : Pemecah suasana
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Ice Breaker*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["icebreaker", "pemecahsuasana"];
handler.tags = ['fun'];
handler.command = /^(icebreaker|pemecahsuasana)$/i;

export default handler;
