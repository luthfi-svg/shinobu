// plugins/fun/kapan.js — Random future prediction game (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Kapan
 * 🔧 Fungsi     : Prediksi random kapan sesuatu terjadi
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `Contoh penggunaan:\n${usedPrefix + command} <pertanyaan>\n\n` +
      `Contoh:\n` +
      `${usedPrefix + command} aku nikah?\n` +
      `${usedPrefix + command} aku kaya?`
    );
  }

  const times = [
    "Besok",
    "Lusa",
    "1 minggu lagi",
    "1 bulan lagi",
    "1 tahun lagi",
    "5 tahun lagi",
    "10 tahun lagi",
    "Hari ini juga!",
    "Sebentar lagi",
    "Tidak akan pernah",
    "Saat kamu sudah dewasa",
    "Saat bulan berwarna biru",
    "Saat ayam berkokok tengah malam",
    "Ketika hujan salju di Indonesia",
    "Setelah kamu tobat",
    "Minggu depan",
    "Bulan depan",
    "Tahun depan",
    "Sebentar lagi kok",
    "Sudah dekat!",
    "Masih lama",
    "Entahlah kapan",
    "Tergantung usaha kamu"
  ];

  const randomTime = times[Math.floor(Math.random() * times.length)];

  await m.reply(
    `⏰ *Pertanyaan:*\n${text}\n\n` +
    `🔮 *Prediksi:* ${randomTime}\n\n` +
    `_Ini hanya prediksi random ya!_ 😄`
  );
};

handler.help = ["kapan <pertanyaan>"];
handler.tags = ["fun"];
handler.command = /^(kapan|kapankah)$/i;
handler.limit = false;

export default handler;
