// plugins/fun/debate-topic.js — Debate Topic (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Debate Topic
 * 🔧 Fungsi     : Topik debat
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Debate Topic*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["debatetopic", "topikdebat"];
handler.tags = ['fun'];
handler.command = /^(debatetopic|topikdebat)$/i;

export default handler;
