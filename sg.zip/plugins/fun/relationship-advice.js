// plugins/fun/relationship-advice.js — Relationship Advice (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Relationship Advice
 * 🔧 Fungsi     : Nasihat hubungan
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Relationship Advice*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["relationshipadvice", "nasihathubungan"];
handler.tags = ['fun'];
handler.command = /^(relationshipadvice|nasihathubungan)$/i;

export default handler;
