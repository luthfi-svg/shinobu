// plugins/fun/love-percentage.js — Love Percentage (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Love Percentage
 * 🔧 Fungsi     : Persentase cinta
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Love Percentage*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["lovepercentage", "persentasecinta"];
handler.tags = ['fun'];
handler.command = /^(lovepercentage|persentasecinta)$/i;

export default handler;
