// plugins/fun/nickname-generator.js — Nickname Generator (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Nickname Generator
 * 🔧 Fungsi     : Generate nickname
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Nickname Generator*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["nickgen", "buatnickname"];
handler.tags = ['fun'];
handler.command = /^(nickgen|buatnickname)$/i;

export default handler;
