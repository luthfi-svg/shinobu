// plugins/fun-tembak.js — dari Ourin MD 3
// Sistem tembak + terima + tolak + putus

if (!global.tembakSessions) global.tembakSessions = {};
if (!global.pasangan) global.pasangan = {};

const romanticQuotes = [
  "Aku bukan pilot, tapi aku bisa buat hatimu terbang tinggi 💕",
  "Kamu adalah alasan kenapa aku senyum tanpa sebab 😊",
  "Kalau kamu bintang, aku mau jadi langit yang nemenin kamu ✨",
  "Aku gak butuh GPS, hatiku udah nunjuk ke arahmu 💘",
  "Boleh pinjam hatimu? Janji bakal dijaga selamanya 💖",
];

let handler = async (m, { sock, command }) => {
  const db = global.db?.users || {};

  // ── .putus ──────────────────────────
  if (command === "putus") {
    const user = db[m.sender] || {};
    if (!user.fun?.pasangan) return m.reply("❌ Kamu belum punya pasangan!");
    const ex = user.fun.pasangan;
    user.fun.pasangan = null;
    if (db[ex]?.fun) db[ex].fun.pasangan = null;
    await m.react("💔");
    return sock.sendMessage(m.chat, {
      text: `💔 @${m.sender.split("@")[0]} dan @${ex.split("@")[0]} resmi *PUTUS*\n\nSabar ya, masih banyak yang lain 😢`,
      mentions: [m.sender, ex],
    }, { quoted: m });
  }

  // ── .pacar ──────────────────────────
  if (command === "pacar") {
    const user = db[m.sender] || {};
    if (!user.fun?.pasangan) return m.reply("😔 Kamu belum punya pasangan!\n\nCari dulu pakai *.tembak @tag*");
    return sock.sendMessage(m.chat, {
      text: `💑 Pasangan kamu: @${user.fun.pasangan.split("@")[0]}`,
      mentions: [user.fun.pasangan],
    }, { quoted: m });
  }

  // ── .tembak ─────────────────────────
  const target =
    m.mentionedJid?.[0] ||
    (m.quoted?.sender);

  if (!target) return m.reply(`💘 *ᴛᴇᴍʙᴀᴋ*\n\n> Tembak seseorang buat ngajak pacaran!\n\n*Contoh:*\n> ${m.cmd} @tag\n> Reply pesan + ${m.cmd}`);
  if (target === m.sender) return m.reply("❌ Nggak bisa nembak diri sendiri!");
  if (target === (sock.user?.id?.split(":")[0] + "@s.whatsapp.net")) return m.reply("🤖 Bot nggak bisa pacaran!");

  if (!db[m.sender]) db[m.sender] = {};
  if (!db[m.sender].fun) db[m.sender].fun = {};
  if (!db[target]) db[target] = {};
  if (!db[target].fun) db[target].fun = {};

  if (db[m.sender].fun.pasangan) {
    return sock.sendMessage(m.chat, {
      text: `❌ Kamu sudah punya pasangan: @${db[m.sender].fun.pasangan.split("@")[0]}\nPutus dulu pakai *.putus*`,
      mentions: [db[m.sender].fun.pasangan],
    }, { quoted: m });
  }

  if (db[target].fun.pasangan && db[target].fun.pasangan !== m.sender) {
    return sock.sendMessage(m.chat, {
      text: `💔 @${target.split("@")[0]} sudah punya pasangan!`,
      mentions: [target],
    }, { quoted: m });
  }

  // Jika target sudah nembak sender sebelumnya → langsung jadian
  if (db[target].fun.tembakTarget === m.sender) {
    db[m.sender].fun.pasangan = target;
    db[target].fun.pasangan = m.sender;
    db[target].fun.tembakTarget = null;
    await m.react("💕");
    return sock.sendMessage(m.chat, {
      text: `💕 *CIE CIEE :3*\n@${m.sender.split("@")[0]} dan @${target.split("@")[0]} resmi *PACARAN!* 💍\n\nSemoga langgeng yak!`,
      mentions: [m.sender, target],
    }, { quoted: m });
  }

  db[m.sender].fun.tembakTarget = target;

  const quote = romanticQuotes[Math.floor(Math.random() * romanticQuotes.length)];
  global.tembakSessions[`${m.chat}_${target}`] = {
    shooter: m.sender,
    target,
    chat: m.chat,
    timestamp: Date.now(),
  };

  await m.react("💘");
  await sock.sendMessage(m.chat, {
    text: `💘 *ADA YANG NEMBAK NIHH!*\n\nHei @${target.split("@")[0]}, kamu ditembak oleh @${m.sender.split("@")[0]}!\n\n_"${quote}"_\n\n⏱️ Berlaku *1 jam*\nGunakan: *.terima* / *.tolak*`,
    mentions: [target, m.sender],
  }, { quoted: m });
};

handler.command = ["tembak", "nembak", "propose", "putus", "pacar"];
handler.tags = ["fun"];
handler.help = ["tembak @tag", "putus", "pacar"];
export default handler;
// ── Separate handler for terima/tolak ─
let terimaHandler = async (m, { sock, command }) => {
  const db = global.db?.users || {};
  const sessions = Object.entries(global.tembakSessions || {})
    .filter(([k, v]) => v.target === m.sender && v.chat === m.chat);

  const valid = sessions.find(([k, v]) => Date.now() - v.timestamp < 3600000);

  if (!valid) return m.reply("❌ Tidak ada yang nembak kamu nih!");
  const [sessKey, sessData] = valid;

  if (!db[m.sender]) db[m.sender] = {};
  if (!db[m.sender].fun) db[m.sender].fun = {};
  if (!db[sessData.shooter]) db[sessData.shooter] = {};
  if (!db[sessData.shooter].fun) db[sessData.shooter].fun = {};

  delete global.tembakSessions[sessKey];

  if (command === "terima") {
    db[m.sender].fun.pasangan = sessData.shooter;
    db[sessData.shooter].fun.pasangan = m.sender;
    await m.react("💕");
    return sock.sendMessage(m.chat, {
      text: `💕 *WIDIHHHH CIE CIE DITERIMA!*\n\n@${m.sender.split("@")[0]} dan @${sessData.shooter.split("@")[0]} resmi *PACARAN!* 💍\n\nSemoga langgeng dan bahagia ya! 🎉`,
      mentions: [m.sender, sessData.shooter],
    }, { quoted: m });
  } else {
    delete db[sessData.shooter].fun.tembakTarget;
    await m.react("💔");
    return sock.sendMessage(m.chat, {
      text: `💔 *WADUHH, YANG SABAR YAK* @${sessData.shooter.split("@")[0]}\n\n@${m.sender.split("@")[0]} menolak tembakan kamu\n\nSabar ya, masih banyak yang lain! 😢`,
      mentions: [m.sender, sessData.shooter],
    }, { quoted: m });
  }
};

terimaHandler.command = ["terima", "tolak"];
terimaHandler.tags = ["fun"];
terimaHandler.help = ["terima", "tolak"];
