// plugins/fun/challenge-me.js — Challenge Me (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Challenge Me
 * 🔧 Fungsi     : Tantang saya
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Challenge Me*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["challengeme", "tantangsaya"];
handler.tags = ['fun'];
handler.command = /^(challengeme|tantangsaya)$/i;

export default handler;
