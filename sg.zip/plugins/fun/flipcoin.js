// plugins/fun/flipcoin.js — Flip coin game (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Flip Coin
 * 🔧 Fungsi     : Flip a coin (heads or tails)
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m) => {
  const result = Math.random() < 0.5 ? "Kepala" : "Ekor";
  const emoji = result === "Kepala" ? "🪙" : "🔘";

  await m.reply(
    `🪙 *FLIP COIN*\n\n` +
    `${emoji}\n\n` +
    `Hasil: *${result}*`
  );
};

handler.help = ["flipcoin"];
handler.tags = ["fun"];
handler.command = /^(flipcoin|koin|coinflip)$/i;
handler.limit = false;

export default handler;
