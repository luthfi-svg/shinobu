// plugins/fun/baby-generator.js — Baby Generator (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Baby Generator
 * 🔧 Fungsi     : Prediksi bayi
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Baby Generator*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["babygen", "prediksibayi"];
handler.tags = ['fun'];
handler.command = /^(babygen|prediksibayi)$/i;

export default handler;
