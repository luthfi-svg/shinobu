// plugins/fun/this-or-that.js — This or That (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : This or That
 * 🔧 Fungsi     : Pilih antara 2 hal
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *This or That*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["thisorthat", "pilihan"];
handler.tags = ['fun'];
handler.command = /^(thisorthat|pilihan)$/i;

export default handler;
