// plugins/fun/life-goal.js — Life Goal (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Life Goal
 * 🔧 Fungsi     : Tujuan hidup
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Life Goal*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["lifegoal", "tujuanhidup"];
handler.tags = ['fun'];
handler.command = /^(lifegoal|tujuanhidup)$/i;

export default handler;
