// plugins/fun/dream-job.js — Dream Job (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Dream Job
 * 🔧 Fungsi     : Pekerjaan impian
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Dream Job*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["dreamjob", "pekerjaanimpian"];
handler.tags = ['fun'];
handler.command = /^(dreamjob|pekerjaanimpian)$/i;

export default handler;
