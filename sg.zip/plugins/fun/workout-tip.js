// plugins/fun/workout-tip.js — Workout Tip (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Workout Tip
 * 🔧 Fungsi     : Tips workout
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  await m.reply(
    `✨ *Workout Tip*\n\n` +
    `📝 Content generated\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["workouttip", "tipsworkout"];
handler.tags = ['fun'];
handler.command = /^(workouttip|tipsworkout)$/i;

export default handler;
