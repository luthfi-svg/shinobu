// plugins/fun/fun-fact.js — Fun Fact (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Fun Fact
 * 🔧 Fungsi     : Fakta menarik
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Fun Fact*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["funfact", "faktamenarik"];
handler.tags = ['fun'];
handler.command = /^(funfact|faktamenarik)$/i;

export default handler;
