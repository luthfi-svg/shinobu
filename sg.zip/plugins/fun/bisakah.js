// plugins/fun/bisakah.js — Random "can I" question game (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Bisakah
 * 🔧 Fungsi     : Jawab pertanyaan "bisakah" dengan random
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `Contoh penggunaan:\n${usedPrefix + command} <pertanyaan>\n\n` +
      `Contoh:\n` +
      `${usedPrefix + command} aku jadi orang kaya?\n` +
      `${usedPrefix + command} aku lulus ujian?`
    );
  }

  const answers = [
    "Bisa",
    "Tidak bisa",
    "Mungkin bisa",
    "Sepertinya bisa",
    "Sepertinya tidak bisa",
    "Pasti bisa!",
    "Mustahil!",
    "Bisa kalau kamu usaha",
    "Bisa kalau kamu beruntung",
    "Tidak bisa kalau kamu malas",
    "Sangat bisa!",
    "Jangan bermimpi!",
    "Tergantung usaha kamu",
    "Kalau Tuhan mengizinkan",
    "50% bisa, 50% tidak",
    "Bisa dong!",
    "Kayaknya sih bisa",
    "Rasanya tidak mungkin",
    "Coba aja dulu!",
    "Why not?"
  ];

  const randomAnswer = answers[Math.floor(Math.random() * answers.length)];
  const probability = Math.floor(Math.random() * 100) + 1;

  await m.reply(
    `❓ *Pertanyaan:*\n${text}\n\n` +
    `💡 *Jawaban:* ${randomAnswer}\n` +
    `🎲 *Probability:* ${probability}%`
  );
};

handler.help = ["bisakah <pertanyaan>"];
handler.tags = ["fun"];
handler.command = /^(bisakah|bisagak|bisakan)$/i;
handler.limit = false;

export default handler;
