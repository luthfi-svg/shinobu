// plugins/fun/slot.js — Slot machine game (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Slot Machine
 * 🔧 Fungsi     : Game slot machine dengan emoji
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m) => {
  const emojis = ["🍇", "🍊", "🍋", "🍎", "🍉", "⭐", "💎"];
  
  const slot1 = emojis[Math.floor(Math.random() * emojis.length)];
  const slot2 = emojis[Math.floor(Math.random() * emojis.length)];
  const slot3 = emojis[Math.floor(Math.random() * emojis.length)];

  let result;
  let win = false;

  if (slot1 === slot2 && slot2 === slot3) {
    if (slot1 === "💎") {
      result = "JACKPOT! 💎💎💎";
      win = true;
    } else {
      result = "MENANG! 🎉";
      win = true;
    }
  } else if (slot1 === slot2 || slot2 === slot3 || slot1 === slot3) {
    result = "Hampir! 😊";
  } else {
    result = "Kalah! 😭";
  }

  await m.reply(
    `🎰 *SLOT MACHINE*\n\n` +
    `┏━━━━━━━┓\n` +
    `┃ ${slot1} ┃ ${slot2} ┃ ${slot3} ┃\n` +
    `┗━━━━━━━┛\n\n` +
    `${result}\n\n` +
    `${win ? "🎊 Selamat!" : "Coba lagi!"}`
  );
};

handler.help = ["slot"];
handler.tags = ["fun"];
handler.command = /^(slot|slots)$/i;
handler.limit = false;

export default handler;
