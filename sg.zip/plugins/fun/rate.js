// plugins/fun/rate.js — Rate anything 1-100 (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Rate
 * 🔧 Fungsi     : Kasih rating 1-100 untuk apapun
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `Contoh penggunaan:\n${usedPrefix + command} <sesuatu>\n\n` +
      `Contoh:\n` +
      `${usedPrefix + command} ketampanan aku\n` +
      `${usedPrefix + command} kepintaran aku\n` +
      `${usedPrefix + command} kesombongan dia`
    );
  }

  const rating = Math.floor(Math.random() * 100) + 1;

  let emoji;
  let status;
  
  if (rating >= 90) {
    emoji = "🌟";
    status = "Perfect!";
  } else if (rating >= 75) {
    emoji = "⭐";
    status = "Excellent!";
  } else if (rating >= 60) {
    emoji = "✨";
    status = "Good!";
  } else if (rating >= 40) {
    emoji = "👍";
    status = "Not bad";
  } else if (rating >= 25) {
    emoji = "😐";
    status = "Below average";
  } else {
    emoji = "💔";
    status = "Very low";
  }

  await m.reply(
    `📊 *Rating*\n\n` +
    `📝 ${text}\n\n` +
    `${emoji} *Score:* ${rating}/100\n` +
    `📈 *Status:* ${status}`
  );
};

handler.help = ["rate <text>"];
handler.tags = ["fun"];
handler.command = /^(rate|nilai)$/i;
handler.limit = false;

export default handler;
