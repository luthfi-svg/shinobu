// plugins/fun-cekpacar.js — Cek Status Hubungan dari Ourin MD 3.1

let handler = async (m, { sock, args }) => {
  let targetJid = m.sender;
  let isOther = false;

  if (m.quoted) {
    targetJid = m.quoted.sender;
    isOther = true;
  } else if (m.mentionedJid?.[0]) {
    targetJid = m.mentionedJid[0];
    isOther = true;
  } else if (args?.[0]) {
    let num = args[0].replace(/[^0-9]/g, "");
    if (num.length > 5 && num.length < 20) {
      targetJid = num + "@s.whatsapp.net";
      isOther = true;
    }
  }

  const userData = global.db.users?.[targetJid] || {};
  const nama = isOther ? `@${targetJid.split("@")[0]}` : "Kamu";

  if (!userData.fun?.pasangan) {
    await m.react("💔");
    return sock.sendMessage(m.chat, {
      text:
        `💔 *sᴛᴀᴛᴜs ʜᴜʙᴜɴɢᴀɴ*\n\n` +
        `*${nama}* tidak punya pasangan.\n` +
        `TIP: Cari pasangan dulu dengan \`${global.prefix}tembak @tag\``,
      mentions: isOther ? [targetJid] : [],
    }, { quoted: m });
  }

  const partnerJid = userData.fun.pasangan;
  const partnerData = global.db.users?.[partnerJid] || {};
  const isMutual = partnerData.fun?.pasangan === targetJid;

  if (isMutual) {
    await m.react("💕");
    return sock.sendMessage(m.chat, {
      text: `💕 *sᴛᴀᴛᴜs ʜᴜʙᴜɴɢᴀɴ*\n\n*${nama}* sedang pacaran dengan @${partnerJid.split("@")[0]}! 🥳`,
      mentions: [targetJid, partnerJid],
    }, { quoted: m });
  }

  await m.react("💭");
  return sock.sendMessage(m.chat, {
    text: `💭 *sᴛᴀᴛᴜs ʜᴜʙᴜɴɢᴀɴ*\n\n*${nama}* lagi PDKT/menunggu jawaban dari @${partnerJid.split("@")[0]}.\nMasih digantung nih! 😅`,
    mentions: [targetJid, partnerJid],
  }, { quoted: m });
};

handler.command = ["cekpacar", "pacar2", "pasangan", "gebetan"];
handler.tags = ["fun"];
handler.help = ["cekpacar", "cekpacar @tag"];
handler.group = true;
export default handler;