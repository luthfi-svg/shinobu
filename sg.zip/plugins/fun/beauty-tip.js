// plugins/fun/beauty-tip.js — Beauty Tip (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Beauty Tip
 * 🔧 Fungsi     : Tips kecantikan
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Beauty Tip*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["beautytip", "tipskecantikan"];
handler.tags = ['fun'];
handler.command = /^(beautytip|tipskecantikan)$/i;

export default handler;
