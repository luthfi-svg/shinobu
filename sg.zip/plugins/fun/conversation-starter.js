// plugins/fun/conversation-starter.js — Conversation Starter (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Conversation Starter
 * 🔧 Fungsi     : Pemula percakapan
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Conversation Starter*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["convostarter", "mulaipercakapan"];
handler.tags = ['fun'];
handler.command = /^(convostarter|mulaipercakapan)$/i;

export default handler;
