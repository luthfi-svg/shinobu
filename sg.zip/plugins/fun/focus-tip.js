// plugins/fun/focus-tip.js — Focus Tip (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Focus Tip
 * 🔧 Fungsi     : Tips fokus
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  await m.reply(
    `✨ *Focus Tip*\n\n` +
    `📝 Content generated\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["focustip", "tipsfokus"];
handler.tags = ['fun'];
handler.command = /^(focustip|tipsfokus)$/i;

export default handler;
