// plugins/fun/spirit-emoji.js — Spirit Emoji (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Spirit Emoji
 * 🔧 Fungsi     : Emoji spiritmu
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Spirit Emoji*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["spritemoji", "emojispirit"];
handler.tags = ['fun'];
handler.command = /^(spritemoji|emojispirit)$/i;

export default handler;
