// plugins/fun/sleep-tip.js — Sleep Tip (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Sleep Tip
 * 🔧 Fungsi     : Tips tidur
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  await m.reply(
    `✨ *Sleep Tip*\n\n` +
    `📝 Content generated\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["sleeptip", "tipstidur"];
handler.tags = ['fun'];
handler.command = /^(sleeptip|tipstidur)$/i;

export default handler;
