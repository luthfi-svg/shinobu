// plugins/fun-cek.js — CEK SERIES dari Ourin MD 3

const cekData = {
  cekganteng:    { label: "Kegantengan",   emojis: ["😍🔥","😎","👍","😅","🤭"],  texts: ["Ganteng maksimal! Idol visual!","Ganteng banget!","Lumayan ganteng~","Biasa aja sih","Mungkin inner beauty?"] },
  cekcantik:     { label: "Kecantikan",    emojis: ["👸✨","💕","🌸","😊","💖"],   texts: ["Cantik kayak bidadari!","Cantik banget!","Manis dan cantik~","Lumayan cantik","Tetep cantik kok!"] },
  cekhoki:       { label: "Kehokian",      emojis: ["🍀✨","🎰","🍀","😊","😅"],   texts: ["HOKI DEWA! Main gacha pasti menang!","Hoki banget!","Lumayan hoki","Sedikit hoki","Sabar ya, lagi apes"] },
  cekjahat:      { label: "Kejahatanmu",   emojis: ["😈💀","😈","😏","😐","😇"],   texts: ["VILLAIN SEJATI! Hati-hati!","Lumayan jahat nih","Agak nakal","Biasa aja","Malaikat kamu!"] },
  cekmalas:      { label: "Kemalasan",     emojis: ["😴💀","😴","🛌","😪","⚡"],   texts: ["MALAS LEVEL DEWA!","Malas banget","Cukup malas","Lumayan rajin","Rajin banget!"] },
  cekwibu:       { label: "Kewibuanmu",    emojis: ["🎌💀","🎌","🎌","😐","😎"],   texts: ["WIBU SEJATI!!! Sugoi!!!","Lumayan wibu","Agak wibu","Sedikit wibu","Bukan wibu murni"] },
  cekgabut:      { label: "Kegabutanmu",   emojis: ["😵‍💫","😵","😑","😐","⚡"],    texts: ["GABUT LEVEL 99!","Sangat gabut","Lumayan gabut","Sedikit gabut","Produktif banget!"] },
  cekjomblo:     { label: "Jomblo-meter",  emojis: ["💔😭","💔","😅","🥰","💕"],   texts: ["JOMBLO ABADI!","Masih jomblo sih","Lumayan jomblo","Hampir punya pacar","Kayaknya udah punya!"] },
  cekkaya:       { label: "Kekayaan",      emojis: ["💰💎","💰","💵","🪙","😬"],   texts: ["SULTAN! Crazy rich!","Kaya banget!","Lumayan tajir","Cukup-cukupan","Sabar, rezeki ada aja"] },
  cekimut:       { label: "Keimutan",      emojis: ["🐱💕","🥰","😊","😐","😬"],   texts: ["IMUT PARAH! Kawaii!!!","Imut banget!","Lumayan imut~","Biasa aja","Hmm… cute inside?"] },
  cekgamer:      { label: "Gamer-meter",   emojis: ["🎮🔥","🎮","🕹️","🤔","😴"],  texts: ["GAMER SEJATI! Pro player!","Gamer handal","Casual gamer","Newbie","Bukan gamer kayaknya"] },
  cekotaku:      { label: "Otaku-meter",   emojis: ["🎌🔥","🎌","🎌","😐","🤷"],   texts: ["OTAKU HARDCORE! Sugoi!!!","Otaku sejati","Lumayan otaku","Sedikit otaku","Bukan otaku"] },
  ceksetia:      { label: "Kesetiaan",     emojis: ["💍✨","💕","😊","🤔","💔"],   texts: ["SETIA BANGET! Dream partner!","Sangat setia","Cukup setia","Lumayan setia","Perlu belajar setia"] },
  cekpsikopat:   { label: "Psikopat-meter",emojis: ["😈💀","😈","😏","😐","😇"],   texts: ["PSIKOPAT LEVEL MAX!","Lumayan mencurigakan","Agak aneh","Normal aja","Orang paling baik!"] },
  ceksabar:      { label: "Kesabaran",     emojis: ["😇✨","😊","🙂","😤","💢"],   texts: ["SABAR BANGET! Bidadari!","Sabar banget","Lumayan sabar","Agak sensitif","Gampang tersulut!"] },
};

let handler = async (m, { command }) => {
  const data = cekData[command];
  if (!data) return;

  const target = m.mentionedJid?.[0] || m.sender;
  const percent = Math.floor(Math.random() * 101);
  const idx = percent >= 90 ? 0 : percent >= 70 ? 1 : percent >= 50 ? 2 : percent >= 30 ? 3 : 4;
  const emoji = data.emojis[idx];
  const text = data.texts[idx];
  const bar = "█".repeat(Math.floor(percent / 10)) + "░".repeat(10 - Math.floor(percent / 10));

  const isSelf = target === m.sender;
  return m.reply(
    `${emoji} *ᴄᴇᴋ ${data.label.toUpperCase()}*\n\n` +
    `╭┈┈⬡「 👤 *${isSelf ? "Kamu" : "@" + target.split("@")[0]}* 」\n` +
    `┃ ${bar} *${percent}%*\n` +
    `┃ ${emoji} ${text}\n` +
    `╰┈┈⬡`,
    { mentions: [target] }
  );
};

handler.command = Object.keys(cekData);
handler.tags = ["fun"];
handler.help = Object.keys(cekData).map(k => `${k} [@tag]`);
export default handler;