// plugins/fun/compatibility.js — Compatibility Test (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Compatibility Test
 * 🔧 Fungsi     : Test kecocokan
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const responses = [
    "Response 1",
    "Response 2",
    "Response 3",
    "Response 4",
    "Response 5"
  ];
  
  const result = responses[Math.floor(Math.random() * responses.length)];
  
  await m.reply(
    `✨ *Compatibility Test*\n\n` +
    `📝 ${result}\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["compatibility", "kecocokantest"];
handler.tags = ['fun'];
handler.command = /^(compatibility|kecocokantest)$/i;

export default handler;
