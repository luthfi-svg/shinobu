// plugins/fun/hobby-finder.js — Hobby Finder (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Hobby Finder
 * 🔧 Fungsi     : Cari hobi baru
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  await m.reply(
    `✨ *Hobby Finder*\n\n` +
    `📝 Content generated\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["hobbyfinder", "carihobi"];
handler.tags = ['fun'];
handler.command = /^(hobbyfinder|carihobi)$/i;

export default handler;
