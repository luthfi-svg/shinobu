// plugins/fun/mindfulness.js — Mindfulness Exercise (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Mindfulness Exercise
 * 🔧 Fungsi     : Latihan mindfulness
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  await m.reply(
    `✨ *Mindfulness Exercise*\n\n` +
    `📝 Content generated\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["mindfulness", "latihanmindfulness"];
handler.tags = ['fun'];
handler.command = /^(mindfulness|latihanmindfulness)$/i;

export default handler;
