// plugins/fun/mining.js — Mining game sederhana (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Mining
 * 🔧 Fungsi     : Game mining untuk dapat reward
 * ⚡ By Shinobu
 * ─────────────────────────
 */

// Global mining cooldown
global.miningCooldown = global.miningCooldown || {};

let handler = async (m) => {
  const user = m.sender;
  const now = Date.now();
  const cooldown = 3600000; // 1 hour

  if (global.miningCooldown[user] && (now - global.miningCooldown[user]) < cooldown) {
    const timeLeft = cooldown - (now - global.miningCooldown[user]);
    const minutes = Math.floor(timeLeft / 60000);
    
    return m.reply(
      `⏰ *Mining Cooldown*\n\n` +
      `Kamu baru saja mining!\n` +
      `Tunggu ${minutes} menit lagi`
    );
  }

  // Random rewards
  const rewards = [
    { name: "💎 Diamond", amount: Math.floor(Math.random() * 5) + 1 },
    { name: "⛏️ Iron", amount: Math.floor(Math.random() * 10) + 5 },
    { name: "🪨 Stone", amount: Math.floor(Math.random() * 20) + 10 },
    { name: "⚱️ Coal", amount: Math.floor(Math.random() * 15) + 5 }
  ];

  const reward = rewards[Math.floor(Math.random() * rewards.length)];
  
  global.miningCooldown[user] = now;

  await m.reply(
    `⛏️ *Mining Result*\n\n` +
    `Kamu mendapatkan:\n` +
    `${reward.name} x${reward.amount}\n\n` +
    `⏰ Cooldown: 1 jam`
  );
};

handler.help = ["mining"];
handler.tags = ["fun"];
handler.command = /^(mining|mine|nambang)$/i;
handler.limit = false;

export default handler;
