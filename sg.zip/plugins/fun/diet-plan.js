// plugins/fun/diet-plan.js — Diet Plan (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Diet Plan
 * 🔧 Fungsi     : Rencana diet
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  await m.reply(
    `✨ *Diet Plan*\n\n` +
    `📝 Content generated\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["dietplan", "rencanadiet"];
handler.tags = ['fun'];
handler.command = /^(dietplan|rencanadiet)$/i;

export default handler;
