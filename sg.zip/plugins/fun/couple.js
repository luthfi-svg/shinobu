// plugins/fun/couple.js — Random couple/jodoh (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Couple
 * 🔧 Fungsi     : Random pasangan dari member group
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock }) => {
  if (!m.isGroup) {
    return m.reply("❌ Command ini hanya bisa digunakan di group!");
  }

  try {
    const participants = m.metadata?.participants || [];
    
    if (participants.length < 2) {
      return m.reply("❌ Member group kurang dari 2 orang!");
    }

    // Random 2 members
    const shuffled = participants.sort(() => Math.random() - 0.5);
    const person1 = shuffled[0].id;
    const person2 = shuffled[1].id;

    const compatibility = Math.floor(Math.random() * 100) + 1;

    let status;
    if (compatibility >= 80) {
      status = "Jodoh banget! 💕";
    } else if (compatibility >= 60) {
      status = "Cocok! 💑";
    } else if (compatibility >= 40) {
      status = "Lumayan! 👫";
    } else {
      status = "Kurang cocok! 💔";
    }

    await sock.sendMessage(
      m.chat,
      {
        text: 
          `💑 *Couple Today*\n\n` +
          `👤 @${person1.split("@")[0]}\n` +
          `❤️\n` +
          `👤 @${person2.split("@")[0]}\n\n` +
          `💯 Compatibility: ${compatibility}%\n` +
          `📊 Status: ${status}\n\n` +
          `_Random couple of the day!_`,
        mentions: [person1, person2]
      },
      { quoted: m }
    );

  } catch (e) {
    console.error(e);
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["couple"];
handler.tags = ["fun"];
handler.command = /^(couple|jodoh|ship)$/i;
handler.group = true;
handler.limit = false;

export default handler;
