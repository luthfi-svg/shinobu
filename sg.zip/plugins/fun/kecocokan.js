// plugins/fun/kecocokan.js — Cek kecocokan 2 nama (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Kecocokan
 * 🔧 Fungsi     : Cek tingkat kecocokan antara 2 nama
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `Contoh penggunaan:\n${usedPrefix + command} <nama1> & <nama2>\n\n` +
      `Contoh:\n` +
      `${usedPrefix + command} Budi & Ani\n` +
      `${usedPrefix + command} John & Jane`
    );
  }

  const names = text.split("&").map(n => n.trim());
  
  if (names.length !== 2) {
    return m.reply("❌ Format salah! Gunakan: nama1 & nama2");
  }

  const [name1, name2] = names;
  const percentage = Math.floor(Math.random() * 100) + 1;

  let status;
  if (percentage >= 80) {
    status = "Jodoh banget! 💕💕💕";
  } else if (percentage >= 60) {
    status = "Cocok! 💑";
  } else if (percentage >= 40) {
    status = "Lumayan 👫";
  } else {
    status = "Kurang cocok 💔";
  }

  await m.reply(
    `💕 *Cek Kecocokan*\n\n` +
    `👤 ${name1}\n` +
    `❤️\n` +
    `👤 ${name2}\n\n` +
    `💯 Kecocokan: ${percentage}%\n` +
    `📊 Status: ${status}\n\n` +
    `_Random compatibility check_`
  );
};

handler.help = ["kecocokan <nama1> & <nama2>"];
handler.tags = ["fun"];
handler.command = /^(kecocokan|cocok|compatibility)$/i;
handler.limit = false;

export default handler;
