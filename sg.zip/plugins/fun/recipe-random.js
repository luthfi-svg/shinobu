// plugins/fun/recipe-random.js — Random Recipe (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Random Recipe
 * 🔧 Fungsi     : Resep random
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  await m.reply(
    `✨ *Random Recipe*\n\n` +
    `📝 Content generated\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
};

handler.help = ["randomrecipe", "reseprandom"];
handler.tags = ['fun'];
handler.command = /^(randomrecipe|reseprandom)$/i;

export default handler;
