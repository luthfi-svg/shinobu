// plugins/fun/siapa.js — Siapa yang... random game (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Siapa Yang
 * 🔧 Fungsi     : Random pilih member untuk pertanyaan "siapa yang..."
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, text }) => {
  if (!m.isGroup) {
    return m.reply("❌ Command ini hanya bisa digunakan di group!");
  }

  if (!text) {
    return m.reply(
      `Contoh penggunaan:\n.siapa <pertanyaan>\n\n` +
      `Contoh:\n` +
      `.siapa yang paling ganteng?\n` +
      `.siapa yang paling pinter?\n` +
      `.siapa yang bakal jadi presiden?`
    );
  }

  try {
    const participants = m.metadata?.participants || [];
    
    if (participants.length === 0) {
      return m.reply("❌ Tidak ada member di group!");
    }

    // Random member
    const random = participants[Math.floor(Math.random() * participants.length)];
    const jid = random.id || random.jid;

    await sock.sendMessage(
      m.chat,
      {
        text: 
          `🎲 *Siapa Yang ${text}*\n\n` +
          `Jawabannya adalah...\n` +
          `👉 @${jid.split("@")[0]} 🎯\n\n` +
          `_Random selection from group members_`,
        mentions: [jid]
      },
      { quoted: m }
    );

  } catch (e) {
    console.error(e);
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["siapa <text>"];
handler.tags = ["fun"];
handler.command = /^(siapa|siapakah)$/i;
handler.group = true;
handler.limit = false;

export default handler;
