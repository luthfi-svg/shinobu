// plugins/religi-shota.js — Islamic dari Shota Bot MD
import axios from "axios";

const DOA_HARIAN = [
  { nama: "Doa Bangun Tidur", arab: "اَلْحَمْدُ لِلّٰهِ الَّذِيْ أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُوْرُ", latin: "Alhamdulillahil ladzi ahyaanaa ba'da maa amaatanaa wa ilaihin nusyuur", arti: "Segala puji bagi Allah yang telah menghidupkan kami sesudah mematikan kami, dan hanya kepada-Nya kami kembali." },
  { nama: "Doa Sebelum Makan", arab: "اَللّٰهُمَّ بَارِكْ لَنَا فِيْمَا رَزَقْتَنَا وَقِنَا عَذَابَ النَّارِ", latin: "Allahumma baarik lanaa fiimaa razaqtanaa wa qinaa 'adzaaban naar", arti: "Ya Allah, berkahilah kami dalam rezeki yang telah Engkau berikan kepada kami dan peliharalah kami dari siksa api neraka." },
  { nama: "Doa Sesudah Makan", arab: "اَلْحَمْدُ لِلّٰهِ الَّذِيْ أَطْعَمَنَا وَسَقَانَا وَجَعَلَنَا مِنَ الْمُسْلِمِيْنَ", latin: "Alhamdulillahil ladzii ath'amanaa wa saqaanaa wa ja'alanaa minal muslimiin", arti: "Segala puji bagi Allah yang telah memberi kami makan dan minum serta menjadikan kami termasuk orang-orang Islam." },
  { nama: "Doa Masuk Kamar Mandi", arab: "اَللّٰهُمَّ إِنِّيْ أَعُوْذُبِكَ مِنَ الْخُبُثِ وَالْخَبَائِثِ", latin: "Allahumma innii a'uudzubika minal khubutsi wal khabaa-its", arti: "Ya Allah, sesungguhnya aku berlindung kepada Engkau dari godaan syaitan laki-laki dan syaitan perempuan." },
  { nama: "Doa Keluar Kamar Mandi", arab: "غُفْرَانَكَ الْحَمْدُ لِلّٰهِ الَّذِيْ أَذْهَبَ عَنِّى الْأَذٰى وَعَافَانِيْ", latin: "Ghufraanaka alhamdulillahil ladzii adzhaba 'annil adzaa wa 'aafaanii", arti: "Aku memohon ampunan-Mu. Segala puji bagi Allah yang telah menghilangkan penyakitku dan menyehatkan aku." },
  { nama: "Doa Sebelum Tidur", arab: "بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا", latin: "Bismika allahumma amuutu wa ahyaa", arti: "Dengan nama-Mu ya Allah, aku mati dan aku hidup." },
  { nama: "Doa Keluar Rumah", arab: "بِسْمِ اللَّهِ تَوَكَّلْتُ عَلَى اللَّهِ وَلَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ", latin: "Bismillahi tawakkaltu 'alallaahi wa laa hawla wa laa quwwata illaa billaah", arti: "Dengan nama Allah, aku bertawakkal kepada Allah, tiada daya dan kekuatan melainkan dengan pertolongan Allah." },
  { nama: "Doa Masuk Masjid", arab: "اَللَّهُمَّ افْتَحْ لِيْ أَبْوَابَ رَحْمَتِكَ", latin: "Allahummaf-tah lii abwaaba rahmatik", arti: "Ya Allah, bukakanlah untukku pintu-pintu rahmat-Mu." },
  { nama: "Doa Naik Kendaraan", arab: "سُبْحَانَ الَّذِيْ سَخَّرَلَنَا هٰذَا وَمَا كُنَّا لَهُ مُقْرِنِيْنَ وَإِنَّا إِلَى رَبِّنَا لَمُنْقَلِبُوْنَ", latin: "Subhaanaladzii sakhkhara lanaa haadzaa wa maa kunnaa lahu muqriniin wa innaa ilaa rabbinaa lamun qalibuun", arti: "Mahasuci Allah yang telah menundukkan ini bagi kami, padahal kami tidak mampu menguasainya, dan sesungguhnya kami akan kembali kepada Tuhan kami." },
  { nama: "Doa Mau Belajar", arab: "رَبِّ زِدْنِيْ عِلْمًا وَارْزُقْنِيْ فَهْمًا", latin: "Rabbi zidnii 'ilman warzuqnii fahmaa", arti: "Ya Tuhanku, tambahkanlah aku ilmu pengetahuan dan berikanlah aku kepahaman." },
];

const KISAH_NABI = [
  { nama: "Nabi Adam AS", kisah: "Nabi Adam AS adalah manusia pertama yang diciptakan Allah SWT dari tanah. Beliau diciptakan dengan sempurna dan ditempatkan di surga bersama Hawa. Allah melarang keduanya mendekati pohon tertentu, namun karena godaan iblis (Azazil yang kemudian menjadi setan), mereka memakan buah dari pohon tersebut sehingga diturunkan ke bumi. Di bumi, Nabi Adam mengajarkan manusia cara bercocok tanam dan berbagai keterampilan dasar kehidupan." },
  { nama: "Nabi Nuh AS", kisah: "Nabi Nuh AS diutus kepada kaum yang telah menyembah berhala. Selama 950 tahun beliau berdakwah, namun hanya sedikit yang beriman. Atas perintah Allah, Nabi Nuh membuat bahtera besar. Ketika banjir besar datang, hanya orang-orang beriman yang selamat beserta sepasang dari setiap jenis hewan. Bahtera berlabuh di Gunung Judi setelah banjir surut." },
  { nama: "Nabi Ibrahim AS", kisah: "Nabi Ibrahim AS dikenal sebagai Khalilullah (Kekasih Allah). Beliau diuji dengan perintah menyembelih putranya Ismail, namun Allah menggantinya dengan seekor domba saat Ibrahim menunjukkan ketaatan penuh. Ibrahim dan Ismail bersama-sama membangun Ka'bah di Mekkah sebagai rumah ibadah pertama bagi manusia." },
  { nama: "Nabi Musa AS", kisah: "Nabi Musa AS lahir di zaman Fir'aun yang zalim. Sejak kecil ia diasuh di istana Fir'aun. Allah mengutusnya untuk membebaskan Bani Israel dari perbudakan Mesir. Dengan mukjizat tongkat yang bisa berubah jadi ular dan membelah Laut Merah, Nabi Musa berhasil membawa kaumnya keluar dari Mesir. Beliau juga menerima wahyu Kitab Taurat di Gunung Sinai." },
  { nama: "Nabi Isa AS", kisah: "Nabi Isa AS lahir dari Siti Maryam tanpa ayah, atas kuasa Allah SWT. Beliau dianugerahi mukjizat dapat menyembuhkan orang sakit, menghidupkan orang mati dengan izin Allah, dan berbicara saat masih bayi. Nabi Isa diutus untuk meluruskan ajaran Bani Israel dan membawa Injil. Beliau diangkat Allah ke langit dan akan turun kembali di akhir zaman." },
  { nama: "Nabi Muhammad SAW", kisah: "Nabi Muhammad SAW adalah Nabi terakhir dan penutup para nabi. Lahir di Mekkah pada 570 M, beliau diutus membawa Islam untuk seluruh umat manusia. Hijrah ke Madinah menjadi tonggak sejarah Islam. Dalam 23 tahun, beliau berhasil menyatukan Arab di bawah Islam dan wahyu Al-Quran diturunkan melalui beliau. Kepribadiannya yang mulia menjadi suri tauladan seluruh umat Muslim." },
];

const AYAT_KURSI = {
  arab: "اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۗ مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ ۖ وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ ۖ وَلَا يَئُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ",
  latin: "Allahu laa ilaaha illaa huwal hayyul qayyuum, laa ta'khudzuhuu sinatuw wa laa nawm, lahuu maa fis samaawaati wa maa fil ardh, man dzal ladzii yasyfa'u 'indahuu illaa bi idznih, ya'lamu maa baina aidiihim wa maa khalfahum, wa laa yuhiithuuna bisyai'im min 'ilmihii illaa bimaa syaa', wasi'a kursiyyuhus samaawaati wal ardh, wa laa ya'uuduhuu hifzhuhumaa, wa huwal 'aliyyul 'aziim",
  arti: "Allah, tidak ada Tuhan (yang berhak disembah) melainkan Dia Yang Hidup kekal lagi terus menerus mengurus (makhluk-Nya); tidak mengantuk dan tidak tidur. Kepunyaan-Nya apa yang di langit dan di bumi. Tiada yang dapat memberi syafa'at di sisi Allah tanpa izin-Nya. Allah mengetahui apa-apa yang di hadapan mereka dan di belakang mereka, dan mereka tidak mengetahui apa-apa dari ilmu Allah melainkan apa yang dikehendaki-Nya. Kursi Allah meliputi langit dan bumi. Dan Allah tidak merasa berat memelihara keduanya, dan Allah Maha Tinggi lagi Maha Besar.",
  keutamaan: "Barangsiapa membaca Ayat Kursi setiap selesai sholat fardhu, tidak ada yang menghalanginya masuk surga kecuali kematian. (HR. An-Nasa'i)",
};

let handler = async (m, { sock, command, text }) => {

  // ── Ayat Kursi ─────────────────────────
  if (command === "ayatkursi") {
    const teks =
      `📖 *AYAT KURSI*\n` +
      `_(QS. Al-Baqarah: 255)_\n\n` +
      `*Arab:*\n${AYAT_KURSI.arab}\n\n` +
      `*Latin:*\n_${AYAT_KURSI.latin}_\n\n` +
      `*Artinya:*\n${AYAT_KURSI.arti}\n\n` +
      `💡 *Keutamaan:*\n_${AYAT_KURSI.keutamaan}_`;
    return m.reply(teks);
  }

  // ── Doa Harian ─────────────────────────
  if (command === "doaharian" || command === "doa") {
    const doa = DOA_HARIAN[Math.floor(Math.random() * DOA_HARIAN.length)];
    const teks =
      `🤲 *${doa.nama}*\n\n` +
      `*Arab:*\n${doa.arab}\n\n` +
      `*Latin:*\n_${doa.latin}_\n\n` +
      `*Artinya:*\n${doa.arti}`;
    return m.reply(teks);
  }

  // ── Kisah Nabi ─────────────────────────
  if (command === "kisahnabi" || command === "nabi") {
    const nabi = KISAH_NABI[Math.floor(Math.random() * KISAH_NABI.length)];
    const teks =
      `📚 *Kisah ${nabi.nama}*\n\n` +
      `${nabi.kisah}\n\n` +
      `🤲 _Semoga bermanfaat!_`;
    return m.reply(teks);
  }

  // ── Quran Audio ────────────────────────
  if (command === "quranaudio" || command === "dengarsurat") {
    const surahNum = parseInt(text);
    if (!surahNum || surahNum < 1 || surahNum > 114)
      return m.reply(`*Contoh:*\n> ${m.cmd} 1\n\nMasukkan nomor surah 1-114`);

    await m.react("🎵");
    const audioUrl = `https://cdn.islamic.network/quran/audio-surah/128/ar.alafasy/${surahNum}.mp3`;

    try {
      const { data: surahData } = await axios.get(
        `https://api.alquran.cloud/v1/surah/${surahNum}`,
        { timeout: 10000 }
      );
      const surah = surahData?.data;

      await sock.sendMessage(m.chat, {
        audio: { url: audioUrl },
        mimetype: "audio/mpeg",
        fileName: `Surah ${surah?.englishName || surahNum}.mp3`,
        contextInfo: {
          externalAdReply: {
            title: `${surah?.name || "Surah"} - ${surah?.englishName || ""}`,
            body: `${surah?.numberOfAyahs || ""} Ayat | ${surah?.revelationType || ""}`,
            mediaType: 1,
          },
        },
      }, { quoted: m.verifiedQuoted });
      await m.react("✅");
    } catch (e) {
      await m.react("❌");
      m.reply("❌ Gagal: " + e.message);
    }
  }
};

handler.command = ["ayatkursi", "doaharian", "doa", "kisahnabi", "nabi", "quranaudio", "dengarsurat"];
handler.tags = ["religi"];
handler.help = ["ayatkursi", "doaharian", "kisahnabi", "quranaudio <no surah>"];
export default handler;