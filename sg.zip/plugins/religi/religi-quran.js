// plugins/religi-quran.js — dari Ourin MD 3
import axios from "axios";

let handler = async (m, { command, text, args }) => {

  // ── .quran <surah>:<ayat> ────────────
  if (command === "quran" || command === "alquran") {
    if (!text) return m.reply(
      `📖 *ᴀʟ-Qᴜʀᴀɴ*\n\n` +
      `> ${m.cmd} <surah>:<ayat>\n\n` +
      `*Contoh:*\n> ${m.cmd} 1:1\n> ${m.cmd} 2:255`
    );

    const [surah, ayat] = text.split(":").map(Number);
    if (!surah || isNaN(surah)) return m.reply("❌ Format salah! Gunakan: .quran surah:ayat\nContoh: .quran 1:1");

    await m.react("📖");

    try {
      const { data } = await axios.get(
        `https://api.alquran.cloud/v1/ayah/${surah}:${ayat || 1}/editions/quran-uthmani,id.indonesian`,
        { timeout: 10000 }
      );

      const editions = data?.data;
      if (!editions || !editions.length) throw new Error("Ayat tidak ditemukan");

      const arab = editions[0];
      const indo = editions[1];
      const meta = arab.surah;

      return m.reply(
        `📖 *Al-Qur'an*\n\n` +
        `╭┈┈⬡「 📌 *INFO SURAH* 」\n` +
        `┃ 📕 Surah: *${meta.englishName} (${meta.name})*\n` +
        `┃ 📖 Arti: *${meta.englishNameTranslation}*\n` +
        `┃ 🔢 Ayat ke: *${arab.numberInSurah}*\n` +
        `┃ 📍 Turun: *${meta.revelationType}*\n` +
        `╰┈┈⬡\n\n` +
        `🕌 *Arab:*\n${arab.text}\n\n` +
        `🇮🇩 *Terjemahan:*\n_${indo.text}_`
      );
    } catch (err) {
      await m.react("❌");
      return m.reply("❌ Ayat tidak ditemukan: " + err.message);
    }
  }

  // ── .surah ───────────────────────────
  if (command === "surah" || command === "listsurah") {
    try {
      const { data } = await axios.get("https://api.alquran.cloud/v1/surah", { timeout: 10000 });
      const surahs = data?.data?.slice(0, 30) || [];
      let teks = `📖 *Daftar Surah Al-Qur'an* (1-30)\n\n`;
      surahs.forEach((s) => {
        teks += `${s.number}. *${s.englishName}* (${s.name}) - ${s.numberOfAyahs} ayat\n`;
      });
      teks += `\n_Gunakan .quran <nomor_surah>:<ayat> untuk membaca_`;
      return m.reply(teks);
    } catch {
      return m.reply("❌ Gagal memuat daftar surah.");
    }
  }

  // ── .hadits ──────────────────────────
  if (command === "hadits") {
    const HADITS = [
      "Sesungguhnya setiap amal perbuatan tergantung pada niatnya. (HR. Bukhari & Muslim)",
      "Orang yang kuat bukanlah orang yang bisa mengalahkan orang lain, melainkan orang yang bisa mengendalikan dirinya ketika marah. (HR. Bukhari)",
      "Senyummu kepada saudaramu adalah sedekah. (HR. Tirmidzi)",
      "Barangsiapa yang beriman kepada Allah dan Hari Akhir, hendaklah berbicara yang baik atau diam. (HR. Bukhari & Muslim)",
      "Sebaik-baik manusia adalah yang paling bermanfaat bagi orang lain. (HR. Ahmad)",
      "Kebersihan adalah sebagian dari iman. (HR. Muslim)",
      "Sampaikanlah dariku walau satu ayat. (HR. Bukhari)",
      "Tuntutlah ilmu dari buaian hingga liang lahat.",
      "Makan dan minumlah, berpakaianlah dan bersedekahlah tanpa berlebihan dan tanpa kesombongan. (HR. Ahmad)",
      "Sesungguhnya Allah itu Maha Indah dan menyukai keindahan. (HR. Muslim)",
    ];
    const h = HADITS[Math.floor(Math.random() * HADITS.length)];
    return m.reply(`📚 *ʜᴀᴅɪᴛs ʜᴀʀɪ ɪɴɪ*\n\n_"${h}"_\n\n🤲 Semoga bermanfaat!`);
  }
};

handler.command = ["quran", "alquran", "surah", "listsurah", "hadits"];
handler.tags = ["religi"];
handler.help = ["quran <surah>:<ayat>", "surah", "hadits"];
export default handler;