// plugins/ytinfo.js — YouTube Info (CommonJS)
"use strict";

import axios from "axios";

const OEMBED = "https://www.youtube.com/oembed";
const REQUEST_TIMEOUT_MS = 15000;

function buildUsageText(command) {
  return (
    `▶ *YouTube Info*\n\n` +
    `Cara pakai:\n` +
    `${command} <url yt>\n\n` +
    `Contoh:\n` +
    `${command} https://www.youtube.com/watch?v=dQw4w9WgXcQ`
  );
}

async function getYoutubeInfo(url) {
  const res = await axios.get(OEMBED, {
    params: { url, format: "json" },
    timeout: REQUEST_TIMEOUT_MS,
    validateStatus: () => true,
  });

  if (res.status !== 200) {
    throw new Error("URL YouTube tidak valid atau info video tidak tersedia.");
  }

  return res.data;
}

let handler = async (m, { text, command, sock }) => {
  const input = String(text || "").trim();

  if (!input) {
    return sock.sendMessage(
      m.chat,
      { text: buildUsageText(command) },
      { quoted: m.verifiedQuoted }
    );
  }

  try {
    const info = await getYoutubeInfo(input);

    await sock.sendMessage(
      m.chat,
      {
        image: { url: info.thumbnail_url },
        caption:
          `🎬 *YouTube Info*\n\n` +
          `• Title: ${info.title}\n` +
          `• Author: ${info.author_name}\n` +
          `• Type: ${info.type}\n\n` +
          `🔗 ${info.url}`,
      },
      { quoted: m.verifiedQuoted }
    );
  } catch (err) {
    await sock.sendMessage(
      m.chat,
      { text: `❌ Gagal ambil info YouTube.\n\nAlasan: ${err.message}` },
      { quoted: m.verifiedQuoted }
    ).catch(() => {});
  }
};

handler.command = ["checkyt", "ytcheck", "ytdetail"];
handler.tags = ["download"];
handler.help = ["ytinfo <url yt>"];

export default handler;