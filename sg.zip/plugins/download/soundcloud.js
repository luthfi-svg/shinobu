// plugins/download/soundcloud.js — Download music dari SoundCloud (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : SoundCloud Downloader
 * 🔧 Fungsi     : Download lagu dari SoundCloud
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

let handler = async (m, { sock, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `Contoh penggunaan:\n${usedPrefix + command} <url>\n\n` +
      `Contoh:\n` +
      `${usedPrefix + command} https://soundcloud.com/artist/track-name`
    );
  }

  const url = text.trim();

  if (!url.includes("soundcloud.com")) {
    return m.reply("❌ URL tidak valid! Gunakan link SoundCloud yang benar.");
  }

  try {
    await m.reply("⏳ *Downloading...*\n\nMohon tunggu, proses download...");

    // Try API
    let result;
    try {
      const res = await axios.post(
        "https://www.klickaud.co/download.php",
        { url: url },
        { timeout: 60000 }
      );
      result = res.data;
    } catch {
      // Fallback API
      const res2 = await axios.get(
        `https://api.soundcloudapi.com/resolve?url=${encodeURIComponent(url)}`,
        { timeout: 60000 }
      );
      result = res2.data;
    }

    const audioUrl = result.download_url || result.url;
    const title = result.title || "SoundCloud Audio";
    const artist = result.artist || result.user?.username || "Unknown";
    const duration = result.duration ? `${Math.floor(result.duration / 1000 / 60)}:${Math.floor((result.duration / 1000) % 60).toString().padStart(2, "0")}` : "N/A";

    if (!audioUrl) {
      throw new Error("Audio URL tidak ditemukan");
    }

    // Download audio
    const audioRes = await axios.get(audioUrl, {
      responseType: "arraybuffer",
      timeout: 120000
    });

    const audioBuffer = Buffer.from(audioRes.data);
    const audioSizeMB = (audioBuffer.length / (1024 * 1024)).toFixed(2);

    await sock.sendMessage(
      m.chat,
      {
        audio: audioBuffer,
        mimetype: "audio/mpeg",
        fileName: `${title}.mp3`,
        contextInfo: {
          externalAdReply: {
            title: title,
            body: `Artist: ${artist} • Duration: ${duration}`,
            mediaType: 2,
            sourceUrl: url
          }
        }
      },
      { quoted: m }
    );

    await m.reply(
      `✅ *SoundCloud Download*\n\n` +
      `🎵 Title: ${title}\n` +
      `👤 Artist: ${artist}\n` +
      `⏱️ Duration: ${duration}\n` +
      `📦 Size: ${audioSizeMB} MB`
    );

    await m.react("✅");

  } catch (e) {
    console.error(e);
    await m.reply(
      `❌ *Download Error*\n\n` +
      `Gagal download: ${e.message}\n\n` +
      `Tips:\n` +
      `• Pastikan URL valid\n` +
      `• Track mungkin private atau dihapus\n` +
      `• Coba lagi beberapa saat`
    );
  }
};

handler.help = ["soundcloud <url>", "scdl <url>"];
handler.tags = ["download"];
handler.command = /^(soundcloud|scdl|sc)$/i;
handler.limit = true;

export default handler;
