// plugins/download/pinterest.js — Download image/video dari Pinterest (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Pinterest Downloader
 * 🔧 Fungsi     : Download media dari Pinterest
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

let handler = async (m, { sock, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `Contoh penggunaan:\n${usedPrefix + command} <url/query>\n\n` +
      `Download:\n` +
      `${usedPrefix + command} https://pin.it/xxxxx\n\n` +
      `Search:\n` +
      `${usedPrefix + command} aesthetic wallpaper`
    );
  }

  const input = text.trim();

  try {
    // Check if URL or search query
    if (input.includes("pin.it") || input.includes("pinterest.com")) {
      // Download mode
      await m.reply("⏳ *Downloading...*\n\nMohon tunggu...");

      const res = await axios.get(
        `https://www.pinterest.com/resource/PinResource/get/?source_url=${encodeURIComponent(input)}`,
        { timeout: 30000 }
      );

      const data = res.data?.resource_response?.data;
      if (!data) throw new Error("Data tidak ditemukan");

      const mediaUrl = data.images?.orig?.url || data.videos?.video_list?.V_720P?.url;
      const title = data.title || data.description || "Pinterest Media";
      const isVideo = !!data.videos;

      if (!mediaUrl) throw new Error("Media URL tidak ditemukan");

      // Download media
      const mediaRes = await axios.get(mediaUrl, {
        responseType: "arraybuffer",
        timeout: 60000
      });

      const mediaBuffer = Buffer.from(mediaRes.data);

      if (isVideo) {
        await sock.sendMessage(
          m.chat,
          {
            video: mediaBuffer,
            caption: `✅ *Pinterest Video*\n\n📝 ${title}`
          },
          { quoted: m }
        );
      } else {
        await sock.sendMessage(
          m.chat,
          {
            image: mediaBuffer,
            caption: `✅ *Pinterest Image*\n\n📝 ${title}`
          },
          { quoted: m }
        );
      }

    } else {
      // Search mode
      await m.reply("⏳ *Searching Pinterest...*\n\nMencari gambar...");

      const res = await axios.get(
        `https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=/search/pins/?q=${encodeURIComponent(input)}&data={"options":{"query":"${encodeURIComponent(input)}"}}`,
        { timeout: 30000 }
      );

      const pins = res.data?.resource_response?.data?.results || [];
      if (pins.length === 0) throw new Error("Tidak ada hasil");

      // Send first 5 images
      for (let i = 0; i < Math.min(5, pins.length); i++) {
        const pin = pins[i];
        const imageUrl = pin.images?.orig?.url;
        
        if (imageUrl) {
          await sock.sendMessage(
            m.chat,
            {
              image: { url: imageUrl },
              caption: `🔍 *Pinterest Search*\n\n📝 Query: ${input}\n📊 Result: ${i + 1}/${Math.min(5, pins.length)}`
            },
            { quoted: m }
          );
          
          await new Promise(r => setTimeout(r, 1000)); // Delay
        }
      }
    }

    await m.react("✅");

  } catch (e) {
    console.error(e);
    await m.reply(
      `❌ *Pinterest Error*\n\n` +
      `Gagal: ${e.message}\n\n` +
      `Tips:\n` +
      `• Untuk download: gunakan link Pinterest\n` +
      `• Untuk search: gunakan keyword\n` +
      `• Contoh: ${usedPrefix + command} anime art`
    );
  }
};

handler.help = ["pinterest <url/query>", "pin <url/query>"];
handler.tags = ["download"];
handler.command = /^(pinterest|pin|pindl)$/i;
handler.limit = true;

export default handler;
