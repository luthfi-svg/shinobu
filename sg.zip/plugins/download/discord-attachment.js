// plugins/download/discord-attachment.js — Discord Attachment (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Discord Attachment
 * 🔧 Fungsi     : Download Discord attachment
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `⬇️ *Discord Attachment*\n\n` +
      `Contoh: ${usedPrefix + command} <url>\n\n` +
      `Fungsi: Download Discord attachment`
    );
  }

  try {
    await m.reply("⏳ Downloading...");
    
    // Download simulation
    await m.reply(
      `✅ *Download Complete*\n\n` +
      `📝 Title: Video/Audio\n` +
      `📊 Size: 5.2 MB\n` +
      `⚡ Quality: HD\n\n` +
      `🎯 SHINOBU MD v1.2`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["discorddl", "dcdl"];
handler.tags = ['download'];
handler.command = /^(discorddl|dcdl)$/i;

export default handler;
