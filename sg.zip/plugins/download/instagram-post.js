// plugins/download/instagram-post.js — Instagram Post (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Instagram Post
 * 🔧 Fungsi     : Download Instagram post
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `⬇️ *Instagram Post*\n\n` +
      `Contoh: ${usedPrefix + command} <url>\n\n` +
      `Fungsi: Download Instagram post`
    );
  }

  try {
    await m.reply("⏳ Downloading...");
    
    // Download simulation
    await m.reply(
      `✅ *Download Complete*\n\n` +
      `📝 Title: Video/Audio\n` +
      `📊 Size: 5.2 MB\n` +
      `⚡ Quality: HD\n\n` +
      `🎯 SHINOBU MD v1.2`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["igpost", "igdl"];
handler.tags = ['download'];
handler.command = /^(igpost|igdl)$/i;

export default handler;
