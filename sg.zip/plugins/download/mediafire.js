// plugins/download/mediafire.js — Download dari MediaFire (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : MediaFire Downloader
 * 🔧 Fungsi     : Download file dari MediaFire
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

let handler = async (m, { sock, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `Contoh penggunaan:\n${usedPrefix + command} <url>\n\n` +
      `Contoh:\n` +
      `${usedPrefix + command} https://www.mediafire.com/file/xxxxx`
    );
  }

  const url = text.trim();

  if (!url.includes("mediafire.com")) {
    return m.reply("❌ URL tidak valid! Gunakan link MediaFire.");
  }

  try {
    await m.reply("⏳ *Downloading...*\n\nMohon tunggu...");

    const response = await axios.get(
      `https://api-mediafire-dl.vercel.app/?url=${encodeURIComponent(url)}`,
      { timeout: 30000 }
    ).catch(async () => {
      // Fallback API
      return axios.post(
        "https://mediafire-dl-api.herokuapp.com/download",
        { url: url },
        { timeout: 30000 }
      );
    });

    const data = response.data;
    const downloadUrl = data.url || data.download;
    const filename = data.filename || data.name || "file";
    const filesize = data.filesize || data.size || "Unknown";

    if (!downloadUrl) {
      throw new Error("Download URL tidak ditemukan");
    }

    // Check file size (max 100MB)
    const sizeMatch = filesize.match(/(\d+\.?\d*)\s*(MB|GB)/i);
    if (sizeMatch) {
      const size = parseFloat(sizeMatch[1]);
      const unit = sizeMatch[2].toUpperCase();
      if ((unit === "GB" && size >= 0.1) || (unit === "MB" && size > 100)) {
        return m.reply(
          `❌ *File Terlalu Besar*\n\n` +
          `📦 Size: ${filesize}\n` +
          `⚠️ Max: 100MB\n\n` +
          `Download manual: ${downloadUrl}`
        );
      }
    }

    await m.reply(
      `✅ *MediaFire Download*\n\n` +
      `📝 Name: ${filename}\n` +
      `📦 Size: ${filesize}\n\n` +
      `⏳ Sending file...`
    );

    // Download and send
    const fileRes = await axios.get(downloadUrl, {
      responseType: "arraybuffer",
      timeout: 120000,
      maxContentLength: 100 * 1024 * 1024
    });

    const fileBuffer = Buffer.from(fileRes.data);

    await sock.sendMessage(
      m.chat,
      {
        document: fileBuffer,
        fileName: filename,
        mimetype: "application/octet-stream"
      },
      { quoted: m }
    );

    await m.react("✅");

  } catch (e) {
    console.error(e);
    await m.reply(
      `❌ *Download Error*\n\n` +
      `${e.message}\n\n` +
      `Tips:\n` +
      `• File mungkin dihapus\n` +
      `• File terlalu besar\n` +
      `• Link expired`
    );
  }
};

handler.help = ["mediafire <url>"];
handler.tags = ["download"];
handler.command = /^(mediafire|mf|mfdl)$/i;
handler.limit = true;

export default handler;
