// plugins/pinterestvideo.js — Pinterest Video Search (SynoxCloud API)
"use strict";

import axios from "axios";
import { spawn } from "child_process";
import fs from "fs";
import os from "os";
import path from "path";
import crypto from "crypto";

const API_BASE = "https://api.synoxcloud.xyz/search/pinterest-video";
const REQUEST_TIMEOUT_MS = 30000;
const FFMPEG_TIMEOUT_MS = 90000;
const MAX_QUERY_LENGTH = 200;
const MAX_ALT_RESULTS = 5;

/**
 * Memanggil endpoint /search/pinterest-video.
 * Struktur response asli:
 * {
 *   statusCode, creator, status,
 *   result: [
 *     { id, title, description, video (m3u8), thumbnail, duration,
 *       link, pinner, username, likes }
 *   ],
 *   timestamp
 * }
 */
async function searchPinterestVideo(query) {
  let res;
  try {
    res = await axios.get(API_BASE, {
      params: { q: query },
      timeout: REQUEST_TIMEOUT_MS,
      validateStatus: () => true,
    });
  } catch (err) {
    if (err.code === "ECONNABORTED") {
      throw new Error("Timeout saat menghubungi server pencarian Pinterest.");
    }
    throw new Error(`Gagal menghubungi server: ${err.message}`);
  }

  const body = res.data;

  if (res.status !== 200) {
    const msg =
      (body && typeof body === "object" && (body.message || body.error)) ||
      `HTTP ${res.status} - ${res.statusText || "Request gagal"}`;
    throw new Error(msg);
  }

  if (!body || typeof body !== "object") {
    throw new Error("Response API tidak valid (bukan JSON object).");
  }

  if (body.status !== true) {
    throw new Error(body.message || "API mengembalikan status gagal.");
  }

  const list = Array.isArray(body.result) ? body.result : [];

  if (!list.length) {
    throw new Error(`Tidak ditemukan video untuk pencarian "${query}".`);
  }

  const normalized = list
    .map(normalizeItem)
    .filter((item) => Boolean(item.videoUrl));

  if (!normalized.length) {
    throw new Error("Ditemukan hasil, tapi tidak ada URL video (m3u8) yang valid.");
  }

  return normalized;
}

function cleanText(val, fallback) {
  if (typeof val !== "string") return fallback;
  const trimmed = val.trim();
  return trimmed.length ? trimmed : fallback;
}

function normalizeItem(item) {
  if (!item || typeof item !== "object") return {};
  return {
    id: item.id || null,
    title: cleanText(item.title, "Tanpa judul"),
    description: cleanText(item.description, ""),
    videoUrl: item.video || null,
    thumbnail: item.thumbnail || null,
    link: item.link || null,
    pinner: cleanText(item.pinner, "-"),
    username: cleanText(item.username, "-"),
    likes: typeof item.likes === "number" ? item.likes : 0,
  };
}

/**
 * Video Pinterest disajikan sebagai HLS (.m3u8), bukan file mp4 langsung.
 * axios/GET biasa tidak bisa "mengunduh" m3u8 jadi satu file utuh karena
 * itu playlist yang menunjuk ke banyak segmen .ts terpisah.
 * Solusinya: remux/transcode via ffmpeg ke mp4 di temp file, lalu baca sebagai buffer.
 */
function convertHlsToMp4Buffer(m3u8Url) {
  return new Promise((resolve, reject) => {
    const tmpFile = path.join(
      os.tmpdir(),
      `pinvideo-${crypto.randomBytes(8).toString("hex")}.mp4`
    );

    const ffmpeg = spawn("ffmpeg", [
      "-y",
      "-loglevel", "error",
      "-timeout", "15000000", // 15 detik dalam microseconds, untuk koneksi ke source HLS
      "-i", m3u8Url,
      "-c", "copy",
      "-bsf:a", "aac_adtstoasc",
      "-movflags", "+faststart",
      tmpFile,
    ]);

    let stderr = "";
    const timer = setTimeout(() => {
      ffmpeg.kill("SIGKILL");
      reject(new Error("Timeout saat mengonversi video HLS ke MP4."));
    }, FFMPEG_TIMEOUT_MS);

    ffmpeg.stderr.on("data", (chunk) => {
      stderr += chunk.toString();
    });

    ffmpeg.on("error", (err) => {
      clearTimeout(timer);
      if (err.code === "ENOENT") {
        reject(new Error("ffmpeg tidak ditemukan di server. Install ffmpeg terlebih dahulu."));
      } else {
        reject(new Error(`Gagal menjalankan ffmpeg: ${err.message}`));
      }
    });

    ffmpeg.on("close", (code) => {
      clearTimeout(timer);

      if (code !== 0) {
        fs.unlink(tmpFile, () => {});
        const shortErr = stderr.trim().split("\n").slice(-3).join(" | ") || `exit code ${code}`;
        return reject(new Error(`Konversi video gagal: ${shortErr}`));
      }

      fs.readFile(tmpFile, (readErr, buffer) => {
        fs.unlink(tmpFile, () => {});

        if (readErr) {
          return reject(new Error(`Gagal membaca hasil konversi: ${readErr.message}`));
        }
        if (!buffer || !buffer.length) {
          return reject(new Error("Hasil konversi video kosong."));
        }
        resolve(buffer);
      });
    });
  });
}

function buildUsageText(command) {
  return (
    `📌 *Pinterest Video Search*\n\n` +
    `*Cara pakai:*\n` +
    `${command} <kata kunci>\n\n` +
    `*Contoh:*\n` +
    `${command} Doraemon\n\n` +
    `*Batas panjang kata kunci:* ${MAX_QUERY_LENGTH} karakter`
  );
}

function formatLikes(n) {
  if (n >= 1000000) return `${(n / 1000000).toFixed(1)}jt`;
  if (n >= 1000) return `${(n / 1000).toFixed(1)}rb`;
  return String(n);
}

let handler = async (m, { text, command, sock }) => {
  if (!text || !text.trim()) {
    return sock.sendMessage(m.chat, { text: buildUsageText(command) }, { quoted: m.verifiedQuoted });
  }

  const query = text.trim();

  if (query.length > MAX_QUERY_LENGTH) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Kata kunci terlalu panjang (${query.length}/${MAX_QUERY_LENGTH} karakter).` },
      { quoted: m.verifiedQuoted }
    );
  }

  await sock.sendMessage(
    m.chat,
    { text: `🔍 Mencari & memproses video Pinterest...\n\n*Kata kunci:* ${query}\n\n_Konversi video butuh beberapa saat, mohon tunggu._` },
    { quoted: m.verifiedQuoted }
  );

  try {
    const results = await searchPinterestVideo(query);
    const picked = results[0];

    const buffer = await convertHlsToMp4Buffer(picked.videoUrl);

    const captionParts = [
      `📌 *Pinterest Video*`,
      "",
      `📝 *Judul:* ${picked.title}`,
    ];
    if (picked.description) captionParts.push(`💬 *Deskripsi:* ${picked.description}`);
    captionParts.push(
      `👤 *Pinner:* ${picked.pinner} (@${picked.username})`,
      `❤️ *Likes:* ${formatLikes(picked.likes)}`,
      `🔗 *Link:* ${picked.link || "-"}`
    );
    if (results.length > 1) {
      captionParts.push("", `💡 Ditemukan ${results.length} hasil, dikirim hasil pertama.`);
    }

    await sock.sendMessage(
      m.chat,
      {
        video: buffer,
        mimetype: "video/mp4",
        caption: captionParts.join("\n"),
      },
      { quoted: m.verifiedQuoted }
    );

    if (results.length > 1) {
      const altList = results
        .slice(1, MAX_ALT_RESULTS)
        .map((r, i) => `${i + 2}. ${r.title} (❤️ ${formatLikes(r.likes)})\n${r.link}`)
        .join("\n\n");

      if (altList) {
        await sock.sendMessage(
          m.chat,
          { text: `📋 *Hasil lainnya:*\n\n${altList}` },
          { quoted: m.verifiedQuoted }
        ).catch(() => {});
      }
    }
  } catch (err) {
    await sock.sendMessage(
      m.chat,
      { text: `❌ Gagal memproses video Pinterest.\n\n*Alasan:* ${err.message}` },
      { quoted: m.verifiedQuoted }
    ).catch(() => {});
  }
};

handler.command = ["pinvideo", "pinterestvideo", "pinvid"];
handler.tags = ["download"];
handler.help = ["pinvideo <kata kunci>"];

export default handler;