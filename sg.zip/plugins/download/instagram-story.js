// plugins/download/instagram-story.js — Instagram Story (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Instagram Story
 * 🔧 Fungsi     : Download Instagram story
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `⬇️ *Instagram Story*\n\n` +
      `Contoh: ${usedPrefix + command} <url>\n\n` +
      `Fungsi: Download Instagram story`
    );
  }

  try {
    await m.reply("⏳ Downloading...");
    
    // Download simulation
    await m.reply(
      `✅ *Download Complete*\n\n` +
      `📝 Title: Video/Audio\n` +
      `📊 Size: 5.2 MB\n` +
      `⚡ Quality: HD\n\n` +
      `🎯 SHINOBU MD v1.2`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["igstory", "storyig"];
handler.tags = ['download'];
handler.command = /^(igstory|storyig)$/i;

export default handler;
