// plugins/download/instagram.js — Download Instagram reels/post (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Instagram Downloader
 * 🔧 Fungsi     : Download post/reels/story dari Instagram
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

let handler = async (m, { sock, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `Contoh penggunaan:\n${usedPrefix + command} <url>\n\n` +
      `Contoh:\n` +
      `${usedPrefix + command} https://www.instagram.com/p/xxxxx/\n` +
      `${usedPrefix + command} https://www.instagram.com/reel/xxxxx/`
    );
  }

  const url = text.trim();

  if (!url.includes("instagram.com")) {
    return m.reply("❌ URL tidak valid! Gunakan link Instagram yang benar.");
  }

  try {
    await m.reply("⏳ *Downloading...*\n\nMohon tunggu...");

    // Try API
    let result;
    
    try {
      const res1 = await axios.get(
        `https://api.instagramsave.com/download?url=${encodeURIComponent(url)}`,
        { timeout: 30000 }
      );
      result = res1.data;
    } catch {
      // Fallback API
      const res2 = await axios.post(
        "https://downloadgram.org/download",
        { url: url },
        { timeout: 30000 }
      );
      result = res2.data;
    }

    const mediaUrl = result.url || result.download_url;
    const mediaType = result.type || "image";
    const caption = result.caption || "Instagram Media";

    if (!mediaUrl) {
      throw new Error("Media URL tidak ditemukan");
    }

    // Download media
    const mediaRes = await axios.get(mediaUrl, {
      responseType: "arraybuffer",
      timeout: 60000
    });

    const mediaBuffer = Buffer.from(mediaRes.data);

    if (mediaType === "video" || url.includes("/reel/")) {
      await sock.sendMessage(
        m.chat,
        {
          video: mediaBuffer,
          caption: `✅ *Instagram Download*\n\n📝 ${caption.substring(0, 100)}`
        },
        { quoted: m }
      );
    } else {
      await sock.sendMessage(
        m.chat,
        {
          image: mediaBuffer,
          caption: `✅ *Instagram Download*\n\n📝 ${caption.substring(0, 100)}`
        },
        { quoted: m }
      );
    }

    await m.react("✅");

  } catch (e) {
    console.error(e);
    await m.reply(
      `❌ *Download Error*\n\n` +
      `Gagal download: ${e.message}\n\n` +
      `Tips:\n` +
      `• Pastikan post public\n` +
      `• Post mungkin dihapus\n` +
      `• Coba lagi beberapa saat`
    );
  }
};

handler.help = ["instagram <url>", "ig <url>"];
handler.tags = ["download"];
handler.command = /^(instagram|ig|igdl)$/i;
handler.limit = true;

export default handler;
