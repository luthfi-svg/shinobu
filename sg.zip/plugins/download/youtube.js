// plugins/youtube.js — Sky Bot V3
import axios from "axios";
import yt from "yt-search";

async function ytSearch(query) {
  const r = await yt(query);
  return r.videos.slice(0, 5);
}

async function ytDl(url, type) {
  const { data } = await axios.get(
    `https://api.serverweb.qzz.io/download/youtube?apikey=skyy&url=${encodeURIComponent(url)}&type=${type}`
  );
  return data;
}

let handler = async (m, { sock, text, command }) => {
  if (!text) return m.reply(`*Contoh:*\n${m.cmd} <judul/url>`);

  const isUrl = /youtu(be\.com|\.be)/.test(text);

  if (command === "yts") {
    await m.reply("🔍 Mencari di YouTube...");
    const results = await ytSearch(text).catch(() => []);
    if (!results.length) return m.reply("❌ Tidak ada hasil ditemukan.");

    let teks = `🎬 *Hasil Pencarian YouTube*\n\n`;
    results.forEach((v, i) => {
      teks += `${i + 1}. *${v.title}*\n`;
      teks += `   ⏱ Durasi: ${v.timestamp} | 👁 ${v.views?.toLocaleString("id-ID")} views\n`;
      teks += `   🔗 ${v.url}\n\n`;
    });
    return m.reply(teks);
  }

  await m.reply(`⏳ Sedang memproses *${command === "ytmp3" ? "Audio" : "Video"}*...`);

  let url = text;
  if (!isUrl) {
    const results = await ytSearch(text).catch(() => []);
    if (!results.length) return m.reply("❌ Lagu/video tidak ditemukan.");
    url = results[0].url;
  }

  try {
    const type = command === "ytmp3" ? "audio" : "video";
    const data = await ytDl(url, type);
    if (!data?.result) throw new Error("Gagal mendapatkan link download.");

    const dl = data.result;
    const title = dl.title || "Unknown";
    const thumb = dl.thumbnail || "";
    const dlUrl = dl.url;
    const duration = dl.duration || "-";

    if (command === "ytmp3") {
      await sock.sendMessage(m.chat, {
        audio: { url: dlUrl },
        mimetype: "audio/mpeg",
        fileName: `${title}.mp3`,
        contextInfo: {
          externalAdReply: {
            title: title,
            body: `Durasi: ${duration}`,
            thumbnailUrl: thumb,
            mediaType: 1,
            renderLargerThumbnail: true,
          },
        },
      }, { quoted: m });
    } else {
      await sock.sendMessage(m.chat, {
        video: { url: dlUrl },
        caption: `🎬 *${title}*\n⏱ Durasi: ${duration}`,
        contextInfo: {
          externalAdReply: {
            title: title,
            body: `Durasi: ${duration}`,
            thumbnailUrl: thumb,
            mediaType: 1,
            renderLargerThumbnail: true,
          },
        },
      }, { quoted: m });
    }
  } catch (err) {
    m.reply("❌ Gagal download: " + err.message);
  }
};

handler.command = ["ytmp3", "ytmp4", "yta", "ytv", "yts", "ytdl"];
handler.tags = ["Download"];
handler.help = ["ytmp3 <judul/url>", "ytmp4 <judul/url>", "yts <judul>"];

export default handler;