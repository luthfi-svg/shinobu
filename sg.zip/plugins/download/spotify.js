// plugins/downloader/spotify.js — Spotify Downloader
/**
 * ───「 FEATURE AUTHOR 」───
 * ❒ Nama Fitur : Spotify Download
 * ❒ Creator     : Blackrose
 * ❒ Link Channel: https://whatsapp.com/channel/0029VbBt4432f3ENa8ULoM1J
 * ⚠️ Converted to Common JS
 * ─────────────────────────
 */

"use strict";

import axios from "axios";

/**
 * Download single track dari Spotify.
 */
async function downloadTrack(trackUrl) {
  try {
    const res = await axios.post(
      'https://spotyloader.com/api/spotify/track',
      { url: trackUrl },
      {
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'Mozilla/5.0'
        },
        timeout: 30000
      }
    );

    const trackId = res.data.jobId;
    if (!trackId) {
      throw new Error("Gagal mendapatkan job ID dari server.");
    }

    // Polling status sampai 20x (60 detik)
    for (let i = 0; i < 20; i++) {
      await new Promise(resolve => setTimeout(resolve, 3000));

      const statusRes = await axios.get(
        `https://spotyloader.com/api/spotify/track/status/${trackId}`,
        {
          headers: { 'User-Agent': 'Mozilla/5.0' },
          timeout: 15000
        }
      );

      const data = statusRes.data;

      if (data.status === 'ready' || data.status === 'success') {
        const downloadUrl = data.downloadLink || data.downloadUrl || (data.post && data.post.download_url);
        if (downloadUrl) {
          return {
            success: true,
            download_url: downloadUrl,
            metadata: data.post ? {
              title: data.post.name || 'Unknown',
              artist: data.post.artist || 'Unknown',
              album: data.post.album || 'Unknown',
              image: data.post.image || ''
            } : null
          };
        }
      } else if (data.status === 'error' || data.status === 'failed') {
        throw new Error("Konversi gagal di server.");
      }
    }

    throw new Error("Timeout menunggu konversi.");
  } catch (error) {
    throw new Error(error.response?.data?.message || error.message || "Gagal download track");
  }
}

/**
 * Download album atau playlist Spotify.
 */
async function downloadAlbumOrPlaylist(url) {
  const type = url.includes('/album/') ? 'album' : 'playlist';

  const res = await axios.post(
    `https://spotyloader.com/api/spotify/${type}`,
    { url },
    {
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0'
      },
      timeout: 30000
    }
  );

  const tracks = res.data.post?.tracks || [];
  if (tracks.length === 0) {
    throw new Error("Tidak ada track ditemukan.");
  }

  // Batasi maksimal 5 track biar gak timeout
  const maxTracks = Math.min(tracks.length, 5);
  const limitedTracks = tracks.slice(0, maxTracks);
  const results = [];

  for (let i = 0; i < limitedTracks.length; i += 2) {
    const batch = limitedTracks.slice(i, i + 2);
    const batchResults = await Promise.all(
      batch.map(track => downloadTrack(track.url).catch(err => ({ error: err.message })))
    );
    results.push(...batchResults);

    if (i + 2 < limitedTracks.length) {
      await new Promise(resolve => setTimeout(resolve, 2000));
    }
  }

  return {
    type,
    title: res.data.post.name || 'Unknown',
    artist: res.data.post.artist || 'Unknown',
    total_tracks: tracks.length,
    downloaded: results.length,
    results
  };
}

function buildUsageText(prefix, command) {
  return (
    `🎵 *Spotify Downloader*\n\n` +
    `Download lagu dari Spotify.\n\n` +
    `*Cara Pakai:*\n` +
    `${prefix + command} <url_spotify>\n\n` +
    `*Contoh:*\n` +
    `${prefix + command} https://open.spotify.com/track/xxx\n` +
    `${prefix + command} https://open.spotify.com/album/xxx\n\n` +
    `*Fitur:*\n` +
    `• Download single track\n` +
    `• Download album/playlist (max 5 lagu)\n\n` +
    `*Note:* Proses butuh waktu, sabar ya!`
  );
}

let handler = async (m, { text, command, sock }) => {
  const prefix = global.prefix || ".";

  // Validasi input
  if (!text || !text.trim()) {
    return sock.sendMessage(
      m.chat,
      { text: buildUsageText(prefix, command) },
      { quoted: m.verifiedQuoted }
    );
  }

  const url = text.trim();

  // Validasi URL Spotify
  if (!url.includes('spotify.com') && !url.includes('open.spotify.com')) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ URL tidak valid!\n\nMasukkan URL Spotify yang benar.\nContoh: https://open.spotify.com/track/xxx` },
      { quoted: m.verifiedQuoted }
    );
  }

  // Reaksi loading
  await sock.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

  // Kirim pesan proses
  await sock.sendMessage(
    m.chat,
    { text: `🎵 *Memproses Spotify...*\n\n🔗 ${url}\n\n_Tunggu sebentar, proses bisa memakan waktu 1-2 menit..._` },
    { quoted: m.verifiedQuoted }
  );

  try {
    // Cek apakah album/playlist atau single track
    if (url.includes('/album/') || url.includes('/playlist/')) {
      // Download album/playlist
      const result = await downloadAlbumOrPlaylist(url);

      let caption =
        `🎵 *SPOTIFY ${result.type.toUpperCase()}*\n\n` +
        `📀 Judul: ${result.title}\n` +
        `👤 Artist: ${result.artist}\n` +
        `📊 Total Track: ${result.total_tracks}\n` +
        `📥 Didownload: ${result.downloaded} lagu\n\n`;

      // Kirim per track
      for (let i = 0; i < result.results.length; i++) {
        const track = result.results[i];

        if (track.success && track.download_url) {
          const meta = track.metadata || {};

          try {
            // Download audio
            const audioRes = await axios.get(track.download_url, {
              responseType: 'arraybuffer',
              timeout: 60000
            });

            const buffer = Buffer.from(audioRes.data);

            let trackCaption =
              `🎵 *${meta.title || 'Unknown'}*\n` +
              `👤 ${meta.artist || 'Unknown'}\n` +
              `💿 ${meta.album || 'Unknown'}\n` +
              `📊 Track ${i + 1}/${result.results.length}\n\n` +
              `_Downloaded via Spotify_`;

            // Kirim audio
            await sock.sendMessage(
              m.chat,
              {
                audio: buffer,
                mimetype: 'audio/mpeg',
                fileName: `${meta.title || 'track'}.mp3`,
                caption: trackCaption
              },
              { quoted: m.verifiedQuoted }
            );

            // Delay antar kirim
            await new Promise(resolve => setTimeout(resolve, 1500));

          } catch (err) {
            caption += `❌ Track ${i + 1}: Gagal download\n`;
          }
        } else {
          caption += `❌ Track ${i + 1}: ${track.error || 'Gagal'}\n`;
        }
      }

      // Kirim summary
      await sock.sendMessage(
        m.chat,
        { text: caption },
        { quoted: m.verifiedQuoted }
      );

    } else {
      // Download single track
      const result = await downloadTrack(url);

      if (!result.success || !result.download_url) {
        throw new Error("Gagal mendapatkan link download.");
      }

      const meta = result.metadata || {};

      // Download audio
      const audioRes = await axios.get(result.download_url, {
        responseType: 'arraybuffer',
        timeout: 60000
      });

      const buffer = Buffer.from(audioRes.data);

      let caption =
        `🎵 *SPOTIFY DOWNLOADER*\n\n` +
        `📀 Judul: ${meta.title || 'Unknown'}\n` +
        `👤 Artist: ${meta.artist || 'Unknown'}\n` +
        `💿 Album: ${meta.album || 'Unknown'}\n\n` +
        `_Downloaded via Spotify_`;

      // Kirim audio
      await sock.sendMessage(
        m.chat,
        {
          audio: buffer,
          mimetype: 'audio/mpeg',
          fileName: `${meta.title || 'track'}.mp3`,
          caption: caption
        },
        { quoted: m.verifiedQuoted }
      );

      // Kirim thumbnail kalo ada
      if (meta.image) {
        try {
          const imgRes = await axios.get(meta.image, {
            responseType: 'arraybuffer',
            timeout: 15000
          });

          await sock.sendMessage(
            m.chat,
            {
              image: Buffer.from(imgRes.data),
              caption: `🎵 ${meta.title} - ${meta.artist}`
            },
            { quoted: m.verifiedQuoted }
          );
        } catch (err) {
          // Gagal kirim thumbnail, skip
        }
      }
    }

    await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

  } catch (error) {
    console.error("[SPOTIFY ERROR]", error);
    await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    await sock.sendMessage(
      m.chat,
      {
        text:
          `❌ *Gagal Download!*\n\n` +
          `*Alasan:* ${error.message || "Unknown error"}\n\n` +
          `Coba lagi nanti atau cek URL Spotify.`
      },
      { quoted: m.verifiedQuoted }
    );
  }
};

handler.command = ["spotify", "spotifydl", "spdl"];
handler.tags = ["downloader"];
handler.help = ["spotify <url>"];
handler.limit = true;

export default handler;