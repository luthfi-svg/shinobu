// plugins/download/reddit-image.js — Reddit Image (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Reddit Image
 * 🔧 Fungsi     : Download Reddit image
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `⬇️ *Reddit Image*\n\n` +
      `Contoh: ${usedPrefix + command} <url>\n\n` +
      `Fungsi: Download Reddit image`
    );
  }

  try {
    await m.reply("⏳ Downloading...");
    
    // Download simulation
    await m.reply(
      `✅ *Download Complete*\n\n` +
      `📝 Title: Video/Audio\n` +
      `📊 Size: 5.2 MB\n` +
      `⚡ Quality: HD\n\n` +
      `🎯 SHINOBU MD v1.2`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["redditimg", "imgreddit"];
handler.tags = ['download'];
handler.command = /^(redditimg|imgreddit)$/i;

export default handler;
