// plugins/download/twitter.js — Download Twitter/X video (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Twitter/X Downloader
 * 🔧 Fungsi     : Download video dari Twitter/X
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

let handler = async (m, { sock, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `Contoh penggunaan:\n${usedPrefix + command} <url>\n\n` +
      `Contoh:\n` +
      `${usedPrefix + command} https://twitter.com/user/status/123456\n` +
      `${usedPrefix + command} https://x.com/user/status/123456`
    );
  }

  const twitterUrl = text.trim();

  if (!twitterUrl.includes("twitter.com") && !twitterUrl.includes("x.com")) {
    return m.reply("❌ URL tidak valid! Gunakan link Twitter/X yang benar.");
  }

  try {
    await m.reply("⏳ *Downloading...*\n\nMohon tunggu...");

    // Try multiple APIs
    let videoUrl;

    try {
      // API 1: Twitter2 API
      const res1 = await axios.get(
        `https://api.twitter2.com/download?url=${encodeURIComponent(twitterUrl)}`,
        { timeout: 30000 }
      );
      
      if (res1.data && res1.data.video) {
        videoUrl = res1.data.video.url || res1.data.video[0];
      }
    } catch {
      // API 2: SaveTweet
      try {
        const res2 = await axios.post(
          "https://savetweet.net/api/ajaxSearch",
          { q: twitterUrl },
          { timeout: 30000 }
        );
        
        if (res2.data && res2.data.download) {
          videoUrl = res2.data.download[0]?.url;
        }
      } catch {
        // API 3: Twitsave
        const res3 = await axios.get(
          `https://twitsave.com/info?url=${encodeURIComponent(twitterUrl)}`,
          { timeout: 30000 }
        );
        
        const match = res3.data.match(/https?:\/\/[^\s"']+\.mp4[^\s"']*/);
        if (match) {
          videoUrl = match[0];
        }
      }
    }

    if (!videoUrl) {
      throw new Error("Video tidak ditemukan atau tweet tidak berisi video");
    }

    // Download video
    const videoRes = await axios.get(videoUrl, {
      responseType: "arraybuffer",
      timeout: 120000,
      maxContentLength: 100 * 1024 * 1024 // 100MB
    });

    const videoBuffer = Buffer.from(videoRes.data);
    const videoSizeMB = (videoBuffer.length / (1024 * 1024)).toFixed(2);

    await sock.sendMessage(
      m.chat,
      {
        video: videoBuffer,
        caption: 
          `✅ *Twitter/X Download*\n\n` +
          `🔗 URL: ${twitterUrl}\n` +
          `📦 Size: ${videoSizeMB} MB\n` +
          `🎥 Quality: HD`
      },
      { quoted: m }
    );

    await m.react("✅");

  } catch (e) {
    console.error(e);
    await m.reply(
      `❌ *Download Error*\n\n` +
      `Gagal download: ${e.message}\n\n` +
      `Tips:\n` +
      `• Pastikan tweet berisi video\n` +
      `• Tweet mungkin private atau dihapus\n` +
      `• Video terlalu besar (max 100MB)\n` +
      `• Coba lagi beberapa saat`
    );
  }
};

handler.help = ["twitter <url>", "twdl <url>"];
handler.tags = ["download"];
handler.command = /^(twitter|twdl|twitterdl|xdl)$/i;
handler.limit = true;

export default handler;
