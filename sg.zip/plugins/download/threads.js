// plugins/download/threads.js — Download Threads video/image (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Threads Downloader
 * 🔧 Fungsi     : Download video/image dari Threads (Meta)
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

let handler = async (m, { sock, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `Contoh penggunaan:\n${usedPrefix + command} <url>\n\n` +
      `Contoh:\n` +
      `${usedPrefix + command} https://www.threads.net/@username/post/xxxxx`
    );
  }

  const threadsUrl = text.trim();

  if (!threadsUrl.includes("threads.net")) {
    return m.reply("❌ URL tidak valid! Gunakan link Threads yang benar.");
  }

  try {
    await m.reply("⏳ *Downloading...*\n\nMohon tunggu...");

    // Try API 1
    let result;
    try {
      const res1 = await axios.get(
        `https://api.threadsphotodownloader.com/v2/media?url=${encodeURIComponent(threadsUrl)}`,
        { timeout: 30000 }
      );
      result = res1.data;
    } catch {
      // Fallback API 2
      const res2 = await axios.post(
        "https://threaddownloader.net/api/download",
        { url: threadsUrl },
        { timeout: 30000 }
      );
      result = res2.data;
    }

    if (!result || !result.media) {
      throw new Error("Gagal mendapatkan media");
    }

    const mediaUrl = result.media.url || result.media[0]?.url;
    const mediaType = result.media.type || "image";

    if (!mediaUrl) {
      throw new Error("URL media tidak ditemukan");
    }

    // Download media
    const mediaRes = await axios.get(mediaUrl, {
      responseType: "arraybuffer",
      timeout: 60000
    });

    const mediaBuffer = Buffer.from(mediaRes.data);

    // Send media
    if (mediaType === "video") {
      await sock.sendMessage(
        m.chat,
        {
          video: mediaBuffer,
          caption: `✅ *Threads Download*\n\n🔗 URL: ${threadsUrl}\n📱 Type: Video`
        },
        { quoted: m }
      );
    } else {
      await sock.sendMessage(
        m.chat,
        {
          image: mediaBuffer,
          caption: `✅ *Threads Download*\n\n🔗 URL: ${threadsUrl}\n📷 Type: Image`
        },
        { quoted: m }
      );
    }

    await m.react("✅");

  } catch (e) {
    console.error(e);
    await m.reply(
      `❌ *Download Error*\n\n` +
      `Gagal download: ${e.message}\n\n` +
      `Tips:\n` +
      `• Pastikan URL valid dan bisa diakses\n` +
      `• Post mungkin private atau dihapus\n` +
      `• Coba lagi beberapa saat`
    );
  }
};

handler.help = ["threads <url>"];
handler.tags = ["download"];
handler.command = /^(threads|threaddl|threadsdl)$/i;
handler.limit = true;

export default handler;
