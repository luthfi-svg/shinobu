// plugins/download-aio.js — All In One Downloader dari Ourin MD 3
import axios from "axios";

const PLATFORMS = {
  tiktok: /tiktok\.com|vm\.tiktok/i,
  instagram: /instagram\.com|instagr\.am/i,
  facebook: /facebook\.com|fb\.watch|fb\.com/i,
  youtube: /youtu(be\.com|\.be)/i,
  twitter: /twitter\.com|x\.com/i,
  capcut: /capcut\.com/i,
  pinterest: /pinterest\.com|pin\.it/i,
  reddit: /reddit\.com|redd\.it/i,
  snackvideo: /snackvideo\.com/i,
  likee: /likee\.video/i,
};

function detectPlatform(url) {
  for (const [name, regex] of Object.entries(PLATFORMS)) {
    if (regex.test(url)) return name;
  }
  return null;
}

async function dlAPI(url, platform) {
  const base = "https://api.serverweb.qzz.io/download";
  const endpoints = {
    tiktok: `${base}/tiktok?apikey=skyy&url=${encodeURIComponent(url)}`,
    instagram: `${base}/instagram?apikey=skyy&url=${encodeURIComponent(url)}`,
    facebook: `${base}/facebook?apikey=skyy&url=${encodeURIComponent(url)}`,
    youtube: `${base}/youtube?apikey=skyy&url=${encodeURIComponent(url)}&type=video`,
    twitter: `https://api.nexray.eu.cc/download/twitter?url=${encodeURIComponent(url)}`,
    capcut: `https://api.nexray.eu.cc/download/capcut?url=${encodeURIComponent(url)}`,
    pinterest: `https://api.nexray.eu.cc/download/pinterest?url=${encodeURIComponent(url)}`,
    reddit: `https://api.nexray.eu.cc/download/reddit?url=${encodeURIComponent(url)}`,
    snackvideo: `https://api.nexray.eu.cc/download/snack?url=${encodeURIComponent(url)}`,
    likee: `https://api.nexray.eu.cc/download/likee?url=${encodeURIComponent(url)}`,
  };

  const endpoint = endpoints[platform];
  if (!endpoint) throw new Error("Platform tidak didukung");
  const { data } = await axios.get(endpoint, { timeout: 30000 });
  return data;
}

let handler = async (m, { sock }) => {
  const url = (m.text || "").trim();

  if (!url || !url.startsWith("http")) return m.reply(
    `📥 *ᴀʟʟ ɪɴ ᴏɴᴇ ᴅᴏᴡɴʟᴏᴀᴅᴇʀ*\n\n` +
    `> Kirim link dari platform apapun!\n\n` +
    `*Platform yang didukung:*\n` +
    `> TikTok, Instagram, Facebook\n` +
    `> YouTube, Twitter/X, CapCut\n` +
    `> Pinterest, Reddit, Snack Video, Likee\n\n` +
    `*Contoh:*\n> ${m.cmd} https://www.tiktok.com/@user/video/xxx`
  );

  const platform = detectPlatform(url);
  if (!platform) return m.reply("❌ Link tidak dikenali! Pastikan link dari platform yang didukung.");

  await m.react("🕕");
  await m.reply(`⏳ Mendownload dari *${platform.toUpperCase()}*...`);

  try {
    const data = await dlAPI(url, platform);

    const results = data?.result || data?.data || data?.results || (Array.isArray(data) ? data : [data]);
    const items = Array.isArray(results) ? results : [results];

    if (!items.length) throw new Error("Tidak ada media ditemukan");

    let sent = 0;
    for (const item of items.slice(0, 5)) {
      const dlUrl = item?.url || item?.url_download || item?.video || item?.image || item?.hd || item?.sd;
      const mime = item?.mimetype || item?.type || "";
      const title = item?.title || data?.title || platform.toUpperCase();

      if (!dlUrl) continue;

      const isVideo = /video|mp4/.test(mime) || /\.mp4|video/.test(dlUrl);
      const isAudio = /audio|mp3/.test(mime) || /\.mp3|audio/.test(dlUrl);

      if (isAudio) {
        await sock.sendMessage(m.chat, {
          audio: { url: dlUrl },
          mimetype: "audio/mpeg",
          fileName: `${title}.mp3`,
        }, { quoted: m });
      } else if (isVideo) {
        await sock.sendMessage(m.chat, {
          video: { url: dlUrl },
          caption: `📥 *${title}*`,
        }, { quoted: m });
      } else {
        await sock.sendMessage(m.chat, {
          image: { url: dlUrl },
          caption: `📥 *${title}*`,
        }, { quoted: m });
      }
      sent++;
    }

    if (sent === 0) throw new Error("Gagal kirim media");
    await m.react("✅");
  } catch (err) {
    await m.react("❌");
    m.reply(`❌ Gagal download dari ${platform}: ${err.message}`);
  }
};

handler.command = ["dl", "aio", "download", "unduh"];
handler.tags = ["Download"];
handler.help = ["dl <url>", "aio <url>"];
export default handler;