import axios from "axios"
import fs from "fs"
import path from "path"
import * as tar from "tar"
import AdmZip from "adm-zip"

let handler = async (m, { sock, text }) => {
  if (!text) return m.reply(`*example:*\n${m.cmd} axios`)

  try {
    let pkgName = text.trim()

    if (pkgName.includes("npmjs.com/package/")) {
      let url = new URL(pkgName)
      let parts = url.pathname.split("/").filter(v => v)

      if (parts[1].startsWith("@")) {
        pkgName = `${parts[1]}/${parts[2]}`
      } else {
        pkgName = parts[1]
      }
    }

    const info = await axios.get(`https://registry.npmjs.org/${encodeURIComponent(pkgName)}`)
    const version = info.data["dist-tags"].latest

    const meta = await axios.get(
      `https://registry.npmjs.org/${encodeURIComponent(pkgName)}/${version}`
    )

    const tarballUrl = meta.data.dist.tarball
    if (!tarballUrl) return m.reply("❌ Tarball tidak ditemukan untuk package ini.")

    await m.reply(`📦 Mengunduh *${pkgName} versi terbaru ${version}*...`)

    const tmpDir = path.join(process.cwd(), "tmp")
    if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true })

    const safeName = pkgName.replace(/[\/@]/g, "_")
    const tarballPath = path.join(tmpDir, `${safeName}-${version}.tgz`)
    const extractPath = path.join(tmpDir, `${safeName}-${version}`)

    const res = await axios.get(tarballUrl, { responseType: "arraybuffer" })
    fs.writeFileSync(tarballPath, res.data)

    fs.mkdirSync(extractPath, { recursive: true })
    await tar.x({ file: tarballPath, cwd: extractPath, strip: 1 })

    const zip = new AdmZip()
    zip.addLocalFolder(extractPath)

    const zipPath = path.join(tmpDir, `${safeName}-${version}.zip`)
    zip.writeZip(zipPath)

    await sock.sendMessage(
      m.chat,
      {
        document: fs.readFileSync(zipPath),
        mimetype: "application/zip",
        fileName: `${safeName}-${version}.zip`,
        caption: `✅ Berhasil mengunduh *${pkgName}@${version}*`
      },
      { quoted: m }
    )

    fs.unlinkSync(tarballPath)
    fs.rmSync(extractPath, { recursive: true, force: true })
    fs.unlinkSync(zipPath)

  } catch (err) {
    console.error(err)
    m.reply("❌ Gagal mengunduh package.\nPastikan nama package atau link benar.\n\n" + err.message)
  }
}

handler.help = ['npm']
handler.tags = ['download']
handler.command = ['npmdl', 'npm']
handler.owner = true

export default handler;