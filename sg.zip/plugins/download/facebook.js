// plugins/download/facebook.js — Download video dari Facebook (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Facebook Downloader
 * 🔧 Fungsi     : Download video dari Facebook
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

let handler = async (m, { sock, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `Contoh penggunaan:\n${usedPrefix + command} <url>\n\n` +
      `Contoh:\n` +
      `${usedPrefix + command} https://www.facebook.com/watch?v=xxxxx\n` +
      `${usedPrefix + command} https://fb.watch/xxxxx`
    );
  }

  const url = text.trim();

  if (!url.includes("facebook.com") && !url.includes("fb.watch")) {
    return m.reply("❌ URL tidak valid! Gunakan link Facebook yang benar.");
  }

  try {
    await m.reply("⏳ *Downloading...*\n\nMohon tunggu...");

    // Try API 1
    let videoUrl, title;
    
    try {
      const res1 = await axios.post(
        "https://www.getfbstuff.com/api/video",
        { url: url },
        { timeout: 30000 }
      );
      
      videoUrl = res1.data?.sd || res1.data?.hd;
      title = res1.data?.title || "Facebook Video";
    } catch {
      // Fallback API 2
      const res2 = await axios.get(
        `https://api.neoxr.eu/api/facebook?url=${encodeURIComponent(url)}&apikey=free`,
        { timeout: 30000 }
      );
      
      videoUrl = res2.data?.data?.url;
      title = res2.data?.data?.title || "Facebook Video";
    }

    if (!videoUrl) {
      throw new Error("Video URL tidak ditemukan");
    }

    // Download video
    const videoRes = await axios.get(videoUrl, {
      responseType: "arraybuffer",
      timeout: 120000,
      maxContentLength: 100 * 1024 * 1024
    });

    const videoBuffer = Buffer.from(videoRes.data);
    const videoSizeMB = (videoBuffer.length / (1024 * 1024)).toFixed(2);

    await sock.sendMessage(
      m.chat,
      {
        video: videoBuffer,
        caption: 
          `✅ *Facebook Download*\n\n` +
          `📝 Title: ${title}\n` +
          `📦 Size: ${videoSizeMB} MB`
      },
      { quoted: m }
    );

    await m.react("✅");

  } catch (e) {
    console.error(e);
    await m.reply(
      `❌ *Download Error*\n\n` +
      `Gagal download: ${e.message}\n\n` +
      `Tips:\n` +
      `• Pastikan video public\n` +
      `• Video terlalu besar (max 100MB)\n` +
      `• Coba lagi beberapa saat`
    );
  }
};

handler.help = ["facebook <url>", "fb <url>"];
handler.tags = ["download"];
handler.command = /^(facebook|fb|fbdl)$/i;
handler.limit = true;

export default handler;
