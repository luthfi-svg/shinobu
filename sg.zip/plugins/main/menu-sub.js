// plugins/main/menu-sub.js — List Menu Handler — Style Ourin v3.1

const CAT_EMOJI = {
  owner:"👑",main:"🏠",group:"👥",fun:"🎭",game:"🎯",rpg:"🗡️",
  download:"📥",tools:"🛠️",ai:"🤖",search:"🔍",sticker:"🖼️",
  religi:"☪️",info:"ℹ️",user:"📊",primbon:"🔮",maker:"🎨",
  store:"🏪",pterodactyl:"🖥️",convert:"🔄",random:"🎲",
};

const CAT_ORDER = [
  "owner","main","group","fun","game","rpg","download","tools","ai",
  "search","sticker","religi","info","user","primbon","maker",
  "store","pterodactyl","convert","random",
];

function toMonoUpperBold(t) {
  const mp = {A:"𝗔",B:"𝗕",C:"𝗖",D:"𝗗",E:"𝗘",F:"𝗙",G:"𝗚",H:"𝗛",I:"𝗜",J:"𝗝",K:"𝗞",L:"𝗟",M:"𝗠",N:"𝗡",O:"𝗢",P:"𝗣",Q:"𝗤",R:"𝗥",S:"𝗦",T:"𝗧",U:"𝗨",V:"𝗩",W:"𝗪",X:"𝗫",Y:"𝗬",Z:"𝗭"," ":" "};
  return t.toUpperCase().split("").map(c => mp[c]||c).join("");
}

function collectCategories(ownerMode = false) {
  const toArr = v => !v ? [] : Array.isArray(v) ? v : [v];
  let cats = {};
  for (let file in global.plugins) {
    const plug = global.plugins[file];
    if (!plug) continue;
    const tags = toArr(plug.tags);
    const cmds = plug.help ? toArr(plug.help) : toArr(plug.command);
    if (!tags.length || !cmds.length) continue;
    for (const rawTag of tags) {
      const key = String(rawTag).toLowerCase();
      if (key === "owner" && !ownerMode) continue;
      if (!cats[key]) cats[key] = new Set();
      cmds.forEach(c => { if (c) cats[key].add(c.toString().split(" ")[0]); });
    }
  }
  return cats;
}

function getSortedCats(cats) {
  return [
    ...CAT_ORDER.filter(k => cats[k]),
    ...Object.keys(cats).filter(k => !CAT_ORDER.includes(k)).sort(),
  ];
}

let handler = async (m, { sock, command, args }) => {
  const cats = collectCategories(m.isOwner);
  const sorted = getSortedCats(cats);

  // ── .listmenu — tampilkan semua command per kategori ──
  if (command === "listmenu" || command === "allcmd") {
    let txt = `📋 *𝗦𝗘𝗠𝗨𝗔 𝗠𝗘𝗡𝗨 ${global.botname.toUpperCase()}*\n\n`;

    for (const key of sorted) {
      const emoji = CAT_EMOJI[key] || "📁";
      const cmds = Array.from(cats[key]).sort();
      txt += `╭─〔 ${emoji} *${toMonoUpperBold(key)}* 〕─⬣\n`;
      cmds.forEach(c => { txt += `│  ✦ ${global.prefix}${c}\n`; });
      txt += `╰─⬣ _${cmds.length} command_\n\n`;
    }

    txt += `\n🌐 ${global.linkChannel || ""}\n👥 ${global.linkGrup || ""}`;

    return sock.sendMessage(m.chat, {
      text: txt,
      contextInfo: {
        isForwarded: true,
        forwardingScore: 9,
        forwardedNewsletterMessageInfo: {
          newsletterJid: global.idChannel || "120363400911374213@newsletter",
          newsletterName: global.botname,
          serverMessageId: 127,
        },
      },
    }, { quoted: m.verifiedQuoted });
  }

  // ── .kategori — tampilkan list kategori interaktif ──
  if (command === "kategori") {
    const totalCmd = sorted.reduce((a, k) => a + cats[k].size, 0);
    const rows = sorted.map(key => {
      const emoji = CAT_EMOJI[key] || "📁";
      return {
        title: `${emoji} ${toMonoUpperBold(key)}`,
        description: `✦ ${cats[key].size} command tersedia`,
        id: `${global.prefix}cat_${key}`,
      };
    });

    const body =
      `📋 *𝗞𝗔𝗧𝗘𝗚𝗢𝗥𝗜 𝗠𝗘𝗡𝗨*\n\n` +
      `╭─〔 📊 *𝗜𝗡𝗙𝗢* 〕─⬣\n` +
      `│ ✦ Total Kategori: *${sorted.length}*\n` +
      `│ ✦ Total Command: *${totalCmd}*\n` +
      `│ ✦ Prefix: *${global.prefix}*\n` +
      `╰─⬣\n\n` +
      sorted.map(key => {
        const emoji = CAT_EMOJI[key] || "📁";
        return `${emoji} *${toMonoUpperBold(key)}* — ${cats[key].size} cmd`;
      }).join("\n") +
      `\n\nPilih kategori dari tombol di bawah 👇`;

    try {
      await sock.relayMessage(m.chat, {
        viewOnceMessage: {
          message: {
            messageContextInfo: {},
            interactiveMessage: {
              header: { title: "📋 Kategori Menu", hasMediaAttachment: false },
              body: { text: body },
              footer: { text: `${global.botname} v${global.versibot}` },
              contextInfo: {
                isForwarded: true,
                forwardingScore: 9,
                participant: "0@s.whatsapp.net",
                quotedMessage: { conversation: global.botname },
                mentionedJid: [m.sender],
                forwardedNewsletterMessageInfo: {
                  newsletterJid: global.idChannel || "120363400911374213@newsletter",
                  newsletterName: global.botname,
                  serverMessageId: 127,
                },
              },
              nativeFlowMessage: {
                messageParamsJson: "",
                buttons: [
                  {
                    name: "single_select",
                    buttonParamsJson: JSON.stringify({
                      title: "📂 Pilih Kategori",
                      sections: [{ title: "Daftar Kategori", rows }],
                    }),
                  },
                  {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                      display_text: "📋 Lihat Semua Menu",
                      id: `${global.prefix}listmenu`,
                    }),
                  },
                ],
              },
            },
          },
        },
      }, {});
    } catch {
      // Fallback teks
      let txt = `📋 *𝗞𝗔𝗧𝗘𝗚𝗢𝗥𝗜 𝗠𝗘𝗡𝗨*\n\n`;
      sorted.forEach(key => {
        const emoji = CAT_EMOJI[key] || "📁";
        txt += `${emoji} *${toMonoUpperBold(key)}* — ${cats[key].size} cmd\n`;
        txt += `   › \`${global.prefix}cat_${key}\`\n`;
      });
      await sock.sendMessage(m.chat, { text: txt }, { quoted: m.verifiedQuoted });
    }
  }

  // ── .cat_xxx — tampilkan isi 1 kategori ──
  if (command.startsWith("cat_")) {
    const key = command.replace("cat_", "").toLowerCase();
    if (!cats[key]) return m.reply(`❌ Kategori *${key}* tidak ditemukan!`);

    const emoji = CAT_EMOJI[key] || "📁";
    const cmds = Array.from(cats[key]).sort();

    let txt =
      `╭─〔 ${emoji} *${toMonoUpperBold(key)}* 〕─⬣\n` +
      `│ ✦ Total: *${cmds.length} command*\n` +
      `╰─⬣\n\n` +
      `╭─☰ ${toMonoUpperBold(key)}\n` +
      cmds.map(c => `> ${global.prefix}${c}`).join("\n") +
      `\n╰─⬣`;

    return sock.sendMessage(m.chat, {
      text: txt,
      contextInfo: {
        isForwarded: true,
        forwardingScore: 9,
        forwardedNewsletterMessageInfo: {
          newsletterJid: global.idChannel || "120363400911374213@newsletter",
          newsletterName: global.botname,
          serverMessageId: 127,
        },
      },
    }, { quoted: m.verifiedQuoted });
  }
};

const ALL_CATS = Object.keys(CAT_EMOJI);
handler.command = [
  "listmenu", "allcmd", "kategori",
  ...ALL_CATS.map(k => `cat_${k}`),
];
handler.tags = ["main"];
handler.help = ["listmenu", "kategori"];
export default handler;