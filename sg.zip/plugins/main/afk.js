// plugins/main/afk.js — Set status AFK dengan alasan (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : AFK (Away From Keyboard)
 * 🔧 Fungsi     : Set status AFK dengan alasan, auto notif saat di-mention
 * ⚡ By Shinobu
 * ─────────────────────────
 */

// Import (ESM)
import fs from "fs";

// Database AFK (persistent)
const afkFile = "./database/afk.json";

// Helper: Load AFK data
const loadAFK = () => {
  try {
    if (!fs.existsSync("./database")) fs.mkdirSync("./database", { recursive: true });
    if (!fs.existsSync(afkFile)) fs.writeFileSync(afkFile, "{}");
    return JSON.parse(fs.readFileSync(afkFile, "utf-8"));
  } catch {
    return {};
  }
};

// Helper: Save AFK data
const saveAFK = (data) => {
  try {
    fs.writeFileSync(afkFile, JSON.stringify(data, null, 2));
  } catch (e) {
    console.error("Error saving AFK data:", e);
  }
};

// Handler
let handler = async (m, { text }) => {
  const sender = m.sender;
  
  // Load data AFK
  let afkData = loadAFK();

  // Set AFK
  const reason = text || "Tidak ada alasan";
  const timestamp = Date.now();

  afkData[sender] = {
    reason: reason,
    time: timestamp
  };

  saveAFK(afkData);

  // Kirim konfirmasi
  await m.reply(
    `✅ *Status AFK Aktif*\n\n` +
    `👤 User: @${sender.split("@")[0]}\n` +
    `📝 Alasan: ${reason}\n` +
    `⏰ Waktu: ${new Date(timestamp).toLocaleString("id-ID")}\n\n` +
    `_Kamu akan otomatis kembali saat mengirim pesan_`
  );

  // Reaction
  await m.react("💤");
};

// Metadata
handler.command = ["afk"];
handler.tags = ["main"];
handler.help = ["afk <alasan>"];
handler.limit = false;
handler.owner = false;
handler.group = false;
handler.admin = false;
handler.premium = false;

export default handler;
