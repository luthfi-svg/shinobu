// plugins/main/menu.js — Menu Utama (SHINOBU MD v1.3)
/**
 * ───「 SHINOBU MD v1.3 」───
 * 📝 Plugin     : Menu Utama
 * 🎨 Design     : Clean • Rapi • Profesional
 * 📱 Support    : ALL WhatsApp Version
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import os from "os";
import fs from "fs";
import path from "path";

// ── FONT ──────────────────────────────
function toFont(t) {
  const mp = {A:"𝗔",B:"𝗕",C:"𝗖",D:"𝗗",E:"𝗘",F:"𝗙",G:"𝗚",H:"𝗛",I:"𝗜",J:"𝗝",K:"𝗞",L:"𝗟",M:"𝗠",N:"𝗡",O:"𝗢",P:"𝗣",Q:"𝗤",R:"𝗥",S:"𝗦",T:"𝗧",U:"𝗨",V:"𝗩",W:"𝗪",X:"𝗫",Y:"𝗬",Z:"𝗭"};
  return t.toUpperCase().split("").map(c => mp[c] || c).join("");
}

function greet() {
  const h = parseInt(new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta", hour: "numeric", hour12: false }));
  if (h < 5)  return { t: "Selamat Malam", e: "🌙" };
  if (h < 11) return { t: "Selamat Pagi", e: "☀️" };
  if (h < 15) return { t: "Selamat Siang", e: "🔆" };
  if (h < 18) return { t: "Selamat Sore", e: "🌤️" };
  return { t: "Selamat Malam", e: "🌙" };
}

function up(s) {
  const d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600),
        m = Math.floor((s % 3600) / 60), sc = Math.floor(s % 60);
  return d ? `${d}d ${h}j` : h ? `${h}j ${m}m` : `${m}m ${sc}d`;
}

const EMOJI = { main:"🏠",owner:"👑",group:"👥",download:"📥",tools:"🛠️",ai:"🤖",user:"👤",game:"🎮",fun:"🎉",search:"🔍",sticker:"✨",religi:"🕌",info:"ℹ️",convert:"🔄",store:"🛒",pterodactyl:"🖥️",rpg:"⚔️",maker:"🎨" };
const LABEL = { main:"Home",owner:"Owner",group:"Group",download:"Download",tools:"Tools",ai:"AI",user:"User",game:"Game",fun:"Fun",search:"Search",sticker:"Sticker",religi:"Religi",info:"Info",convert:"Convert",store:"Store",pterodactyl:"Cloud",rpg:"RPG",maker:"Maker" };
const ORDER = ["main","owner","group","fun","game","rpg","maker","download","tools","ai","search","sticker","religi","info","user","store","pterodactyl"];
const SKIP = ["anime","downloader","primbon","uploader","plugins","random"];

function scan() {
  const toArr = v => !v ? [] : (Array.isArray(v) ? v : [v]);
  let cat = {};
  if (global.plugins) {
    for (const f in global.plugins) {
      const p = global.plugins[f]; if (!p) continue;
      const tags = toArr(p.tags), cmds = p.help ? toArr(p.help) : toArr(p.command);
      if (!tags.length && cmds.length) {
        let t = "tools";
        if (f.includes("owner")) t = "owner"; else if (f.includes("group")) t = "group";
        else if (f.includes("ai")) t = "ai"; else if (f.includes("download")) t = "download";
        else if (f.includes("fun")) t = "fun"; else if (f.includes("game")) t = "game";
        else if (f.includes("rpg")) t = "rpg"; else if (f.includes("maker")) t = "maker";
        tags.push(t);
      }
      if (!tags.length || !cmds.length) continue;
      for (const t of tags) {
        const k = t.toLowerCase(); if (SKIP.includes(k)) continue;
        if (!cat[k]) cat[k] = { k, cmds: [] };
        cmds.forEach(c => { const cmd = c.toString().split(" ")[0]; if (cmd && !cat[k].cmds.includes(cmd)) cat[k].cmds.push(cmd); });
      }
    }
  }
  try { const d = path.join(process.cwd(), "plugins"); if (fs.existsSync(d)) scanF(d, cat); } catch {}
  return cat;
}

function scanF(dir, cat) {
  for (const f of fs.readdirSync(dir)) {
    const fp = path.join(dir, f);
    if (fs.statSync(fp).isDirectory()) { scanF(fp, cat); continue; }
    if (!f.endsWith(".js") || f.includes("menu")) continue;
    try {
      const c = fs.readFileSync(fp, "utf-8");
      let cmds=[], tags=[], help=[];
      const cm = c.match(/handler\.command\s*=\s*\[([^\]]+)\]/); if (cm) cmds=cm[1].split(",").map(v=>v.trim().replace(/['"]/g,""));
      const tm = c.match(/handler\.tags\s*=\s*\[([^\]]+)\]/); if (tm) tags=tm[1].split(",").map(v=>v.trim().replace(/['"]/g,""));
      const hm = c.match(/handler\.help\s*=\s*\[([^\]]+)\]/); if (hm) help=hm[1].split(",").map(v=>v.trim().replace(/['"]/g,""));
      const fi = help.length ? help : cmds;
      if (!tags.length && fi.length) { let t="tools"; const fn=path.basename(path.dirname(fp)); if (["owner","group","ai","download","fun","game","rpg","maker","tools"].includes(fn)) t=fn; tags.push(t); }
      if (tags.length && fi.length) {
        for (const t of tags) {
          const k=t.toLowerCase(); if (SKIP.includes(k)) continue;
          if (!cat[k]) cat[k]={k,cmds:[]};
          fi.forEach(c=>{ const cmd=c.split(" ")[0]; if (cmd&&!cat[k].cmds.includes(cmd)) cat[k].cmds.push(cmd); });
        }
      }
    } catch {}
  }
}

function sort(cat) { return [...ORDER.filter(k=>cat[k]).map(k=>cat[k]), ...Object.keys(cat).filter(k=>!ORDER.includes(k)&&!SKIP.includes(k)).sort().map(k=>cat[k])]; }

// ══════════════════════════════════════
let handler = async (m,{sock,command}) => {
  await sock.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

  const categories = scan();
  const sorted = sort(categories);

  if (command?.startsWith("cat_")) {
    const found = sorted.find(c => c.k === command.replace("cat_", ""));
    if (!found) {
      await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      return sock.sendMessage(m.chat, { text: `⚠️ Kategori tidak ditemukan.\nKetik *${global.prefix}menu*` }, { quoted: m.verifiedQuoted });
    }
    const cmds = [...found.cmds].sort();
    await sock.sendMessage(m.chat, {
      text: `${EMOJI[found.k]||"📌"} *${toFont(LABEL[found.k]||found.k)}*\n${cmds.length} perintah\n\n${cmds.map(c => `▸ ${global.prefix}${c}`).join("\n")}\n\n💡 *${global.prefix}menu* kembali`
    }, { quoted: m.verifiedQuoted });
    await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
    return;
  }

  const total = sorted.reduce((a,c) => a + c.cmds.length, 0);
  const uptime = up(process.uptime());
  const ram = ((os.totalmem() - os.freemem()) / 1024 / 1024).toFixed(0);
  const tmem = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2);
  const user = global.db?.users?.[m.sender] || {};
  const isP = m.isPremium;
  const g = greet();
  const eM = isP ? (global.energiPremium || 500) : (global.energiDefault || 50);

  let menu =
`╭──────────────────────────────────╮
│  ${toFont(global.botname || "SHINOBU MD")}
│  ${g.e} ${g.t}, ${m.pushName || "Kak"}
╰──────────────────────────────────╯

  ◈  *BOT INFO*
  │  Versi    : v${global.versibot || "1.3"}
  │  Prefix   : ${global.prefix}
  │  Mode     : ${sock.public ? "Public" : "Self"}
  │  Uptime   : ${uptime}
  │  RAM      : ${ram}MB / ${tmem}GB
  │  Kategori : ${sorted.length}  •  ${total} cmd

  ◈  *YOUR INFO*
  │  Role     : ${m.isOwner ? "👑 Owner" : isP ? "💎 Premium" : "🙍 User"}
  │  Energi   : ${user.energi ?? eM}/${eM}
  │  Koin     : ${user.koin || 0}  •  XP : ${user.exp || 0}
  │  Status   : ${user.registered ? "✅ Registered" : "⚠️ Not Registered"}

╔══════════════════════════════════╗
║      📂  *DAFTAR MENU*  📂      ║
╚══════════════════════════════════╝
`;

  for (const {k, cmds} of sorted) {
    const label = toFont(LABEL[k] || k);
    const emoji = EMOJI[k] || "📌";
    const list = [...cmds].sort().map(c => `  ▸ ${global.prefix}${c}`).join("\n");
    menu += `┌─ ${emoji} *${label}* — ${cmds.length} cmd\n${list}\n└──────────────────────────────\n\n`;
  }

  menu += `💡 Ketik *${global.prefix}menu* untuk melihat menu ini.\n⚡ Shinobu MD v${global.versibot || "1.3"} • By Shinobu`;

  await sock.sendMessage(m.chat, { text: menu }, { quoted: m.verifiedQuoted });
  await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
};

handler.command = ["menu","help","?","m",/^cat_/i];
handler.tags = ["main"];
handler.help = ["menu"];
export default handler;