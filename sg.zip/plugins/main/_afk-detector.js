// plugins/main/_afk-detector.js — Deteksi user AFK kembali atau di-mention (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : AFK Detector
 * 🔧 Fungsi     : Auto unset AFK saat user kirim pesan & notif saat di-mention
 * ⚡ By Shinobu
 * ─────────────────────────
 */

// Import (ESM)
import fs from "fs";

// Database AFK
const afkFile = "./database/afk.json";

// Helper: Load AFK data
const loadAFK = () => {
  try {
    if (!fs.existsSync("./database")) fs.mkdirSync("./database", { recursive: true });
    if (!fs.existsSync(afkFile)) fs.writeFileSync(afkFile, "{}");
    return JSON.parse(fs.readFileSync(afkFile, "utf-8"));
  } catch {
    return {};
  }
};

// Helper: Save AFK data
const saveAFK = (data) => {
  try {
    fs.writeFileSync(afkFile, JSON.stringify(data, null, 2));
  } catch (e) {
    console.error("Error saving AFK data:", e);
  }
};

// Helper: Format durasi waktu
const formatDuration = (ms) => {
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (days > 0) return `${days} hari ${hours % 24} jam`;
  if (hours > 0) return `${hours} jam ${minutes % 60} menit`;
  if (minutes > 0) return `${minutes} menit ${seconds % 60} detik`;
  return `${seconds} detik`;
};

// Handler
let handler = async (m, { sock }) => {
  const sender = m.sender;
  let afkData = loadAFK();

  // 1. CEK: User yang AFK ini kirim pesan? (UNSET AFK)
  if (afkData[sender]) {
    const afkInfo = afkData[sender];
    const duration = Date.now() - afkInfo.time;
    const durationText = formatDuration(duration);

    // Hapus dari database
    delete afkData[sender];
    saveAFK(afkData);

    // Notifikasi kembali
    await m.reply(
      `🔔 *User Kembali dari AFK*\n\n` +
      `👤 @${sender.split("@")[0]} sudah kembali!\n` +
      `⏱️ Durasi AFK: ${durationText}\n` +
      `📝 Alasan: ${afkInfo.reason}`
    );

    await m.react("👋");
  }

  // 2. CEK: Ada yang mention user AFK? (NOTIFIKASI)
  const mentionedJids = m.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
  
  for (let mentioned of mentionedJids) {
    if (afkData[mentioned]) {
      const afkInfo = afkData[mentioned];
      const duration = Date.now() - afkInfo.time;
      const durationText = formatDuration(duration);

      await sock.sendMessage(m.chat, {
        text: 
          `💤 *User sedang AFK*\n\n` +
          `👤 @${mentioned.split("@")[0]} sedang AFK\n` +
          `📝 Alasan: ${afkInfo.reason}\n` +
          `⏱️ Durasi: ${durationText}\n\n` +
          `_User akan kembali nanti_`,
        mentions: [mentioned]
      });

      await m.react("💤");
    }
  }

  // 3. CEK: Ada yang reply pesan dari user AFK? (NOTIFIKASI)
  const quotedSender = m.message?.extendedTextMessage?.contextInfo?.participant;
  if (quotedSender && afkData[quotedSender] && !afkData[sender]) {
    const afkInfo = afkData[quotedSender];
    const duration = Date.now() - afkInfo.time;
    const durationText = formatDuration(duration);

    await sock.sendMessage(m.chat, {
      text:
        `💤 *User sedang AFK*\n\n` +
        `👤 @${quotedSender.split("@")[0]} sedang AFK\n` +
        `📝 Alasan: ${afkInfo.reason}\n` +
        `⏱️ Durasi: ${durationText}\n\n` +
        `_User akan kembali nanti_`,
      mentions: [quotedSender]
    });
  }

  return true;
};

// Metadata
handler.before = true; // Jalankan sebelum command handler lain
handler.priority = 1;  // Priority tinggi

export default handler;
