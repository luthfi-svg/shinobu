// plugins/owner/join.js — Join group via invite link (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Join Group
 * 🔧 Fungsi     : Bot join group via invite link
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `Contoh penggunaan:\n${usedPrefix + command} <link>\n\n` +
      `Contoh:\n` +
      `${usedPrefix + command} https://chat.whatsapp.com/xxxxx\n\n` +
      `Bot akan join ke group tersebut`
    );
  }

  // Extract invite code from link
  let code = text.trim();
  
  // Remove https://chat.whatsapp.com/ if present
  code = code.replace(/https?:\/\/chat\.whatsapp\.com\//gi, "");
  
  // Remove any extra characters
  code = code.split(/\s+/)[0];

  if (code.length < 20) {
    return m.reply(
      `❌ *Invalid Link*\n\n` +
      `Link group tidak valid!\n\n` +
      `Format yang benar:\n` +
      `https://chat.whatsapp.com/xxxxx`
    );
  }

  try {
    await m.reply("⏳ *Joining Group...*\n\nSedang join ke group...");

    // Join group
    const result = await sock.groupAcceptInvite(code);

    await m.reply(
      `✅ *Joined Successfully*\n\n` +
      `Group ID: ${result}\n` +
      `⏰ ${new Date().toLocaleString("id-ID")}\n\n` +
      `Bot sudah masuk ke group!`
    );

    await m.react("✅");

  } catch (e) {
    console.error(e);
    
    let errorMsg = e.message;
    if (errorMsg.includes("406")) {
      errorMsg = "Link sudah expired atau tidak valid";
    } else if (errorMsg.includes("already")) {
      errorMsg = "Bot sudah ada di group tersebut";
    }

    await m.reply(
      `❌ *Join Failed*\n\n` +
      `Gagal join group: ${errorMsg}\n\n` +
      `Possible reasons:\n` +
      `• Link expired atau invalid\n` +
      `• Bot sudah ada di group\n` +
      `• Group sudah full\n` +
      `• Bot di-ban dari group`
    );
  }
};

handler.help = ["join <link>"];
handler.tags = ["owner"];
handler.command = /^(join|joingc)$/i;
handler.owner = true;

export default handler;
