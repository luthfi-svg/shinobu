// plugins/owner/broadcast.js — Broadcast message ke semua chat (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Broadcast
 * 🔧 Fungsi     : Kirim pesan ke semua chat (private & group)
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, text, usedPrefix, command }) => {
  if (!text && !m.quoted) {
    return m.reply(
      `Contoh penggunaan:\n` +
      `${usedPrefix + command} <teks>\n` +
      `Atau reply pesan dengan ${usedPrefix + command}\n\n` +
      `Contoh:\n` +
      `${usedPrefix + command} Halo semua! Bot update fitur baru!\n\n` +
      `Mode:\n` +
      `• ${usedPrefix}bc - Broadcast ke semua\n` +
      `• ${usedPrefix}bcgc - Broadcast ke group only\n` +
      `• ${usedPrefix}bcpc - Broadcast ke private chat only`
    );
  }

  const bcText = text || m.quoted?.text || m.quoted?.caption || "";
  
  if (!bcText) {
    return m.reply("❌ Tidak ada teks yang akan dibroadcast!");
  }

  try {
    await m.reply("⏳ *Broadcasting...*\n\nSedang mengirim pesan, tunggu sebentar...");

    // Get all chats
    const chats = Object.entries(await sock.chats || {});
    
    let successCount = 0;
    let failCount = 0;
    let targetChats = [];

    // Filter chats based on command
    for (const [jid, chat] of chats) {
      if (jid === "status@broadcast") continue; // Skip status
      if (jid === m.chat) continue; // Skip current chat
      
      const isGroup = jid.endsWith("@g.us");
      const isPrivate = jid.endsWith("@s.whatsapp.net");

      if (command === "bcgc" && !isGroup) continue;
      if (command === "bcpc" && !isPrivate) continue;
      if ((command === "bc" || command === "broadcast") && !(isGroup || isPrivate)) continue;

      targetChats.push({ jid, isGroup });
    }

    // Send broadcast message
    const broadcastMessage = 
      `╭━━━━━━━━━━━━━━━━━━━╮\n` +
      `┃  📢 *BROADCAST*\n` +
      `┃  🤖 Bot: ${global.botname}\n` +
      `┃  ⏰ ${new Date().toLocaleString("id-ID")}\n` +
      `╰━━━━━━━━━━━━━━━━━━━╯\n\n` +
      `${bcText}\n\n` +
      `_Pesan broadcast dari owner bot_`;

    for (const { jid, isGroup } of targetChats) {
      try {
        // Add delay to prevent spam detection
        await new Promise(resolve => setTimeout(resolve, 1000));

        await sock.sendMessage(jid, {
          text: broadcastMessage
        });

        successCount++;
      } catch (e) {
        console.error(`Broadcast error to ${jid}:`, e.message);
        failCount++;
      }
    }

    // Send result
    await m.reply(
      `✅ *Broadcast Complete*\n\n` +
      `📊 Statistics:\n` +
      `• Total Target: ${targetChats.length}\n` +
      `• Success: ${successCount} chat\n` +
      `• Failed: ${failCount} chat\n` +
      `• Mode: ${command === "bcgc" ? "Group Only" : command === "bcpc" ? "Private Only" : "All Chats"}\n\n` +
      `⏰ Duration: ~${Math.ceil(targetChats.length / 60)} menit`
    );

    await m.react("✅");

  } catch (e) {
    console.error(e);
    await m.reply(
      `❌ *Broadcast Error*\n\n` +
      `Gagal broadcast: ${e.message}\n\n` +
      `Tips:\n` +
      `• Pastikan bot tidak di-ban/restricted\n` +
      `• Jangan spam broadcast terlalu sering\n` +
      `• Delay antar pesan minimal 1 detik`
    );
  }
};

handler.help = ["broadcast <teks>", "bc <teks>", "bcgc <teks>", "bcpc <teks>"];
handler.tags = ["owner"];
handler.command = /^(broadcast|bc|bcgc|bcpc)$/i;
handler.owner = true;

export default handler;
