
let handler = async (m, { sock, isOwner }) => {

  try {
    await sock.query({
      tag: "iq",
      attrs: {
        to: "@s.whatsapp.net",
        type: "set",
        xmlns: "w:profile:picture",
      },
      content: [
        {
          tag: "picture",
          attrs: { type: "image" },
          content: Buffer.alloc(0) 
        },
      ],
    })

    await m.reply("Berhasil menghapus profile bot ✅")

  } catch (err) {
    console.error(err)
    m.reply("Gagal menghapus profile bot ❌")
  }
}

handler.help = ["delppbot"]
handler.tags = ["owner"]
handler.command = ["delpp", "delppbot"]
handler.owner = true

export default handler;