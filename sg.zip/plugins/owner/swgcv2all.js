// plugins/owner/swgcv2all.js — Status Grup V2 All (SHINOBU MD v1.2)
import { generateWAMessage } from "dekzymarket-cyber";
import pkg from "file-type";
const { fileTypeFromBuffer } = pkg;

function buildSyntheticSwGcRawMessage(sock, remoteJid, innerMessage, messageId) {
  const botJid = sock.user?.id?.split(":")[0] + "@s.whatsapp.net";
  return {
    key: { remoteJid, fromMe: true, id: messageId, participant: botJid },
    message: { groupStatusMessageV2: { message: innerMessage } },
    messageTimestamp: Math.floor(Date.now() / 1000),
  };
}

let handler = async (m, { sock, text, command }) => {
  const prefix = global.prefix || ".";
  const qmsg = m.quoted || m;
  const mime = qmsg.mime || qmsg.msg?.mimetype || "";
  let rawContent = null;

  if (/image|video|audio/.test(mime)) {
    let buffer;
    try {
      buffer = m.quoted ? await m.quoted.download() : await m.download();
    } catch (e) {}

    if (!buffer) {
      return sock.sendMessage(m.chat, { text: "❌ Gagal mengunduh media." }, { quoted: m.verifiedQuoted });
    }

    let detectedMime = mime;
    try {
      const fileType = await fileTypeFromBuffer(buffer);
      if (fileType) detectedMime = fileType.mime;
    } catch (e) {}

    if (detectedMime.startsWith("image/")) {
      rawContent = { image: buffer, caption: text || "" };
    } else if (detectedMime.startsWith("video/")) {
      rawContent = { video: buffer, caption: text || "" };
    } else if (detectedMime.startsWith("audio/")) {
      rawContent = { audio: buffer, mimetype: "audio/mpeg", ptt: qmsg.msg?.ptt || false };
    } else {
      return sock.sendMessage(m.chat, { text: "❌ Format media tidak didukung." }, { quoted: m.verifiedQuoted });
    }
  } else if (text && text.trim()) {
    rawContent = { text };
  } else {
    return sock.sendMessage(m.chat, {
      text:
        `╭──────────────────────────────╮\n` +
        `  📱  *SW GC V2 ALL*\n` +
        `╰──────────────────────────────╯\n\n` +
        `  📌 *Cara Pakai:*\n` +
        `  ${prefix}swgcv2all <teks>\n` +
        `  ${prefix}swgcv2all (reply media)\n\n` +
        `  💡 *Contoh:*\n` +
        `  ${prefix}swgcv2all Halo semua!\n` +
        `  ${prefix}swgcv2all (reply foto)\n\n` +
        `  🌐 Kirim status ke SEMUA grup!\n\n` +
        `  👤 *By Valzz*`
    }, { quoted: m.verifiedQuoted });
  }

  await sock.sendMessage(m.chat, { react: { text: "🔄", key: m.key } });

  try {
    const groups = await sock.groupFetchAllParticipating();
    const groupIds = Object.keys(groups);

    if (groupIds.length === 0) {
      await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      return sock.sendMessage(m.chat, { text: "❌ Bot tidak berada di grup manapun." }, { quoted: m.verifiedQuoted });
    }

    await sock.sendMessage(m.chat, {
      text:
        `╭──────────────────────────────╮\n` +
        `  ⏳  *BROADCAST STATUS...*\n` +
        `╰──────────────────────────────╯\n\n` +
        `  🌐 Total Grup : ${groupIds.length}\n` +
        `  📱 Media      : ${rawContent.text ? "Teks" : rawContent.image ? "Gambar" : rawContent.video ? "Video" : "Audio"}\n\n` +
        `  _Proses mungkin memakan waktu..._\n\n` +
        `  👤 *By Valzz*`
    }, { quoted: m.verifiedQuoted });

    let successCount = 0, failCount = 0;

    for (const targetGroupId of groupIds) {
      try {
        let baseContent = {};
        if (rawContent.image) baseContent = { image: rawContent.image, caption: rawContent.caption || "" };
        else if (rawContent.video) baseContent = { video: rawContent.video, caption: rawContent.caption || "" };
        else if (rawContent.audio) baseContent = { audio: rawContent.audio, mimetype: rawContent.mimetype || "audio/mpeg", ptt: rawContent.ptt || false };
        else if (rawContent.text) baseContent = { text: rawContent.text };

        const genMsg = await generateWAMessage(targetGroupId, baseContent, {
          userJid: sock.user.id, upload: sock.waUploadToServer,
        });

        const msgType = Object.keys(genMsg.message).find(
          (k) => k.endsWith("Message") && k !== "senderKeyDistributionMessage"
        );

        let mediaMessage = {};
        if (msgType) {
          mediaMessage[msgType] = genMsg.message[msgType];
          const newContextInfo = {
            isGroupStatus: true,
            statusSourceType: rawContent.text ? 4 : rawContent.audio ? 3 : rawContent.video ? 1 : 0,
            featureEligibilities: { canBeReshared: true, canBeSentToParticipants: true },
            statusAttributions: [{ type: 10 }],
            statusAudienceMetadata: { audienceType: 1 },
          };
          if (mediaMessage[msgType].contextInfo) {
            Object.assign(mediaMessage[msgType].contextInfo, newContextInfo);
          } else {
            mediaMessage[msgType].contextInfo = newContextInfo;
          }
        }

        const messageId = genMsg.key.id;
        const finalMessage = buildSyntheticSwGcRawMessage(sock, targetGroupId, mediaMessage, messageId);
        await sock.relayMessage(targetGroupId, finalMessage.message, { messageId });
        successCount++;
      } catch {
        failCount++;
      }
    }

    await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    await sock.sendMessage(m.chat, {
      text:
        `╭──────────────────────────────╮\n` +
        `  ✅  *BROADCAST SELESAI!*\n` +
        `╰──────────────────────────────╯\n\n` +
        `  🌐 Total Grup : ${groupIds.length}\n` +
        `  ✅ Sukses     : ${successCount}\n` +
        `  ❌ Gagal      : ${failCount}\n\n` +
        `  📱 Status V2 (Ring Pink) berhasil!\n\n` +
        `  👤 *By Valzz*`
    }, { quoted: m.verifiedQuoted });

  } catch (error) {
    console.error("[SWGCV2ALL] Error:", error.message);
    await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    await sock.sendMessage(m.chat, {
      text: `❌ Gagal broadcast!\n📡 ${error.message}\n\n👤 *By Valzz*`
    }, { quoted: m.verifiedQuoted });
  }
};

handler.command = ["swgcv2all", "statusgrupv2all"];
handler.tags = ["owner"];
handler.help = ["swgcv2all <teks>", "swgcv2all (reply media)"];
handler.owner = true;

export default handler;