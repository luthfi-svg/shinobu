// plugins/owner/update.js — Update bot from GitHub (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Update Bot
 * 🔧 Fungsi     : Update bot dari GitHub repository
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import { exec } from "child_process";
import { promisify } from "util";

const execPromise = promisify(exec);

let handler = async (m) => {
  try {
    await m.reply("⏳ *Updating Bot...*\n\nPulling latest changes from GitHub...");

    // Git pull
    const { stdout, stderr } = await execPromise("git pull", { timeout: 30000 });

    if (stderr && stderr.includes("error")) {
      throw new Error(stderr);
    }

    await m.reply(
      `✅ *Update Complete*\n\n` +
      `📝 Changes:\n\`\`\`\n${stdout || "Already up to date"}\n\`\`\`\n\n` +
      `♻️ Bot akan restart otomatis...`
    );

    // Restart bot
    setTimeout(() => {
      process.exit(0);
    }, 2000);

  } catch (e) {
    console.error(e);
    await m.reply(
      `❌ *Update Failed*\n\n` +
      `Error: ${e.message}\n\n` +
      `Tips:\n` +
      `• Pastikan folder .git ada\n` +
      `• Check koneksi internet\n` +
      `• Manual: git pull && npm start`
    );
  }
};

handler.help = ["update"];
handler.tags = ["owner"];
handler.command = /^(update|gitpull)$/i;
handler.owner = true;

export default handler;
