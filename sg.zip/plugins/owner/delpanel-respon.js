let handler = async (m, { text }) => {
  if (!text) return m.reply("ID server tidak ditemukan")

  try {
    const res = await fetch(domain + "/api/application/servers", {
      method: "GET",
      headers: {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": "Bearer " + apikey
      }
    })

    const data = await res.json()
    const servers = data.data

    let serverName
    let serverSection
    let found = false

    for (const server of servers) {
      const s = server.attributes

      if (Number(text) === s.id) {
        serverName = s.name
        serverSection = s.name.toLowerCase()
        found = true

        await fetch(domain + `/api/application/servers/${s.id}`, {
          method: "DELETE",
          headers: {
            "Authorization": "Bearer " + apikey
          }
        })

        break
      }
    }

    if (!found) return m.reply("ID server tidak ditemukan")

    const userRes = await fetch(domain + "/api/application/users", {
      method: "GET",
      headers: {
        "Authorization": "Bearer " + apikey
      }
    })

    const users = (await userRes.json()).data

    for (const user of users) {
      const u = user.attributes
      if (u.first_name.toLowerCase() === serverSection) {
        await fetch(domain + `/api/application/users/${u.id}`, {
          method: "DELETE",
          headers: {
            "Authorization": "Bearer " + apikey
          }
        })
        break
      }
    }

    m.reply(`Berhasil Menghapus Server Panel ✅\nID Server: ${text}\nNama: ${serverName}`)

  } catch (err) {
    console.error(err)
    m.reply("Terjadi kesalahan saat menghapus server")
  }
}

handler.command = ['delpanel-response']
handler.tags = ["plugins"];
handler.help = 'delpanel-response';
handler.owner = true

export default handler;