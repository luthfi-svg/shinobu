// plugins/owner/restart.js — Restart bot process (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Restart Bot
 * 🔧 Fungsi     : Restart bot process
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m) => {
  await m.reply("♻️ *Restarting Bot...*\n\nBot akan restart dalam beberapa detik...");
  
  await m.react("♻️");
  
  // Exit process, PM2 will auto-restart
  process.exit(0);
};

handler.help = ["restart"];
handler.tags = ["owner"];
handler.command = /^(restart|reboot)$/i;
handler.owner = true;

export default handler;
