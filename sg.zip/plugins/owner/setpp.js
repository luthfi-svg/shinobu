import fs from "fs"

let handler = async (m, { sock, mime, isOwner }) => {
  if (!mime || !/image/.test(mime)) {
    return m.reply("Kirim / reply gambar dengan caption .setpp")
  }

  try {
    const qmsg = m.qmsg
    const bufferPath = await sock.downloadAndSaveMediaMessage(qmsg)
    const { img } = await global.generateProfilePicture(bufferPath)

    await sock.query({
      tag: "iq",
      attrs: {
        to: "@s.whatsapp.net",
        type: "set",
        xmlns: "w:profile:picture",
      },
      content: [
        {
          tag: "picture",
          attrs: { type: "image" },
          content: img,
        },
      ],
    })

    await m.reply("Berhasil mengganti profile bot ✅")

    fs.unlinkSync(bufferPath)

  } catch (err) {
    console.error(err)
    m.reply("Gagal mengganti profile bot ❌")
  }
}

handler.help = ["setppbot"]
handler.tags = ["owner"]
handler.command = ["setpp", "setppbot"]
handler.owner = true

export default handler;