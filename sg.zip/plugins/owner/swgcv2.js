// plugins/owner/swgcv2.js — Status Grup V2 (SHINOBU MD v1.2)
import { generateWAMessage } from "dekzymarket-cyber";
import pkg from "file-type";
const { fileTypeFromBuffer } = pkg;

if (!global.pendingSwgcV2) global.pendingSwgcV2 = new Map();

let handler = async (m, { sock, args, text, command }) => {
  const prefix = global.prefix || ".";

  if (args[0] === "--confirm" && args[1]) {
    const targetGroupId = args[1];
    const pendingData = global.pendingSwgcV2.get(m.sender);

    if (!pendingData) {
      return sock.sendMessage(m.chat, {
        text: "⚠️ *Tidak ada data pending.* Silakan kirim ulang media + .swgcv2"
      }, { quoted: m.verifiedQuoted });
    }

    try {
      let groupName = "Grup";
      try {
        const meta = await sock.groupMetadata(targetGroupId);
        groupName = meta.subject;
      } catch {}

      await sock.sendMessage(m.chat, { react: { text: "🔄", key: m.key } });

      const rawContent = pendingData.rawContent;
      let baseContent = {};

      if (rawContent.image) baseContent = { image: rawContent.image, caption: rawContent.caption || "" };
      else if (rawContent.video) baseContent = { video: rawContent.video, caption: rawContent.caption || "" };
      else if (rawContent.audio) baseContent = { audio: rawContent.audio, mimetype: rawContent.mimetype || "audio/mpeg", ptt: rawContent.ptt || false };
      else if (rawContent.text) baseContent = { text: rawContent.text };

      const genMsg = await generateWAMessage(targetGroupId, baseContent, {
        userJid: sock.user.id,
        upload: sock.waUploadToServer,
      });

      const msgType = Object.keys(genMsg.message).find(
        (k) => k.endsWith("Message") && k !== "senderKeyDistributionMessage"
      );

      let mediaMessage = {};
      if (msgType) {
        mediaMessage[msgType] = genMsg.message[msgType];
        const newContextInfo = {
          isGroupStatus: true,
          statusSourceType: rawContent.text ? 4 : rawContent.audio ? 3 : rawContent.video ? 1 : 0,
          featureEligibilities: { canBeReshared: true, canReceiveMultiReact: false },
          statusAttributions: [{ type: 10 }],
          statusAudienceMetadata: { audienceType: 1 },
        };
        if (mediaMessage[msgType].contextInfo) {
          Object.assign(mediaMessage[msgType].contextInfo, newContextInfo);
        } else {
          mediaMessage[msgType].contextInfo = newContextInfo;
        }
      }

      const payload = { groupStatusMessageV2: { message: mediaMessage } };
      const messageId = genMsg.key.id;

      await sock.relayMessage(targetGroupId, payload, { messageId });

      await sock.sendMessage(m.chat, {
        text: `✅ Berhasil up SW (V2 Ring Pink) ke grup *${groupName}*\n\n👤 *By Valzz*`
      }, { quoted: m.verifiedQuoted });

      global.pendingSwgcV2.delete(m.sender);

    } catch (error) {
      await sock.sendMessage(m.chat, {
        text: `❌ *Error*\n\nGagal posting story V2.\n_${error.message}_\n\n👤 *By Valzz*`
      }, { quoted: m.verifiedQuoted });
    }
    return;
  }

  let rawContent = {};
  const qmsg = m.quoted || m;
  const mime = qmsg.mime || qmsg.msg?.mimetype || "";

  if (/image|video|audio/.test(mime)) {
    try {
      const buffer = m.quoted ? await m.quoted.download() : await m.download();
      if (!buffer) {
        return sock.sendMessage(m.chat, { text: "❌ Gagal mengambil media." }, { quoted: m.verifiedQuoted });
      }

      let detectedMime = mime;
      try {
        const fileType = await fileTypeFromBuffer(buffer);
        if (fileType) detectedMime = fileType.mime;
      } catch (e) {
        // Gunakan mime default
      }

      if (detectedMime.startsWith("image/")) {
        rawContent = { image: buffer, caption: text || "" };
      } else if (detectedMime.startsWith("video/")) {
        rawContent = { video: buffer, caption: text || "" };
      } else if (detectedMime.startsWith("audio/")) {
        rawContent = { audio: buffer, mimetype: detectedMime || "audio/mpeg", ptt: qmsg.msg?.ptt || false };
      } else {
        return sock.sendMessage(m.chat, { text: "❌ Format media tidak didukung." }, { quoted: m.verifiedQuoted });
      }
    } catch (e) {
      return sock.sendMessage(m.chat, { text: "❌ Gagal mengunduh media: " + e.message }, { quoted: m.verifiedQuoted });
    }
  } else if (text && text.trim() && args[0] !== "--confirm") {
    rawContent.text = text;
  } else {
    return sock.sendMessage(m.chat, {
      text:
        `╭──────────────────────────────╮\n` +
        `  📱  *STATUS GRUP V2*\n` +
        `╰──────────────────────────────╯\n\n` +
        `  📌 *Cara Pakai:*\n` +
        `  ${prefix}swgcv2 <teks>\n` +
        `  ${prefix}swgcv2 (reply media)\n\n` +
        `  💡 *Contoh:*\n` +
        `  ${prefix}swgcv2 Halo semua!\n` +
        `  ${prefix}swgcv2 (reply foto)\n\n` +
        `  👤 *By Valzz*`
    }, { quoted: m.verifiedQuoted });
  }

  global.pendingSwgcV2.set(m.sender, { rawContent, timestamp: Date.now() });

  try {
    const groups = await sock.groupFetchAllParticipating();
    const groupList = Object.entries(groups);

    if (groupList.length === 0) {
      return sock.sendMessage(m.chat, { text: "⚠️ *Bot tidak berada di grup manapun.*" }, { quoted: m.verifiedQuoted });
    }

    const groupRows = groupList.map(([id, meta]) => ({
      title: meta.subject || "Unknown Group",
      description: id,
      id: `${prefix}swgcv2 --confirm ${id}`,
    }));

    const mediaType = rawContent.text ? "Teks" : rawContent.image ? "Gambar" : rawContent.video ? "Video" : rawContent.audio ? "Audio" : "Media";

    await sock.relayMessage(m.chat, {
      viewOnceMessage: {
        message: {
          messageContextInfo: {},
          interactiveMessage: {
            header: { title: "📋 Pilih Grup untuk Post Story V2", hasMediaAttachment: false },
            body: { text: `Media: *${mediaType}*\nTotal Grup: *${groupList.length}*\n\n_Pilih grup dari daftar:_` },
            footer: { text: global.botname || "Shinobu MD" },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: JSON.stringify({
                    title: "📋 Pilih Grup",
                    sections: [{ title: "Daftar Grup", rows: groupRows }],
                  }),
                },
                {
                  name: "quick_reply",
                  buttonParamsJson: JSON.stringify({
                    display_text: "❌ Batal",
                    id: `${prefix}cancelswgcv2`,
                  }),
                },
              ],
            },
          },
        },
      },
    }, {});

  } catch (error) {
    await sock.sendMessage(m.chat, {
      text: `❌ *Error*\n\nGagal mengambil daftar grup.\n_${error.message}_\n\n👤 *By Valzz*`
    }, { quoted: m.verifiedQuoted });
    global.pendingSwgcV2.delete(m.sender);
  }
};

handler.command = ["swgcv2", "statusgrupv2"];
handler.tags = ["owner"];
handler.help = ["swgcv2 <teks>", "swgcv2 (reply media)"];
handler.owner = true;

export default handler;