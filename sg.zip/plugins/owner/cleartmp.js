// plugins/owner/cleartmp.js — Clear temporary files (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Clear Temp
 * 🔧 Fungsi     : Hapus file temporary untuk free space
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import fs from "fs";
import path from "path";

let handler = async (m, { usedPrefix, command }) => {
  try {
    await m.reply("⏳ *Cleaning...*\n\nSedang hapus file temporary...");

    const tempDirs = ["./temp", "./tmp", "./cache"];
    let totalSize = 0;
    let totalFiles = 0;

    for (const dir of tempDirs) {
      if (!fs.existsSync(dir)) continue;

      const files = fs.readdirSync(dir);
      
      for (const file of files) {
        const filePath = path.join(dir, file);
        
        try {
          const stats = fs.statSync(filePath);
          
          if (stats.isFile()) {
            totalSize += stats.size;
            fs.unlinkSync(filePath);
            totalFiles++;
          }
        } catch (e) {
          console.error(`Error deleting ${filePath}:`, e.message);
        }
      }
    }

    const sizeMB = (totalSize / (1024 * 1024)).toFixed(2);

    await m.reply(
      `✅ *Cleanup Complete*\n\n` +
      `📁 Files Deleted: ${totalFiles}\n` +
      `💾 Space Freed: ${sizeMB} MB\n` +
      `📂 Directories Cleaned: ${tempDirs.length}\n\n` +
      `⏰ ${new Date().toLocaleString("id-ID")}`
    );

    await m.react("✅");

  } catch (e) {
    console.error(e);
    await m.reply(
      `❌ *Cleanup Error*\n\n` +
      `Gagal cleanup: ${e.message}`
    );
  }
};

handler.help = ["cleartmp", "cleartemp"];
handler.tags = ["owner"];
handler.command = /^(cleartmp|cleartemp|cleancache)$/i;
handler.owner = true;

export default handler;
