// plugins/owner/saveplugin.js — Save Plugin Auto Folder (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Save Plugin Auto Folder
 * 📂 Fungsi     : Simpan plugin sesuai folder & tags
 * 👤 By Valzz
 * ─────────────────────────
 */

import fs from "fs";
import path from "path";

const PLUGIN_DIR = "./plugins";

// ==================== DETECT FOLDER ====================
function detectFolder(code) {
  // Cek folder dari content/import path
  const folderMatch = code.match(/plugins\/([a-zA-Z]+)\//);
  if (folderMatch) return folderMatch[1].toLowerCase();

  // Cek dari tags handler
  const tagsMatch = code.match(/handler\.tags\s*=\s*\[?"?([a-zA-Z]+)"?\]?/);
  if (tagsMatch) {
    const tag = tagsMatch[1].toLowerCase();
    const folderMap = {
      main: "main", owner: "owner", group: "group",
      download: "download", downloader: "download",
      tools: "tools", tool: "tools",
      ai: "ai", artificial: "ai",
      user: "user", users: "user",
      game: "game", games: "game",
      fun: "fun", funny: "fun",
      search: "search", searching: "search",
      sticker: "sticker", stickers: "sticker",
      religi: "religi", religion: "religi",
      info: "info", information: "info",
      convert: "convert", converter: "convert",
      store: "store", shop: "store",
      pterodactyl: "pterodactyl", panel: "pterodactyl",
      random: "random", rpg: "rpg",
      maker: "maker", create: "maker",
      uploader: "uploader", upload: "uploader",
    };
    if (folderMap[tag]) return folderMap[tag];
    return tag;
  }

  // Cek dari command
  const cmdMatch = code.match(/handler\.command\s*=\s*\[([^\]]+)\]/);
  if (cmdMatch) {
    const cmds = cmdMatch[1];
    if (cmds.includes("menu") || cmds.includes("help")) return "main";
    if (cmds.includes("owner") || cmds.includes("anticulik")) return "owner";
    if (cmds.includes("group") || cmds.includes("kick")) return "group";
    if (cmds.includes("yt") || cmds.includes("play") || cmds.includes("download")) return "download";
    if (cmds.includes("ai") || cmds.includes("claude") || cmds.includes("gemini")) return "ai";
    if (cmds.includes("game") || cmds.includes("tebak")) return "game";
    if (cmds.includes("sticker") || cmds.includes("stiker")) return "sticker";
    if (cmds.includes("search") || cmds.includes("cari")) return "search";
    if (cmds.includes("store") || cmds.includes("shop")) return "store";
    if (cmds.includes("panel") || cmds.includes("pterodactyl")) return "pterodactyl";
    if (cmds.includes("fake") || cmds.includes("make")) return "maker";
  }

  return "tools"; // default
}

// ==================== DETECT COMMAND ====================
function detectCommands(code) {
  const cmdMatch = code.match(/handler\.command\s*=\s*\[([^\]]+)\]/);
  if (cmdMatch) {
    return cmdMatch[1].split(",").map(c => c.trim().replace(/['"`]/g, "")).filter(Boolean);
  }
  return [];
}

// ==================== DETECT TAGS ====================
function detectTags(code) {
  const tagsMatch = code.match(/handler\.tags\s*=\s*\[?"?([a-zA-Z]+)"?\]?/);
  if (tagsMatch) {
    return [tagsMatch[1].toLowerCase()];
  }
  const tagsArrMatch = code.match(/handler\.tags\s*=\s*\[([^\]]+)\]/);
  if (tagsArrMatch) {
    return tagsArrMatch[1].split(",").map(t => t.trim().replace(/['"`]/g, "")).filter(Boolean);
  }
  return [detectFolder(code)];
}

// ==================== BUILD MENU ====================
function buildMenuText(prefix) {
  return (
    `╭══════════════════════════════╮\n` +
    `│   💾  *SAVE PLUGIN*  💾    │\n` +
    `│   ──────────────────────    │\n` +
    `│   Auto Detect Folder & Tag │\n` +
    `│   👤 By Valzz              │\n` +
    `╰══════════════════════════════╯\n\n` +
    `  📌 *Cara Pakai:*\n` +
    `  ${prefix}saveplugin namafile.js\n` +
    `  (reply kode plugin)\n\n` +
    `  💡 *Contoh:*\n` +
    `  ${prefix}saveplugin tes.js\n` +
    `  (reply kode)\n\n` +
    `  📂 *Auto Detect:*\n` +
    `  Folder & Tags dari kode!\n\n` +
    `  👤 *By Valzz*`
  );
}

// ==================== HANDLER ====================
let handler = async (m, { sock, text, command }) => {
  const prefix = global.prefix || ".";

  if (!text || !m.quoted) {
    return sock.sendMessage(m.chat, {
      text: buildMenuText(prefix)
    }, { quoted: m.verifiedQuoted });
  }

  let filename = text.trim();
  if (!filename.endsWith(".js") && !filename.endsWith(".cjs")) {
    return sock.sendMessage(m.chat, {
      text: "⚠️ Format file wajib .js atau .cjs\n\n👤 *By Valzz*"
    }, { quoted: m.verifiedQuoted });
  }

  // Ambil kode dari reply
  let code = "";
  const quotedMsg = m.quoted || m;

  if (quotedMsg.text) {
    code = quotedMsg.text;
  } else if (quotedMsg.mtype === "documentMessage") {
    try {
      const buffer = await sock.downloadMediaMessage(quotedMsg);
      if (buffer) code = buffer.toString("utf-8");
    } catch (e) {
      return sock.sendMessage(m.chat, {
        text: `❌ Gagal membaca file!\n📡 ${e.message}\n\n👤 *By Valzz*`
      }, { quoted: m.verifiedQuoted });
    }
  }

  if (!code) {
    return sock.sendMessage(m.chat, {
      text: "⚠️ Reply pesan kode plugin atau kirim file .js\n\n👤 *By Valzz*"
    }, { quoted: m.verifiedQuoted });
  }

  // ===== DETECT FOLDER =====
  const folder = detectFolder(code);
  const folderPath = path.join(PLUGIN_DIR, folder);

  // Buat folder kalo belum ada
  if (!fs.existsSync(folderPath)) {
    fs.mkdirSync(folderPath, { recursive: true });
  }

  const filePath = path.join(folderPath, filename);

  // ===== DETECT TAGS & COMMANDS =====
  const tags = detectTags(code);
  const commands = detectCommands(code);

  try {
    fs.writeFileSync(filePath, code);

    let infoText =
      `╭──────────────────────────────╮\n` +
      `  ✅  *PLUGIN TERSIMPAN!*\n` +
      `╰──────────────────────────────╯\n\n` +
      `  📛 File    : *${filename}*\n` +
      `  📂 Folder  : *${folder}*\n` +
      `  🏷️ Tags    : *${tags.join(", ") || "auto"}*\n` +
      `  🔧 Command : *${commands.length ? commands.join(", ") : "auto"}*\n` +
      `  📍 Path    : ${filePath}\n\n` +
      `  👤 *By Valzz*`;

    await sock.sendMessage(m.chat, { text: infoText }, { quoted: m.verifiedQuoted });
    await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    // ===== HOT RELOAD (opsional) =====
    try {
      // Hapus cache require
      delete require.cache[require.resolve(filePath)];
      // Reload plugin ke global
      if (global.plugins) {
        const plugin = await import(filePath);
        if (plugin.default) {
          global.plugins[filePath] = plugin.default;
        }
      }
    } catch (e) {
      console.log("[SavePlugin] Hot reload gagal:", e.message);
    }

  } catch (error) {
    console.error("[SAVEPLUGIN ERROR]", error);
    await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    await sock.sendMessage(m.chat, {
      text:
        `╭──────────────────────────────╮\n` +
        `  ❌  *GAGAL!*\n` +
        `╰──────────────────────────────╯\n\n` +
        `  📡 ${error.message}\n\n` +
        `  👤 *By Valzz*`
    }, { quoted: m.verifiedQuoted });
  }
};

handler.tags = ["owner"];
handler.help = ["saveplugin <namafile.js>"];
handler.command = ["saveplugin", "sp", "sv", "svp", "addplugin"];
handler.owner = true;

export default handler;