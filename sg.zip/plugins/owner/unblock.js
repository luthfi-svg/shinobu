// plugins/owner/unblock.js — Unblock user (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Unblock User
 * 🔧 Fungsi     : Unblock user yang di-block
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, text }) => {
  let who;
  
  if (m.quoted) {
    who = m.quoted.sender;
  } else if (text) {
    who = text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
  } else if (m.mentionedJid && m.mentionedJid[0]) {
    who = m.mentionedJid[0];
  } else {
    return m.reply(
      `Cara pakai:\n` +
      `• Tag orangnya\n` +
      `• Reply pesannya\n` +
      `• Ketik nomor`
    );
  }

  try {
    await sock.updateBlockStatus(who, "unblock");
    
    await m.reply(
      `✅ *User Unblocked*\n\n` +
      `👤 Number: @${who.split("@")[0]}\n` +
      `✅ Status: Unblocked\n\n` +
      `User bisa chat dengan bot lagi`
    );

  } catch (e) {
    console.error(e);
    await m.reply(`❌ Gagal unblock: ${e.message}`);
  }
};

handler.help = ["unblock <@user>"];
handler.tags = ["owner"];
handler.command = /^(unblock|unblok)$/i;
handler.owner = true;

export default handler;
