// plugins/owner/autoreply.js — Auto reply setup (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Auto Reply
 * 🔧 Fungsi     : Setup auto reply untuk keyword tertentu
 * ⚡ By Shinobu
 * ─────────────────────────
 */

// Global storage for auto replies
global.autoReplies = global.autoReplies || {};

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `Contoh penggunaan:\n\n` +
      `Set auto reply:\n${usedPrefix + command} add <keyword>|<reply>\n\n` +
      `Hapus auto reply:\n${usedPrefix + command} del <keyword>\n\n` +
      `Lihat list:\n${usedPrefix + command} list\n\n` +
      `Contoh:\n` +
      `${usedPrefix + command} add halo|Halo juga!\n` +
      `${usedPrefix + command} del halo`
    );
  }

  const args = text.split(" ");
  const action = args[0].toLowerCase();

  if (action === "add") {
    const content = args.slice(1).join(" ");
    const parts = content.split("|");
    
    if (parts.length < 2) {
      return m.reply("❌ Format salah! Gunakan: add keyword|reply");
    }

    const keyword = parts[0].trim().toLowerCase();
    const reply = parts.slice(1).join("|").trim();

    global.autoReplies[keyword] = reply;

    await m.reply(
      `✅ *Auto Reply Added*\n\n` +
      `🔑 Keyword: ${keyword}\n` +
      `💬 Reply: ${reply}`
    );

  } else if (action === "del" || action === "delete") {
    const keyword = args.slice(1).join(" ").trim().toLowerCase();

    if (!global.autoReplies[keyword]) {
      return m.reply(`❌ Keyword "${keyword}" tidak ditemukan!`);
    }

    delete global.autoReplies[keyword];

    await m.reply(`✅ Auto reply untuk "${keyword}" dihapus!`);

  } else if (action === "list") {
    const replies = Object.entries(global.autoReplies);

    if (replies.length === 0) {
      return m.reply("❌ Belum ada auto reply yang di-set!");
    }

    let list = `📋 *Auto Reply List*\n\n`;
    replies.forEach(([keyword, reply], i) => {
      list += `${i + 1}. ${keyword} → ${reply}\n`;
    });

    await m.reply(list);

  } else {
    return m.reply("❌ Action tidak valid! Gunakan: add, del, atau list");
  }
};

handler.help = ["autoreply <add/del/list>"];
handler.tags = ["owner"];
handler.command = /^(autoreply|ar)$/i;
handler.owner = true;

export default handler;
