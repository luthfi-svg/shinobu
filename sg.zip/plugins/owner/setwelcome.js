// plugins/owner/setwelcometype.js — Set Welcome Type (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Set Welcome Type
 * 👋 Fungsi     : Atur tipe welcome message
 * 👤 By Valzz
 * ─────────────────────────
 */

import axios from "axios";
import { prepareWAMessageMedia } from "dekzymarket-cyber";

const VARIANTS = {
  1: { name: "Canvas Image", desc: "Gambar canvas dengan foto profil", emoji: "🎨" },
  2: { name: "Carousel Cards", desc: "Kartu carousel interaktif dengan tombol", emoji: "🃏" },
  3: { name: "Text Only", desc: "Pesan teks minimalis tanpa gambar", emoji: "📝" },
  4: { name: "Group", desc: "ContextInfo group style", emoji: "👥" },
  5: { name: "Simple", desc: "Pesan teks simple + foto profile", emoji: "✨" },
  6: { name: "Video", desc: "Kirim video perkenalan", emoji: "🎥" },
  7: { name: "Interactive Quoted", desc: "Interactive message dengan fake quoted", emoji: "💬" },
};

let handler = async (m, { sock }) => {
  const args = m.text ? m.text.trim().split(/\s+/) : [];
  const variant = args[0]?.toLowerCase();
  const current = global.db?.settings?.welcomeType || 1;

  // ===== UBAH TIPE =====
  if (variant && /^v?[1-7]$/.test(variant)) {
    if (!m.isOwner) {
      return sock.sendMessage(m.chat, {
        text: "⚠️ Khusus Owner!\n\n👤 *By Valzz*"
      }, { quoted: m.verifiedQuoted });
    }

    const id = parseInt(variant.replace("v", ""));
    if (!global.db) global.db = { settings: {} };
    if (!global.db.settings) global.db.settings = {};
    global.db.settings.welcomeType = id;

    return sock.sendMessage(m.chat, {
      text:
        `✅ *WELCOME TYPE DIUBAH*\n\n` +
        `${VARIANTS[id].emoji} *V${id} — ${VARIANTS[id].name}*\n` +
        `_${VARIANTS[id].desc}_\n\n` +
        `👤 *By Valzz*`
    }, { quoted: m.verifiedQuoted });
  }

  // ===== MENU =====
  const rows = [];
  for (const [id, val] of Object.entries(VARIANTS)) {
    const mark = parseInt(id) === current ? " ✓" : "";
    rows.push({
      title: `${val.emoji} V${id}${mark} — ${val.name}`,
      description: val.desc,
      id: `${global.prefix}setwelcometype v${id}`,
    });
  }

  const bodyText =
    `👋🎨 *WELCOME TYPE*\n\n` +
    `Atur tampilan pesan welcome saat member baru masuk grup 🚪✨\n` +
    `Tipe aktif saat ini: *V${current} — ${VARIANTS[current].name}* 🎯\n\n` +
    `*PENJELASAN TIPE:*\n\n` +
    `- *V1 Canvas Image* 🎨 — Bot membuat gambar canvas otomatis berisi foto profil dan nama member yang baru join, lalu dikirim sebagai gambar\n\n` +
    `- *V2 Carousel Cards* 🃏 — Menampilkan kartu carousel interaktif yang bisa di-swipe lengkap dengan tombol action, cocok untuk grup yang ingin tampilan modern\n\n` +
    `- *V3 Text Only* 📝 — Pesan teks biasa tanpa gambar sama sekali, ringan dan minimalis\n\n` +
    `- *V4 Group* 👥 — Menggunakan contextInfo bergaya group forward, tampilan rapi dengan label newsletter\n\n` +
    `- *V5 Simple* ✨ — Pesan teks sederhana disertai foto profile member yang join, tidak terlalu mencolok namun informatif\n\n` +
    `- *V6 Video* 🎥 — Mengirimkan video sambutan menarik dilengkapi caption selamat datang untuk member\n\n` +
    `- *V7 Interactive Quoted* 💬 — Mengirimkan pesan interaktif dan fake quoted dari orang yang join\n\n` +
    `> Pilih tipe welcome dari tombol di bawah 👇\n\n` +
    `👤 *By Valzz*`;

  // Kirim interactive
  try {
    let thumbBuf = null;
    if (global.thumbnail) {
      try {
        const r = await axios.get(global.thumbnail, { responseType: "arraybuffer", timeout: 5000 });
        thumbBuf = Buffer.from(r.data);
      } catch {}
    }

    const nativeFlow = {
      messageParamsJson: JSON.stringify({
        bottom_sheet: {
          in_thread_buttons_limit: 1,
          divider_indices: [1, 999],
          list_title: "Daftar Tipe Welcome",
          button_title: "👋 Pilih Tipe Welcome",
        },
      }),
      buttons: [
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "👋 Pilih Tipe Welcome",
            sections: [{ title: "Daftar Tipe Welcome", rows }],
          }),
        },
      ],
    };

    if (thumbBuf) {
      const media = await prepareWAMessageMedia({ image: thumbBuf }, { upload: sock.waUploadToServer });
      await sock.relayMessage(m.chat, {
        viewOnceMessage: {
          message: {
            messageContextInfo: {},
            interactiveMessage: {
              header: { title: "", subtitle: "", hasMediaAttachment: true, imageMessage: media.imageMessage },
              body: { text: bodyText },
              footer: { text: "⚡ Shinobu MD v1.2 • By Valzz" },
              nativeFlowMessage: nativeFlow,
            },
          },
        },
      }, {});
    } else {
      await sock.relayMessage(m.chat, {
        viewOnceMessage: {
          message: {
            messageContextInfo: {},
            interactiveMessage: {
              header: { title: "👋 Welcome Type", subtitle: "", hasMediaAttachment: false },
              body: { text: bodyText },
              footer: { text: "⚡ Shinobu MD v1.2 • By Valzz" },
              nativeFlowMessage: nativeFlow,
            },
          },
        },
      }, {});
    }
  } catch (e) {
    console.error("[SETWELCOMETYPE]", e.message);
    await sock.sendMessage(m.chat, { text: bodyText }, { quoted: m.verifiedQuoted });
  }
};

handler.tags = ["owner"];
handler.help = ["setwelcometype"];
handler.command = ["setwelcometype", "welcometype", "welcomevariant", "welcomestyle"];
handler.owner = true;

export default handler;