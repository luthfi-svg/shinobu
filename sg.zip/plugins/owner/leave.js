// plugins/owner/leave.js — Bot leave dari group (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Leave Group
 * 🔧 Fungsi     : Bot keluar dari group
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock }) => {
  if (!m.isGroup) {
    return m.reply(
      `❌ *Group Only*\n\n` +
      `Command ini hanya bisa digunakan di group!`
    );
  }

  try {
    await m.reply(
      `👋 *Goodbye!*\n\n` +
      `Terima kasih sudah menggunakan bot.\n` +
      `Bot akan keluar dari group ini...\n\n` +
      `_Sampai jumpa lagi!_`
    );

    // Wait 2 seconds before leaving
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Leave group
    await sock.groupLeave(m.chat);

  } catch (e) {
    console.error(e);
    await m.reply(
      `❌ *Leave Failed*\n\n` +
      `Gagal keluar dari group: ${e.message}`
    );
  }
};

handler.help = ["leave"];
handler.tags = ["owner"];
handler.command = /^(leave|keluar|out)$/i;
handler.owner = true;
handler.group = true;

export default handler;
