// plugins/owner/block.js — Block user (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Block User
 * 🔧 Fungsi     : Block user dari bot
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, text }) => {
  let who;
  
  if (m.quoted) {
    who = m.quoted.sender;
  } else if (text) {
    who = text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
  } else if (m.mentionedJid && m.mentionedJid[0]) {
    who = m.mentionedJid[0];
  } else {
    return m.reply(
      `Cara pakai:\n` +
      `• Tag orangnya\n` +
      `• Reply pesannya\n` +
      `• Ketik nomor`
    );
  }

  try {
    await sock.updateBlockStatus(who, "block");
    
    await m.reply(
      `✅ *User Blocked*\n\n` +
      `👤 Number: @${who.split("@")[0]}\n` +
      `🚫 Status: Blocked\n\n` +
      `User tidak bisa chat dengan bot`
    );

  } catch (e) {
    console.error(e);
    await m.reply(`❌ Gagal block: ${e.message}`);
  }
};

handler.help = ["block <@user>"];
handler.tags = ["owner"];
handler.command = /^(block|blok)$/i;
handler.owner = true;

export default handler;
