// plugins/owner/sewabot.js — Sewa Bot + Anti Culik Cerdas (SHINOBU MD v1.2)
"use strict";

const BOT_NAME = global.botname || "Shinobu MD";
const OWNER_NUMBER = String(global.owner || "628xxx").replace(/[^0-9]/g, "");
const AUTO_LEAVE_CULIK = true;
const NOTIFY_OWNER = true;

function parseDuration(str) {
  if (["lifetime", "permanent", "forever", "unlimited"].includes(str?.toLowerCase())) return Infinity;
  const match = str?.match(/^(\d+)([iIdDmMyYhH])$/);
  if (!match) return null;
  const value = parseInt(match[1]);
  const unit = match[2].toLowerCase();
  const multiplier = { i: 60000, h: 3600000, d: 86400000, m: 2592000000, y: 31536000000 };
  return multiplier[unit] ? Date.now() + value * multiplier[unit] : null;
}

function formatDuration(str) {
  if (["lifetime", "permanent", "forever", "unlimited"].includes(str?.toLowerCase())) return "Permanent";
  const match = str?.match(/^(\d+)([iIdDmMyYhH])$/);
  if (!match) return str;
  const units = { i: "menit", h: "jam", d: "hari", m: "bulan", y: "tahun" };
  return `${match[1]} ${units[match[2].toLowerCase()] || match[2]}`;
}

function formatExpired(expiredAt) {
  if (expiredAt === Infinity) return "Permanent";
  return new Date(expiredAt).toLocaleString("id-ID", { timeZone: "Asia/Jakarta", day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" });
}

async function resolveGroupId(sock, input) {
  if (input.includes("chat.whatsapp.com/")) {
    const inviteCode = input.split("chat.whatsapp.com/")[1]?.split(/[\s?]/)[0];
    if (!inviteCode) return null;
    try { const m = await sock.groupGetInviteInfo(inviteCode); return m?.id ? { id: m.id, name: m.subject || "Unknown", inviteCode } : null; } catch { return null; }
  }
  const gid = input.includes("@g.us") ? input : input + "@g.us";
  try { const m = await sock.groupMetadata(gid); return { id: gid, name: m?.subject || "Unknown", inviteCode: null }; } catch { return { id: gid, name: "Unknown", inviteCode: null }; }
}

async function tryJoinGroup(sock, inviteCode, groupId) {
  if (!inviteCode) return { joined: false, reason: "Tidak ada invite code" };
  try {
    const botJid = sock.user?.id?.split(":")[0] + "@s.whatsapp.net";
    const meta = await sock.groupMetadata(groupId).catch(() => null);
    if (meta?.participants?.some(p => (p.id?.split(":")[0] + "@s.whatsapp.net") === botJid || p.id === botJid)) {
      return { joined: true, reason: "Bot sudah di grup" };
    }
    await sock.groupAcceptInvite(inviteCode);
    return { joined: true, reason: "Bot berhasil join" };
  } catch (e) { return { joined: false, reason: e.message }; }
}

// ==================== SMART CHECKER ====================
function isGroupSewa(groupId) {
  const sewa = global.db?.data?.sewa?.groups?.[groupId];
  if (!sewa) return false;
  if (!sewa.isLifetime && sewa.expiredAt > 0 && Date.now() > sewa.expiredAt) {
    delete global.db.data.sewa.groups[groupId];
    return false;
  }
  return true;
}

function isOwnerNum(sender) {
  const s = String(sender || "").split("@")[0];
  return s === OWNER_NUMBER;
}

// ==================== CHECK OWNER DI GRUP ====================
async function isOwnerInGroup(sock, groupId) {
  try {
    const meta = await sock.groupMetadata(groupId);
    if (!meta?.participants) return false;
    return meta.participants.some(p => {
      const pNum = String(p.id || "").split("@")[0].split(":")[0];
      return pNum === OWNER_NUMBER;
    });
  } catch { return false; }
}

function buildMenuText(prefix) {
  return (
    `╭══════════════════════════════╮\n` +
    `│   🤖 *SEWA + ANTI CULIK* 🤖 │\n` +
    `│   👤 By Valzz              │\n` +
    `╰══════════════════════════════╯\n\n` +
    `  📌 *Commands:*\n` +
    `  ${prefix}addsewa <link/id> <durasi>\n` +
    `  ${prefix}delsewa <link/id>\n` +
    `  ${prefix}listsewa\n` +
    `  ${prefix}ceksewa <link/id>\n` +
    `  ${prefix}anticulik on/off/status\n\n` +
    `  🔒 *Proteksi Cerdas:*\n` +
    `  • Grup sewa = AMAN\n` +
    `  • Owner di grup = AMAN\n` +
    `  • Lainnya = AUTO LEAVE\n\n` +
    `  👤 *By Valzz*`
  );
}

let handler = async (m, { sock, text, command }) => {
  const prefix = global.prefix || ".";
  const args = text ? text.trim().split(/\s+/) : [];

  if (!global.db) global.db = { data: { sewa: { enabled: false, groups: {} } } };
  if (!global.db.data) global.db.data = { sewa: { enabled: false, groups: {} } };
  if (!global.db.data.sewa) global.db.data.sewa = { enabled: false, groups: {} };
  if (global.antiCulik === undefined) global.antiCulik = true;

  if (!args.length) return sock.sendMessage(m.chat, { text: buildMenuText(prefix) }, { quoted: m.verifiedQuoted });

  const action = args[0].toLowerCase();

  // ===== ADD SEWA =====
  if (["add", "tambah"].includes(action) && args[1] && args[2]) {
    if (!m.isOwner) return sock.sendMessage(m.chat, { text: "⚠️ Khusus Owner!\n\n👤 *By Valzz*" }, { quoted: m.verifiedQuoted });

    const expiredAt = parseDuration(args[2]);
    if (!expiredAt) return sock.sendMessage(m.chat, { text: "❌ Format durasi tidak valid!\n\n👤 *By Valzz*" }, { quoted: m.verifiedQuoted });

    await sock.sendMessage(m.chat, { react: { text: "🕕", key: m.key } });

    try {
      const result = await resolveGroupId(sock, args[1]);
      if (!result) { await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } }); return sock.sendMessage(m.chat, { text: "❌ Grup tidak ditemukan!\n\n👤 *By Valzz*" }, { quoted: m.verifiedQuoted }); }

      const { id: groupId, name: groupName, inviteCode } = result;
      const isLifetime = expiredAt === Infinity;

      global.db.data.sewa.groups[groupId] = { name: groupName, addedAt: Date.now(), expiredAt: isLifetime ? 0 : expiredAt, isLifetime, addedBy: m.sender };

      const expiredStr = formatExpired(expiredAt);
      let txt = `✅ *SEWA DITAMBAHKAN*\n\nGrup: *${groupName}*\nDurasi: *${formatDuration(args[2])}*\nExpired: *${expiredStr}*\n🔒 Anti Culik: AMAN\n\n`;
      const joinResult = await tryJoinGroup(sock, inviteCode, groupId);
      if (joinResult.joined) {
        txt += `✅ ${joinResult.reason}\n\n`;
        try { await new Promise(r => setTimeout(r, 2000)); await sock.sendMessage(groupId, { text: `👋 *Halo!* Aku *${BOT_NAME}*\n\n📌 Sewa: *${formatDuration(args[2])}*\n📅 Expired: *${expiredStr}*\n\nKetik *${prefix}menu*\n\n👤 *By Valzz*` }); } catch {}
      } else { txt += `⚠️ ${joinResult.reason}\n`; }
      txt += `\n👤 *By Valzz*`;
      await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
      return sock.sendMessage(m.chat, { text: txt }, { quoted: m.verifiedQuoted });
    } catch (e) {
      await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      return sock.sendMessage(m.chat, { text: `❌ ${e.message}\n\n👤 *By Valzz*` }, { quoted: m.verifiedQuoted });
    }
  }

  // ===== DELETE SEWA =====
  if (["del", "delete", "hapus"].includes(action) && args[1]) {
    if (!m.isOwner) return sock.sendMessage(m.chat, { text: "⚠️ Khusus Owner!\n\n👤 *By Valzz*" }, { quoted: m.verifiedQuoted });
    const r = await resolveGroupId(sock, args[1]);
    if (!r || !global.db.data.sewa.groups[r.id]) return sock.sendMessage(m.chat, { text: "❌ Tidak ditemukan!\n\n👤 *By Valzz*" }, { quoted: m.verifiedQuoted });
    delete global.db.data.sewa.groups[r.id];
    await sock.sendMessage(m.chat, { react: { text: "🗑️", key: m.key } });
    return sock.sendMessage(m.chat, { text: `🗑️ *SEWA DIHAPUS!*\n\n📛 ${r.name}\n\n👤 *By Valzz*` }, { quoted: m.verifiedQuoted });
  }

  // ===== LIST SEWA =====
  if (["list", "daftar"].includes(action)) {
    const g = Object.entries(global.db.data.sewa.groups);
    if (!g.length) return sock.sendMessage(m.chat, { text: "📭 Kosong\n\n👤 *By Valzz*" }, { quoted: m.verifiedQuoted });
    let t = `📋 *LIST SEWA* (${g.length})\n\n`;
    g.forEach(([id, d], i) => { t += `*${i+1}. ${d.name}*\n│ 🆔 ${id.split("@")[0]}\n│ 📅 ${d.isLifetime?"Permanent":formatExpired(d.expiredAt)}\n\n`; });
    t += `👤 *By Valzz*`;
    return sock.sendMessage(m.chat, { text: t }, { quoted: m.verifiedQuoted });
  }

  // ===== CEK SEWA =====
  if (["cek", "check"].includes(action) && args[1]) {
    const r = await resolveGroupId(sock, args[1]);
    const s = r ? global.db.data.sewa.groups[r.id] : null;
    if (!s) return sock.sendMessage(m.chat, { text: "❌ Tidak terdaftar!\n\n👤 *By Valzz*" }, { quoted: m.verifiedQuoted });
    const ex = !s.isLifetime && s.expiredAt > 0 && Date.now() > s.expiredAt;
    return sock.sendMessage(m.chat, { text: `🔍 *CEK SEWA*\n\n📛 ${s.name}\n⏱️ ${s.isLifetime?"Permanent":formatDuration("custom")}\n📊 ${ex?"🔴 Expired":"🟢 Aktif"}\n🔒 ${ex?"⚠️ Kena Culik":"✅ Aman"}\n\n👤 *By Valzz*` }, { quoted: m.verifiedQuoted });
  }

  // ===== ANTI CULIK =====
  if (action === "anticulik") {
    if (!m.isOwner) return sock.sendMessage(m.chat, { text: "⚠️ Khusus Owner!\n\n👤 *By Valzz*" }, { quoted: m.verifiedQuoted });
    const sub = args[1]?.toLowerCase();
    if (sub === "on") { global.antiCulik = true; return sock.sendMessage(m.chat, { text: "🔒 *ANTI CULIK ON*\n\n✅ Bot akan auto leave dari grup ilegal!\n🤝 Owner di grup = AMAN\n🤝 Grup sewa = AMAN\n\n👤 *By Valzz*" }, { quoted: m.verifiedQuoted }); }
    if (sub === "off") { global.antiCulik = false; return sock.sendMessage(m.chat, { text: "🔓 *ANTI CULIK OFF*\n\n⚠️ Bot bisa di-invite ke grup manapun!\n\n👤 *By Valzz*" }, { quoted: m.verifiedQuoted }); }
    const st = global.antiCulik ? "🟢 AKTIF" : "🔴 NONAKTIF";
    const tot = Object.keys(global.db.data.sewa.groups).length;
    return sock.sendMessage(m.chat, { text: `🛡️ *STATUS ANTI CULIK*\n\n📊 ${st}\n🤝 Sewa: ${tot} grup\n👑 Owner: ${OWNER_NUMBER}\n🚫 Auto Leave: ${AUTO_LEAVE_CULIK?"✅":"❌"}\n\n👤 *By Valzz*` }, { quoted: m.verifiedQuoted });
  }

  return sock.sendMessage(m.chat, { text: buildMenuText(prefix) }, { quoted: m.verifiedQuoted });
};

// ==================== ANTI CULIK CERDAS ====================
handler.before = async function (m, { sock }) {
  if (!global.antiCulik) return;
  if (!m.isGroup) return;

  const groupId = m.chat;

  // 1. Owner = AMAN
  if (isOwnerNum(m.sender)) return;

  // 2. Grup sewa = AMAN
  if (isGroupSewa(groupId)) return;

  // 3. Owner ada di grup? = AMAN
  const ownerInGroup = await isOwnerInGroup(sock, groupId);
  if (ownerInGroup) return;

  // === GRUP ILEGAL! ===
  const time = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });

  // Kirim peringatan
  try {
    const meta = await sock.groupMetadata(groupId).catch(() => ({ subject: "Unknown" }));
    await sock.sendMessage(groupId, {
      text:
        `🚫 *ANTI CULIK!*\n\n` +
        `Bot tidak diizinkan di grup:\n*${meta.subject || "Unknown"}*\n\n` +
        `📌 Sewa bot: wa.me/${OWNER_NUMBER}\n` +
        `👑 Owner: ${OWNER_NUMBER}\n\n` +
        `_Bot akan leave..._ 👋\n\n` +
        `👤 *By Valzz*`
    });
  } catch (e) {}

  // Notif owner
  if (NOTIFY_OWNER) {
    try {
      const meta = await sock.groupMetadata(groupId).catch(() => ({ subject: "Unknown" }));
      await sock.sendMessage(OWNER_NUMBER + "@s.whatsapp.net", {
        text:
          `🚫 *ANTI CULIK!*\n\n` +
          `📛 Grup: ${meta.subject || "Unknown"}\n` +
          `🆔 ID: ${groupId}\n` +
          `👤 Pengundang: ${(m.sender||"").split("@")[0]}\n` +
          `⏰ ${time}\n\n` +
          `Bot akan auto leave.\n\n` +
          `👤 *By Valzz*`
      });
    } catch (e) {}
  }

  // Auto leave
  if (AUTO_LEAVE_CULIK) {
    setTimeout(async () => {
      try { await sock.groupLeave(groupId); } catch (e) {}
    }, 3000);
  }

  return true;
};

handler.tags = ["owner"];
handler.help = ["addsewa"];
handler.command = ["addsewa", "sewaadd", "tambahsewa", "sewabot", "delsewa", "listsewa", "ceksewa", "anticulik"];
handler.owner = true;

export default handler;