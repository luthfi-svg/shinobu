// plugins/owner/delplugin.js — Delete Plugin (SHINOBU MD v1.2)
import fs from "fs";
import path from "path";

const PLUGIN_DIR = "./plugins";

function findPlugin(filename) {
  const results = [];
  function searchDir(dir) {
    const files = fs.readdirSync(dir);
    for (const file of files) {
      const fullPath = path.join(dir, file);
      const stat = fs.statSync(fullPath);
      if (stat.isDirectory()) {
        searchDir(fullPath);
      } else if (file === filename || file.toLowerCase() === filename.toLowerCase()) {
        results.push(fullPath);
      }
    }
  }
  try { searchDir(PLUGIN_DIR); } catch (e) {}
  return results;
}

function searchByKeyword(keyword) {
  const results = [];
  const kw = keyword.toLowerCase();
  function searchDir(dir) {
    const files = fs.readdirSync(dir);
    for (const file of files) {
      const fullPath = path.join(dir, file);
      const stat = fs.statSync(fullPath);
      if (stat.isDirectory()) {
        searchDir(fullPath);
      } else if (file.toLowerCase().includes(kw)) {
        results.push({ name: file, path: fullPath });
      }
    }
  }
  try { searchDir(PLUGIN_DIR); } catch (e) {}
  return results;
}

function buildMenuText(prefix) {
  return (
    `╭══════════════════════════════╮\n` +
    `│   🗑️  *DELETE PLUGIN*  🗑️  │\n` +
    `│   👤 By Valzz              │\n` +
    `╰══════════════════════════════╯\n\n` +
    `  ${prefix}delp namafile.js\n` +
    `  ${prefix}delp keyword\n` +
    `  ${prefix}delp --list\n\n` +
    `  👤 *By Valzz*`
  );
}

let handler = async (m, { sock, text, command }) => {
  const prefix = global.prefix || ".";

  if (!text || !text.trim()) {
    return sock.sendMessage(m.chat, { text: buildMenuText(prefix) }, { quoted: m.verifiedQuoted });
  }

  const filename = text.trim();

  // LIST
  if (filename === "--list") {
    const allFiles = [];
    function scanDir(dir) {
      const files = fs.readdirSync(dir);
      for (const file of files) {
        const fullPath = path.join(dir, file);
        const stat = fs.statSync(fullPath);
        if (stat.isDirectory()) scanDir(fullPath);
        else if (file.endsWith(".js")) {
          const relPath = fullPath.replace(PLUGIN_DIR + "/", "");
          allFiles.push({ path: relPath, size: (stat.size / 1024).toFixed(1) });
        }
      }
    }
    try { scanDir(PLUGIN_DIR); } catch (e) {}

    let listText = `📂 *LIST PLUGIN* (${allFiles.length})\n\n`;
    const grouped = {};
    for (const f of allFiles) {
      const folder = f.path.includes("/") ? f.path.split("/")[0] : "root";
      if (!grouped[folder]) grouped[folder] = [];
      grouped[folder].push(f);
    }
    for (const folder in grouped) {
      listText += `📁 *${folder}/* (${grouped[folder].length})\n`;
      grouped[folder].forEach(f => listText += `  ▸ ${f.path.split("/").pop()} (${f.size} KB)\n`);
      listText += `\n`;
    }
    listText += `👤 *By Valzz*`;
    return sock.sendMessage(m.chat, { text: listText }, { quoted: m.verifiedQuoted });
  }

  // CARI
  let foundFiles;
  if (filename.endsWith(".js")) {
    foundFiles = findPlugin(filename);
  } else {
    foundFiles = searchByKeyword(filename).map(r => r.path);
  }

  if (foundFiles.length === 0) {
    return sock.sendMessage(m.chat, {
      text: `❌ File *"${filename}"* tidak ditemukan!\n\n👤 *By Valzz*`
    }, { quoted: m.verifiedQuoted });
  }

  if (foundFiles.length > 1) {
    let msg = `⚠️ *DITEMUKAN ${foundFiles.length} FILE*\n\n`;
    foundFiles.forEach((f, i) => {
      const relPath = f.replace(PLUGIN_DIR + "/", "");
      msg += `${i + 1}. ${relPath}\n`;
    });
    msg += `\n💡 Gunakan nama file lengkap!\n\n👤 *By Valzz*`;
    return sock.sendMessage(m.chat, { text: msg }, { quoted: m.verifiedQuoted });
  }

  // LANGSUNG HAPUS
  const filePath = foundFiles[0];
  const relPath = filePath.replace(PLUGIN_DIR + "/", "");
  const fileName = path.basename(filePath);
  const folder = relPath.includes("/") ? relPath.split("/")[0] : "root";
  const stat = fs.statSync(filePath);
  const size = (stat.size / 1024).toFixed(1);

  try {
    fs.unlinkSync(filePath);
    try { delete require.cache[require.resolve(filePath)]; } catch (e) {}

    await sock.sendMessage(m.chat, { react: { text: "🗑️", key: m.key } });

    return sock.sendMessage(m.chat, {
      text:
        `╭──────────────────────────────╮\n` +
        `  ✅  *PLUGIN DIHAPUS!*\n` +
        `╰──────────────────────────────╯\n\n` +
        `  📛 ${fileName}\n` +
        `  📂 ${folder}\n` +
        `  📏 ${size} KB\n\n` +
        `  👤 *By Valzz*`
    }, { quoted: m.verifiedQuoted });

  } catch (error) {
    await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    return sock.sendMessage(m.chat, {
      text: `❌ ${error.message}\n\n👤 *By Valzz*`
    }, { quoted: m.verifiedQuoted });
  }
};

handler.tags = ["owner"];
handler.help = ["delplugin <file|keyword>"];
handler.command = ["delplugin", "delp", "deleteplugin", "rmplugin"];
handler.owner = true;

export default handler;