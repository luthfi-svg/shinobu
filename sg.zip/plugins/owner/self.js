
let handler = async (m, { sock, command }) => {

switch (command) {
case "public": {
sock.public = true
return m.reply("Berhasil beralih ke mode Public ✅")
}
break

case "self": {
sock.public = false
return m.reply("Berhasil beralih ke mode Self ✅")
}
break
}

}

handler.tags = "owner"
handler.help = ["self", "public"]
handler.command = ["self", "public"]
handler.owner = true

export default handler;