// plugins/owner/setbio.js — Set bot bio/status (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Set Bio
 * 🔧 Fungsi     : Ganti bio/status WhatsApp bot
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `Contoh penggunaan:\n${usedPrefix + command} <bio baru>\n\n` +
      `Contoh:\n` +
      `${usedPrefix + command} Bot WhatsApp Multi-Device 🤖\n\n` +
      `Max: 139 karakter`
    );
  }

  if (text.length > 139) {
    return m.reply(
      `❌ *Bio Terlalu Panjang*\n\n` +
      `Panjang: ${text.length} karakter\n` +
      `Max: 139 karakter\n\n` +
      `WhatsApp membatasi bio maksimal 139 karakter!`
    );
  }

  try {
    await m.reply("⏳ *Updating Bio...*");

    // Update bot status/bio
    await sock.updateProfileStatus(text);

    await m.reply(
      `✅ *Bio Updated*\n\n` +
      `📝 Bio Baru:\n${text}\n\n` +
      `⏰ Updated: ${new Date().toLocaleString("id-ID")}`
    );

    await m.react("✅");

  } catch (e) {
    console.error(e);
    await m.reply(
      `❌ *Set Bio Error*\n\n` +
      `Gagal update bio: ${e.message}\n\n` +
      `Possible reasons:\n` +
      `• Bot tidak punya permission\n` +
      `• WhatsApp rate limit\n` +
      `• Karakter tidak valid`
    );
  }
};

handler.help = ["setbio <teks>"];
handler.tags = ["owner"];
handler.command = /^(setbio|changebio|bio)$/i;
handler.owner = true;

export default handler;
