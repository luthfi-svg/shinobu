import fs from "fs"
import path from "path"
import { uploadImageBuffer } from "../../lib/screaper.js"

let handler = async (m, { sock }) => {
  let mime = m.mime || ""
  if (!/image/.test(mime)) { 
    return m.reply(`*example:*\n${m.cmd} dengan reply foto`)
  }

  try {
    let qmsg = m?.quoted || m
    let buffer = await qmsg.download()

    m.reply("Uploading thumbnail...")

    let url = await uploadImageBuffer(buffer)
    if (!url) return m.reply("Upload gagal!")

    // lokasi config
    let configPath = path.join(process.cwd(), "config.js")
    let config = fs.readFileSync(configPath, "utf8")

    // replace thumbnail lama
    if (/global\.thumbnail\s*=/.test(config)) {
      config = config.replace(
        /global\.thumbnail\s*=\s*["'`](.*?)["'`]/,
        `global.thumbnail = "${url}"`
      )
    } else {
      config += `\nglobal.thumbnail = "${url}"\n`
    }

    fs.writeFileSync(configPath, config)

    global.thumbnail = url

    m.reply(`✅ Thumbnail menu berhasil diubah\n\nURL:\n${url}`)
  } catch (e) {
    console.log(e)
    m.reply("Terjadi error saat set thumbnail")
  }
}

handler.tags = ["owner"]
handler.help = "setthumbnail"
handler.command = ["setthumbnail", "setthumb"]
handler.owner = true

export default handler;