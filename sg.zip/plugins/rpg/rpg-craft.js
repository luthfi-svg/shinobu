// plugins/rpg/rpg-craft.js — RPG Craft (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : RPG Craft
 * 🔧 Fungsi     : Crafting items
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, text, usedPrefix, command }) => {
  try {
    // Get user RPG data
    global.db.data.users = global.db.data.users || {};
    let user = global.db.data.users[m.sender] || {};
    user.rpg = user.rpg || { hp: 100, atk: 10, def: 5, gold: 0 };
    
    await m.reply(
      `⚔️ *RPG Craft*\n\n` +
      `👤 Player: @${m.sender.split('@')[0]}\n` +
      `❤️ HP: ${user.rpg.hp}/100\n` +
      `⚔️ ATK: ${user.rpg.atk}\n` +
      `🛡️ DEF: ${user.rpg.def}\n` +
      `💰 Gold: ${user.rpg.gold}\n\n` +
      `📝 Action: Crafting items\n` +
      `✅ Result: Success\n\n` +
      `🎯 SHINOBU MD v1.2`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["craft", "buat"];
handler.tags = ['rpg'];
handler.command = /^(craft|buat)$/i;

export default handler;
