// plugins/rpg/rpg-adventure.js — RPG Adventure (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : RPG Adventure
 * 🔧 Fungsi     : Petualangan RPG
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, text, usedPrefix, command }) => {
  try {
    // Get user RPG data
    global.db.data.users = global.db.data.users || {};
    let user = global.db.data.users[m.sender] || {};
    user.rpg = user.rpg || { hp: 100, atk: 10, def: 5, gold: 0 };
    
    await m.reply(
      `⚔️ *RPG Adventure*\n\n` +
      `👤 Player: @${m.sender.split('@')[0]}\n` +
      `❤️ HP: ${user.rpg.hp}/100\n` +
      `⚔️ ATK: ${user.rpg.atk}\n` +
      `🛡️ DEF: ${user.rpg.def}\n` +
      `💰 Gold: ${user.rpg.gold}\n\n` +
      `📝 Action: Petualangan RPG\n` +
      `✅ Result: Success\n\n` +
      `🎯 SHINOBU MD v1.2`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["adventure", "petualangan"];
handler.tags = ['rpg'];
handler.command = /^(adventure|petualangan)$/i;

export default handler;
