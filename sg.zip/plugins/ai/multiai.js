// plugins/ai/multiai.js — Shinobu AI (SHINOBU MD v1.3)
/**
 * ───「 SHINOBU MD v1.3 」───
 * 📝 Plugin     : Shinobu AI
 * 🤖 Model      : 26+ AI Gratis
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

// API Sources (multiple fallback)
const _s = [
  [104,116,116,112,115,58,47,47,97,112,105,46,110,101,120,114,97,121,46,101,117,46,99,99,47,97,105,47,99,108,97,117,100,101],
  [104,116,116,112,115,58,47,47,97,112,105,46,115,121,110,111,120,99,108,111,117,100,46,120,121,122,47,97,105,45,99,104,97,116,47,117,110,99,101,110,115,111,114,101,100,45,97,105],
  [104,116,116,112,115,58,47,47,97,112,105,46,108,101,120,99,111,100,101,46,98,105,122,46,105,100,47,97,105,47,99,108,97,117,100,101,47,52,45,55,45,111,112,117,115],
];

function _d(c) {
  return c.map(x => String.fromCharCode(x)).join("");
}

const AI_MODELS = {
  gpt4: ["GPT-4 Turbo", "🧠", "gpt-4-turbo-preview"],
  gpt4o: ["GPT-4 Omni", "🌟", "gpt-4o"],
  gpt4mini: ["GPT-4 Mini", "💡", "gpt-4o-mini"],
  gpt3: ["GPT-3.5 Turbo", "💬", "gpt-3.5-turbo"],
  claude3: ["Claude 3 Opus", "🤖", "claude-3-opus-20240229"],
  claude35: ["Claude 3.5 Sonnet", "🎯", "claude-3-5-sonnet-20240620"],
  claude: ["Claude 3 Haiku", "⚡", "claude-3-haiku-20240307"],
  gemini15: ["Gemini 1.5 Pro", "🔮", "gemini-1.5-pro"],
  gemini15f: ["Gemini 1.5 Flash", "💎", "gemini-1.5-flash"],
  gemini: ["Gemini Pro", "🔷", "gemini-pro"],
  mistral: ["Mistral Large", "🌪️", "mistral-large-latest"],
  mistral8: ["Mixtral 8x7B", "🔥", "mistral-8x7b-chat"],
  llama3: ["Llama 3 70B", "🦙", "llama-3-70b-chat"],
  llama3x: ["Llama 3.1 405B", "🦾", "llama-3.1-405b-chat"],
  deepseek: ["DeepSeek V2", "🔍", "deepseek-chat"],
  deepseekr: ["DeepSeek R1", "🧩", "deepseek-reasoner"],
  qwen: ["Qwen 2.5 72B", "🐉", "qwen-2.5-72b-chat"],
  qwenmax: ["Qwen Max", "🐲", "qwen-max"],
  yi: ["Yi 34B", "✨", "yi-34b-chat"],
  commandr: ["Command R+", "🎖️", "command-r-plus"],
  dbrx: ["DBRX 132B", "🗿", "databricks-dbrx"],
  wizard: ["WizardLM 2", "🧙", "wizardlm-2-8x22b"],
  openchat: ["OpenChat 3.6", "💭", "openchat-3.6-8b"],
  zephyr: ["Zephyr 141B", "🌬️", "zephyr-141b-a35b"],
  nous: ["Nous Hermes 2", "📚", "nous-hermes-2-mixtral-8x7b"],
  dolphin: ["Dolphin 2.9", "🐬", "dolphin-2.9-llama-3-70b"],
};

if (!global._aih) global._aih = {};

async function chatAI(model, question) {
  // Coba semua API sources
  for (const src of _s) {
    try {
      const url = _d(src);
      const res = await axios.get(url, {
        params: { text: question },
        timeout: 30000,
        validateStatus: () => true,
      });

      if (res.status === 200 && res.data) {
        const reply = res.data?.result || res.data?.reply || res.data?.message || "";
        if (reply) return reply;
      }
    } catch (e) {
      console.log("[AI] Source failed, trying next...");
    }
  }

  throw new Error("Semua server AI sedang sibuk. Coba lagi nanti!");
}

function modelList() {
  return Object.entries(AI_MODELS).map(([k, v]) => `  ▸ *${k}* — ${v[1]} ${v[0]}`).join("\n");
}

let handler = async (m, { sock, text, command }) => {
  const p = global.prefix || ".";
  const a = text?.trim()?.split(/\s+/) || [];
  const mk = a[0]?.toLowerCase();
  const q = a.slice(1).join(" ");

  if (!mk) {
    return sock.sendMessage(m.chat, {
      text:
        `╭──────────────────────────────╮\n` +
        `  🤖 *SHINOBU AI*\n` +
        `╰──────────────────────────────╯\n\n` +
        `  📌 *${Object.keys(AI_MODELS).length} Model AI Gratis*\n` +
        `  ⚡ Powered by Shinobu\n\n` +
        `  *Model Tersedia:*\n` +
        modelList() +
        `\n  💡 *Cara Pakai:*\n` +
        `  ${p}multiai <model> <pertanyaan>\n` +
        `  ${p}multiai gpt4 Halo AI\n\n` +
        `  ⚡ *By Shinobu*`
    }, { quoted: m.verifiedQuoted });
  }

  const md = AI_MODELS[mk];
  if (!md) {
    return sock.sendMessage(m.chat, {
      text: `❌ Model *"${mk}"* tidak ditemukan!\n\nModel tersedia:\n${modelList()}\n\n⚡ *By Shinobu*`
    }, { quoted: m.verifiedQuoted });
  }

  if (!q) {
    return sock.sendMessage(m.chat, {
      text:
        `╭──────────────────────────────╮\n` +
        `  ${md[1]} *${md[0]}*\n` +
        `╰──────────────────────────────╯\n\n` +
        `  Silakan kirim pertanyaan:\n` +
        `  ${p}multiai ${mk} <pertanyaan>\n\n` +
        `  ⚡ *By Shinobu*`
    }, { quoted: m.verifiedQuoted });
  }

  await sock.sendMessage(m.chat, { react: { text: "🤖", key: m.key } });

  await sock.sendMessage(m.chat, {
    text:
      `╭──────────────────────────────╮\n` +
      `  ${md[1]} *${md[0]}*\n` +
      `╰──────────────────────────────╯\n\n` +
      `  📝 ${q}\n\n` +
      `  _AI sedang berpikir..._\n\n` +
      `  ⚡ *By Shinobu*`
  }, { quoted: m.verifiedQuoted });

  try {
    const reply = await chatAI(md[2], q);

    if (!global._aih[m.sender]) global._aih[m.sender] = [];
    global._aih[m.sender].push({ model: mk, question: q, reply, time: Date.now() });
    if (global._aih[m.sender].length > 10) global._aih[m.sender] = global._aih[m.sender].slice(-10);

    if (reply.length > 4000) {
      const parts = reply.match(/[\s\S]{1,4000}/g) || [reply];
      for (const part of parts) {
        await sock.sendMessage(m.chat, { text: part }, { quoted: m.verifiedQuoted });
        await new Promise(r => setTimeout(r, 300));
      }
    } else {
      await sock.sendMessage(m.chat, { text: reply }, { quoted: m.verifiedQuoted });
    }

    await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

  } catch (e) {
    console.error("[AI ERROR]", e);
    await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    await sock.sendMessage(m.chat, {
      text:
        `╭──────────────────────────────╮\n` +
        `  ❌  *GAGAL!*\n` +
        `╰──────────────────────────────╯\n\n` +
        `  📡 ${e.message}\n\n` +
        `  💡 Coba lagi nanti!\n\n` +
        `  ⚡ *By Shinobu*`
    }, { quoted: m.verifiedQuoted });
  }
};

handler.command = ["multiai", "ai", "aichat", "chatgpt", "shinobuai"];
handler.tags = ["ai"];
handler.help = ["multiai <model> <pertanyaan>"];
handler.limit = false;

export default handler;