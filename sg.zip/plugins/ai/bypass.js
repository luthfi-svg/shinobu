// plugins/ai/bypass.js — AI Content Humanizer (QueVaroU V2.0)
/**
 * ───「 QueVaroU V2.0 」───
 * 📝 Plugin     : AI Bypass / Humanizer
 * 🔗 API        : Nexray API
 * 🤖 Fungsi     : Humanize AI content
 * 📦 Version    : 1.1
 * ⚡ By Shinobu
 * ─────────────────────────
 */

"use strict";

import axios from "axios";

const API_BASE = "https://api.nexray.eu.cc/ai/bypass";
const REQUEST_TIMEOUT_MS = 30000;

/**
 * Humanize / Bypass AI detection.
 */
async function bypassAI(text) {
  let res;
  try {
    res = await axios.get(API_BASE, {
      params: { text },
      timeout: REQUEST_TIMEOUT_MS,
      validateStatus: () => true,
    });
  } catch (err) {
    if (err.code === "ECONNABORTED") {
      throw new Error("⏰ Timeout! Server terlalu lama merespon.");
    }
    throw new Error(`🌐 Gagal menghubungi server: ${err.message}`);
  }

  if (res.status !== 200) {
    let errMsg = `📡 HTTP ${res.status} - ${res.statusText || "Request gagal"}`;
    if (res.data && res.data.message) errMsg = res.data.message;
    throw new Error(errMsg);
  }

  if (!res.data || !res.data.status) {
    throw new Error("❌ Gagal memproses teks.");
  }

  const result = res.data.result || res.data.humanized || res.data.text || res.data;
  
  return {
    original: text,
    humanized: typeof result === "string" ? result : result.text || result.humanized || JSON.stringify(result),
    timestamp: res.data.timestamp || new Date().toISOString()
  };
}

function buildMenuText(prefix) {
  return (
    `╭══════════════════════════════╮\n` +
    `│                              │\n` +
    `│   🤖  *AI BYPASS*  🤖      │\n` +
    `│   ──────────────────────    │\n` +
    `│   AI Content Humanizer     │\n` +
    `│   Bypass AI Detection      │\n` +
    `│   QueVaroU V2.0 📦       │\n` +
    `│                              │\n` +
    `╰══════════════════════════════╯\n\n` +
    `  📌 *Deskripsi:*\n` +
    `  › Humanize teks AI\n` +
    `  › Bypass AI detection\n` +
    `  › Bikin teks lebih natural\n` +
    `  › Cocok untuk konten\n\n` +
    `╭──────────────────────────────╮\n` +
    `  📋 *CARA PAKAI:*\n` +
    `╰──────────────────────────────╯\n\n` +
    `  ${prefix}bypass <teks>\n\n` +
    `╭──────────────────────────────╮\n` +
    `  💡 *CONTOH:*\n` +
    `╰──────────────────────────────╯\n\n` +
    `  ${prefix}bypass The old lighthouse\n` +
    `  stood sentinel on the rugged\n` +
    `  cliff...\n\n` +
    `  ${prefix}bypass Artificial intelligence\n` +
    `  has revolutionized the way we\n` +
    `  interact with technology...\n\n` +
    `╭──────────────────────────────╮\n` +
    `  ✨ *FITUR:*\n` +
    `╰──────────────────────────────╯\n\n` +
    `  ✅ Humanize AI text\n` +
    `  ✅ Bypass detection\n` +
    `  ✅ Natural language\n` +
    `  ✅ Keep original meaning\n` +
    `  ✅ No limit teks\n\n` +
    `╭──────────────────────────────╮\n` +
    `  📦 *INFO:*\n` +
    `╰──────────────────────────────╯\n\n` +
    `  🤖 Bot    : Shinobu MD\n` +
    `  📦 Version : 1.1\n` +
    `  🔗 API     : Nexray\n` +
    `  ⚡ Powered : Shinobu\n\n` +
    `  ⚡ *QueVaroU V2.0*  |  🤖 *Bypass*`
  );
}

let handler = async (m, { text, command, sock }) => {
  const prefix = global.prefix || ".";

  // Tampilkan menu kalo gak ada input
  if (!text || !text.trim()) {
    return sock.sendMessage(
      m.chat,
      { text: buildMenuText(prefix) },
      { quoted: m.verifiedQuoted }
    );
  }

  const inputText = text.trim();

  // Reaksi
  await sock.sendMessage(m.chat, { react: { text: "🤖", key: m.key } });

  // Progress
  await sock.sendMessage(
    m.chat,
    {
      text:
        `╭──────────────────────────────╮\n` +
        `  🤖  *AI BYPASS*\n` +
        `╰──────────────────────────────╯\n\n` +
        `  📝 *Original:*\n` +
        `  ❝ ${inputText.substring(0, 100)}${inputText.length > 100 ? '...' : ''} ❞\n\n` +
        `  ⏳ *Status:* Humanizing...\n` +
        `  🧠 *AI:* Memproses teks\n\n` +
        `  _Tunggu sebentar..._\n\n` +
        `  ⚡ *QueVaroU V2.0*`
    },
    { quoted: m.verifiedQuoted }
  );

  try {
    const result = await bypassAI(inputText);

    // Kirim hasil humanized langsung
    let humanizedText = result.humanized;

    if (humanizedText.length > 4000) {
      const parts = humanizedText.match(/[\s\S]{1,4000}/g) || [humanizedText];
      for (const part of parts) {
        await sock.sendMessage(m.chat, { text: part }, { quoted: m.verifiedQuoted });
        await new Promise(resolve => setTimeout(resolve, 300));
      }
    } else {
      await sock.sendMessage(m.chat, { text: humanizedText }, { quoted: m.verifiedQuoted });
    }

    // Info singkat
    await sock.sendMessage(
      m.chat,
      {
        text:
          `╭──────────────────────────────╮\n` +
          `  ✅  *HUMANIZED!*  ✅\n` +
          `╰──────────────────────────────╯\n\n` +
          `  📝 *Original:* ${inputText.length} karakter\n` +
          `  🤖 *Humanized:* ${humanizedText.length} karakter\n` +
          `  📦 QueVaroU V2.0\n\n` +
          `  ⚡ *By Shinobu*`
      },
      { quoted: m.verifiedQuoted }
    );

    await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

  } catch (error) {
    console.error("[BYPASS ERROR]", error);
    await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });

    await sock.sendMessage(
      m.chat,
      {
        text:
          `╭──────────────────────────────╮\n` +
          `  ❌  *GAGAL!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  📡 ${error.message}\n` +
          `  📦 QueVaroU V2.0\n\n` +
          `  💡 Coba lagi nanti!\n\n` +
          `  ⚡ *By Shinobu*`
      },
      { quoted: m.verifiedQuoted }
    );
  }
};

handler.command = ["bypass", "humanize", "bypassai"];
handler.tags = ["ai"];
handler.help = ["bypass <teks>"];
handler.limit = false;

export default handler;