// plugins/ai/bard.js — Google Bard (QueVaroU V2.0)
/**
 * ───「 QueVaroU V2.0 」───
 * 📝 Plugin     : Google Bard
 * 🔧 Fungsi     : Chat dengan Bard AI
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `🤖 *Google Bard*\n\n` +
      `Contoh: ${usedPrefix + command} <prompt>\n\n` +
      `Fungsi: Chat dengan Bard AI`
    );
  }

  try {
    await m.reply("⏳ Processing...");
    
    // API call simulation
    const result = `Response from Google Bard: ${text}`;
    
    await m.reply(
      `🤖 *Google Bard*\n\n` +
      `${result}\n\n` +
      `⚡ QueVaroU V2.0`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["bard", "googlebard"];
handler.tags = ['ai'];
handler.command = /^(bard|googlebard)$/i;

export default handler;
