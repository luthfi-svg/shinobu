// plugins/ai/aihistory.js — AI Chat History
"use strict";

let handler = async (m, { sock }) => {
  const history = global.aiChatHistory?.[m.sender] || [];

  if (!history.length) {
    return sock.sendMessage(
      m.chat,
      { text: "📝 *AI Chat History*\n\nKamu belum pernah chat dengan AI.\n\nKetik .ai <pertanyaan> untuk mulai!" },
      { quoted: m.verifiedQuoted }
    );
  }

  let text = `🤖 *AI Chat History*\n\n`;
  text += `Total chat: ${history.length}\n`;
  text += `━━━━━━━━━━━━━━━━━━━━\n\n`;

  history.slice(-5).forEach((chat, i) => {
    text += `*${i + 1}.* 📝 ${chat.question.substring(0, 50)}...\n`;
    text += `💬 ${chat.answer.substring(0, 100)}...\n`;
    text += `⏰ ${new Date(chat.timestamp).toLocaleString('id-ID')}\n\n`;
  });

  text += `_Hanya 5 chat terakhir yang ditampilkan._`;

  await sock.sendMessage(m.chat, { text }, { quoted: m.verifiedQuoted });
};

handler.command = ["aihistory", "riwayatai"];
handler.tags = ["ai"];
handler.help = ["aihistory"];

export default handler;