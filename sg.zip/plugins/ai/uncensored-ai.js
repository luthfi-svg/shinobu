// plugins/ai/uncensored-ai.js — Uncensored AI Chat (SynoxCloud API)
/**
 * ───「 FEATURE AUTHOR 」───
 * 📝 Plugin     : Uncensored AI Chat
 * 🔗 API        : SynoxCloud API
 * ⚠️ Note       : For educational purposes only
 * ─────────────────────────
 */

"use strict";

import axios from "axios";

const API_BASE = "https://api.synoxcloud.xyz/ai-chat/uncensored-ai";
const REQUEST_TIMEOUT_MS = 60000; // 60 detik karena AI butuh waktu
const MAX_MESSAGE_LENGTH = 500;

// Simpan history chat per user
if (!global.aiChatHistory) global.aiChatHistory = {};

/**
 * Kirim pesan ke Uncensored AI.
 */
async function chatWithAI(pesan) {
  let res;
  try {
    res = await axios.get(API_BASE, {
      params: { pesan },
      timeout: REQUEST_TIMEOUT_MS,
      validateStatus: () => true,
    });
  } catch (err) {
    if (err.code === "ECONNABORTED") {
      throw new Error("Timeout! AI terlalu lama merespon, coba lagi.");
    }
    throw new Error(`Gagal menghubungi server AI: ${err.message}`);
  }

  if (res.status !== 200) {
    let errMsg = `HTTP ${res.status} - ${res.statusText || "Request gagal"}`;
    if (res.data && res.data.message) {
      errMsg = res.data.message;
    }
    throw new Error(errMsg);
  }

  if (!res.data || !res.data.status) {
    throw new Error("AI tidak memberikan respon yang valid.");
  }

  const reply = res.data.result?.reply || res.data.reply || "Maaf, AI tidak bisa menjawab saat ini.";
  
  return {
    reply,
    timestamp: res.data.timestamp || new Date().toISOString(),
    creator: res.data.creator || "SynoxCloud"
  };
}

function buildUsageText(prefix, command) {
  return (
    `🤖 *Uncensored AI Chat*\n\n` +
    `Chat dengan AI tanpa sensor.\n` +
    `Cocok buat tanya apa aja!\n\n` +
    `*Cara Pakai:*\n` +
    `${prefix + command} <pertanyaan>\n\n` +
    `*Contoh:*\n` +
    `${prefix + command} Apa itu black hole?\n` +
    `${prefix + command} Buatkan kode python untuk kalkulator\n` +
    `${prefix + command} Jelaskan teori relativitas\n\n` +
    `*Fitur:*\n` +
    `• AI tanpa sensor\n` +
    `• Respon detail\n` +
    `• Support multi bahasa\n\n` +
    `*Batas:* ${MAX_MESSAGE_LENGTH} karakter\n` +
    `*Timeout:* 60 detik\n\n` +
    `⚠️ *Disclaimer:* Gunakan dengan bijak!\n` +
    `Bot tidak bertanggung jawab atas konten.`
  );
}

let handler = async (m, { text, command, sock }) => {
  const prefix = global.prefix || ".";

  // Validasi input
  if (!text || !text.trim()) {
    return sock.sendMessage(
      m.chat,
      { text: buildUsageText(prefix, command) },
      { quoted: m.verifiedQuoted }
    );
  }

  const pesan = text.trim();

  // Validasi panjang pesan
  if (pesan.length > MAX_MESSAGE_LENGTH) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Pesan terlalu panjang! Maksimal ${MAX_MESSAGE_LENGTH} karakter.` },
      { quoted: m.verifiedQuoted }
    );
  }

  // Reaksi loading
  await sock.sendMessage(m.chat, { react: { text: "🤖", key: m.key } });

  // Kirim pesan proses
  await sock.sendMessage(
    m.chat,
    {
      text:
        `🤖 *AI sedang berpikir...*\n\n` +
        `📝 *Pertanyaan:* ${pesan}\n\n` +
        `_Tunggu sebentar, AI lagi mikir..._`
    },
    { quoted: m.verifiedQuoted }
  );

  try {
    // Chat dengan AI
    const result = await chatWithAI(pesan);

    // Simpan history
    if (!global.aiChatHistory[m.sender]) {
      global.aiChatHistory[m.sender] = [];
    }
    global.aiChatHistory[m.sender].push({
      question: pesan,
      answer: result.reply,
      timestamp: result.timestamp
    });

    // Batasi history 10 aja
    if (global.aiChatHistory[m.sender].length > 10) {
      global.aiChatHistory[m.sender] = global.aiChatHistory[m.sender].slice(-10);
    }

    // Format jawaban
    let replyText = `🤖 *Uncensored AI*\n\n`;
    replyText += `📝 *Pertanyaan:*\n${pesan}\n\n`;
    replyText += `💬 *Jawaban:*\n${result.reply}\n\n`;
    replyText += `━━━━━━━━━━━━━━━━━━━━\n`;
    replyText += `⏰ ${new Date(result.timestamp).toLocaleString('id-ID')}\n`;
    replyText += `👤 Creator: ${result.creator}\n\n`;
    replyText += `⚠️ *Disclaimer:* Jawaban AI hanya untuk referensi.`;

    // Kirim jawaban (potong kalo kepanjangan)
    if (replyText.length > 4000) {
      // Kirim per bagian
      const parts = replyText.match(/[\s\S]{1,4000}/g) || [replyText];
      for (const part of parts) {
        await sock.sendMessage(
          m.chat,
          { text: part },
          { quoted: m.verifiedQuoted }
        );
        await new Promise(resolve => setTimeout(resolve, 500));
      }
    } else {
      await sock.sendMessage(
        m.chat,
        { text: replyText },
        { quoted: m.verifiedQuoted }
      );
    }

    await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

  } catch (error) {
    console.error("[AI CHAT ERROR]", error);
    await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    await sock.sendMessage(
      m.chat,
      {
        text:
          `❌ *Gagal Chat AI!*\n\n` +
          `*Alasan:* ${error.message || "Unknown error"}\n\n` +
          `Coba lagi nanti ya!`
      },
      { quoted: m.verifiedQuoted }
    );
  }
};

handler.command = ["ai", "uncensored", "aichat", "chatgpt", "openai"];
handler.tags = ["ai"];
handler.help = ["ai <pertanyaan>"];
handler.limit = true;

export default handler;