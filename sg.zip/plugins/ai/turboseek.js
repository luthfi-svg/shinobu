// plugins/ai/turboseek.js — Turboseek AI Search (SynoxCloud API)
/**
 * ───「 FEATURE AUTHOR 」───
 * 📝 Plugin     : Turboseek AI Search
 * 🔗 API        : SynoxCloud API
 * 📚 Fungsi     : AI search engine kaya Perplexity
 * ─────────────────────────
 */

"use strict";

import axios from "axios";

const API_BASE = "https://api.synoxcloud.xyz/ai-chat/turboseek-ai";
const REQUEST_TIMEOUT_MS = 30000;
const MAX_QUESTION_LENGTH = 300;

/**
 * Mencari jawaban dengan Turboseek AI.
 */
async function searchWithTurboseek(question) {
  let res;
  try {
    res = await axios.get(API_BASE, {
      params: { q: question },
      timeout: REQUEST_TIMEOUT_MS,
      validateStatus: () => true,
    });
  } catch (err) {
    if (err.code === "ECONNABORTED") {
      throw new Error("Timeout! Server AI terlalu lama merespon.");
    }
    throw new Error(`Gagal menghubungi server: ${err.message}`);
  }

  if (res.status !== 200) {
    let errMsg = `HTTP ${res.status} - ${res.statusText || "Request gagal"}`;
    if (res.data && res.data.message) {
      errMsg = res.data.message;
    }
    throw new Error(errMsg);
  }

  if (!res.data || !res.data.success) {
    throw new Error("AI tidak memberikan respon yang valid.");
  }

  const result = res.data.result || {};
  const answer = result.answer || "Tidak ada jawaban.";
  const references = result.references || [];
  const related = result.related || [];

  // Bersihin HTML tags dari jawaban
  const cleanAnswer = answer
    .replace(/<[^>]*>/g, '')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\n{3,}/g, '\n\n')
    .trim();

  return {
    question: res.data.question || question,
    answer: cleanAnswer,
    references,
    related,
    timestamp: res.data.timestamp || new Date().toISOString(),
    creator: res.data.creator || "SynoxCloud"
  };
}

function buildUsageText(prefix, command) {
  return (
    `🔍 *Turboseek AI Search*\n\n` +
    `AI search engine kaya Perplexity.\n` +
    `Cari jawaban dari web + referensi!\n\n` +
    `*Cara Pakai:*\n` +
    `${prefix + command} <pertanyaan>\n\n` +
    `*Contoh:*\n` +
    `${prefix + command} lebih dulu tercipta bumi atau bulan?\n` +
    `${prefix + command} Apa itu black hole?\n` +
    `${prefix + command} Cara membuat website dengan React\n\n` +
    `*Fitur:*\n` +
    `• AI search engine\n` +
    `• Jawaban + referensi\n` +
    `• Sumber dari web\n` +
    `• Pertanyaan terkait\n\n` +
    `*Batas:* ${MAX_QUESTION_LENGTH} karakter`
  );
}

let handler = async (m, { text, command, sock }) => {
  const prefix = global.prefix || ".";

  // Validasi input
  if (!text || !text.trim()) {
    return sock.sendMessage(
      m.chat,
      { text: buildUsageText(prefix, command) },
      { quoted: m.verifiedQuoted }
    );
  }

  const question = text.trim();

  // Validasi panjang pertanyaan
  if (question.length > MAX_QUESTION_LENGTH) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Pertanyaan terlalu panjang! Maksimal ${MAX_QUESTION_LENGTH} karakter.` },
      { quoted: m.verifiedQuoted }
    );
  }

  // Reaksi loading
  await sock.sendMessage(m.chat, { react: { text: "🔍", key: m.key } });

  // Kirim pesan proses
  await sock.sendMessage(
    m.chat,
    {
      text:
        `🔍 *Mencari jawaban...*\n\n` +
        `📝 *Pertanyaan:* ${question}\n\n` +
        `_AI sedang mencari dari berbagai sumber..._`
    },
    { quoted: m.verifiedQuoted }
  );

  try {
    // Search dengan Turboseek
    const result = await searchWithTurboseek(question);

    // Format jawaban
    let replyText = `🔍 *TURBOSEEK AI*\n\n`;
    replyText += `📝 *Pertanyaan:*\n${result.question}\n\n`;
    replyText += `━━━━━━━━━━━━━━━━━━━━\n\n`;
    replyText += `💡 *Jawaban:*\n${result.answer}\n\n`;

    // Tambahkan referensi
    if (result.references.length > 0) {
      replyText += `━━━━━━━━━━━━━━━━━━━━\n\n`;
      replyText += `📚 *Referensi:*\n`;
      result.references.slice(0, 5).forEach((ref, i) => {
        replyText += `${i + 1}. *${ref.title || ref.name}*\n`;
        replyText += `   🔗 ${ref.url}\n`;
      });

      if (result.references.length > 5) {
        replyText += `\n_...dan ${result.references.length - 5} referensi lainnya_\n`;
      }
    }

    // Tambahkan pertanyaan terkait
    if (result.related.length > 0) {
      replyText += `\n━━━━━━━━━━━━━━━━━━━━\n\n`;
      replyText += `🔗 *Pertanyaan Terkait:*\n`;
      result.related.slice(0, 3).forEach((q, i) => {
        replyText += `${i + 1}. ${q}\n`;
      });
    }

    replyText += `\n━━━━━━━━━━━━━━━━━━━━\n`;
    replyText += `⏰ ${new Date(result.timestamp).toLocaleString('id-ID')}\n`;
    replyText += `👤 Creator: ${result.creator}\n\n`;
    replyText += `💡 _Jawaban didukung oleh AI & sumber web._`;

    // Kirim jawaban (potong kalo kepanjangan)
    if (replyText.length > 4000) {
      const parts = replyText.match(/[\s\S]{1,4000}/g) || [replyText];
      for (const part of parts) {
        await sock.sendMessage(
          m.chat,
          { text: part },
          { quoted: m.verifiedQuoted }
        );
        await new Promise(resolve => setTimeout(resolve, 500));
      }
    } else {
      await sock.sendMessage(
        m.chat,
        { text: replyText },
        { quoted: m.verifiedQuoted }
      );
    }

    await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

  } catch (error) {
    console.error("[TURBOSEEK ERROR]", error);
    await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    await sock.sendMessage(
      m.chat,
      {
        text:
          `❌ *Gagal Mencari!*\n\n` +
          `*Alasan:* ${error.message || "Unknown error"}\n\n` +
          `Coba lagi dengan pertanyaan yang berbeda.`
      },
      { quoted: m.verifiedQuoted }
    );
  }
};

handler.command = ["turboseek", "tsearch", "searchai", "perplexity"];
handler.tags = ["ai"];
handler.help = ["turboseek <pertanyaan>"];
handler.limit = true;

export default handler;