// plugins/ai/gemini.js — Google Gemini AI (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Google Gemini AI
 * 🔧 Fungsi     : Chat dengan Gemini AI
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `Contoh penggunaan:\n${usedPrefix + command} <pertanyaan>\n\n` +
      `Contoh:\n` +
      `${usedPrefix + command} Siapa presiden Indonesia?\n` +
      `${usedPrefix + command} Cara membuat website`
    );
  }

  try {
    await m.reply("🤖 *Gemini AI*\n\n⏳ Sedang berpikir...");

    const response = await axios.post(
      "https://api.gemini-ai.com/v1/chat",
      {
        message: text,
        model: "gemini-pro"
      },
      { timeout: 30000 }
    ).catch(async () => {
      // Fallback API
      return axios.get(
        `https://api.betabotz.eu.org/api/search/gemini-ai?text=${encodeURIComponent(text)}`,
        { timeout: 30000 }
      );
    });

    const result = response.data.result || response.data.response || response.data.answer;

    if (!result) {
      throw new Error("Tidak ada respons dari Gemini");
    }

    await m.reply(
      `🤖 *Gemini AI*\n\n` +
      `${result}\n\n` +
      `_Powered by Google Gemini_`
    );

  } catch (e) {
    console.error(e);
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["gemini <text>"];
handler.tags = ["ai"];
handler.command = /^(gemini|bard)$/i;
handler.limit = true;

export default handler;
