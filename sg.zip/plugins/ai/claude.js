// plugins/claude-ai.js — AI Chat Claude Sonnet 4.6 (SynoxCloud API)
import axios from "axios";

// ── Claude Sonnet 4.6 API ─────────────────────────────
async function askClaude(prompt) {
  const url = "https://api.synoxcloud.xyz/ai-chat/claude-sonnet-4.6";

  const res = await axios.get(url, {
    params: { pesan: prompt },
    timeout: 30000,
  });

  const data = res.data;

  if (!data || data.status !== true || !data.result?.reply) {
    throw new Error("Respons API tidak valid atau kosong.");
  }

  return data.result.reply.trim();
}

// ── Handler ───────────────────────────────
let handler = async (m, { text, command, conn }) => {
  if (!text) {
    return m.reply(
      `*Contoh:*\n${command} Siapa presiden Indonesia?\n\n*Kegunaan:*\nChat dengan AI Claude Sonnet 4.6.`
    );
  }

  await m.reply("🤖 Sedang memproses...");

  try {
    const result = await askClaude(text);
    await m.reply(`🤖 *Claude Sonnet 4.6*\n\n${result}`);
  } catch (err) {
    const errMsg = err.response
      ? `HTTP ${err.response.status} - ${err.response.statusText}`
      : err.code === "ECONNABORTED"
      ? "Timeout, server AI terlalu lama merespons."
      : err.message;

    await m.reply(`❌ Gagal memproses permintaan.\n\n*Alasan:* ${errMsg}`);
  }
};

handler.command = ["claude", "claudeai", "sonnet"];
handler.tags = ["ai"];
handler.help = ["claude <pertanyaan>", "sonnet <pertanyaan>"];

export default handler;