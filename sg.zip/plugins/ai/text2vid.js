// plugins/hdvideo.js — HD Video Upscaler v1 (Nexray API)
"use strict";

import axios from "axios";
import FormData from "form-data";
import { downloadContentFromMessage } from "dekzymarket-cyber";

const API_BASE = "https://api.nexray.eu.cc/tools/v1/hdvideo";
const REQUEST_TIMEOUT_MS = 300000; // response_time API bisa sampai 36s+, kasih ruang jauh lebih besar
const DOWNLOAD_TIMEOUT_MS = 120000;
const UPLOAD_TIMEOUT_MS = 60000;
const VERIFY_TIMEOUT_MS = 15000;
const MAX_URL_LENGTH = 2000;
const MAX_INPUT_SIZE_BYTES = 100 * 1024 * 1024; // 100MB
const URL_REGEX = /^https?:\/\/[^\s/$.?#].[^\s]*$/i;

const BROWSER_USER_AGENT =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

const LOG_PREFIX = "[hdvideo]";
const logDebug = (...args) => console.log(LOG_PREFIX, ...args);
const logError = (...args) => console.error(LOG_PREFIX, ...args);

// ═══════════════════════════════════════════════════════════
// RESOLUTION HANDLING
// ═══════════════════════════════════════════════════════════

const VALID_RESOLUTIONS = ["hd", "fullhd", "2k", "4k"];
const RESOLUTION_ALIASES = {
  hd: "hd",
  "720p": "hd",
  "720": "hd",
  fullhd: "fullhd",
  fhd: "fullhd",
  "1080p": "fullhd",
  "1080": "fullhd",
  "2k": "2k",
  "1440p": "2k",
  "1440": "2k",
  "4k": "4k",
  uhd: "4k",
  "2160p": "4k",
  "2160": "4k",
};
const RESOLUTION_LABEL = {
  hd: "HD (720p)",
  fullhd: "Full HD (1080p)",
  "2k": "2K (1440p)",
  "4k": "4K (2160p)",
};
const DEFAULT_RESOLUTION = "hd";

function normalizeResolution(token) {
  if (!token) return null;
  const key = String(token).trim().toLowerCase();
  return RESOLUTION_ALIASES[key] || null;
}

// ── Parse input teks: pisahkan url/resolusi dari kalimat bebas ──
function parseTextInput(text) {
  const trimmed = (text || "").trim();
  if (!trimmed) return { url: null, resolution: null };

  const tokens = trimmed.split(/\s+/);
  let url = null;
  let resolution = null;
  const leftover = [];

  for (const token of tokens) {
    if (!url && URL_REGEX.test(token)) {
      url = token;
      continue;
    }
    const res = normalizeResolution(token.replace(/[|,]/g, ""));
    if (!resolution && res) {
      resolution = res;
      continue;
    }
    leftover.push(token);
  }

  // Dukung juga format "url | resolusi"
  if (!url && trimmed.includes("|")) {
    const parts = trimmed.split("|").map((s) => s.trim());
    if (URL_REGEX.test(parts[0])) url = parts[0];
    if (parts[1]) resolution = normalizeResolution(parts[1]) || resolution;
  }

  return { url, resolution };
}

// ═══════════════════════════════════════════════════════════
// WA MEDIA DETECTION & DOWNLOAD
// ═══════════════════════════════════════════════════════════

function findVideoMessage(m) {
  if (m.quoted) {
    const qMsg = m.quoted.message || m.quoted;
    if (qMsg?.videoMessage) return { message: qMsg, type: "video" };
    if (m.quoted.mtype === "videoMessage" || m.quoted.mediaType === "video") {
      return { message: m.quoted, type: "video" };
    }
  }

  const directMsg = m.message?.videoMessage ? m.message : null;
  if (directMsg) return { message: directMsg, type: "video" };
  if (m.mtype === "videoMessage") return { message: m, type: "video" };

  return null;
}

async function downloadVideoFromWAMessage(videoInfo) {
  if (!downloadContentFromMessage) {
    throw new Error(
      "Fungsi downloadContentFromMessage tidak tersedia. Pastikan library baileys/dekzymarket-cyber terpasang dengan benar."
    );
  }

  const rawMessage =
    videoInfo.message.videoMessage ||
    videoInfo.message.message?.videoMessage ||
    videoInfo.message;

  if (!rawMessage) {
    throw new Error("Tidak dapat menemukan data video pada pesan yang dipilih.");
  }

  const declaredSize = Number(rawMessage.fileLength || 0);
  if (declaredSize > MAX_INPUT_SIZE_BYTES) {
    throw new Error(
      `Ukuran video terlalu besar (${(declaredSize / 1024 / 1024).toFixed(1)}MB). Maksimal ${MAX_INPUT_SIZE_BYTES / 1024 / 1024}MB.`
    );
  }

  const stream = await downloadContentFromMessage(rawMessage, "video");
  const chunks = [];
  for await (const chunk of stream) {
    chunks.push(chunk);
  }
  const buffer = Buffer.concat(chunks);

  if (!buffer.length) {
    throw new Error("Gagal mengunduh video dari pesan WhatsApp (buffer kosong).");
  }
  if (buffer.length > MAX_INPUT_SIZE_BYTES) {
    throw new Error(
      `Ukuran video terlalu besar (${(buffer.length / 1024 / 1024).toFixed(1)}MB). Maksimal ${MAX_INPUT_SIZE_BYTES / 1024 / 1024}MB.`
    );
  }

  return buffer;
}

// ═══════════════════════════════════════════════════════════
// MULTI-HOST UPLOAD + VERIFICATION
// ═══════════════════════════════════════════════════════════

async function uploadToCatbox(buffer, filename) {
  const form = new FormData();
  form.append("reqtype", "fileupload");
  form.append("fileToUpload", buffer, { filename, contentType: "video/mp4" });

  const res = await axios.post("https://catbox.moe/user/api.php", form, {
    headers: { ...form.getHeaders(), "User-Agent": BROWSER_USER_AGENT, Accept: "*/*" },
    timeout: UPLOAD_TIMEOUT_MS,
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
    validateStatus: () => true,
  });

  if (res.status !== 200) {
    throw new Error(`Catbox menolak upload (HTTP ${res.status}).`);
  }

  const url = String(res.data || "").trim();
  if (!URL_REGEX.test(url)) {
    throw new Error("Catbox tidak mengembalikan URL yang valid.");
  }
  return url;
}

async function uploadToUguu(buffer, filename) {
  const form = new FormData();
  form.append("files[]", buffer, { filename, contentType: "video/mp4" });

  const res = await axios.post("https://uguu.se/upload", form, {
    headers: { ...form.getHeaders(), "User-Agent": BROWSER_USER_AGENT, Accept: "application/json" },
    timeout: UPLOAD_TIMEOUT_MS,
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
    validateStatus: () => true,
  });

  if (res.status !== 200) {
    throw new Error(`Uguu menolak upload (HTTP ${res.status}).`);
  }

  const json = typeof res.data === "object" ? res.data : JSON.parse(res.data);
  const url = json?.files?.[0]?.url;

  if (!url || !URL_REGEX.test(url)) {
    throw new Error("Uguu tidak mengembalikan URL yang valid.");
  }
  return url;
}

async function uploadToTmpfiles(buffer, filename) {
  const form = new FormData();
  form.append("file", buffer, { filename, contentType: "video/mp4" });

  const res = await axios.post("https://tmpfiles.org/api/v1/upload", form, {
    headers: { ...form.getHeaders(), "User-Agent": BROWSER_USER_AGENT },
    timeout: UPLOAD_TIMEOUT_MS,
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
    validateStatus: () => true,
  });

  if (res.status !== 200) {
    throw new Error(`Tmpfiles menolak upload (HTTP ${res.status}).`);
  }

  const json = typeof res.data === "object" ? res.data : JSON.parse(res.data);
  const rawUrl = json?.data?.url;

  if (!rawUrl || !URL_REGEX.test(rawUrl)) {
    throw new Error("Tmpfiles tidak mengembalikan URL yang valid.");
  }

  return rawUrl.replace("tmpfiles.org/", "tmpfiles.org/dl/");
}

const UPLOAD_PROVIDERS = [
  { name: "Catbox", fn: uploadToCatbox },
  { name: "Uguu", fn: uploadToUguu },
  { name: "Tmpfiles", fn: uploadToTmpfiles },
];

async function verifyUrlReachable(url) {
  try {
    const res = await axios.get(url, {
      headers: { "User-Agent": BROWSER_USER_AGENT, Range: "bytes=0-1024" },
      timeout: VERIFY_TIMEOUT_MS,
      responseType: "arraybuffer",
      validateStatus: (status) => status === 200 || status === 206,
    });

    const contentType = String(res.headers["content-type"] || "").toLowerCase();
    const isVideoLike =
      contentType.startsWith("video/") ||
      contentType.includes("octet-stream") ||
      contentType.includes("application/mp4");

    if (!isVideoLike) {
      return { ok: false, reason: `Content-type tidak sesuai (${contentType || "kosong"}).` };
    }
    return { ok: true };
  } catch (err) {
    return { ok: false, reason: err.message };
  }
}

async function uploadVideoWithFallback(buffer, filename) {
  const errors = [];

  for (const provider of UPLOAD_PROVIDERS) {
    let uploadedUrl;
    try {
      uploadedUrl = await provider.fn(buffer, filename);
    } catch (err) {
      errors.push(`${provider.name} (upload): ${err.message}`);
      logDebug(`Upload gagal via ${provider.name}:`, err.message);
      continue;
    }

    const verification = await verifyUrlReachable(uploadedUrl);
    if (verification.ok) {
      logDebug(`Upload berhasil & terverifikasi via ${provider.name}: ${uploadedUrl}`);
      return { url: uploadedUrl, provider: provider.name };
    }

    errors.push(`${provider.name} (verifikasi): ${verification.reason}`);
    logDebug(`URL dari ${provider.name} tidak lolos verifikasi:`, verification.reason);
  }

  throw new Error(`Semua provider hosting sementara gagal.\n${errors.join("\n")}`);
}

// ═══════════════════════════════════════════════════════════
// NEXRAY HD VIDEO API CALL
// ═══════════════════════════════════════════════════════════

/**
 * Struktur response Nexray:
 * {
 *   status: true,
 *   author: "@nexray - ElrayyXml",
 *   result: "https://srv33.fileconverto.com/download.php?hash=...",
 *   timestamp: "...",
 *   response_time: "36714ms"
 * }
 * Field "result" adalah URL langsung ke file hasil upscale (bukan binary,
 * bukan nested object) — proses upscale bisa memakan waktu puluhan detik.
 */
async function upscaleVideo(sourceUrl, resolution) {
  let res;
  try {
    res = await axios.get(API_BASE, {
      params: { url: sourceUrl, resolusi: resolution },
      timeout: REQUEST_TIMEOUT_MS,
      validateStatus: () => true,
    });
  } catch (err) {
    if (err.code === "ECONNABORTED") {
      throw new Error("Timeout saat memproses upscale video. Proses ini bisa memakan waktu lama untuk video berdurasi panjang.");
    }
    throw new Error(`Gagal menghubungi server: ${err.message}`);
  }

  const body = res.data;

  if (res.status !== 200) {
    const msg =
      (body && typeof body === "object" && (body.message || body.error)) ||
      mapStatusToMessage(res.status);
    throw new Error(msg);
  }

  if (!body || typeof body !== "object") {
    throw new Error("Response API tidak valid (bukan JSON object).");
  }

  if (body.status !== true) {
    throw new Error(body.message || "API mengembalikan status gagal.");
  }

  const resultUrl = body.result;
  if (!resultUrl || typeof resultUrl !== "string" || !URL_REGEX.test(resultUrl)) {
    throw new Error("URL hasil upscale tidak ditemukan atau tidak valid pada response API.");
  }

  return {
    resultUrl,
    author: body.author || null,
    responseTime: body.response_time || null,
  };
}

function mapStatusToMessage(status) {
  switch (status) {
    case 400:
      return "Parameter tidak valid atau URL video tidak dapat diproses.";
    case 405:
      return "Metode request tidak didukung oleh server.";
    case 429:
      return "Terlalu banyak permintaan. Coba lagi beberapa saat lagi.";
    case 500:
      return "Server mengalami kesalahan internal saat memproses video.";
    default:
      return `HTTP ${status} - Request gagal.`;
  }
}

async function downloadResultVideo(url) {
  let res;
  try {
    res = await axios.get(url, {
      responseType: "arraybuffer",
      timeout: DOWNLOAD_TIMEOUT_MS,
      headers: { "User-Agent": BROWSER_USER_AGENT },
      validateStatus: (status) => status === 200,
    });
  } catch (err) {
    if (err.code === "ECONNABORTED") {
      throw new Error("Timeout saat mengunduh video hasil upscale.");
    }
    throw new Error(`Gagal mengunduh video hasil upscale: ${err.message}`);
  }

  const buffer = Buffer.from(res.data);
  if (!buffer.length) {
    throw new Error("File video hasil unduhan kosong.");
  }

  const contentType = String(res.headers["content-type"] || "").toLowerCase();
  const mime = contentType.startsWith("video/") ? contentType : "video/mp4";

  return { buffer, mime };
}

// ═══════════════════════════════════════════════════════════
// INPUT RESOLUTION
// ═══════════════════════════════════════════════════════════

function normalizeUrl(input) {
  if (!input) return null;
  const trimmed = input.trim();
  if (trimmed.length > MAX_URL_LENGTH) return null;
  if (!URL_REGEX.test(trimmed)) return null;
  return trimmed;
}

async function resolveSourceUrl(m, parsedUrl) {
  if (parsedUrl) {
    const normalized = normalizeUrl(parsedUrl);
    if (!normalized) throw new Error("URL tidak valid. Pastikan diawali dengan http:// atau https://.");
    return { url: normalized, uploaded: false, provider: null };
  }

  const videoInfo = findVideoMessage(m);
  if (!videoInfo) {
    throw new Error("__NO_INPUT__");
  }

  const buffer = await downloadVideoFromWAMessage(videoInfo);
  const { url, provider } = await uploadVideoWithFallback(buffer, `video-${Date.now()}.mp4`);
  return { url, uploaded: true, provider };
}

// ═══════════════════════════════════════════════════════════
// USAGE TEXT
// ═══════════════════════════════════════════════════════════

function buildUsageText(command) {
  return (
    `🎬 *HD Video Upscaler v1*\n\n` +
    `*Cara pakai:*\n` +
    `1️⃣ Reply video lalu ketik: ${command} <resolusi>\n` +
    `2️⃣ Kirim video dengan caption: ${command} <resolusi>\n` +
    `3️⃣ Atau kirim URL langsung: ${command} <url> <resolusi>\n\n` +
    `*Contoh:*\n` +
    `${command} 4k\n` +
    `${command} https://files.catbox.moe/xxx.mp4 fullhd\n` +
    `${command} https://files.catbox.moe/xxx.mp4 | 2k\n\n` +
    `*Resolusi tersedia:*\n` +
    Object.entries(RESOLUTION_LABEL)
      .map(([key, label]) => `• \`${key}\` — ${label}`)
      .join("\n") +
    `\n\n*Default resolusi:* ${DEFAULT_RESOLUTION} (${RESOLUTION_LABEL[DEFAULT_RESOLUTION]})\n` +
    `*Maksimal ukuran video:* ${MAX_INPUT_SIZE_BYTES / 1024 / 1024}MB\n` +
    `*Catatan:* proses upscale bisa memakan waktu hingga beberapa menit tergantung durasi video & resolusi tujuan.`
  );
}

// ═══════════════════════════════════════════════════════════
// HANDLER
// ═══════════════════════════════════════════════════════════

let handler = async (m, { text, command, sock }) => {
  const { url: parsedUrl, resolution: parsedResolution } = parseTextInput(text);
  const hasDirectVideoInput = Boolean(findVideoMessage(m));

  if (!parsedUrl && !hasDirectVideoInput) {
    return sock.sendMessage(m.chat, { text: buildUsageText(command) }, { quoted: m.verifiedQuoted });
  }

  const resolution = parsedResolution || DEFAULT_RESOLUTION;
  if (!VALID_RESOLUTIONS.includes(resolution)) {
    return sock.sendMessage(
      m.chat,
      {
        text:
          `⚠️ Resolusi tidak valid.\n\n` +
          `*Resolusi tersedia:* ${VALID_RESOLUTIONS.join(", ")}`,
      },
      { quoted: m.verifiedQuoted }
    );
  }

  let resolved;
  try {
    resolved = await resolveSourceUrl(m, parsedUrl);
  } catch (err) {
    if (err.message === "__NO_INPUT__") {
      return sock.sendMessage(m.chat, { text: buildUsageText(command) }, { quoted: m.verifiedQuoted });
    }
    logError("resolveSourceUrl gagal:", err.message);
    return sock
      .sendMessage(m.chat, { text: `⚠️ ${err.message}` }, { quoted: m.verifiedQuoted })
      .catch(() => {});
  }

  const { url: sourceUrl, uploaded, provider } = resolved;
  const resolutionLabel = RESOLUTION_LABEL[resolution];

  await sock.sendMessage(
    m.chat,
    {
      text:
        `🎬 Sedang meng-upscale video ke *${resolutionLabel}*...\n\n` +
        (uploaded
          ? `_Video berhasil diunggah & terverifikasi via ${provider}, memulai proses upscale..._\n\n`
          : `*URL sumber:* ${sourceUrl}\n\n`) +
        `_Proses ini bisa memakan waktu 1 hingga beberapa menit tergantung durasi & resolusi tujuan. Mohon tunggu._`,
    },
    { quoted: m.verifiedQuoted }
  );

  try {
    const { resultUrl, responseTime } = await upscaleVideo(sourceUrl, resolution);

    logDebug(`Upscale selesai dalam ${responseTime || "tidak diketahui"}, mengunduh hasil dari ${resultUrl}`);

    const { buffer, mime } = await downloadResultVideo(resultUrl);

    await sock.sendMessage(
      m.chat,
      {
        video: buffer,
        mimetype: mime,
        caption:
          `🎬 *HD Video Upscaler*\n\n` +
          `✅ Video berhasil di-upscale ke *${resolutionLabel}*.` +
          (responseTime ? `\n⏱️ *Waktu proses:* ${responseTime}` : ""),
      },
      { quoted: m.verifiedQuoted }
    );
  } catch (err) {
    logError("upscaleVideo gagal total:", err.message);
    await sock
      .sendMessage(
        m.chat,
        { text: `❌ Gagal meng-upscale video.\n\n*Alasan:* ${err.message}` },
        { quoted: m.verifiedQuoted }
      )
      .catch(() => {});
  }
};

handler.command = ["hdvideo", "enhancevideo", "hdv", "upscale"];
handler.tags = ["tools"];
handler.help = ["hdvideo <resolusi> (reply/kirim video, atau kasih url)"];

export default handler;