// plugins/ai/claudev2.js — Claude AI Chat V2 (SHINOBU MD)
/**
 * ───「 SHINOBU MD 」───
 * 📝 Plugin     : Claude AI Chat V2
 * 🔗 API        : Nexray API
 * 🤖 Model      : Claude AI
 * 💎 Version    : Premium Edition
 * ⚡ By Shinobu
 * ─────────────────────────
 */

"use strict";

import axios from "axios";

const API_BASE = "https://api.nexray.eu.cc/ai/claude";
const REQUEST_TIMEOUT_MS = 60000;

if (!global.claudeHistory) global.claudeHistory = {};

async function chatWithClaude(text) {
  let res;
  try {
    res = await axios.get(API_BASE, {
      params: { text },
      timeout: REQUEST_TIMEOUT_MS,
      validateStatus: () => true,
    });
  } catch (err) {
    if (err.code === "ECONNABORTED") {
      throw new Error("⏰ Timeout! Claude AI terlalu lama merespon.");
    }
    throw new Error(`🌐 Gagal menghubungi server: ${err.message}`);
  }

  if (res.status !== 200) {
    let errMsg = `📡 HTTP ${res.status} - ${res.statusText || "Request gagal"}`;
    if (res.data && res.data.message) errMsg = res.data.message;
    throw new Error(errMsg);
  }

  if (!res.data || !res.data.status) {
    throw new Error("❌ Claude AI tidak memberikan respon.");
  }

  return {
    reply: res.data.result || "Maaf, AI tidak bisa menjawab.",
    timestamp: res.data.timestamp || new Date().toISOString(),
    response_time: res.data.response_time || "Unknown"
  };
}

function buildMenuText(prefix) {
  return (
    `╭══════════════════════════════╮\n` +
    `│                              │\n` +
    `│   🤖  *CLAUDE AI V2*  🤖   │\n` +
    `│   ──────────────────────    │\n` +
    `│   AI Coding Assistant       │\n` +
    `│   Premium Edition 💎        │\n` +
    `│                              │\n` +
    `╰══════════════════════════════╯\n\n` +
    `  📌 *Deskripsi:*\n` +
    `  › Chat dengan Claude AI\n` +
    `  › AI assistant untuk coding\n` +
    `  › Tanya jawab bebas & detail\n` +
    `  › Respon cepat & akurat\n\n` +
    `╭──────────────────────────────╮\n` +
    `  📋 *CARA PAKAI:*\n` +
    `╰──────────────────────────────╯\n\n` +
    `  ${prefix}claudev2 <pertanyaan>\n\n` +
    `╭──────────────────────────────╮\n` +
    `  💡 *CONTOH PENGGUNAAN:*\n` +
    `╰──────────────────────────────╯\n\n` +
    `  *📚 Edukasi:*\n` +
    `  ${prefix}claudev2 apa itu AI?\n` +
    `  ${prefix}claudev2 jelaskan cara\n` +
    `  kerja machine learning\n\n` +
    `  *💻 Coding:*\n` +
    `  ${prefix}claudev2 buatkan fungsi\n` +
    `  kalkulator JavaScript\n` +
    `  ${prefix}claudev2 debug kode ini:\n` +
    `  const x = [1,2,3]; x.map()\n\n` +
    `  *🔬 Sains:*\n` +
    `  ${prefix}claudev2 apa itu black\n` +
    `  hole dan bagaimana\n` +
    `  terbentuknya?\n\n` +
    `  *🎨 Kreatif:*\n` +
    `  ${prefix}claudev2 buatkan puisi\n` +
    `  tentang teknologi\n` +
    `  ${prefix}claudev2 tulis cerita\n` +
    `  pendek tentang masa depan\n\n` +
    `╭──────────────────────────────╮\n` +
    `  ✨ *FITUR UNGGULAN:*\n` +
    `╰──────────────────────────────╯\n\n` +
    `  ✅ AI Tanpa Batas\n` +
    `  ✅ Respon Detail & Panjang\n` +
    `  ✅ Coding Assistant\n` +
    `  ✅ Multi Bahasa\n` +
    `  ✅ History Chat (10)\n` +
    `  ✅ Auto Save Chat\n\n` +
    `╭──────────────────────────────╮\n` +
    `  ⚠️  *NOTE:*\n` +
    `  › Timeout 60 detik\n` +
    `  › No Limit Pesan\n` +
    `  › Bebas Tanya Apa Aja\n` +
    `╰──────────────────────────────╯\n\n` +
    `  ⚡ *By Shinobu*  |  💎 *Premium*`
  );
}

let handler = async (m, { text, command, sock }) => {
  const prefix = global.prefix || ".";

  // Tampilkan menu mewah kalo gak ada input
  if (!text || !text.trim()) {
    return sock.sendMessage(
      m.chat,
      { text: buildMenuText(prefix) },
      { quoted: m.verifiedQuoted }
    );
  }

  const question = text.trim();

  // Reaksi + Progress mewah
  await sock.sendMessage(m.chat, { react: { text: "🤖", key: m.key } });

  await sock.sendMessage(
    m.chat,
    {
      text:
        `╭──────────────────────────────╮\n` +
        `  🤖  *CLAUDE AI V2*  🤖\n` +
        `╰──────────────────────────────╯\n\n` +
        `  📝 *Pertanyaan:*\n` +
        `  ❝ ${question} ❞\n\n` +
        `  ⏳ *Status:* Menganalisis...\n` +
        `  🧠 *AI:* Sedang berpikir\n\n` +
        `  _Tunggu sebentar ya..._\n\n` +
        `  ⚡ *By Shinobu*`
    },
    { quoted: m.verifiedQuoted }
  );

  try {
    const result = await chatWithClaude(question);

    // Simpan history
    if (!global.claudeHistory[m.sender]) {
      global.claudeHistory[m.sender] = [];
    }
    global.claudeHistory[m.sender].push({
      question,
      answer: result.reply,
      timestamp: result.timestamp
    });
    if (global.claudeHistory[m.sender].length > 10) {
      global.claudeHistory[m.sender] = global.claudeHistory[m.sender].slice(-10);
    }

    // Kirim jawaban AI LANGSUNG (polos, tanpa hiasan)
    let jawaban = result.reply;

    if (jawaban.length > 4000) {
      const parts = jawaban.match(/[\s\S]{1,4000}/g) || [jawaban];
      for (const part of parts) {
        await sock.sendMessage(m.chat, { text: part }, { quoted: m.verifiedQuoted });
        await new Promise(resolve => setTimeout(resolve, 300));
      }
    } else {
      await sock.sendMessage(m.chat, { text: jawaban }, { quoted: m.verifiedQuoted });
    }

    // Info singkat di akhir
    await sock.sendMessage(
      m.chat,
      {
        text:
          `╭──────────────────────────────╮\n` +
          `  ⏱️ ${result.response_time}  |  ⚡ *By Shinobu*\n` +
          `╰──────────────────────────────╯`
      },
      { quoted: m.verifiedQuoted }
    );

    await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

  } catch (error) {
    console.error("[CLAUDE V2 ERROR]", error);
    await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });

    await sock.sendMessage(
      m.chat,
      {
        text:
          `╭──────────────────────────────╮\n` +
          `  ❌  *GAGAL!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  📡 ${error.message}\n\n` +
          `  💡 Coba lagi nanti!\n\n` +
          `  ⚡ *By Shinobu*`
      },
      { quoted: m.verifiedQuoted }
    );
  }
};

handler.command = ["claudev2"];
handler.tags = ["ai"];
handler.help = ["claudev2 <pertanyaan>"];
handler.limit = false;

export default handler;