// plugins/ai/blackbox.js — Blackbox AI coding assistant (QueVaroU V2.0)
/**
 * ───「 QueVaroU V2.0 」───
 * 📝 Plugin     : Blackbox AI
 * 🔧 Fungsi     : AI coding assistant untuk programming
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `Contoh penggunaan:\n${usedPrefix + command} <pertanyaan coding>\n\n` +
      `Contoh:\n` +
      `${usedPrefix + command} Cara membuat API dengan Node.js\n` +
      `${usedPrefix + command} Bagaimana menggunakan async/await?`
    );
  }

  try {
    await m.reply("💻 *Blackbox AI*\n\n⏳ Generating code...");

    const response = await axios.post(
      "https://api.blackbox.ai/v1/chat",
      {
        messages: [{ role: "user", content: text }],
        model: "blackbox"
      },
      { timeout: 30000 }
    ).catch(async () => {
      // Fallback
      return axios.get(
        `https://api.betabotz.eu.org/api/search/blackbox-ai?text=${encodeURIComponent(text)}`,
        { timeout: 30000 }
      );
    });

    const result = response.data.response || response.data.result || response.data.answer;

    await m.reply(
      `💻 *Blackbox AI*\n\n` +
      `${result}\n\n` +
      `_AI Coding Assistant_`
    );

  } catch (e) {
    console.error(e);
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["blackbox <text>"];
handler.tags = ["ai"];
handler.command = /^(blackbox|bb|code)$/i;
handler.limit = true;

export default handler;
