// plugins/text2img.js — Text to Image AI Generator (SynoxCloud API)
"use strict";

import axios from "axios";

const API_BASE = "https://api.synoxcloud.xyz/ai-generate/text-2-image";
const VALID_RATIOS = ["1:1", "16:9", "9:16", "4:3", "3:4", "3:2", "2:3"];
const REQUEST_TIMEOUT_MS = 60000;
const IMAGE_DOWNLOAD_TIMEOUT_MS = 30000;
const MAX_PROMPT_LENGTH = 2000;

/**
 * Memanggil endpoint text-to-image dan mengembalikan data hasil generate.
 * Struktur response API:
 * {
 *   statusCode: 200,
 *   creator: "@lordsaurus",
 *   status: true,
 *   data: { status, code, prompt, ratio, url },
 *   timestamp: "..."
 * }
 */
async function generateImage(prompt, ratio) {
  let res;
  try {
    res = await axios.get(API_BASE, {
      params: { prompt, ratio },
      timeout: REQUEST_TIMEOUT_MS,
      validateStatus: () => true,
    });
  } catch (err) {
    if (err.code === "ECONNABORTED") {
      throw new Error("Timeout saat menghubungi server AI generate image.");
    }
    throw new Error(`Gagal menghubungi server: ${err.message}`);
  }

  const body = res.data;

  if (res.status !== 200) {
    const msg =
      (body && (body.message || body.error)) ||
      `HTTP ${res.status} - ${res.statusText || "Request gagal"}`;
    throw new Error(msg);
  }

  if (!body || typeof body !== "object") {
    throw new Error("Response API tidak valid (bukan JSON object).");
  }

  if (body.status !== true) {
    throw new Error(body.message || "API mengembalikan status gagal.");
  }

  const data = body.data;
  if (!data || typeof data !== "object") {
    throw new Error("Field 'data' tidak ditemukan pada response API.");
  }

  if (data.status !== true || !data.url) {
    throw new Error(data.message || "URL gambar tidak tersedia pada response API.");
  }

  return {
    url: data.url,
    prompt: data.prompt || prompt,
    ratio: data.ratio || ratio,
    creator: body.creator || null,
  };
}

/**
 * Mengunduh gambar dari URL hasil generate menjadi Buffer siap kirim.
 */
async function downloadImageBuffer(url) {
  let res;
  try {
    res = await axios.get(url, {
      responseType: "arraybuffer",
      timeout: IMAGE_DOWNLOAD_TIMEOUT_MS,
      validateStatus: (status) => status === 200,
    });
  } catch (err) {
    if (err.code === "ECONNABORTED") {
      throw new Error("Timeout saat mengunduh hasil gambar.");
    }
    throw new Error(`Gagal mengunduh gambar hasil generate: ${err.message}`);
  }

  const buffer = Buffer.from(res.data);
  if (!buffer.length) {
    throw new Error("File gambar hasil generate kosong.");
  }

  const contentType = String(res.headers["content-type"] || "").toLowerCase();
  const mime = contentType.startsWith("image/") ? contentType : "image/jpeg";

  return { buffer, mime };
}

function normalizeRatio(input) {
  if (!input) return "1:1";
  const cleaned = input.trim().replace(/\s+/g, "");
  return VALID_RATIOS.includes(cleaned) ? cleaned : null;
}

function parseInput(text) {
  const parts = text.split("|").map((s) => s.trim());
  const prompt = parts[0] || "";
  const ratioInput = parts[1];
  return { prompt, ratioInput };
}

function buildUsageText(command) {
  return (
    `🖼️ *Text to Image AI*\n\n` +
    `*Cara pakai:*\n` +
    `${command} <prompt> | <ratio>\n\n` +
    `*Contoh:*\n` +
    `${command} A cyberpunk city at night, neon lights, 4k\n` +
    `${command} Cute cat astronaut in space | 16:9\n\n` +
    `*Ratio tersedia:* ${VALID_RATIOS.join(", ")}\n` +
    `*Default ratio:* 1:1\n` +
    `*Batas panjang prompt:* ${MAX_PROMPT_LENGTH} karakter`
  );
}

let handler = async (m, { text, command, sock }) => {
  if (!text || !text.trim()) {
    return sock.sendMessage(m.chat, { text: buildUsageText(command) }, { quoted: m.verifiedQuoted });
  }

  const { prompt, ratioInput } = parseInput(text);

  if (!prompt) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Prompt tidak boleh kosong.\n\nContoh: ${command} A futuristic city | 16:9` },
      { quoted: m.verifiedQuoted }
    );
  }

  if (prompt.length > MAX_PROMPT_LENGTH) {
    return sock.sendMessage(
      m.chat,
      { text: `⚠️ Prompt terlalu panjang (${prompt.length}/${MAX_PROMPT_LENGTH} karakter). Persingkat dulu ya.` },
      { quoted: m.verifiedQuoted }
    );
  }

  const ratio = normalizeRatio(ratioInput);
  if (ratioInput && !ratio) {
    return sock.sendMessage(
      m.chat,
      {
        text:
          `⚠️ Ratio *"${ratioInput}"* tidak valid.\n\n` +
          `*Ratio tersedia:* ${VALID_RATIOS.join(", ")}`,
      },
      { quoted: m.verifiedQuoted }
    );
  }

  const finalRatio = ratio || "1:1";

  const waitMsg = await sock.sendMessage(
    m.chat,
    { text: `🎨 Sedang membuat gambar...\n\n*Prompt:* ${prompt}\n*Ratio:* ${finalRatio}` },
    { quoted: m.verifiedQuoted }
  );

  try {
    const result = await generateImage(prompt, finalRatio);
    const { buffer, mime } = await downloadImageBuffer(result.url);

    await sock.sendMessage(
      m.chat,
      {
        image: buffer,
        mimetype: mime,
        caption:
          `🖼️ *Text to Image*\n\n` +
          `📝 *Prompt:* ${result.prompt}\n` +
          `📐 *Ratio:* ${result.ratio}`,
      },
      { quoted: m.verifiedQuoted }
    );
  } catch (err) {
    await sock.sendMessage(
      m.chat,
      { text: `❌ Gagal membuat gambar.\n\n*Alasan:* ${err.message}` },
      { quoted: m.verifiedQuoted }
    ).catch(() => {});
  } finally {
    // Hapus pesan "sedang membuat..." kalau bot punya method deleteMessage/sendMessage revoke
    if (waitMsg?.key && typeof sock.sendMessage === "function") {
      try {
        await sock.sendMessage(m.chat, { delete: waitMsg.key });
      } catch {
        // Sebagian koneksi tidak support revoke pesan sendiri di semua konteks — abaikan jika gagal
      }
    }
  }
};

handler.command = ["txt2img", "text2img", "text2image", "img", "imagine"];
handler.tags = ["ai"];
handler.help = ["txt2img <prompt> | <ratio>"];

export default handler;