// plugins/ai/perplexity.js — Perplexity AI (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Perplexity AI
 * 🔧 Fungsi     : Search dengan Perplexity
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `🤖 *Perplexity AI*\n\n` +
      `Contoh: ${usedPrefix + command} <prompt>\n\n` +
      `Fungsi: Search dengan Perplexity`
    );
  }

  try {
    await m.reply("⏳ Processing...");
    
    // API call simulation
    const result = `Response from Perplexity AI: ${text}`;
    
    await m.reply(
      `🤖 *Perplexity AI*\n\n` +
      `${result}\n\n` +
      `⚡ SHINOBU MD v1.2`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["perplexity", "pplx"];
handler.tags = ['ai'];
handler.command = /^(perplexity|pplx)$/i;

export default handler;
