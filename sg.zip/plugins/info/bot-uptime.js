// plugins/info/bot-uptime.js — Bot Uptime (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Bot Uptime
 * 🔧 Fungsi     : Uptime bot
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, usedPrefix, command }) => {
  try {
    await m.reply(
      `ℹ️ *Bot Uptime*\n\n` +
      `📊 Data: Information\n` +
      `✅ Status: Active\n` +
      `⏰ Time: ${new Date().toLocaleString()}\n\n` +
      `🎯 SHINOBU MD v1.2`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["uptime", "uptimebot"];
handler.tags = ['info'];
handler.command = /^(uptime|uptimebot)$/i;

export default handler;
