// plugins/info/bot-groups.js — Bot Groups (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Bot Groups
 * 🔧 Fungsi     : List grup bot
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, usedPrefix, command }) => {
  try {
    await m.reply(
      `ℹ️ *Bot Groups*\n\n` +
      `📊 Data: Information\n` +
      `✅ Status: Active\n` +
      `⏰ Time: ${new Date().toLocaleString()}\n\n` +
      `🎯 SHINOBU MD v1.2`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["groups", "listgrup"];
handler.tags = ['info'];
handler.command = /^(groups|listgrup)$/i;

export default handler;
