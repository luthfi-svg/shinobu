"use strict";

import axios from "axios";

const API_FFNEWS = "https://api.synoxcloud.xyz/berita/ff-news";
const TIMEOUT = 15000;

async function ambilBerita(jumlah = 5) {
  try {
    const res = await axios.get(API_FFNEWS, {
      params: { limit: jumlah },
      timeout: TIMEOUT,
      validateStatus: () => true
    });

    const data = res.data;
    if (res.status !== 200 || !data?.status) {
      throw new Error(data?.message || `Kesalahan: HTTP ${res.status}`);
    }
    return data.result;
  } catch (err) {
    if (err.code === "ECONNABORTED") throw new Error("⏰ Waktu habis!");
    throw new Error(`🌐 Gagal terhubung: ${err.message}`);
  }
}

function tampilMenu(prefix) {
  return `╭══════════════════════════════╮
│   📰 BERITA FREE FIRE TERBARU 📰   │
│   Update Resmi Garena FF    │
╰══════════════════════════════╯

📌 Cara Pakai:
  ${prefix}infoff [jumlah]
  ${prefix}beritaff [jumlah]

💡 Contoh:
  ${prefix}infoff → Tampil 5 berita
  ${prefix}infoff 10 → Tampil 10 berita (maks 20)

⚡ Shinobu MD v1.1`;
}

// ✅ Perbaikan: Pakai `sock` sebagai objek koneksi sesuai standar Shinobu MD
let handler = async (m, { text, sock, prefix }) => {
  if (!text || !text.trim()) {
    return sock.sendMessage(m.chat, { text: tampilMenu(prefix) }, { quoted: m.quoted || m });
  }

  const jumlah = parseInt(text.trim());
  if (isNaN(jumlah) || jumlah < 1 || jumlah > 20) {
    return sock.sendMessage(m.chat, {
      text: `⚠️ Jumlah tidak valid!\nMasukkan angka 1 sampai 20\nContoh: ${prefix}infoff 5`
    }, { quoted: m.quoted || m });
  }

  await sock.sendMessage(m.chat, { react: { text: "🔄", key: m.key } });

  try {
    const berita = await ambilBerita(jumlah);
    let teks = `╭──────────────────────────────╮\n`;
    teks += `  ✅  BERITA FREE FIRE TERBARU\n`;
    teks += `  📊 Total: ${berita.total} | Sumber: ff.garena.com\n`;
    teks += `╰──────────────────────────────╯\n\n`;

    berita.news.forEach((item, i) => {
      teks += `${i + 1}. *${item.title}*\n`;
      teks += `   📂 Kategori: ${item.category}\n`;
      teks += `   📅 Tanggal: ${item.time}\n`;
      teks += `   🔗 ${item.link}\n\n`;
    });

    teks += `⚡ Shinobu MD v1.1`;

    if (berita.news[0]?.cover) {
      await sock.sendMessage(m.chat, {
        image: { url: berita.news[0].cover },
        caption: teks
      }, { quoted: m.quoted || m });
    } else {
      await sock.sendMessage(m.chat, { text: teks }, { quoted: m.quoted || m });
    }

    await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

  } catch (err) {
    console.error("[ERROR INFO FF]", err);
    await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    await sock.sendMessage(m.chat, {
      text: `╭──────────────────────────────╮\n` +
            `  ❌  GAGAL MEMUAT BERITA!\n` +
            `╰──────────────────────────────╯\n\n` +
            `  📡 ${err.message}\n\n` +
            `  ⚡ Shinobu MD v1.1`
    }, { quoted: m.quoted || m });
  }
};

handler.command = ["infoff", "beritaff", "ffberita", "ffnews"];
handler.tags = ["info"];
handler.help = ["infoff [jumlah]"];
handler.limit = true;
export default handler;