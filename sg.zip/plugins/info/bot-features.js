// plugins/info/bot-features.js — Bot Features (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Bot Features
 * 🔧 Fungsi     : Fitur bot
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, usedPrefix, command }) => {
  try {
    await m.reply(
      `ℹ️ *Bot Features*\n\n` +
      `📊 Data: Information\n` +
      `✅ Status: Active\n` +
      `⏰ Time: ${new Date().toLocaleString()}\n\n` +
      `🎯 SHINOBU MD v1.2`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["features", "fiturbot"];
handler.tags = ['info'];
handler.command = /^(features|fiturbot)$/i;

export default handler;
