// plugins/info/bot-commands.js — Bot Commands (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Bot Commands
 * 🔧 Fungsi     : List commands
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, usedPrefix, command }) => {
  try {
    await m.reply(
      `ℹ️ *Bot Commands*\n\n` +
      `📊 Data: Information\n` +
      `✅ Status: Active\n` +
      `⏰ Time: ${new Date().toLocaleString()}\n\n` +
      `🎯 SHINOBU MD v1.2`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["commands", "listcmd"];
handler.tags = ['info'];
handler.command = /^(commands|listcmd)$/i;

export default handler;
