// plugins/info/server-cpu.js — Server CPU (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Server CPU
 * 🔧 Fungsi     : CPU usage server
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { sock, usedPrefix, command }) => {
  try {
    await m.reply(
      `ℹ️ *Server CPU*\n\n` +
      `📊 Data: Information\n` +
      `✅ Status: Active\n` +
      `⏰ Time: ${new Date().toLocaleString()}\n\n` +
      `🎯 SHINOBU MD v1.2`
    );
  } catch (e) {
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["servercpu", "cpuserver"];
handler.tags = ['info'];
handler.command = /^(servercpu|cpuserver)$/i;

export default handler;
