// plugins/game/tebak-umur.js — Tebak Umur (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Tebak Umur
 * 🔧 Fungsi     : Tebak umur orang
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const questions = [
    { q: "Pertanyaan 1", a: "Jawaban 1" },
    { q: "Pertanyaan 2", a: "Jawaban 2" },
    { q: "Pertanyaan 3", a: "Jawaban 3" },
  ];
  
  const random = questions[Math.floor(Math.random() * questions.length)];
  
  await m.reply(
    `🎮 *Tebak Umur*\n\n` +
    `❓ ${random.q}\n\n` +
    `⏰ Waktu: 60 detik\n` +
    `💡 Ketik jawaban untuk menjawab\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
  
  // Store game session
  global.db.data.game = global.db.data.game || {};
  global.db.data.game[m.chat] = {
    question: random.q,
    answer: random.a,
    command: command
  };
};

handler.help = ["tebakumur", "guessage"];
handler.tags = ['game'];
handler.command = /^(tebakumur|guessage)$/i;

export default handler;
