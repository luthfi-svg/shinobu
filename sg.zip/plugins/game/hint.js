// plugins/game/hint.js — Hint untuk game (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Hint
 * 🔧 Fungsi     : Minta hint untuk game yang sedang berjalan
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m) => {
  const id = m.chat;
  
  const games = [
    "tebakgambar",
    "tebaklirik",
    "tebakkata",
    "susunkata",
    "caklontong",
    "tebakkabupaten"
  ];

  let found = false;

  for (const game of games) {
    if (global[game] && global[game][id]) {
      const gameData = global[game][id];
      const jawaban = gameData.jawaban;
      
      // Generate hint (show some letters)
      const hintLength = Math.ceil(jawaban.length * 0.3);
      let hint = "";
      
      for (let i = 0; i < jawaban.length; i++) {
        if (i < hintLength || jawaban[i] === " ") {
          hint += jawaban[i];
        } else {
          hint += "_";
        }
      }
      
      await m.reply(
        `💡 *Hint*\n\n` +
        `Clue: ${hint}\n\n` +
        `_Masih bingung? Tebak aja!_`
      );
      
      found = true;
      break;
    }
  }

  if (!found) {
    await m.reply("❌ Tidak ada game yang sedang berjalan!");
  }
};

handler.help = ["hint"];
handler.tags = ["game"];
handler.command = /^(hint|clue)$/i;
handler.limit = false;

export default handler;
