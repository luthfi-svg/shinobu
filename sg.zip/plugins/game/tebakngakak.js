// plugins/game/tebakngakak.js — Tebak Ngakak Game (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Tebak Ngakak Game
 * 🔗 API        : SynoxCloud API
 * 🎮 Genre      : Quiz / Tebak Lucu
 * 😂 Fun        : Tebak-tebakan ngakak
 * 📦 Version    : 1.2
 * ⚡ By Shinobu
 * ─────────────────────────
 */

"use strict";

import axios from "axios";

const API_BASE = "https://api.synoxcloud.xyz/games/tebakngakak";
const REQUEST_TIMEOUT_MS = 15000;

if (!global.tebakNgakakGame) global.tebakNgakakGame = {};
if (!global.tebakNgakakScore) global.tebakNgakakScore = {};

async function getSoal() {
  let res;
  try {
    res = await axios.get(API_BASE, {
      timeout: REQUEST_TIMEOUT_MS,
      validateStatus: () => true,
    });
  } catch (err) {
    if (err.code === "ECONNABORTED") throw new Error("⏰ Timeout! Server terlalu lama.");
    throw new Error(`🌐 Gagal menghubungi server: ${err.message}`);
  }

  if (res.status !== 200 || !res.data?.status || !res.data?.result) {
    throw new Error("❌ Gagal mendapatkan soal!");
  }

  return {
    questions: res.data.result.questions || "Soal tidak tersedia",
    clues: res.data.result.clues || "",
    answers: res.data.result.answers || "",
    reason: res.data.result.reason || ""
  };
}

let handler = async (m, { text, command, sock }) => {
  const prefix = global.prefix || ".";

  // ===== 1. .tebakngakak (TANPA TEKS) = MULAI GAME =====
  if ((command === "tebakngakak" || command === "tngakak") && (!text || !text.trim())) {
    if (global.tebakNgakakGame[m.sender]) {
      const game = global.tebakNgakakGame[m.sender];
      
      if (Date.now() - game.startTime > 120000) {
        delete global.tebakNgakakGame[m.sender];
      } else {
        return sock.sendMessage(m.chat, {
          text:
            `╭──────────────────────────────╮\n` +
            `  ⚠️  *GAME MASIH AKTIF!*\n` +
            `╰──────────────────────────────╯\n\n` +
            `  📝 *Soal:*\n` +
            `  ❝ ${game.questions} ❞\n\n` +
            `  💡 *Clue:* ${game.clues}\n` +
            `  🔤 *Hint:* ${game.answers.length} huruf\n` +
            `  🔤 Awalan: *${game.answers[0].toUpperCase()}...*\n\n` +
            `  ✍️  *${prefix}tebakngakak <jawaban>*\n` +
            `  🏳️  *${prefix}nyerahngakak* menyerah\n\n` +
            `  ⚡ *Shinobu MD v1.2*`
        }, { quoted: m.verifiedQuoted });
      }
    }

    await sock.sendMessage(m.chat, { react: { text: "😂", key: m.key } });

    try {
      const data = await getSoal();

      global.tebakNgakakGame[m.sender] = {
        questions: data.questions,
        clues: data.clues,
        answers: data.answers,
        reason: data.reason,
        startTime: Date.now()
      };

      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  😂  *TEBAK NGAKAK*  😂\n` +
          `╰──────────────────────────────╯\n\n` +
          `  📝 *Soal:*\n` +
          `  ❝ ${data.questions} ❞\n\n` +
          `  💡 *Clue:* ${data.clues}\n` +
          `  🔤 *Hint:* ${data.answers.length} huruf\n` +
          `  🔤 Awalan: *${data.answers[0].toUpperCase()}...*\n\n` +
          `  ✍️  *${prefix}tebakngakak <jawaban>*\n` +
          `  🏳️  *${prefix}nyerahngakak* menyerah\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });

    } catch (err) {
      console.error("[TEBAK NGAKAK ERROR]", err);
      await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  ❌  *GAGAL!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  📡 ${err.message}\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }
  }

  // ===== 2. .tebakngakak <jawaban> = JAWAB =====
  if (text && text.trim() && (command === "tebakngakak" || command === "tngakak")) {
    if (!global.tebakNgakakGame[m.sender]) {
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  ⚠️  *BELUM ADA GAME!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  Ketik *${prefix}tebakngakak* dulu!\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }

    const game = global.tebakNgakakGame[m.sender];
    const jawabanUser = text.trim().toLowerCase();
    const jawabanBenar = game.answers.toLowerCase();

    if (Date.now() - game.startTime > 120000) {
      delete global.tebakNgakakGame[m.sender];
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  ⏰  *WAKTU HABIS!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  📝 ${game.questions}\n` +
          `  ✅ *${game.answers}*\n` +
          `  💬 ${game.reason}\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }

    const isExact = jawabanUser === jawabanBenar;
    const isContained = jawabanBenar.includes(jawabanUser) && jawabanUser.length > 2;

    if (isExact || isContained) {
      // BENAR
      if (!global.tebakNgakakScore[m.sender]) {
        global.tebakNgakakScore[m.sender] = { total: 0, benar: 0, salah: 0 };
      }
      global.tebakNgakakScore[m.sender].total += 10;
      global.tebakNgakakScore[m.sender].benar += 1;
      delete global.tebakNgakakGame[m.sender];

      await sock.sendMessage(m.chat, { react: { text: "😂", key: m.key } });

      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  😂  *BENAR!*  😂\n` +
          `╰──────────────────────────────╯\n\n` +
          `  📝 ${game.questions}\n` +
          `  ✅ *${game.answers}*\n` +
          `  💬 ${game.reason}\n` +
          `  ⭐ +10 EXP\n\n` +
          `  🏆 Skor : ${global.tebakNgakakScore[m.sender].total}\n\n` +
          `  Ketik *${prefix}tebakngakak* main lagi!\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });

    } else {
      // SALAH
      if (!global.tebakNgakakScore[m.sender]) {
        global.tebakNgakakScore[m.sender] = { total: 0, benar: 0, salah: 0 };
      }
      global.tebakNgakakScore[m.sender].total -= 5;
      global.tebakNgakakScore[m.sender].salah += 1;
      delete global.tebakNgakakGame[m.sender];

      await sock.sendMessage(m.chat, { react: { text: "💔", key: m.key } });

      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  💔  *SALAH!*  💔\n` +
          `╰──────────────────────────────╯\n\n` +
          `  📝 ${game.questions}\n` +
          `  ✅ *${game.answers}*\n` +
          `  💬 ${game.reason}\n` +
          `  ❌ ${jawabanUser}\n` +
          `  💔 -5 EXP\n\n` +
          `  Ketik *${prefix}tebakngakak* coba lagi!\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }
  }

  // ===== 3. .nyerahngakak = MENYERAH =====
  if (command === "nyerahngakak") {
    if (!global.tebakNgakakGame[m.sender]) {
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  ⚠️  *TIDAK ADA GAME!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  Ketik *${prefix}tebakngakak* dulu!\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }

    const game = global.tebakNgakakGame[m.sender];
    delete global.tebakNgakakGame[m.sender];

    return sock.sendMessage(m.chat, {
      text:
        `╭──────────────────────────────╮\n` +
        `  🏳️  *MENYERAH!*  🏳️\n` +
        `╰──────────────────────────────╯\n\n` +
        `  📝 ${game.questions}\n` +
        `  ✅ *${game.answers}*\n` +
        `  💬 ${game.reason}\n\n` +
        `  Ketik *${prefix}tebakngakak* main lagi!\n\n` +
        `  ⚡ *Shinobu MD v1.2*`
    }, { quoted: m.verifiedQuoted });
  }

  // ===== 4. .ngakakskor = CEK SKOR =====
  if (command === "ngakakskor") {
    const score = global.tebakNgakakScore?.[m.sender];
    
    if (!score) {
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  🏆  *SKOR TEBAK NGAKAK*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  Kamu belum pernah main!\n` +
          `  Ketik *${prefix}tebakngakak*\n` +
          `  untuk mulai.\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }

    const total = score.benar + score.salah;
    const akurasi = total > 0 ? Math.round((score.benar / total) * 100) : 0;

    return sock.sendMessage(m.chat, {
      text:
        `╭──────────────────────────────╮\n` +
        `  🏆  *STATISTIK KAMU*\n` +
        `╰──────────────────────────────╯\n\n` +
        `  ⭐ Skor    : ${score.total}\n` +
        `  ✅ Benar   : ${score.benar}\n` +
        `  ❌ Salah   : ${score.salah}\n` +
        `  📊 Akurasi : ${akurasi}%\n` +
        `  🎯 Total   : ${total} soal\n\n` +
        `  ⚡ *Shinobu MD v1.2*`
    }, { quoted: m.verifiedQuoted });
  }
};

handler.command = ["tebakngakak", "tngakak", "nyerahngakak", "ngakakskor"];
handler.tags = ["game"];
handler.help = ["tebakngakak"];
handler.limit = true;

export default handler;