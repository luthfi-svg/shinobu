// plugins/game/tebakkata.js — Tebak kata game (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Tebak Kata
 * 🔧 Fungsi     : Game tebak kata acak
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

global.tebakkata = global.tebakkata || {};

let handler = async (m, { sock, usedPrefix, command }) => {
  const id = m.chat;
  
  if (global.tebakkata[id]) {
    return m.reply(`❌ Masih ada game! Ketik *${usedPrefix}nyerah* untuk menyerah`);
  }

  try {
    await m.reply("⏳ *Loading Game...*");

    const response = await axios.get(
      "https://api.betabotz.eu.org/api/game/tebakkata",
      { timeout: 15000 }
    );

    const data = response.data.result;
    const { soal, jawaban } = data;

    global.tebakkata[id] = {
      jawaban: jawaban.toLowerCase(),
      timeout: setTimeout(() => {
        if (global.tebakkata[id]) {
          sock.sendMessage(id, {
            text: `⏰ *Waktu Habis!*\n\nJawaban: *${jawaban}*`
          });
          delete global.tebakkata[id];
        }
      }, 60000)
    };

    await m.reply(
      `🎮 *TEBAK KATA*\n\n` +
      `📝 Soal: ${soal}\n\n` +
      `⏰ Waktu: 60 detik\n` +
      `💡 Ketik *${usedPrefix}hint* untuk clue`
    );

  } catch (e) {
    console.error(e);
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["tebakkata"];
handler.tags = ["game"];
handler.command = /^(tebakkata)$/i;
handler.limit = true;

export default handler;
