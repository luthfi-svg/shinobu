// plugins/game/tebakgambar.js — Tebak gambar game (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Tebak Gambar
 * 🔧 Fungsi     : Game tebak gambar dengan clue
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

// Global game storage
global.tebakgambar = global.tebakgambar || {};

let handler = async (m, { sock, usedPrefix, command }) => {
  const id = m.chat;
  
  if (global.tebakgambar[id]) {
    return m.reply(
      `❌ Masih ada game yang belum selesai!\n\n` +
      `Jawab dulu atau ketik *${usedPrefix}nyerah* untuk menyerah`
    );
  }

  try {
    await m.reply("⏳ *Loading Game...*");

    // Fetch tebak gambar data
    const response = await axios.get(
      "https://api.betabotz.eu.org/api/game/tebakgambar",
      { timeout: 15000 }
    );

    const data = response.data.result;
    const { image, jawaban, deskripsi } = data;

    // Store game data
    global.tebakgambar[id] = {
      jawaban: jawaban.toLowerCase(),
      timeout: setTimeout(() => {
        if (global.tebakgambar[id]) {
          sock.sendMessage(
            id,
            {
              text: `⏰ *Waktu Habis!*\n\nJawaban: *${jawaban}*\n\nKetik *${usedPrefix + command}* untuk main lagi`
            }
          );
          delete global.tebakgambar[id];
        }
      }, 60000) // 60 seconds
    };

    // Send game
    await sock.sendMessage(
      id,
      {
        image: { url: image },
        caption: 
          `🎮 *TEBAK GAMBAR*\n\n` +
          `${deskripsi}\n\n` +
          `⏰ Waktu: 60 detik\n` +
          `🎁 Ketik jawaban di chat\n` +
          `💡 Ketik *${usedPrefix}hint* untuk clue`
      },
      { quoted: m }
    );

  } catch (e) {
    console.error(e);
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["tebakgambar"];
handler.tags = ["game"];
handler.command = /^(tebakgambar|tebakimg)$/i;
handler.limit = true;

export default handler;
