// plugins/game-tictactoe.js — dari Ourin MD 3

if (!global.tttGames) global.tttGames = {};

const SYM = { X: "❌", O: "⭕", 1:"1️⃣", 2:"2️⃣", 3:"3️⃣", 4:"4️⃣", 5:"5️⃣", 6:"6️⃣", 7:"7️⃣", 8:"8️⃣", 9:"9️⃣" };
const WINS = [7,56,73,84,146,273,292,448];

function checkWin(state) {
  return WINS.some(c => (state & c) === c);
}

function posToMask(pos) { return 1 << (pos - 1); }

function drawBoard(game) {
  const b = game.board;
  let txt = "";
  for (let r = 0; r < 3; r++) {
    for (let c = 0; c < 3; c++) {
      const pos = r * 3 + c + 1;
      const xHas = (game.xState & posToMask(pos)) !== 0;
      const oHas = (game.oState & posToMask(pos)) !== 0;
      txt += xHas ? SYM.X : oHas ? SYM.O : SYM[pos];
    }
    if (r < 2) txt += "\n";
  }
  return txt;
}

let handler = async (m, { sock, command }) => {
  const gameId = m.chat;

  // ── Mulai game ──────────────────────
  if (command === "tictactoe" || command === "ttt") {
    if (global.tttGames[gameId]) {
      const g = global.tttGames[gameId];
      return m.reply(`🎮 Ada game TTT yang berjalan!\n\n${drawBoard(g)}\n\nGiliran: ${g.turn === "X" ? "@" + g.playerX.split("@")[0] : "@" + g.playerO.split("@")[0]} (${g.turn === "X" ? SYM.X : SYM.O})\n\nKetik angka 1-9 untuk bermain. *.ttstop* untuk berhenti.`, { mentions: [g.turn === "X" ? g.playerX : g.playerO] });
    }

    const opponent = m.mentionedJid?.[0];
    if (!opponent) return m.reply(
      `🎮 *TIC TAC TOE*\n\n` +
      `> Tag lawan untuk mulai!\n\n` +
      `> *Contoh:* ${m.cmd} @tag`
    );
    if (opponent === m.sender) return m.reply("❌ Nggak bisa main sendiri!");

    global.tttGames[gameId] = {
      playerX: m.sender,
      playerO: opponent,
      xState: 0,
      oState: 0,
      turn: "X",
      moves: 0,
    };

    const g = global.tttGames[gameId];
    return sock.sendMessage(m.chat, {
      text: `🎮 *TIC TAC TOE DIMULAI!*\n\n${drawBoard(g)}\n\n${SYM.X} = @${m.sender.split("@")[0]}\n${SYM.O} = @${opponent.split("@")[0]}\n\nGiliran pertama: @${m.sender.split("@")[0]} (${SYM.X})\nKetik angka *1-9* untuk bermain!`,
      mentions: [m.sender, opponent],
    }, { quoted: m });
  }

  // ── Stop game ─────────────────────
  if (command === "ttstop") {
    if (!global.tttGames[gameId]) return m.reply("❌ Tidak ada game yang berjalan!");
    delete global.tttGames[gameId];
    return m.reply("🛑 Game TicTacToe dihentikan!");
  }
};

// All hook untuk handle input angka 1-9
handler.all = async function (m, { sock }) {
  const g = global.tttGames?.[m.chat];
  if (!g) return;

  const pos = parseInt(m.body?.trim());
  if (isNaN(pos) || pos < 1 || pos > 9) return;

  const isX = g.turn === "X" && m.sender === g.playerX;
  const isO = g.turn === "O" && m.sender === g.playerO;
  if (!isX && !isO) return;

  const mask = posToMask(pos);
  if ((g.xState & mask) || (g.oState & mask)) {
    return m.reply("❌ Posisi itu sudah terisi! Pilih yang lain.");
  }

  if (g.turn === "X") g.xState |= mask;
  else g.oState |= mask;
  g.moves++;

  const board = drawBoard(g);

  if (checkWin(g.turn === "X" ? g.xState : g.oState)) {
    const winner = g.turn === "X" ? g.playerX : g.playerO;
    delete global.tttGames[m.chat];
    return sock.sendMessage(m.chat, {
      text: `${board}\n\n🏆 @${winner.split("@")[0]} MENANG! Selamat! 🎉`,
      mentions: [winner],
    }, { quoted: m });
  }

  if (g.moves >= 9) {
    delete global.tttGames[m.chat];
    return m.reply(`${board}\n\n🤝 SERI! Tidak ada yang menang.`);
  }

  g.turn = g.turn === "X" ? "O" : "X";
  const next = g.turn === "X" ? g.playerX : g.playerO;
  return sock.sendMessage(m.chat, {
    text: `${board}\n\nGiliran: @${next.split("@")[0]} (${g.turn === "X" ? SYM.X : SYM.O})`,
    mentions: [next],
  }, { quoted: m });
};

handler.command = ["tictactoe", "ttt", "ttstop"];
handler.tags = ["game"];
handler.help = ["tictactoe @lawan", "ttstop"];
handler.group = true;
export default handler;