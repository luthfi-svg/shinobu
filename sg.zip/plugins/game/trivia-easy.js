// plugins/game/trivia-easy.js — Trivia Easy (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Trivia Easy
 * 🔧 Fungsi     : Trivia mudah
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const questions = [
    { q: "Pertanyaan 1", a: "Jawaban 1" },
    { q: "Pertanyaan 2", a: "Jawaban 2" },
    { q: "Pertanyaan 3", a: "Jawaban 3" },
  ];
  
  const random = questions[Math.floor(Math.random() * questions.length)];
  
  await m.reply(
    `🎮 *Trivia Easy*\n\n` +
    `❓ ${random.q}\n\n` +
    `⏰ Waktu: 60 detik\n` +
    `💡 Ketik jawaban untuk menjawab\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
  
  // Store game session
  global.db.data.game = global.db.data.game || {};
  global.db.data.game[m.chat] = {
    question: random.q,
    answer: random.a,
    command: command
  };
};

handler.help = ["triviaeasy", "triviamudah"];
handler.tags = ['game'];
handler.command = /^(triviaeasy|triviamudah)$/i;

export default handler;
