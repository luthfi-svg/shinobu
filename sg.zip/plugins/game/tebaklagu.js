// plugins/game/tebaklagu.js — Tebak Lagu Game (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Tebak Lagu Game
 * 🔗 API        : SynoxCloud API
 * 🎮 Genre      : Quiz / Musik
 * 🎵 Fitur       : Kirim audio + tebak judul
 * 📦 Version    : 1.2
 * ⚡ By Shinobu
 * ─────────────────────────
 */

"use strict";

import axios from "axios";

const API_BASE = "https://api.synoxcloud.xyz/games/tebaklagu";
const REQUEST_TIMEOUT_MS = 30000;

if (!global.tebakLaguGame) global.tebakLaguGame = {};
if (!global.tebakLaguScore) global.tebakLaguScore = {};

async function getSoal() {
  let res;
  try {
    res = await axios.get(API_BASE, {
      timeout: REQUEST_TIMEOUT_MS,
      validateStatus: () => true,
    });
  } catch (err) {
    if (err.code === "ECONNABORTED") throw new Error("⏰ Timeout! Server terlalu lama.");
    throw new Error(`🌐 Gagal menghubungi server: ${err.message}`);
  }

  if (res.status !== 200 || !res.data?.status || !res.data?.data) {
    throw new Error("❌ Gagal mendapatkan soal!");
  }

  return {
    lagu: res.data.data.lagu || "",
    judul: res.data.data.judul || "",
    artis: res.data.data.artis || ""
  };
}

let handler = async (m, { text, command, sock }) => {
  const prefix = global.prefix || ".";

  // ===== 1. .tebaklagu (TANPA TEKS) = MULAI GAME =====
  if ((command === "tebaklagu" || command === "tlague") && (!text || !text.trim())) {
    if (global.tebakLaguGame[m.sender]) {
      const game = global.tebakLaguGame[m.sender];
      
      if (Date.now() - game.startTime > 180000) {
        delete global.tebakLaguGame[m.sender];
      } else {
        return sock.sendMessage(m.chat, {
          text:
            `╭──────────────────────────────╮\n` +
            `  ⚠️  *GAME MASIH AKTIF!*\n` +
            `╰──────────────────────────────╯\n\n` +
            `  🎵 Tebak judul lagunya!\n\n` +
            `  💡 *Hint:*\n` +
            `  › ${game.judul.length} huruf\n` +
            `  › Awalan: *${game.judul[0].toUpperCase()}...*\n` +
            `  🎤 Artis: ${game.artis}\n\n` +
            `  ✍️  *${prefix}tebaklagu <jawaban>*\n` +
            `  🏳️  *${prefix}nyerahgu* menyerah\n` +
            `  🔊 *${prefix}lagu* denger lagi\n\n` +
            `  ⚡ *Shinobu MD v1.2*`
        }, { quoted: m.verifiedQuoted });
      }
    }

    await sock.sendMessage(m.chat, { react: { text: "🎵", key: m.key } });

    try {
      const data = await getSoal();

      global.tebakLaguGame[m.sender] = {
        judul: data.judul,
        artis: data.artis,
        lagu: data.lagu,
        startTime: Date.now()
      };

      // Kirim pesan info dulu
      await sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  🎵  *TEBAK LAGU*  🎵\n` +
          `╰──────────────────────────────╯\n\n` +
          `  🔊 Dengarkan audionya!\n\n` +
          `  💡 *Hint:*\n` +
          `  › ${data.judul.length} huruf\n` +
          `  › Awalan: *${data.judul[0].toUpperCase()}...*\n` +
          `  🎤 Artis: ${data.artis}\n\n` +
          `  ✍️  *${prefix}tebaklagu <jawaban>*\n` +
          `  🏳️  *${prefix}nyerahgu* menyerah\n` +
          `  🔊 *${prefix}lagu* denger lagi\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });

      // Kirim audio
      if (data.lagu) {
        try {
          const audioRes = await axios.get(data.lagu, {
            responseType: "arraybuffer",
            timeout: 30000
          });

          await sock.sendMessage(m.chat, {
            audio: Buffer.from(audioRes.data),
            mimetype: "audio/mpeg",
            ptt: false
          }, { quoted: m.verifiedQuoted });
        } catch (audioErr) {
          console.error("Gagal kirim audio:", audioErr.message);
        }
      }

      return;

    } catch (err) {
      console.error("[TEBAK LAGU ERROR]", err);
      await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  ❌  *GAGAL!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  📡 ${err.message}\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }
  }

  // ===== 2. .lagu = DENGER LAGI =====
  if (command === "lagu" && global.tebakLaguGame[m.sender]) {
    const game = global.tebakLaguGame[m.sender];
    if (game.lagu) {
      try {
        const audioRes = await axios.get(game.lagu, {
          responseType: "arraybuffer",
          timeout: 30000
        });

        await sock.sendMessage(m.chat, {
          audio: Buffer.from(audioRes.data),
          mimetype: "audio/mpeg",
          ptt: false
        }, { quoted: m.verifiedQuoted });

        return sock.sendMessage(m.chat, {
          text:
            `╭──────────────────────────────╮\n` +
            `  🔊  *AUDIO DIPUTAR ULANG*\n` +
            `╰──────────────────────────────╯\n\n` +
            `  💡 ${game.judul.length} huruf, awalan *${game.judul[0].toUpperCase()}...*\n` +
            `  🎤 ${game.artis}\n\n` +
            `  ⚡ *Shinobu MD v1.2*`
        }, { quoted: m.verifiedQuoted });
      } catch (err) {
        return sock.sendMessage(m.chat, {
          text: `❌ Gagal memutar ulang audio.\n\n⚡ *Shinobu MD v1.2*`
        }, { quoted: m.verifiedQuoted });
      }
    }
  }

  // ===== 3. .tebaklagu <jawaban> = JAWAB =====
  if (text && text.trim() && (command === "tebaklagu" || command === "tlague")) {
    if (!global.tebakLaguGame[m.sender]) {
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  ⚠️  *BELUM ADA GAME!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  Ketik *${prefix}tebaklagu* dulu!\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }

    const game = global.tebakLaguGame[m.sender];
    const jawabanUser = text.trim().toLowerCase();
    const jawabanBenar = game.judul.toLowerCase();

    if (Date.now() - game.startTime > 180000) {
      delete global.tebakLaguGame[m.sender];
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  ⏰  *WAKTU HABIS!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  🎵 *${game.judul}*\n` +
          `  🎤 ${game.artis}\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }

    const isExact = jawabanUser === jawabanBenar;
    const isContained = jawabanBenar.includes(jawabanUser) && jawabanUser.length > 3;

    if (isExact || isContained) {
      // BENAR
      if (!global.tebakLaguScore[m.sender]) {
        global.tebakLaguScore[m.sender] = { total: 0, benar: 0, salah: 0 };
      }
      global.tebakLaguScore[m.sender].total += 20;
      global.tebakLaguScore[m.sender].benar += 1;
      delete global.tebakLaguGame[m.sender];

      await sock.sendMessage(m.chat, { react: { text: "🎉", key: m.key } });

      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  🎉  *BENAR!*  🎉\n` +
          `╰──────────────────────────────╯\n\n` +
          `  🎵 *${game.judul}*\n` +
          `  🎤 ${game.artis}\n` +
          `  ⭐ +20 EXP\n\n` +
          `  🏆 Skor : ${global.tebakLaguScore[m.sender].total}\n\n` +
          `  Ketik *${prefix}tebaklagu* main lagi!\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });

    } else {
      // SALAH
      if (!global.tebakLaguScore[m.sender]) {
        global.tebakLaguScore[m.sender] = { total: 0, benar: 0, salah: 0 };
      }
      global.tebakLaguScore[m.sender].total -= 5;
      global.tebakLaguScore[m.sender].salah += 1;
      delete global.tebakLaguGame[m.sender];

      await sock.sendMessage(m.chat, { react: { text: "💔", key: m.key } });

      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  💔  *SALAH!*  💔\n` +
          `╰──────────────────────────────╯\n\n` +
          `  🎵 *${game.judul}*\n` +
          `  🎤 ${game.artis}\n` +
          `  ❌ ${jawabanUser}\n` +
          `  💔 -5 EXP\n\n` +
          `  Ketik *${prefix}tebaklagu* coba lagi!\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }
  }

  // ===== 4. .nyerahgu = MENYERAH =====
  if (command === "nyerahgu") {
    if (!global.tebakLaguGame[m.sender]) {
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  ⚠️  *TIDAK ADA GAME!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  Ketik *${prefix}tebaklagu* dulu!\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }

    const game = global.tebakLaguGame[m.sender];
    delete global.tebakLaguGame[m.sender];

    return sock.sendMessage(m.chat, {
      text:
        `╭──────────────────────────────╮\n` +
        `  🏳️  *MENYERAH!*  🏳️\n` +
        `╰──────────────────────────────╯\n\n` +
        `  🎵 *${game.judul}*\n` +
        `  🎤 ${game.artis}\n\n` +
        `  Ketik *${prefix}tebaklagu* main lagi!\n\n` +
        `  ⚡ *Shinobu MD v1.2*`
    }, { quoted: m.verifiedQuoted });
  }

  // ===== 5. .laguskor = CEK SKOR =====
  if (command === "laguskor") {
    const score = global.tebakLaguScore?.[m.sender];
    
    if (!score) {
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  🏆  *SKOR TEBAK LAGU*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  Kamu belum pernah main!\n` +
          `  Ketik *${prefix}tebaklagu*\n` +
          `  untuk mulai bermain.\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }

    const total = score.benar + score.salah;
    const akurasi = total > 0 ? Math.round((score.benar / total) * 100) : 0;

    return sock.sendMessage(m.chat, {
      text:
        `╭──────────────────────────────╮\n` +
        `  🏆  *STATISTIK KAMU*\n` +
        `╰──────────────────────────────╯\n\n` +
        `  ⭐ Skor    : ${score.total}\n` +
        `  ✅ Benar   : ${score.benar}\n` +
        `  ❌ Salah   : ${score.salah}\n` +
        `  📊 Akurasi : ${akurasi}%\n` +
        `  🎯 Total   : ${total} soal\n\n` +
        `  ⚡ *Shinobu MD v1.2*`
    }, { quoted: m.verifiedQuoted });
  }
};

handler.command = ["tebaklagu", "tlague", "lagu", "nyerahgu", "laguskor"];
handler.tags = ["game"];
handler.help = ["tebaklagu"];
handler.limit = true;

export default handler;