// plugins/game/caklontong.js — Cak lontong game (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Cak Lontong
 * 🔧 Fungsi     : Game tebakan ala Cak Lontong
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

global.caklontong = global.caklontong || {};

let handler = async (m, { sock, usedPrefix, command }) => {
  const id = m.chat;
  
  if (global.caklontong[id]) {
    return m.reply(`❌ Masih ada game! Ketik *${usedPrefix}nyerah* untuk menyerah`);
  }

  try {
    await m.reply("⏳ *Loading Game...*");

    const response = await axios.get(
      "https://api.betabotz.eu.org/api/game/caklontong",
      { timeout: 15000 }
    );

    const data = response.data.result;
    const { soal, jawaban, deskripsi } = data;

    global.caklontong[id] = {
      jawaban: jawaban.toLowerCase(),
      deskripsi: deskripsi,
      timeout: setTimeout(() => {
        if (global.caklontong[id]) {
          sock.sendMessage(id, {
            text: 
              `⏰ *Waktu Habis!*\n\n` +
              `Jawaban: *${jawaban}*\n` +
              `💡 Penjelasan: ${deskripsi}`
          });
          delete global.caklontong[id];
        }
      }, 60000)
    };

    await m.reply(
      `🤔 *CAK LONTONG*\n\n` +
      `❓ Soal:\n${soal}\n\n` +
      `⏰ Waktu: 60 detik\n` +
      `💡 Ketik *${usedPrefix}hint* untuk clue`
    );

  } catch (e) {
    console.error(e);
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["caklontong"];
handler.tags = ["game"];
handler.command = /^(caklontong|caklon)$/i;
handler.limit = true;

export default handler;
