// plugins/game/gabungan.js — Game Gabungan (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Game Gabungan
 * 🔗 API        : SynoxCloud API
 * 🎮 Games      : Family 100 + Susun Kata + Tebak Anime
 * 📦 Version    : 1.2
 * ⚡ By Shinobu
 * ─────────────────────────
 */

"use strict";

import axios from "axios";

const API = {
  family100: "https://api.synoxcloud.xyz/games/familly100",
  susunkata: "https://api.synoxcloud.xyz/games/susun-kata",
  tebakanime: "https://api.synoxcloud.xyz/games/tebak-anime"
};
const REQUEST_TIMEOUT_MS = 15000;

if (!global.family100Game) global.family100Game = {};
if (!global.susunKataGame) global.susunKataGame = {};
if (!global.tebakAnimeGame) global.tebakAnimeGame = {};
if (!global.gameScore) global.gameScore = {};

// ==================== FAMILY 100 ====================
async function getFamily100() {
  const res = await axios.get(API.family100, { timeout: REQUEST_TIMEOUT_MS, validateStatus: () => true });
  if (res.status !== 200 || !res.data?.status || !res.data?.result) throw new Error("❌ Gagal!");
  return {
    question: res.data.result.question || "",
    answers: res.data.result.answers.map(a => a.toLowerCase()) || [],
    total: res.data.result.total_answer || 0
  };
}

// ==================== SUSUN KATA ====================
async function getSusunKata() {
  const res = await axios.get(API.susunkata, { timeout: REQUEST_TIMEOUT_MS, validateStatus: () => true });
  if (res.status !== 200 || !res.data?.status || !res.data?.result) throw new Error("❌ Gagal!");
  return {
    soal: res.data.result.soal || "",
    tipe: res.data.result.tipe || "",
    jawaban: res.data.result.jawaban || "",
    index: res.data.result.index || 0
  };
}

// ==================== TEBAK ANIME ====================
async function getTebakAnime() {
  const res = await axios.get(API.tebakanime, { timeout: REQUEST_TIMEOUT_MS, validateStatus: () => true });
  if (res.status !== 200 || !res.data?.status || !res.data?.result) throw new Error("❌ Gagal!");
  return {
    jawaban: res.data.result.jawaban || "",
    image: res.data.result.image || "",
    deskripsi: res.data.result.deskripsi || "",
    url: res.data.result.url || ""
  };
}

// ==================== HANDLER ====================
let handler = async (m, { text, command, sock }) => {
  const prefix = global.prefix || ".";

  // ===== FAMILY 100 =====
  if ((command === "family100" || command === "f100") && (!text || !text.trim())) {
    if (global.family100Game[m.sender]) {
      const g = global.family100Game[m.sender];
      if (Date.now() - g.startTime > 180000) { delete global.family100Game[m.sender]; }
      else return sock.sendMessage(m.chat, {
        text: `╭──────────────────────────────╮\n  ⚠️  *GAME MASIH AKTIF!*\n╰──────────────────────────────╯\n\n📝 ${g.question}\n✅ ${g.terjawab.length}/${g.total}\n\n💡 *${prefix}f100 <jawaban>*\n🏳️ *${prefix}stopf100* menyerah\n\n⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }
    await sock.sendMessage(m.chat, { react: { text: "💯", key: m.key } });
    try {
      const d = await getFamily100();
      global.family100Game[m.sender] = { question: d.question, answers: d.answers, total: d.total, terjawab: [], startTime: Date.now() };
      return sock.sendMessage(m.chat, {
        text: `╭──────────────────────────────╮\n  💯  *FAMILY 100*  💯\n╰──────────────────────────────╯\n\n📝 *${d.question}*\n📊 ${d.total} jawaban\n\n✍️  *${prefix}f100 <jawaban>*\n🏳️ *${prefix}stopf100*\n\n⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    } catch (e) {
      await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      return sock.sendMessage(m.chat, { text: `❌ ${e.message}\n\n⚡ *Shinobu MD v1.2*` }, { quoted: m.verifiedQuoted });
    }
  }

  if (text && text.trim() && (command === "family100" || command === "f100")) {
    if (!global.family100Game[m.sender]) return sock.sendMessage(m.chat, { text: `⚠️ Ketik *${prefix}family100* dulu!\n\n⚡ *Shinobu MD v1.2*` }, { quoted: m.verifiedQuoted });
    const g = global.family100Game[m.sender];
    const j = text.trim().toLowerCase();
    if (Date.now() - g.startTime > 180000) { delete global.family100Game[m.sender]; return sock.sendMessage(m.chat, { text: `⏰ Waktu habis!\n\n⚡ *Shinobu MD v1.2*` }, { quoted: m.verifiedQuoted }); }
    if (g.terjawab.includes(j)) return sock.sendMessage(m.chat, { text: `⚠️ Udah dijawab!\n\n⚡ *Shinobu MD v1.2*` }, { quoted: m.verifiedQuoted });
    if (g.answers.some(a => a.includes(j) || j.includes(a))) {
      g.terjawab.push(j);
      if (!global.gameScore[m.sender]) global.gameScore[m.sender] = { total: 0 };
      global.gameScore[m.sender].total += 10;
      if (g.terjawab.length >= g.total) {
        delete global.family100Game[m.sender];
        await sock.sendMessage(m.chat, { react: { text: "🎉", key: m.key } });
        return sock.sendMessage(m.chat, { text: `🎉 *LENGKAP!*\n\n📝 ${g.question}\n✅ ${g.answers.join(', ')}\n⭐ +10\n🏆 Skor: ${global.gameScore[m.sender].total}\n\n⚡ *Shinobu MD v1.2*` }, { quoted: m.verifiedQuoted });
      }
      await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
      return sock.sendMessage(m.chat, { text: `✅ *BENAR!* ${j}\n📊 ${g.terjawab.length}/${g.total} ⭐+10\n\n⚡ *Shinobu MD v1.2*` }, { quoted: m.verifiedQuoted });
    }
    return sock.sendMessage(m.chat, { text: `❌ *SALAH!*\n\n⚡ *Shinobu MD v1.2*` }, { quoted: m.verifiedQuoted });
  }

  if (command === "stopf100") {
    if (!global.family100Game[m.sender]) return sock.sendMessage(m.chat, { text: `⚠️ Tidak ada game!\n\n⚡ *Shinobu MD v1.2*` }, { quoted: m.verifiedQuoted });
    const g = global.family100Game[m.sender]; delete global.family100Game[m.sender];
    return sock.sendMessage(m.chat, { text: `🏳️ *MENYERAH!*\n\n📝 ${g.question}\n✅ ${g.answers.join(', ')}\n\n⚡ *Shinobu MD v1.2*` }, { quoted: m.verifiedQuoted });
  }

  // ===== SUSUN KATA =====
  if ((command === "susunkata" || command === "sk") && (!text || !text.trim())) {
    if (global.susunKataGame[m.sender]) {
      const g = global.susunKataGame[m.sender];
      if (Date.now() - g.startTime > 120000) { delete global.susunKataGame[m.sender]; }
      else return sock.sendMessage(m.chat, {
        text: `╭──────────────────────────────╮\n  ⚠️  *GAME MASIH AKTIF!*\n╰──────────────────────────────╯\n\n📝 ${g.soal} [${g.tipe}]\n🔤 ${g.jawaban.length} huruf, awalan *${g.jawaban[0].toUpperCase()}...*\n\n✍️ *${prefix}sk <jawaban>*\n🏳️ *${prefix}stopsusun*\n\n⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }
    await sock.sendMessage(m.chat, { react: { text: "🔤", key: m.key } });
    try {
      const d = await getSusunKata();
      global.susunKataGame[m.sender] = { soal: d.soal, tipe: d.tipe, jawaban: d.jawaban, index: d.index, startTime: Date.now() };
      return sock.sendMessage(m.chat, {
        text: `╭──────────────────────────────╮\n  🔤  *SUSUN KATA*  🔤\n╰──────────────────────────────╯\n\n📝 *Soal #${d.index}:*\n❝ ${d.soal} ❞\n🏷️ Tipe: ${d.tipe}\n🔤 ${d.jawaban.length} huruf, awalan *${d.jawaban[0].toUpperCase()}...*\n\n✍️ *${prefix}sk <jawaban>*\n🏳️ *${prefix}stopsusun*\n\n⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    } catch (e) {
      await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      return sock.sendMessage(m.chat, { text: `❌ ${e.message}\n\n⚡ *Shinobu MD v1.2*` }, { quoted: m.verifiedQuoted });
    }
  }

  if (text && text.trim() && (command === "susunkata" || command === "sk")) {
    if (!global.susunKataGame[m.sender]) return sock.sendMessage(m.chat, { text: `⚠️ Ketik *${prefix}susunkata* dulu!\n\n⚡ *Shinobu MD v1.2*` }, { quoted: m.verifiedQuoted });
    const g = global.susunKataGame[m.sender];
    const j = text.trim().toLowerCase();
    if (Date.now() - g.startTime > 120000) { delete global.susunKataGame[m.sender]; return sock.sendMessage(m.chat, { text: `⏰ Waktu habis! ✅ *${g.jawaban}*\n\n⚡ *Shinobu MD v1.2*` }, { quoted: m.verifiedQuoted }); }
    if (j === g.jawaban.toLowerCase()) {
      if (!global.gameScore[m.sender]) global.gameScore[m.sender] = { total: 0 };
      global.gameScore[m.sender].total += 10; delete global.susunKataGame[m.sender];
      await sock.sendMessage(m.chat, { react: { text: "🎉", key: m.key } });
      return sock.sendMessage(m.chat, { text: `🎉 *BENAR!*\n\n📝 ${g.soal}\n✅ *${g.jawaban}*\n⭐ +10\n🏆 Skor: ${global.gameScore[m.sender].total}\n\n⚡ *Shinobu MD v1.2*` }, { quoted: m.verifiedQuoted });
    }
    if (!global.gameScore[m.sender]) global.gameScore[m.sender] = { total: 0 };
    global.gameScore[m.sender].total -= 5; delete global.susunKataGame[m.sender];
    await sock.sendMessage(m.chat, { react: { text: "💔", key: m.key } });
    return sock.sendMessage(m.chat, { text: `💔 *SALAH!*\n\n📝 ${g.soal}\n✅ *${g.jawaban}*\n❌ ${j}\n💔 -5\n\n⚡ *Shinobu MD v1.2*` }, { quoted: m.verifiedQuoted });
  }

  if (command === "stopsusun") {
    if (!global.susunKataGame[m.sender]) return sock.sendMessage(m.chat, { text: `⚠️ Tidak ada game!\n\n⚡ *Shinobu MD v1.2*` }, { quoted: m.verifiedQuoted });
    const g = global.susunKataGame[m.sender]; delete global.susunKataGame[m.sender];
    return sock.sendMessage(m.chat, { text: `🏳️ *MENYERAH!*\n\n📝 ${g.soal}\n✅ *${g.jawaban}*\n\n⚡ *Shinobu MD v1.2*` }, { quoted: m.verifiedQuoted });
  }

  // ===== TEBAK ANIME =====
  if ((command === "tebakanime" || command === "tanime") && (!text || !text.trim())) {
    if (global.tebakAnimeGame[m.sender]) {
      const g = global.tebakAnimeGame[m.sender];
      if (Date.now() - g.startTime > 120000) { delete global.tebakAnimeGame[m.sender]; }
      else return sock.sendMessage(m.chat, {
        text: `╭──────────────────────────────╮\n  ⚠️  *GAME MASIH AKTIF!*\n╰──────────────────────────────╯\n\n🔤 ${g.jawaban.length} huruf, awalan *${g.jawaban[0].toUpperCase()}...*\n\n✍️ *${prefix}tanime <jawaban>*\n🏳️ *${prefix}stopanime*\n📸 *${prefix}anime* lihat lagi\n\n⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }
    await sock.sendMessage(m.chat, { react: { text: "🎌", key: m.key } });
    try {
      const d = await getTebakAnime();
      global.tebakAnimeGame[m.sender] = { jawaban: d.jawaban, image: d.image, deskripsi: d.deskripsi, url: d.url, startTime: Date.now() };
      let cap = `╭──────────────────────────────╮\n  🎌  *TEBAK ANIME*  🎌\n╰──────────────────────────────╯\n\n📸 Tebak karakter anime!\n🔤 ${d.jawaban.length} huruf, awalan *${d.jawaban[0].toUpperCase()}...*\n📝 ${d.deskripsi.substring(0, 150)}...\n\n✍️ *${prefix}tanime <jawaban>*\n🏳️ *${prefix}stopanime*\n📸 *${prefix}anime* lihat lagi\n\n⚡ *Shinobu MD v1.2*`;
      if (d.image) {
        try {
          const ir = await axios.get(d.image, { responseType: "arraybuffer", timeout: 10000 });
          return sock.sendMessage(m.chat, { image: Buffer.from(ir.data), caption: cap }, { quoted: m.verifiedQuoted });
        } catch (ie) {}
      }
      return sock.sendMessage(m.chat, { text: cap }, { quoted: m.verifiedQuoted });
    } catch (e) {
      await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      return sock.sendMessage(m.chat, { text: `❌ ${e.message}\n\n⚡ *Shinobu MD v1.2*` }, { quoted: m.verifiedQuoted });
    }
  }

  if (command === "anime" && global.tebakAnimeGame[m.sender]) {
    const g = global.tebakAnimeGame[m.sender];
    if (g.image) {
      try {
        const ir = await axios.get(g.image, { responseType: "arraybuffer", timeout: 10000 });
        return sock.sendMessage(m.chat, { image: Buffer.from(ir.data), caption: `📸 *Lihat Lagi*\n🔤 ${g.jawaban.length} huruf\n\n⚡ *Shinobu MD v1.2*` }, { quoted: m.verifiedQuoted });
      } catch (ie) {}
    }
  }

  if (text && text.trim() && (command === "tebakanime" || command === "tanime")) {
    if (!global.tebakAnimeGame[m.sender]) return sock.sendMessage(m.chat, { text: `⚠️ Ketik *${prefix}tebakanime* dulu!\n\n⚡ *Shinobu MD v1.2*` }, { quoted: m.verifiedQuoted });
    const g = global.tebakAnimeGame[m.sender];
    const j = text.trim().toLowerCase();
    if (Date.now() - g.startTime > 120000) { delete global.tebakAnimeGame[m.sender]; return sock.sendMessage(m.chat, { text: `⏰ Waktu habis! ✅ *${g.jawaban}*\n\n⚡ *Shinobu MD v1.2*` }, { quoted: m.verifiedQuoted }); }
    if (j === g.jawaban.toLowerCase() || g.jawaban.toLowerCase().includes(j)) {
      if (!global.gameScore[m.sender]) global.gameScore[m.sender] = { total: 0 };
      global.gameScore[m.sender].total += 15; delete global.tebakAnimeGame[m.sender];
      await sock.sendMessage(m.chat, { react: { text: "🎉", key: m.key } });
      return sock.sendMessage(m.chat, { text: `🎉 *BENAR!*\n\n✅ *${g.jawaban}*\n⭐ +15\n🏆 Skor: ${global.gameScore[m.sender].total}\n🔗 ${g.url}\n\n⚡ *Shinobu MD v1.2*` }, { quoted: m.verifiedQuoted });
    }
    if (!global.gameScore[m.sender]) global.gameScore[m.sender] = { total: 0 };
    global.gameScore[m.sender].total -= 5; delete global.tebakAnimeGame[m.sender];
    await sock.sendMessage(m.chat, { react: { text: "💔", key: m.key } });
    return sock.sendMessage(m.chat, { text: `💔 *SALAH!*\n\n✅ *${g.jawaban}*\n❌ ${j}\n💔 -5\n\n⚡ *Shinobu MD v1.2*` }, { quoted: m.verifiedQuoted });
  }

  if (command === "stopanime") {
    if (!global.tebakAnimeGame[m.sender]) return sock.sendMessage(m.chat, { text: `⚠️ Tidak ada game!\n\n⚡ *Shinobu MD v1.2*` }, { quoted: m.verifiedQuoted });
    const g = global.tebakAnimeGame[m.sender]; delete global.tebakAnimeGame[m.sender];
    return sock.sendMessage(m.chat, { text: `🏳️ *MENYERAH!*\n\n✅ *${g.jawaban}*\n🔗 ${g.url}\n\n⚡ *Shinobu MD v1.2*` }, { quoted: m.verifiedQuoted });
  }

  // ===== GAME SCORE =====
  if (command === "gameskor") {
    const s = global.gameScore?.[m.sender];
    if (!s) return sock.sendMessage(m.chat, { text: `🏆 *SKOR GAME*\n\nBelum pernah main!\n\n⚡ *Shinobu MD v1.2*` }, { quoted: m.verifiedQuoted });
    return sock.sendMessage(m.chat, { text: `╭──────────────────────────────╮\n  🏆  *TOTAL SKOR GAME*\n╰──────────────────────────────╯\n\n⭐ Total Skor: ${s.total}\n\n⚡ *Shinobu MD v1.2*` }, { quoted: m.verifiedQuoted });
  }
};

handler.command = [
  "family100", "f100", "stopf100",
  "susunkata", "sk", "stopsusun",
  "tebakanime", "tanime", "anime", "stopanime",
  "gameskor"
];
handler.tags = ["game"];
handler.help = ["family100", "susunkata", "tebakanime"];
handler.limit = true;

export default handler;