// plugins/game/tebaklirik.js — Tebak lirik lagu game (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Tebak Lirik
 * 🔧 Fungsi     : Game tebak lirik lagu
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

global.tebaklirik = global.tebaklirik || {};

let handler = async (m, { sock, usedPrefix, command }) => {
  const id = m.chat;
  
  if (global.tebaklirik[id]) {
    return m.reply(`❌ Masih ada game! Ketik *${usedPrefix}nyerah* untuk menyerah`);
  }

  try {
    await m.reply("⏳ *Loading Game...*");

    const response = await axios.get(
      "https://api.betabotz.eu.org/api/game/tebaklirik",
      { timeout: 15000 }
    );

    const data = response.data.result;
    const { soal, jawaban } = data;

    global.tebaklirik[id] = {
      jawaban: jawaban.toLowerCase(),
      timeout: setTimeout(() => {
        if (global.tebaklirik[id]) {
          sock.sendMessage(id, {
            text: `⏰ *Waktu Habis!*\n\nJawaban: *${jawaban}*`
          });
          delete global.tebaklirik[id];
        }
      }, 60000)
    };

    await m.reply(
      `🎮 *TEBAK LIRIK*\n\n` +
      `🎵 Lirik:\n${soal}\n\n` +
      `⏰ Waktu: 60 detik\n` +
      `💡 Tebak judul lagunya!`
    );

  } catch (e) {
    console.error(e);
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["tebaklirik"];
handler.tags = ["game"];
handler.command = /^(tebaklirik|tebaklagu)$/i;
handler.limit = true;

export default handler;
