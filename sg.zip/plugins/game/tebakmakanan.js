// plugins/game/tebakmakanan.js — Tebak Makanan Game (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Tebak Makanan Game
 * 🔗 API        : SynoxCloud API
 * 🎮 Genre      : Quiz / Tebak Gambar
 * 🍔 Fun        : Tebak makanan dari foto
 * 📦 Version    : 1.2
 * ⚡ By Shinobu
 * ─────────────────────────
 */

"use strict";

import axios from "axios";

const API_BASE = "https://api.synoxcloud.xyz/games/tebak-makanan";
const REQUEST_TIMEOUT_MS = 15000;

if (!global.tebakMakananGame) global.tebakMakananGame = {};
if (!global.tebakMakananScore) global.tebakMakananScore = {};

async function getSoal() {
  let res;
  try {
    res = await axios.get(API_BASE, {
      timeout: REQUEST_TIMEOUT_MS,
      validateStatus: () => true,
    });
  } catch (err) {
    if (err.code === "ECONNABORTED") throw new Error("⏰ Timeout! Server terlalu lama.");
    throw new Error(`🌐 Gagal menghubungi server: ${err.message}`);
  }

  if (res.status !== 200 || !res.data?.status || !res.data?.result) {
    throw new Error("❌ Gagal mendapatkan soal!");
  }

  return {
    img: res.data.result.img || "",
    jawaban: res.data.result.jawaban || "",
    deskripsi: res.data.result.deskripsi || ""
  };
}

let handler = async (m, { text, command, sock }) => {
  const prefix = global.prefix || ".";

  // ===== 1. .tebakmakanan (TANPA TEKS) = MULAI GAME =====
  if ((command === "tebakmakanan" || command === "teman") && (!text || !text.trim())) {
    // Kalau ada game aktif
    if (global.tebakMakananGame[m.sender]) {
      const game = global.tebakMakananGame[m.sender];
      
      if (Date.now() - game.startTime > 120000) {
        delete global.tebakMakananGame[m.sender];
      } else {
        return sock.sendMessage(m.chat, {
          text:
            `╭──────────────────────────────╮\n` +
            `  ⚠️  *GAME MASIH AKTIF!*\n` +
            `╰──────────────────────────────╯\n\n` +
            `  🍔 Tebak nama makanannya!\n\n` +
            `  💡 *Hint:* ${game.jawaban.length} huruf\n` +
            `  🔤 Awalan: *${game.jawaban[0].toUpperCase()}...*\n` +
            `  📝 ${game.deskripsi}\n\n` +
            `  ✍️  *${prefix}tebakmakanan <jawaban>*\n` +
            `  🏳️  *${prefix}nyerahmakan* menyerah\n\n` +
            `  ⚡ *Shinobu MD v1.2*`
        }, { quoted: m.verifiedQuoted });
      }
    }

    // Mulai game baru
    await sock.sendMessage(m.chat, { react: { text: "🍔", key: m.key } });

    try {
      const data = await getSoal();

      global.tebakMakananGame[m.sender] = {
        jawaban: data.jawaban,
        deskripsi: data.deskripsi,
        img: data.img,
        startTime: Date.now()
      };

      let caption =
        `╭──────────────────────────────╮\n` +
        `  🍔  *TEBAK MAKANAN*  🍔\n` +
        `╰──────────────────────────────╯\n\n` +
        `  📸 Tebak nama makanan di atas!\n\n` +
        `  💡 *Hint:*\n` +
        `  › ${data.jawaban.length} huruf\n` +
        `  › Awalan: *${data.jawaban[0].toUpperCase()}...*\n` +
        `  📝 ${data.deskripsi}\n\n` +
        `  ✍️  *${prefix}tebakmakanan <jawaban>*\n` +
        `  🏳️  *${prefix}nyerahmakan* menyerah\n\n` +
        `  ⚡ *Shinobu MD v1.2*`;

      // Kirim gambar + caption
      if (data.img) {
        try {
          const imgRes = await axios.get(data.img, {
            responseType: "arraybuffer",
            timeout: 10000
          });

          return sock.sendMessage(m.chat, {
            image: Buffer.from(imgRes.data),
            caption: caption
          }, { quoted: m.verifiedQuoted });
        } catch (imgErr) {
          // Kalau gambar gagal, kirim teks aja
        }
      }

      return sock.sendMessage(m.chat, { text: caption }, { quoted: m.verifiedQuoted });

    } catch (err) {
      console.error("[TEBAK MAKANAN ERROR]", err);
      await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  ❌  *GAGAL!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  📡 ${err.message}\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }
  }

  // ===== 2. .tebakmakanan <jawaban> = JAWAB =====
  if (text && text.trim() && (command === "tebakmakanan" || command === "teman")) {
    if (!global.tebakMakananGame[m.sender]) {
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  ⚠️  *BELUM ADA GAME!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  Ketik *${prefix}tebakmakanan* dulu\n` +
          `  untuk mulai bermain!\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }

    const game = global.tebakMakananGame[m.sender];
    const jawabanUser = text.trim().toLowerCase();
    const jawabanBenar = game.jawaban.toLowerCase();

    if (Date.now() - game.startTime > 120000) {
      delete global.tebakMakananGame[m.sender];
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  ⏰  *WAKTU HABIS!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  ✅ *${game.jawaban}*\n` +
          `  📝 ${game.deskripsi}\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }

    const isExact = jawabanUser === jawabanBenar;
    const isContained = jawabanBenar.includes(jawabanUser) && jawabanUser.length > 3;
    const isContainedReverse = jawabanUser.includes(jawabanBenar) && jawabanBenar.length > 3;

    if (isExact || isContained || isContainedReverse) {
      // BENAR
      if (!global.tebakMakananScore[m.sender]) {
        global.tebakMakananScore[m.sender] = { total: 0, benar: 0, salah: 0 };
      }
      global.tebakMakananScore[m.sender].total += 15;
      global.tebakMakananScore[m.sender].benar += 1;
      delete global.tebakMakananGame[m.sender];

      await sock.sendMessage(m.chat, { react: { text: "🎉", key: m.key } });

      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  🎉  *BENAR!*  🎉\n` +
          `╰──────────────────────────────╯\n\n` +
          `  🍔 *${game.jawaban}*\n` +
          `  📝 ${game.deskripsi}\n` +
          `  ⭐ +15 EXP\n\n` +
          `  🏆 Skor : ${global.tebakMakananScore[m.sender].total}\n\n` +
          `  Ketik *${prefix}tebakmakanan* main lagi!\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });

    } else {
      // SALAH
      if (!global.tebakMakananScore[m.sender]) {
        global.tebakMakananScore[m.sender] = { total: 0, benar: 0, salah: 0 };
      }
      global.tebakMakananScore[m.sender].total -= 5;
      global.tebakMakananScore[m.sender].salah += 1;
      delete global.tebakMakananGame[m.sender];

      await sock.sendMessage(m.chat, { react: { text: "💔", key: m.key } });

      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  💔  *SALAH!*  💔\n` +
          `╰──────────────────────────────╯\n\n` +
          `  🍔 *${game.jawaban}*\n` +
          `  📝 ${game.deskripsi}\n` +
          `  ❌ ${jawabanUser}\n` +
          `  💔 -5 EXP\n\n` +
          `  Ketik *${prefix}tebakmakanan* coba lagi!\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }
  }

  // ===== 3. .nyerahmakan = MENYERAH =====
  if (command === "nyerahmakan") {
    if (!global.tebakMakananGame[m.sender]) {
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  ⚠️  *TIDAK ADA GAME!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  Ketik *${prefix}tebakmakanan* dulu!\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }

    const game = global.tebakMakananGame[m.sender];
    delete global.tebakMakananGame[m.sender];

    return sock.sendMessage(m.chat, {
      text:
        `╭──────────────────────────────╮\n` +
        `  🏳️  *MENYERAH!*  🏳️\n` +
        `╰──────────────────────────────╯\n\n` +
        `  🍔 *${game.jawaban}*\n` +
        `  📝 ${game.deskripsi}\n\n` +
        `  Ketik *${prefix}tebakmakanan*\n` +
        `  untuk main lagi!\n\n` +
        `  ⚡ *Shinobu MD v1.2*`
    }, { quoted: m.verifiedQuoted });
  }

  // ===== 4. .makanskor = CEK SKOR =====
  if (command === "makanskor") {
    const score = global.tebakMakananScore?.[m.sender];
    
    if (!score) {
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  🏆  *SKOR TEBAK MAKANAN*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  Kamu belum pernah main!\n` +
          `  Ketik *${prefix}tebakmakanan*\n` +
          `  untuk mulai bermain.\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }

    const total = score.benar + score.salah;
    const akurasi = total > 0 ? Math.round((score.benar / total) * 100) : 0;

    return sock.sendMessage(m.chat, {
      text:
        `╭──────────────────────────────╮\n` +
        `  🏆  *STATISTIK KAMU*\n` +
        `╰──────────────────────────────╯\n\n` +
        `  ⭐ Skor    : ${score.total}\n` +
        `  ✅ Benar   : ${score.benar}\n` +
        `  ❌ Salah   : ${score.salah}\n` +
        `  📊 Akurasi : ${akurasi}%\n` +
        `  🎯 Total   : ${total} soal\n\n` +
        `  ⚡ *Shinobu MD v1.2*`
    }, { quoted: m.verifiedQuoted });
  }
};

handler.command = ["tebakmakanan", "teman", "nyerahmakan", "makanskor"];
handler.tags = ["game"];
handler.help = ["tebakmakanan"];
handler.limit = true;

export default handler;