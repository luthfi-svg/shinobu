// plugins/game/tebakkabupaten.js — Tebak kabupaten game (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Tebak Kabupaten
 * 🔧 Fungsi     : Game tebak nama kabupaten di Indonesia
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

global.tebakkabupaten = global.tebakkabupaten || {};

let handler = async (m, { sock, usedPrefix }) => {
  const id = m.chat;
  
  if (global.tebakkabupaten[id]) {
    return m.reply(`❌ Masih ada game! Ketik *${usedPrefix}nyerah*`);
  }

  try {
    await m.reply("⏳ *Loading...*");

    const response = await axios.get(
      "https://api.betabotz.eu.org/api/game/tebakkabupaten",
      { timeout: 15000 }
    );

    const data = response.data.result;
    const { title, url } = data;

    global.tebakkabupaten[id] = {
      jawaban: title.toLowerCase(),
      timeout: setTimeout(() => {
        if (global.tebakkabupaten[id]) {
          sock.sendMessage(id, {
            text: `⏰ *Waktu Habis!*\n\nJawaban: *${title}*`
          });
          delete global.tebakkabupaten[id];
        }
      }, 60000)
    };

    await sock.sendMessage(
      id,
      {
        image: { url: url },
        caption: 
          `🏛️ *TEBAK KABUPATEN*\n\n` +
          `📍 Tebak nama kabupaten dari gambar!\n\n` +
          `⏰ Waktu: 60 detik`
      },
      { quoted: m }
    );

  } catch (e) {
    console.error(e);
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["tebakkabupaten"];
handler.tags = ["game"];
handler.command = /^(tebakkabupaten|tebakkab)$/i;
handler.limit = true;

export default handler;
