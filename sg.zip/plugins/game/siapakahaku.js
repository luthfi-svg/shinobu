// plugins/game/siapakahaku.js — Siapakah Aku Game (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Siapakah Aku Game
 * 🔗 API        : Nexray API
 * 🎮 Genre      : Quiz / Tebak Kata
 * 📦 Version    : 1.2
 * ⚡ By Shinobu
 * ─────────────────────────
 */

"use strict";

import axios from "axios";

const API_BASE = "https://api.nexray.eu.cc/games/siapakahaku";
const REQUEST_TIMEOUT_MS = 15000;

if (!global.siapaAkuGame) global.siapaAkuGame = {};
if (!global.siapaAkuScore) global.siapaAkuScore = {};

async function getSoal() {
  let res;
  try {
    res = await axios.get(API_BASE, {
      timeout: REQUEST_TIMEOUT_MS,
      validateStatus: () => true,
    });
  } catch (err) {
    if (err.code === "ECONNABORTED") throw new Error("⏰ Timeout! Server terlalu lama.");
    throw new Error(`🌐 Gagal menghubungi server: ${err.message}`);
  }

  if (res.status !== 200 || !res.data?.status || !res.data?.result) {
    throw new Error("❌ Gagal mendapatkan soal!");
  }

  return {
    soal: res.data.result.soal || "Soal tidak tersedia",
    jawaban: res.data.result.jawaban || "",
    index: res.data.result.index || 0
  };
}

function buildMenuText(prefix) {
  return (
    `╭══════════════════════════════╮\n` +
    `│                              │\n` +
    `│   🤔  *SIAPAKAH AKU?*  🤔  │\n` +
    `│   ──────────────────────    │\n` +
    `│   Game Tebak Kata           │\n` +
    `│   dari Clue "Aku adalah..." │\n` +
    `│   Shinobu MD v1.2 📦        │\n` +
    `│                              │\n` +
    `╰══════════════════════════════╯\n\n` +
    `  📌 *Deskripsi:*\n` +
    `  › Bot kasih clue "Aku adalah"\n` +
    `  › Tebak aku siapa/benda apa\n` +
    `  › Jawab dengan 1-2 kata\n\n` +
    `╭──────────────────────────────╮\n` +
    `  📋 *CARA BERMAIN:*\n` +
    `╰──────────────────────────────╯\n\n` +
    `  ① *${prefix}siapakahaku*\n` +
    `     → Mulai game & lihat soal\n\n` +
    `  ② *${prefix}siapakahaku <jawaban>*\n` +
    `     → Jawab soal\n\n` +
    `  ③ *${prefix}nyerahsiapa*\n` +
    `     → Menyerah & lihat jawaban\n\n` +
    `  ④ *${prefix}siaskor*\n` +
    `     → Cek skor kamu\n\n` +
    `╭──────────────────────────────╮\n` +
    `  💡 *CONTOH:*\n` +
    `╰──────────────────────────────╯\n\n` +
    `  ${prefix}siapakahaku\n` +
    `  ${prefix}siapakahaku durian\n` +
    `  ${prefix}nyerahsiapa\n` +
    `  ${prefix}siaskor\n\n` +
    `╭──────────────────────────────╮\n` +
    `  🎯 *RULES:*\n` +
    `╰──────────────────────────────╯\n\n` +
    `  ✅ Bener  : +10 EXP\n` +
    `  ❌ Salah  : -5 EXP\n` +
    `  ⏰ Timeout: 2 menit\n` +
    `  💡 Hint   : Jumlah huruf\n\n` +
    `  ⚡ *Shinobu MD v1.2*  |  🤔 *Siapa Aku*`
  );
}

// ===== HANDLER UTAMA =====
let handler = async (m, { text, command, sock }) => {
  const prefix = global.prefix || ".";

  // ===== 1. .siapakahaku (tanpa teks) = MULAI GAME =====
  if ((command === "siapakahaku" || command === "siapa") && (!text || !text.trim())) {
    // Cek apakah ada game aktif
    if (global.siapaAkuGame[m.sender]) {
      const game = global.siapaAkuGame[m.sender];
      
      if (Date.now() - game.startTime > 120000) {
        delete global.siapaAkuGame[m.sender];
      } else {
        return sock.sendMessage(m.chat, {
          text:
            `╭──────────────────────────────╮\n` +
            `  ⚠️  *GAME MASIH AKTIF!*\n` +
            `╰──────────────────────────────╯\n\n` +
            `  📝 *Soal:*\n` +
            `  ❝ ${game.soal} ❞\n\n` +
            `  💡 *Hint:* ${game.jawaban.length} huruf\n` +
            `  🔤 Awalan: *${game.jawaban[0].toUpperCase()}...*\n\n` +
            `  ✍️  *${prefix}siapakahaku <jawaban>*\n` +
            `  🏳️  *${prefix}nyerahsiapa* menyerah\n\n` +
            `  ⚡ *Shinobu MD v1.2*`
        }, { quoted: m.verifiedQuoted });
      }
    }

    // Mulai game baru
    await sock.sendMessage(m.chat, { react: { text: "🤔", key: m.key } });

    try {
      const data = await getSoal();

      global.siapaAkuGame[m.sender] = {
        soal: data.soal,
        jawaban: data.jawaban,
        index: data.index,
        startTime: Date.now()
      };

      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  🤔  *SIAPAKAH AKU?*  🤔\n` +
          `╰──────────────────────────────╯\n\n` +
          `  📝 *Soal #${data.index}:*\n` +
          `  ❝ ${data.soal} ❞\n\n` +
          `  💡 *Hint:*\n` +
          `  › ${data.jawaban.length} huruf\n` +
          `  › Awalan: *${data.jawaban[0].toUpperCase()}...*\n\n` +
          `  ✍️  *${prefix}siapakahaku <jawaban>*\n` +
          `  🏳️  *${prefix}nyerahsiapa* menyerah\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });

    } catch (err) {
      console.error("[SIAPAKAH AKU ERROR]", err);
      await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  ❌  *GAGAL!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  📡 ${err.message}\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }
  }

  // ===== 2. .siapakahaku <jawaban> = JAWAB =====
  if (text && text.trim() && (command === "siapakahaku" || command === "siapa")) {
    if (!global.siapaAkuGame[m.sender]) {
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  ⚠️  *BELUM ADA GAME!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  Ketik *${prefix}siapakahaku* dulu\n` +
          `  untuk mulai bermain!\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }

    const game = global.siapaAkuGame[m.sender];
    const jawabanUser = text.trim().toLowerCase();
    const jawabanBenar = game.jawaban.toLowerCase();

    if (Date.now() - game.startTime > 120000) {
      delete global.siapaAkuGame[m.sender];
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  ⏰  *WAKTU HABIS!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  📝 ${game.soal}\n` +
          `  ✅ *${game.jawaban}*\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }

    const isExact = jawabanUser === jawabanBenar;
    const isContained = jawabanBenar.includes(jawabanUser) && jawabanUser.length > 2;

    if (isExact || isContained) {
      // BENAR
      if (!global.siapaAkuScore[m.sender]) {
        global.siapaAkuScore[m.sender] = { total: 0, benar: 0, salah: 0 };
      }
      global.siapaAkuScore[m.sender].total += 10;
      global.siapaAkuScore[m.sender].benar += 1;
      delete global.siapaAkuGame[m.sender];

      await sock.sendMessage(m.chat, { react: { text: "🎉", key: m.key } });

      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  🎉  *BENAR!*  🎉\n` +
          `╰──────────────────────────────╯\n\n` +
          `  📝 ${game.soal}\n` +
          `  ✅ *${game.jawaban}*\n` +
          `  ⭐ +10 EXP\n\n` +
          `  🏆 Skor : ${global.siapaAkuScore[m.sender].total}\n\n` +
          `  Ketik *${prefix}siapakahaku* main lagi!\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });

    } else {
      // SALAH
      if (!global.siapaAkuScore[m.sender]) {
        global.siapaAkuScore[m.sender] = { total: 0, benar: 0, salah: 0 };
      }
      global.siapaAkuScore[m.sender].total -= 5;
      global.siapaAkuScore[m.sender].salah += 1;
      delete global.siapaAkuGame[m.sender];

      await sock.sendMessage(m.chat, { react: { text: "💔", key: m.key } });

      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  💔  *SALAH!*  💔\n` +
          `╰──────────────────────────────╯\n\n` +
          `  📝 ${game.soal}\n` +
          `  ✅ *${game.jawaban}*\n` +
          `  ❌ ${jawabanUser}\n` +
          `  💔 -5 EXP\n\n` +
          `  Ketik *${prefix}siapakahaku* coba lagi!\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }
  }

  // ===== 3. .nyerahsiapa = MENYERAH =====
  if (command === "nyerahsiapa") {
    if (!global.siapaAkuGame[m.sender]) {
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  ⚠️  *TIDAK ADA GAME!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  Ketik *${prefix}siapakahaku* dulu\n` +
          `  untuk mulai bermain!\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }

    const game = global.siapaAkuGame[m.sender];
    delete global.siapaAkuGame[m.sender];

    return sock.sendMessage(m.chat, {
      text:
        `╭──────────────────────────────╮\n` +
        `  🏳️  *MENYERAH!*  🏳️\n` +
        `╰──────────────────────────────╯\n\n` +
        `  📝 ${game.soal}\n` +
        `  ✅ *${game.jawaban}*\n\n` +
        `  Jangan nyerah terus! 😂\n` +
        `  Ketik *${prefix}siapakahaku*\n` +
        `  untuk main lagi!\n\n` +
        `  ⚡ *Shinobu MD v1.2*`
    }, { quoted: m.verifiedQuoted });
  }

  // ===== 4. .siaskor = CEK SKOR =====
  if (command === "siaskor") {
    const score = global.siapaAkuScore?.[m.sender];
    
    if (!score) {
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  🏆  *SKOR SIAPAKAH AKU*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  Kamu belum pernah main!\n` +
          `  Ketik *${prefix}siapakahaku*\n` +
          `  untuk mulai bermain.\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }

    const total = score.benar + score.salah;
    const akurasi = total > 0 ? Math.round((score.benar / total) * 100) : 0;

    return sock.sendMessage(m.chat, {
      text:
        `╭──────────────────────────────╮\n` +
        `  🏆  *STATISTIK KAMU*\n` +
        `╰──────────────────────────────╯\n\n` +
        `  ⭐ Skor    : ${score.total}\n` +
        `  ✅ Benar   : ${score.benar}\n` +
        `  ❌ Salah   : ${score.salah}\n` +
        `  📊 Akurasi : ${akurasi}%\n` +
        `  🎯 Total   : ${total} soal\n\n` +
        `  ⚡ *Shinobu MD v1.2*`
    }, { quoted: m.verifiedQuoted });
  }

  // ===== TAMPILKAN MENU (fallback) =====
  return sock.sendMessage(m.chat, {
    text: buildMenuText(prefix)
  }, { quoted: m.verifiedQuoted });
};

handler.command = ["siapakahaku", "siapa", "nyerahsiapa", "siaskor"];
handler.tags = ["game"];
handler.help = ["siapakahaku"];
handler.limit = true;

export default handler;