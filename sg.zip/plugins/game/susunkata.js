// plugins/game/susunkata.js — Susun kata game (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Susun Kata
 * 🔧 Fungsi     : Game susun kata acak
 * ⚡ By Shinobu
 * ─────────────────────────
 */

import axios from "axios";

global.susunkata = global.susunkata || {};

let handler = async (m, { sock, usedPrefix, command }) => {
  const id = m.chat;
  
  if (global.susunkata[id]) {
    return m.reply(`❌ Masih ada game! Ketik *${usedPrefix}nyerah* untuk menyerah`);
  }

  try {
    await m.reply("⏳ *Loading Game...*");

    const response = await axios.get(
      "https://api.betabotz.eu.org/api/game/susunkata",
      { timeout: 15000 }
    );

    const data = response.data.result;
    const { soal, jawaban, tipe } = data;

    global.susunkata[id] = {
      jawaban: jawaban.toLowerCase(),
      timeout: setTimeout(() => {
        if (global.susunkata[id]) {
          sock.sendMessage(id, {
            text: `⏰ *Waktu Habis!*\n\nJawaban: *${jawaban}*`
          });
          delete global.susunkata[id];
        }
      }, 60000)
    };

    await m.reply(
      `🔤 *SUSUN KATA*\n\n` +
      `📝 Kata Acak: ${soal}\n` +
      `📚 Tipe: ${tipe}\n\n` +
      `⏰ Waktu: 60 detik\n` +
      `💡 Susun kata yang benar!`
    );

  } catch (e) {
    console.error(e);
    await m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["susunkata"];
handler.tags = ["game"];
handler.command = /^(susunkata|susunan)$/i;
handler.limit = true;

export default handler;
