// plugins/game/nyerah.js — Menyerah dari game (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Nyerah
 * 🔧 Fungsi     : Menyerah dari game yang sedang berjalan
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m) => {
  const id = m.chat;
  
  const games = [
    "tebakgambar",
    "tebaklirik",
    "tebakkata",
    "susunkata",
    "caklontong",
    "tebakkabupaten"
  ];

  let found = false;

  for (const game of games) {
    if (global[game] && global[game][id]) {
      const gameData = global[game][id];
      const jawaban = gameData.jawaban;
      
      clearTimeout(gameData.timeout);
      delete global[game][id];
      
      await m.reply(
        `🏳️ *Nyerah*\n\n` +
        `Kamu menyerah!\n` +
        `Jawaban yang benar: *${jawaban}*\n\n` +
        `_Better luck next time!_`
      );
      
      found = true;
      break;
    }
  }

  if (!found) {
    await m.reply("❌ Tidak ada game yang sedang berjalan!");
  }
};

handler.help = ["nyerah"];
handler.tags = ["game"];
handler.command = /^(nyerah|surrender)$/i;
handler.limit = false;

export default handler;
