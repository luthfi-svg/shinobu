// plugins/game/tebak-hewan.js — Tebak Hewan (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Tebak Hewan
 * 🔧 Fungsi     : Tebak nama hewan
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m, { text, usedPrefix, command }) => {
  const questions = [
    { q: "Pertanyaan 1", a: "Jawaban 1" },
    { q: "Pertanyaan 2", a: "Jawaban 2" },
    { q: "Pertanyaan 3", a: "Jawaban 3" },
  ];
  
  const random = questions[Math.floor(Math.random() * questions.length)];
  
  await m.reply(
    `🎮 *Tebak Hewan*\n\n` +
    `❓ ${random.q}\n\n` +
    `⏰ Waktu: 60 detik\n` +
    `💡 Ketik jawaban untuk menjawab\n\n` +
    `🎯 SHINOBU MD v1.2`
  );
  
  // Store game session
  global.db.data.game = global.db.data.game || {};
  global.db.data.game[m.chat] = {
    question: random.q,
    answer: random.a,
    command: command
  };
};

handler.help = ["tebakhewan", "guesanimal"];
handler.tags = ['game'];
handler.command = /^(tebakhewan|guesanimal)$/i;

export default handler;
