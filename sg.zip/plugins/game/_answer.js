// plugins/game/_answer.js — Game answer handler (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Game Answer Handler
 * 🔧 Fungsi     : Handle jawaban untuk semua game
 * ⚡ By Shinobu
 * ─────────────────────────
 */

let handler = async (m) => {
  return true;
};

handler.before = async function (m, { sock }) {
  const id = m.chat;
  const text = m.text?.toLowerCase() || "";

  // Check all active games
  const games = [
    "tebakgambar",
    "tebaklirik",
    "tebakkata",
    "susunkata",
    "caklontong",
    "tebakkabupaten"
  ];

  for (const game of games) {
    if (global[game] && global[game][id]) {
      const gameData = global[game][id];
      
      if (text === gameData.jawaban) {
        // Correct answer
        clearTimeout(gameData.timeout);
        delete global[game][id];
        
        await sock.sendMessage(
          id,
          {
            text: `✅ *Jawaban Benar!*\n\n🎉 Selamat! Kamu berhasil!\n\n_Game selesai_`
          },
          { quoted: m }
        );
        
        await m.react("🎉");
        return true;
      }
    }
  }

  return true;
};

export default handler;
