// plugins/game/benarsalah.js — Benar atau Salah Game (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Benar atau Salah Game
 * 🔗 API        : SynoxCloud API
 * 🎮 Genre      : Quiz / Trivia
 * ✅ Fun        : Tebak pernyataan benar/salah
 * 📦 Version    : 1.2
 * ⚡ By Shinobu
 * ─────────────────────────
 */

"use strict";

import axios from "axios";

const API_BASE = "https://api.synoxcloud.xyz/games/benaratausalah";
const REQUEST_TIMEOUT_MS = 15000;

if (!global.benarSalahGame) global.benarSalahGame = {};
if (!global.benarSalahScore) global.benarSalahScore = {};

async function getSoal() {
  let res;
  try {
    res = await axios.get(API_BASE, {
      timeout: REQUEST_TIMEOUT_MS,
      validateStatus: () => true,
    });
  } catch (err) {
    if (err.code === "ECONNABORTED") throw new Error("⏰ Timeout! Server terlalu lama.");
    throw new Error(`🌐 Gagal menghubungi server: ${err.message}`);
  }

  if (res.status !== 200 || !res.data?.status || !res.data?.result) {
    throw new Error("❌ Gagal mendapatkan soal!");
  }

  return {
    question: res.data.result.question || "Soal tidak tersedia",
    answer: res.data.result.answer || "",
    index: res.data.result.index || 0
  };
}

let handler = async (m, { text, command, sock }) => {
  const prefix = global.prefix || ".";

  // ===== 1. .benarsalah (TANPA TEKS) = MULAI GAME =====
  if ((command === "benarsalah" || command === "bs") && (!text || !text.trim())) {
    if (global.benarSalahGame[m.sender]) {
      const game = global.benarSalahGame[m.sender];
      
      if (Date.now() - game.startTime > 120000) {
        delete global.benarSalahGame[m.sender];
      } else {
        return sock.sendMessage(m.chat, {
          text:
            `╭──────────────────────────────╮\n` +
            `  ⚠️  *GAME MASIH AKTIF!*\n` +
            `╰──────────────────────────────╯\n\n` +
            `  📝 *Pernyataan:*\n` +
            `  ❝ ${game.question} ❞\n\n` +
            `  ✍️  Jawab *benar* atau *salah*!\n` +
            `  🏳️  *${prefix}nyerahbs* menyerah\n\n` +
            `  ⚡ *Shinobu MD v1.2*`
        }, { quoted: m.verifiedQuoted });
      }
    }

    await sock.sendMessage(m.chat, { react: { text: "🎯", key: m.key } });

    try {
      const data = await getSoal();

      global.benarSalahGame[m.sender] = {
        question: data.question,
        answer: data.answer,
        index: data.index,
        startTime: Date.now()
      };

      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  🎯  *BENAR ATAU SALAH*  🎯\n` +
          `╰──────────────────────────────╯\n\n` +
          `  📝 *Soal #${data.index}:*\n` +
          `  ❝ ${data.question} ❞\n\n` +
          `  🎯 *Jawab:*\n` +
          `  ✅ *${prefix}benarsalah benar*\n` +
          `  ❌ *${prefix}benarsalah salah*\n\n` +
          `  🏳️  *${prefix}nyerahbs* menyerah\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });

    } catch (err) {
      console.error("[BENAR SALAH ERROR]", err);
      await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  ❌  *GAGAL!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  📡 ${err.message}\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }
  }

  // ===== 2. .benarsalah <benar/salah> = JAWAB =====
  if (text && text.trim() && (command === "benarsalah" || command === "bs")) {
    const jawabanUser = text.trim().toLowerCase();

    // Validasi jawaban
    if (jawabanUser !== "benar" && jawabanUser !== "salah") {
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  ⚠️  *JAWABAN INVALID!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  Hanya bisa jawab:\n` +
          `  ✅ *benar*\n` +
          `  ❌ *salah*\n\n` +
          `  Contoh: *${prefix}benarsalah benar*\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }

    if (!global.benarSalahGame[m.sender]) {
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  ⚠️  *BELUM ADA GAME!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  Ketik *${prefix}benarsalah* dulu!\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }

    const game = global.benarSalahGame[m.sender];

    if (Date.now() - game.startTime > 120000) {
      delete global.benarSalahGame[m.sender];
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  ⏰  *WAKTU HABIS!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  📝 ${game.question}\n` +
          `  ✅ *${game.answer.toUpperCase()}*\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }

    // Cek jawaban
    if (jawabanUser === game.answer.toLowerCase()) {
      // BENAR
      if (!global.benarSalahScore[m.sender]) {
        global.benarSalahScore[m.sender] = { total: 0, benar: 0, salah: 0 };
      }
      global.benarSalahScore[m.sender].total += 10;
      global.benarSalahScore[m.sender].benar += 1;
      delete global.benarSalahGame[m.sender];

      await sock.sendMessage(m.chat, { react: { text: "🎉", key: m.key } });

      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  🎉  *BENAR!*  🎉\n` +
          `╰──────────────────────────────╯\n\n` +
          `  📝 ${game.question}\n` +
          `  ✅ *${game.answer.toUpperCase()}*\n` +
          `  ⭐ +10 EXP\n\n` +
          `  🏆 Skor : ${global.benarSalahScore[m.sender].total}\n\n` +
          `  Ketik *${prefix}benarsalah* main lagi!\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });

    } else {
      // SALAH
      if (!global.benarSalahScore[m.sender]) {
        global.benarSalahScore[m.sender] = { total: 0, benar: 0, salah: 0 };
      }
      global.benarSalahScore[m.sender].total -= 5;
      global.benarSalahScore[m.sender].salah += 1;
      delete global.benarSalahGame[m.sender];

      await sock.sendMessage(m.chat, { react: { text: "💔", key: m.key } });

      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  💔  *SALAH!*  💔\n` +
          `╰──────────────────────────────╯\n\n` +
          `  📝 ${game.question}\n` +
          `  ✅ *${game.answer.toUpperCase()}*\n` +
          `  ❌ ${jawabanUser.toUpperCase()}\n` +
          `  💔 -5 EXP\n\n` +
          `  Ketik *${prefix}benarsalah* coba lagi!\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }
  }

  // ===== 3. .nyerahbs = MENYERAH =====
  if (command === "nyerahbs") {
    if (!global.benarSalahGame[m.sender]) {
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  ⚠️  *TIDAK ADA GAME!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  Ketik *${prefix}benarsalah* dulu!\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }

    const game = global.benarSalahGame[m.sender];
    delete global.benarSalahGame[m.sender];

    return sock.sendMessage(m.chat, {
      text:
        `╭──────────────────────────────╮\n` +
        `  🏳️  *MENYERAH!*  🏳️\n` +
        `╰──────────────────────────────╯\n\n` +
        `  📝 ${game.question}\n` +
        `  ✅ *${game.answer.toUpperCase()}*\n\n` +
        `  Ketik *${prefix}benarsalah* main lagi!\n\n` +
        `  ⚡ *Shinobu MD v1.2*`
    }, { quoted: m.verifiedQuoted });
  }

  // ===== 4. .bsscore = CEK SKOR =====
  if (command === "bsscore") {
    const score = global.benarSalahScore?.[m.sender];
    
    if (!score) {
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  🏆  *SKOR BENAR SALAH*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  Kamu belum pernah main!\n` +
          `  Ketik *${prefix}benarsalah*\n` +
          `  untuk mulai.\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }

    const total = score.benar + score.salah;
    const akurasi = total > 0 ? Math.round((score.benar / total) * 100) : 0;

    return sock.sendMessage(m.chat, {
      text:
        `╭──────────────────────────────╮\n` +
        `  🏆  *STATISTIK KAMU*\n` +
        `╰──────────────────────────────╯\n\n` +
        `  ⭐ Skor    : ${score.total}\n` +
        `  ✅ Benar   : ${score.benar}\n` +
        `  ❌ Salah   : ${score.salah}\n` +
        `  📊 Akurasi : ${akurasi}%\n` +
        `  🎯 Total   : ${total} soal\n\n` +
        `  ⚡ *Shinobu MD v1.2*`
    }, { quoted: m.verifiedQuoted });
  }
};

handler.command = ["benarsalah", "bs", "nyerahbs", "bsscore"];
handler.tags = ["game"];
handler.help = ["benarsalah"];
handler.limit = true;

export default handler;