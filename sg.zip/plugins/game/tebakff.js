// plugins/game/tebakkarakterff.js — Tebak Karakter FF (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Tebak Karakter FF
 * 🔗 API        : SynoxCloud API
 * 🎮 Genre      : Quiz / Game
 * 🔫 Game       : Free Fire
 * 📦 Version    : 1.2
 * ⚡ By Shinobu
 * ─────────────────────────
 */

"use strict";

import axios from "axios";

const API_BASE = "https://api.synoxcloud.xyz/games/tebakkarakterff";
const REQUEST_TIMEOUT_MS = 15000;

if (!global.tebakFFGame) global.tebakFFGame = {};
if (!global.tebakFFScore) global.tebakFFScore = {};

async function getSoal() {
  let res;
  try {
    res = await axios.get(API_BASE, {
      timeout: REQUEST_TIMEOUT_MS,
      validateStatus: () => true,
    });
  } catch (err) {
    if (err.code === "ECONNABORTED") throw new Error("⏰ Timeout! Server terlalu lama.");
    throw new Error(`🌐 Gagal menghubungi server: ${err.message}`);
  }

  if (res.status !== 200 || !res.data?.status || !res.data?.data) {
    throw new Error("❌ Gagal mendapatkan soal!");
  }

  return {
    name: res.data.data.name || "Unknown",
    gambar: res.data.data.gambar || "",
    index: res.data.data.index || 0
  };
}

let handler = async (m, { text, command, sock }) => {
  const prefix = global.prefix || ".";

  // ===== 1. .tebakff (TANPA TEKS) = MULAI GAME =====
  if ((command === "tebakff" || command === "tebakkarakterff") && (!text || !text.trim())) {
    if (global.tebakFFGame[m.sender]) {
      const game = global.tebakFFGame[m.sender];
      
      if (Date.now() - game.startTime > 120000) {
        delete global.tebakFFGame[m.sender];
      } else {
        return sock.sendMessage(m.chat, {
          text:
            `╭──────────────────────────────╮\n` +
            `  ⚠️  *GAME MASIH AKTIF!*\n` +
            `╰──────────────────────────────╯\n\n` +
            `  🔫 Tebak karakter FF-nya!\n\n` +
            `  💡 *Hint:* ${game.name.length} huruf\n` +
            `  🔤 Awalan: *${game.name[0].toUpperCase()}...*\n\n` +
            `  ✍️  *${prefix}tebakff <jawaban>*\n` +
            `  🏳️  *${prefix}nyerahff* menyerah\n\n` +
            `  ⚡ *Shinobu MD v1.2*`
        }, { quoted: m.verifiedQuoted });
      }
    }

    await sock.sendMessage(m.chat, { react: { text: "🔫", key: m.key } });

    try {
      const data = await getSoal();

      global.tebakFFGame[m.sender] = {
        name: data.name,
        gambar: data.gambar,
        index: data.index,
        startTime: Date.now()
      };

      let caption =
        `╭──────────────────────────────╮\n` +
        `  🔫  *TEBAK KARAKTER FF*  🔫\n` +
        `╰──────────────────────────────╯\n\n` +
        `  📸 Tebak nama karakter di atas!\n\n` +
        `  💡 *Hint:*\n` +
        `  › ${data.name.length} huruf\n` +
        `  › Awalan: *${data.name[0].toUpperCase()}...*\n\n` +
        `  ✍️  *${prefix}tebakff <jawaban>*\n` +
        `  🏳️  *${prefix}nyerahff* menyerah\n\n` +
        `  ⚡ *Shinobu MD v1.2*`;

      if (data.gambar) {
        try {
          const imgRes = await axios.get(data.gambar, {
            responseType: "arraybuffer",
            timeout: 10000
          });

          return sock.sendMessage(m.chat, {
            image: Buffer.from(imgRes.data),
            caption: caption
          }, { quoted: m.verifiedQuoted });
        } catch (imgErr) {}
      }

      return sock.sendMessage(m.chat, { text: caption }, { quoted: m.verifiedQuoted });

    } catch (err) {
      console.error("[TEBAK FF ERROR]", err);
      await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  ❌  *GAGAL!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  📡 ${err.message}\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }
  }

  // ===== 2. .tebakff <jawaban> = JAWAB =====
  if (text && text.trim() && (command === "tebakff" || command === "tebakkarakterff")) {
    if (!global.tebakFFGame[m.sender]) {
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  ⚠️  *BELUM ADA GAME!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  Ketik *${prefix}tebakff* dulu!\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }

    const game = global.tebakFFGame[m.sender];
    const jawabanUser = text.trim().toLowerCase();
    const jawabanBenar = game.name.toLowerCase();

    if (Date.now() - game.startTime > 120000) {
      delete global.tebakFFGame[m.sender];
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  ⏰  *WAKTU HABIS!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  🔫 *${game.name}*\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }

    const isExact = jawabanUser === jawabanBenar;
    const isContained = jawabanBenar.includes(jawabanUser) && jawabanUser.length > 2;

    if (isExact || isContained) {
      // BENAR
      if (!global.tebakFFScore[m.sender]) {
        global.tebakFFScore[m.sender] = { total: 0, benar: 0, salah: 0 };
      }
      global.tebakFFScore[m.sender].total += 15;
      global.tebakFFScore[m.sender].benar += 1;
      delete global.tebakFFGame[m.sender];

      await sock.sendMessage(m.chat, { react: { text: "🎉", key: m.key } });

      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  🎉  *BENAR!*  🎉\n` +
          `╰──────────────────────────────╯\n\n` +
          `  🔫 *${game.name}*\n` +
          `  ⭐ +15 EXP\n\n` +
          `  🏆 Skor : ${global.tebakFFScore[m.sender].total}\n\n` +
          `  Ketik *${prefix}tebakff* main lagi!\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });

    } else {
      // SALAH
      if (!global.tebakFFScore[m.sender]) {
        global.tebakFFScore[m.sender] = { total: 0, benar: 0, salah: 0 };
      }
      global.tebakFFScore[m.sender].total -= 5;
      global.tebakFFScore[m.sender].salah += 1;
      delete global.tebakFFGame[m.sender];

      await sock.sendMessage(m.chat, { react: { text: "💔", key: m.key } });

      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  💔  *SALAH!*  💔\n` +
          `╰──────────────────────────────╯\n\n` +
          `  🔫 *${game.name}*\n` +
          `  ❌ ${jawabanUser}\n` +
          `  💔 -5 EXP\n\n` +
          `  Ketik *${prefix}tebakff* coba lagi!\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }
  }

  // ===== 3. .nyerahff = MENYERAH =====
  if (command === "nyerahff") {
    if (!global.tebakFFGame[m.sender]) {
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  ⚠️  *TIDAK ADA GAME!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  Ketik *${prefix}tebakff* dulu!\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }

    const game = global.tebakFFGame[m.sender];
    delete global.tebakFFGame[m.sender];

    return sock.sendMessage(m.chat, {
      text:
        `╭──────────────────────────────╮\n` +
        `  🏳️  *MENYERAH!*  🏳️\n` +
        `╰──────────────────────────────╯\n\n` +
        `  🔫 *${game.name}*\n\n` +
        `  Ketik *${prefix}tebakff*\n` +
        `  untuk main lagi!\n\n` +
        `  ⚡ *Shinobu MD v1.2*`
    }, { quoted: m.verifiedQuoted });
  }

  // ===== 4. .ffskor = CEK SKOR =====
  if (command === "ffskor") {
    const score = global.tebakFFScore?.[m.sender];
    
    if (!score) {
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  🏆  *SKOR TEBAK FF*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  Kamu belum pernah main!\n` +
          `  Ketik *${prefix}tebakff*\n` +
          `  untuk mulai bermain.\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }

    const total = score.benar + score.salah;
    const akurasi = total > 0 ? Math.round((score.benar / total) * 100) : 0;

    return sock.sendMessage(m.chat, {
      text:
        `╭──────────────────────────────╮\n` +
        `  🏆  *STATISTIK KAMU*\n` +
        `╰──────────────────────────────╯\n\n` +
        `  ⭐ Skor    : ${score.total}\n` +
        `  ✅ Benar   : ${score.benar}\n` +
        `  ❌ Salah   : ${score.salah}\n` +
        `  📊 Akurasi : ${akurasi}%\n` +
        `  🎯 Total   : ${total} soal\n\n` +
        `  ⚡ *Shinobu MD v1.2*`
    }, { quoted: m.verifiedQuoted });
  }
};

handler.command = ["tebakff", "tebakkarakterff", "nyerahff", "ffskor"];
handler.tags = ["game"];
handler.help = ["tebakff"];
handler.limit = true;

export default handler;