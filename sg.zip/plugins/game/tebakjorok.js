// plugins/game/tebakjorok.js — Tebak Jorok Game (SHINOBU MD v1.2)
/**
 * ───「 SHINOBU MD v1.2 」───
 * 📝 Plugin     : Tebak Jorok Game
 * 🔗 API        : SynoxCloud API
 * 🎮 Genre      : Game Dewasa
 * 🔞 Warning    : 18+ ONLY!
 * 📦 Version    : 1.2
 * ⚡ By Shinobu
 * ─────────────────────────
 */

"use strict";

import axios from "axios";

const API_BASE = "https://api.synoxcloud.xyz/games/tebak-jorok";
const REQUEST_TIMEOUT_MS = 15000;

if (!global.tebakJorokGame) global.tebakJorokGame = {};
if (!global.tebakJorokScore) global.tebakJorokScore = {};

async function getSoal() {
  let res;
  try {
    res = await axios.get(API_BASE, {
      timeout: REQUEST_TIMEOUT_MS,
      validateStatus: () => true,
    });
  } catch (err) {
    if (err.code === "ECONNABORTED") throw new Error("⏰ Timeout! Server terlalu lama.");
    throw new Error(`🌐 Gagal menghubungi server: ${err.message}`);
  }

  if (res.status !== 200 || !res.data?.status || !res.data?.result) {
    throw new Error("❌ Gagal mendapatkan soal!");
  }

  return {
    soal: res.data.result.soal || "Soal tidak tersedia",
    jawaban: res.data.result.jawaban || "",
    index: res.data.result.index || 0
  };
}

let handler = async (m, { text, command, sock }) => {
  const prefix = global.prefix || ".";

  // ===== 1. .tebakjorok (TANPA TEKS) = MULAI GAME BARU =====
  if ((command === "tebakjorok" || command === "tjorok") && (!text || !text.trim())) {
    // Kalau ada game aktif, tampilkan soal lama
    if (global.tebakJorokGame[m.sender]) {
      const game = global.tebakJorokGame[m.sender];
      
      if (Date.now() - game.startTime > 120000) {
        delete global.tebakJorokGame[m.sender];
      } else {
        return sock.sendMessage(m.chat, {
          text:
            `╭──────────────────────────────╮\n` +
            `  ⚠️  *GAME MASIH AKTIF!*\n` +
            `╰──────────────────────────────╯\n\n` +
            `  📝 *Soal:*\n` +
            `  ❝ ${game.soal} ❞\n\n` +
            `  💡 *Hint:* ${game.jawaban.length} huruf\n` +
            `  🔤 Awalan: *${game.jawaban[0].toUpperCase()}...*\n\n` +
            `  ✍️  *${prefix}tebakjorok <jawaban>*\n` +
            `  🏳️  *${prefix}nyerahjorok* menyerah\n\n` +
            `  ⚡ *Shinobu MD v1.2*`
        }, { quoted: m.verifiedQuoted });
      }
    }

    // MULAI GAME BARU
    await sock.sendMessage(m.chat, { react: { text: "🔞", key: m.key } });

    try {
      const data = await getSoal();

      global.tebakJorokGame[m.sender] = {
        soal: data.soal,
        jawaban: data.jawaban,
        index: data.index,
        startTime: Date.now()
      };

      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  🔞  *TEBAK JOROK*  🔞\n` +
          `╰──────────────────────────────╯\n\n` +
          `  📝 *Soal #${data.index}:*\n` +
          `  ❝ ${data.soal} ❞\n\n` +
          `  💡 *Hint:*\n` +
          `  › ${data.jawaban.length} huruf\n` +
          `  › Awalan: *${data.jawaban[0].toUpperCase()}...*\n\n` +
          `  ✍️  *${prefix}tebakjorok <jawaban>*\n` +
          `  🏳️  *${prefix}nyerahjorok* menyerah\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });

    } catch (err) {
      console.error("[TEBAK JOROK ERROR]", err);
      await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  ❌  *GAGAL!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  📡 ${err.message}\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }
  }

  // ===== 2. .tebakjorok <jawaban> = JAWAB =====
  if (text && text.trim() && (command === "tebakjorok" || command === "tjorok")) {
    if (!global.tebakJorokGame[m.sender]) {
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  ⚠️  *BELUM ADA GAME!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  Ketik *${prefix}tebakjorok* dulu\n` +
          `  untuk mulai bermain!\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }

    const game = global.tebakJorokGame[m.sender];
    const jawabanUser = text.trim().toLowerCase();
    const jawabanBenar = game.jawaban.toLowerCase();

    if (Date.now() - game.startTime > 120000) {
      delete global.tebakJorokGame[m.sender];
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  ⏰  *WAKTU HABIS!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  📝 ${game.soal}\n` +
          `  ✅ *${game.jawaban}*\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }

    const isExact = jawabanUser === jawabanBenar;
    const isContained = jawabanBenar.includes(jawabanUser) && jawabanUser.length > 2;

    if (isExact || isContained) {
      // BENAR
      if (!global.tebakJorokScore[m.sender]) {
        global.tebakJorokScore[m.sender] = { total: 0, benar: 0, salah: 0 };
      }
      global.tebakJorokScore[m.sender].total += 10;
      global.tebakJorokScore[m.sender].benar += 1;
      delete global.tebakJorokGame[m.sender];

      await sock.sendMessage(m.chat, { react: { text: "🎉", key: m.key } });

      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  🎉  *BENAR!*  🎉\n` +
          `╰──────────────────────────────╯\n\n` +
          `  📝 ${game.soal}\n` +
          `  ✅ *${game.jawaban}*\n` +
          `  ⭐ +10 EXP\n\n` +
          `  🏆 Skor : ${global.tebakJorokScore[m.sender].total}\n\n` +
          `  Ketik *${prefix}tebakjorok* main lagi!\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });

    } else {
      // SALAH
      if (!global.tebakJorokScore[m.sender]) {
        global.tebakJorokScore[m.sender] = { total: 0, benar: 0, salah: 0 };
      }
      global.tebakJorokScore[m.sender].total -= 5;
      global.tebakJorokScore[m.sender].salah += 1;
      delete global.tebakJorokGame[m.sender];

      await sock.sendMessage(m.chat, { react: { text: "💔", key: m.key } });

      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  💔  *SALAH!*  💔\n` +
          `╰──────────────────────────────╯\n\n` +
          `  📝 ${game.soal}\n` +
          `  ✅ *${game.jawaban}*\n` +
          `  ❌ ${jawabanUser}\n` +
          `  💔 -5 EXP\n\n` +
          `  Ketik *${prefix}tebakjorok* coba lagi!\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }
  }

  // ===== 3. .nyerahjorok = MENYERAH =====
  if (command === "nyerahjorok") {
    if (!global.tebakJorokGame[m.sender]) {
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  ⚠️  *TIDAK ADA GAME!*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  Ketik *${prefix}tebakjorok* dulu\n` +
          `  untuk mulai bermain!\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }

    const game = global.tebakJorokGame[m.sender];
    delete global.tebakJorokGame[m.sender];

    return sock.sendMessage(m.chat, {
      text:
        `╭──────────────────────────────╮\n` +
        `  🏳️  *MENYERAH!*  🏳️\n` +
        `╰──────────────────────────────╯\n\n` +
        `  📝 ${game.soal}\n` +
        `  ✅ *${game.jawaban}*\n\n` +
        `  Ketik *${prefix}tebakjorok*\n` +
        `  untuk main lagi!\n\n` +
        `  ⚡ *Shinobu MD v1.2*`
    }, { quoted: m.verifiedQuoted });
  }

  // ===== 4. .jorokskor = CEK SKOR =====
  if (command === "jorokskor") {
    const score = global.tebakJorokScore?.[m.sender];
    
    if (!score) {
      return sock.sendMessage(m.chat, {
        text:
          `╭──────────────────────────────╮\n` +
          `  🏆  *SKOR TEBAK JOROK*\n` +
          `╰──────────────────────────────╯\n\n` +
          `  Kamu belum pernah main!\n` +
          `  Ketik *${prefix}tebakjorok*\n` +
          `  untuk mulai bermain.\n\n` +
          `  ⚡ *Shinobu MD v1.2*`
      }, { quoted: m.verifiedQuoted });
    }

    const total = score.benar + score.salah;
    const akurasi = total > 0 ? Math.round((score.benar / total) * 100) : 0;

    return sock.sendMessage(m.chat, {
      text:
        `╭──────────────────────────────╮\n` +
        `  🏆  *STATISTIK KAMU*\n` +
        `╰──────────────────────────────╯\n\n` +
        `  ⭐ Skor    : ${score.total}\n` +
        `  ✅ Benar   : ${score.benar}\n` +
        `  ❌ Salah   : ${score.salah}\n` +
        `  📊 Akurasi : ${akurasi}%\n` +
        `  🎯 Total   : ${total} soal\n\n` +
        `  ⚡ *Shinobu MD v1.2*`
    }, { quoted: m.verifiedQuoted });
  }

  // Fallback (seharusnya gak nyampe sini)
  return sock.sendMessage(m.chat, {
    text:
      `╭──────────────────────────────╮\n` +
      `  🔞  *TEBAK JOROK*\n` +
      `╰──────────────────────────────╯\n\n` +
      `  Ketik *${prefix}tebakjorok*\n` +
      `  untuk mulai game!\n\n` +
      `  ⚡ *Shinobu MD v1.2*`
  }, { quoted: m.verifiedQuoted });
};

handler.command = ["tebakjorok", "tjorok", "nyerahjorok", "jorokskor"];
handler.tags = ["game"];
handler.help = ["tebakjorok"];
handler.limit = true;

export default handler;