──────────────────────────────
# 🤖 Shinobu MD Information !!
──────────────────────────────
👨‍💻 Developer  : dekzymarket official 
📜 Script Asli  : Shinobu Multidevice 
🗓️ Dibuat       : 06 Juni 2026
🛍️ Rilis Resmi  : 08 Juni 2026

## ✨ Fitur Baru dari Shinobu MD V1.3

| Kategori | Fitur |
|---|---|
| 👥 **Grup** | AntiViewOnce, AntiDelete, AntiToxic, AntiDocument, AntiSticker, AntiMedia, AntiBot |
| 👥 **Grup** | Goodbye Message, Rules Grup, Grup Lock/Unlock, Grup Name, Grup Desc, Grup Link, Grup Revoke, Grup Info |
| 👤 **User** | Registrasi, Profil, Leaderboard (Top Koin, Top XP) |
| ⚡ **Sistem** | Energi/Limit Harian, Reset Scheduler, Premium Management |
| 📥 **Download** | Instagram, Facebook, YouTube (MP3/MP4/Search) |
| 🤖 **AI** | Gemini AI, Groq AI |
| 🛠️ **Tools** | Cuaca, Kalkulator, Translate, Jadwal Sholat, Generate OTP |
| 🎮 **Game** | Tebak Kata |
| 👑 **Owner** | Anti Call, Premium/Ban management, Donasi |

---

## 📦 Cara Install

```bash
git clone <repo> ShinobuMD-V1.3
cd ShinobuMD-V1
npm install
```
---

## 🚀 Jalankan Bot

```bash
node index.js
```

Saat pertama kali, bot akan meminta **Pairing Code**.  
Masukkan kode di WhatsApp → Perangkat Tertaut → Hubungkan Perangkat.

---

──────────────────────────────
# 📢 INFORMASI TAMBAHAN
──────────────────────────────
• Semua update resmi hanya diumumkan di ""Saluran""  
• Tidak ada update melalui WhatsApp atau platform lain  

──────────────────────────────
# 👑 INFO DEVELOPER & KONTAK RESMI
──────────────────────────────
📲 WhatsApp Resmi    : https://wa.me/6281927989701
📞 Telegram Utama     : https://t.me/dekzymarket
💬 Channel Testimoni   : https://t.me/dekzymarket1209
💚 Channel WhatsApp   : https://whatsapp.com/channel/0029VbBrvuIFSAtB1oL60Q3o  
📢 Channel Update      : https://whatsapp.com/channel/0029VbCgjWUFXUuRf0RRCW1h
📌 Channel YouTube     : https://youtube.com/@dekzymarket

👤 Developer Resmi © dekzymarket official 

> Made with ❤️ — Shinobu MD V1.3

# since 2026