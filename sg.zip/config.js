import fs from "fs";
import { fileURLToPath } from "url";
import { dirname } from "path";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// ═══════════════════════════════════════════
//  QueVaroU-v2.0 V2.0 — Config (ESM)
// ═══════════════════════════════════════════

// ── INFO BOT ──────────────────────────────
global.botname      = "QueVaroU-v2.0 V2.0"
global.versibot     = "1.3.0"
global.ownername    = "dekzymarket"         // Global Owner
global.owner        = "6281927989701"     // Ubah jadi no lu
global.pairingNumber = "6285805575583"  // Ubah jadi no bot lu

// ── LINK ──────────────────────────────────
global.linkChannel  = "https://whatsapp.com/channel/0029VbCgjWUFXUuRf0RRCW1h"
global.idChannel    = "120363427915199733@newsletter"
global.linkGrup     = "https://chat.whatsapp.com/HK56HeTkb9O0XalmSIi5Ne?s=cl&p=a&ilr=1"
global.thumbnail    = "https://athars.space/uploads/4ca49930.jpg"


// ── PREFIX & MODE ─────────────────────────
global.prefix       = "x"                        // prefix
global.mode         = "self"               // public / self

// ── STICKER ───────────────────────────────
global.packname     = "QueVaroU-v2.0 V2.0"
global.author       = "Owner"

// ── PAYMENT ───────────────────────────────
global.dana         = "082194398295"
global.ovo          = "0812xxxxxxxx"
global.gopay        = "082194398295"
global.qris          = "https://athars.space/uploads/80c7606b.jpg"                     // URL gambar QRIS

// ── PTERODACTYL PANEL ─────────────────────
global.domain       = "https://"                  // domain 
global.apikey       = "plta_"                     // ptla_
global.capikey      = "pltc"                     // ptlc_xxx
global.egg          = "15"
global.nestid       = "5"
global.loc          = "1"

// ── API KEYS ──────────────────────────────
global.groqApiKey   = ""    // https://console.groq.com
global.geminiApiKey = ""    // https://aistudio.google.com/apikey
global.cukiApiKey   = ""    // https://cuki.biz.id (untuk .caribug)

// ── FITUR OURIN: ENERGI/LIMIT ─────────────
global.energiDefault  = 50   // Limit default per hari
global.energiPremium  = 500  // Limit premium per hari
global.energiOwner    = -1   // -1 = unlimited

// ── FITUR OURIN: REGISTRASI ───────────────
global.registrasiEnabled = true   // true = user harus daftar dulu
global.registrasiReward  = { koin: 1000, energi: 100, exp: 1000 }

// ── FITUR OURIN: GROUP PROTECTION ─────────
global.pesan = {
  antilink       : "⚠ *Antilink* — @%user% mengirim link. Pesan dihapus.",
  antilinkKick   : "⚠ *Antilink* — @%user% di-kick karena mengirim link.",
  antitagsw      : "⚠ *AntiTagSW* — Tag status dari @%user% dihapus.",
  antitoxic      : "⚠ @%user% berkata kasar. Peringatan ke %warn% dari %max%.",
  antidocument   : "⚠ *AntiDokumen* — Dokumen dari @%user% dihapus.",
  antisticker    : "⚠ *AntiStiker* — Stiker dari @%user% dihapus.",
  antimedia      : "⚠ *AntiMedia* — Media dari @%user% dihapus.",
}

// ── FITUR OTOMATIS ────────────────────────
global.autoTyping    = false
global.antiCall      = false    // true = tolak panggilan masuk
global.blockIfCall   = false    // true = blokir yang telepon

// ── WELCOME / GOODBYE DEFAULT ─────────────
global.welcomeDefault = false
global.goodbyeDefault = false

// ── SCHEDULER RESET LIMIT ─────────────────
global.resetHour   = 0    // Jam reset limit (0 = tengah malam)
global.resetMinute = 0

// ── DATABASE ──────────────────────────────
global.dbPath = "./database"

// ── HOT RELOAD ────────────────────────────
const configFile = fileURLToPath(import.meta.url);
fs.watchFile(configFile, () => {
  fs.unwatchFile(configFile);
  console.log("Config updated, restart required for full effect");
});

export default global;
