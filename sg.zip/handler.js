// handler.js — Shinobu MD V1.3 (ESM) — Command Handler
//
// FIX NOTE:
// This file previously had no function wrapper and no `export default`,
// and no command-dispatch logic — it was just a leftover code fragment
// (the group/admin-check block) sitting at the top level of the module.
// Because index.js does `import handler from "./handler.js"`, that
// top-level code ran immediately on import and threw
// "ReferenceError: m is not defined" before the bot even tried to
// connect to WhatsApp. That's why the bot never responded (or even
// started). Restored the missing function wrapper, export, and the
// actual command parsing / plugin dispatch logic below.

export default async function handler(sock, m) {
  try {
    if (!m || !m.message) return;

    // ── Group metadata / admin check ─────────
    if (m.isGroup) {
      const normalizeJid = (jid = "") => {
        return String(jid)
          .trim()
          .replace(/:\d+(?=@)/, "")       // buang suffix device
          .replace(/@lid$/i, "@s.whatsapp.net");
      };

      const jidUser = (jid = "") => {
        const clean = normalizeJid(jid);
        return clean.split("@")[0].replace(/\D/g, "");
      };

      const sameUser = (a, b) => jidUser(a) && jidUser(a) === jidUser(b);
      const isAdminRole = (role) =>
        ["admin", "superadmin", true].includes(role);

      let meta = null;

      // Ambil metadata fresh dulu untuk cek permission
      try {
        meta = await sock.groupMetadata(m.chat);
      } catch (e) {
        // fallback ke cache kalau fetch gagal
        meta = global.groupMetadataCache?.get?.(m.chat) || null;
      }

      if (meta && global.groupMetadataCache?.set) {
        global.groupMetadataCache.set(m.chat, meta);
      }

      m.metadata = meta || {};
      const participants = Array.isArray(meta?.participants) ? meta.participants : [];

      const senderJid =
        m.sender ||
        m.participant ||
        m.key?.participant ||
        m.key?.remoteJid ||
        "";

      const botJid =
        m.botNumber ||
        sock?.user?.id ||
        sock?.user?.jid ||
        "";

      m.isAdmin = participants.some((p) => {
        const participantJid = p?.id || p?.jid || "";
        return sameUser(participantJid, senderJid) && isAdminRole(p?.admin);
      });

      m.isBotAdmin = participants.some((p) => {
        const participantJid = p?.id || p?.jid || "";
        return sameUser(participantJid, botJid) && isAdminRole(p?.admin);
      });
    }

    // ── Ban check ─────────────────────────
    const bannedList = global.db?.settings?.banned || [];
    if (!m.isOwner && bannedList.includes(m.sender)) return;

    // ── Ensure user exists in DB ──────────
    if (!global.db.users) global.db.users = {};
    if (!global.db.users[m.sender]) {
      global.db.users[m.sender] = {
        energi: global.energiDefault ?? 50,
        limit: global.energiDefault ?? 50,
        isPremium: false,
        registered: !global.registrasiEnabled,
      };
    }
    const user = global.db.users[m.sender];
    m.isPremium = !!user.isPremium;

    // ── Parse prefix / command / args ─────
    const body = m.body || "";
    const prefixCfg = global.prefix || ".";
    const prefixRegex =
      prefixCfg instanceof RegExp
        ? prefixCfg
        : new RegExp("^[" + String(prefixCfg).replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "]");

    const prefixMatch = body.match(prefixRegex);
    const usedPrefix = prefixMatch ? prefixMatch[0] : "";
    if (!usedPrefix) return; // pesan tanpa prefix diabaikan

    const noPrefix = body.slice(usedPrefix.length).trim();
    if (!noPrefix) return;

    const [rawCommand, ...args] = noPrefix.split(/\s+/);
    const command = (rawCommand || "").toLowerCase();
    if (!command) return;

    const text = args.join(" ");

    m.cmd = command;
    m.args = args;
    m.text = text;

    // ── Autotyping (optional) ─────────────
    if (global.autoTyping && typeof sock.sendPresenceUpdate === "function") {
      sock.sendPresenceUpdate("composing", m.chat).catch(() => {});
    }

    // ── Find matching plugin ──────────────
    let plugin = null;
    for (const name in global.plugins) {
      const p = global.plugins[name];
      if (!p || typeof p !== "function") continue;
      const cmds = p.command;
      if (!cmds) continue;

      if (cmds instanceof RegExp) {
        if (cmds.test(command)) { plugin = p; break; }
      } else if (Array.isArray(cmds)) {
        if (cmds.map((c) => String(c).toLowerCase()).includes(command)) { plugin = p; break; }
      } else if (typeof cmds === "string") {
        if (cmds.toLowerCase() === command) { plugin = p; break; }
      }
    }

    if (!plugin) return; // command tidak ditemukan, diamkan saja

    // ── Permission gates ───────────────────
    if (plugin.owner && !m.isOwner)
      return m.reply("🚫 Perintah ini khusus *Owner*!");
    if (plugin.group && !m.isGroup)
      return m.reply("🚫 Perintah ini hanya bisa digunakan di *Grup*!");
    if (plugin.admin && m.isGroup && !m.isAdmin)
      return m.reply("🚫 Perintah ini khusus *Admin Grup*!");
    if (plugin.botAdmin && m.isGroup && !m.isBotAdmin)
      return m.reply("🚫 Bot harus jadi *Admin* dulu untuk menjalankan perintah ini!");
    if (plugin.premium && !m.isPremium && !m.isOwner)
      return m.reply("🚫 Perintah ini khusus *Premium User*!");

    // ── Energi / limit ─────────────────────
    if (plugin.limit && !m.isOwner) {
      if ((user.energi ?? 0) <= 0) {
        return m.reply("⚡ Energi kamu habis! Tunggu reset harian atau upgrade ke Premium.");
      }
      user.energi = (user.energi ?? 0) - 1;
    }

    // ── Execute plugin ─────────────────────
    try {
      await plugin(m, {
        sock,
        conn: sock,
        text,
        args,
        command,
        usedPrefix,
        prefix: usedPrefix,
        isOwner: m.isOwner,
        isAdmin: m.isAdmin,
        isBotAdmin: m.isBotAdmin,
        isPremium: m.isPremium,
      });
    } catch (err) {
      console.error(`[Plugin Error] ${command}:`, err);
      m.reply(`❌ Terjadi error saat menjalankan perintah *${command}*:\n${err.message || err}`).catch(() => {});
    }
  } catch (err) {
    console.error("[Handler Error]", err);
  }
}
